<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '_public';
$progress = ['level'=>1, 'best'=>0, 'sound'=>true];
if ($email && $email !== '_public') {
  $file = __DIR__ . "/../../users/profiles/$email/candy.json";
  if (is_file($file)) {
    $j = json_decode(file_get_contents($file), true);
    if (is_array($j)) $progress = array_merge($progress, $j);
  }
}
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Candy — Match-3</title>
<style>
:root{
  --dms-bg:#0e1116; --dms-card:#151a22; --dms-text:#f2f4f8; --dms-muted:#c9ced8;
  --dms-border:#2a313d; --dms-shadow:rgba(0,0,0,.35);
  --primary-color:#8a7dff; --primary-dark:#5f55d1;
  --tile-glow:0 10px 28px rgba(0,0,0,.35);
  --c-red:#ff6b6b; --c-red-deep:#d34a4a;     
  --c-yellow:#ffd166; --c-yellow-deep:#e3b545; 
  --c-purple:#b084ff; --c-purple-deep:#7a5fd6; 
  --c-green:#66d39a; --c-green-deep:#3cab75;   
  --c-orange:#ffb26b; --c-orange-deep:#e08d46; 
  --c-pink:#f393e6; --c-pink-deep:#d16cc1; 
}
*{box-sizing:border-box}
html,body{height:100%}
body{margin:0;background:transparent;color:var(--dms-text);
  font-family:system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif}
.wrap{position:relative;width:100%;height:100%;padding:8px;display:flex}
.card{
  display:flex; flex-direction:column; width:100%; height:100%;
  background:linear-gradient(180deg, rgba(255,255,255,.03), rgba(0,0,0,.12));
  border:1px solid var(--dms-border); border-radius:16px; box-shadow:var(--tile-glow);
  overflow:hidden;
}
.header{
  display:grid; grid-template-columns:auto 1fr auto; gap:8px; align-items:center;
  padding:10px; border-bottom:1px solid var(--dms-border);
}
.title{font-weight:800; letter-spacing:.2px; padding:0 4px}
.title .big{font-size:clamp(16px,2.6vw,20px)}
.controls{display:flex; gap:6px; flex-wrap:wrap; justify-content:center}
.btn{
  border:1px solid var(--dms-border); border-radius:10px; padding:6px 10px; cursor:pointer;
  background:linear-gradient(180deg, rgba(255,255,255,.06), rgba(0,0,0,.18));
  color:var(--dms-text); font-weight:600; font-size:14px;
}
.btn:hover{filter:brightness(1.06)}
.btn.primary{border-color:var(--primary-dark); background:linear-gradient(180deg,var(--primary-color),var(--primary-dark)); color:#fff}
.iconbtn{width:36px;height:36px;display:flex;align-items:center;justify-content:center;font-size:18px}
.select{
  appearance:none; -webkit-appearance:none; -moz-appearance:none;
  border:1px solid var(--dms-border); border-radius:10px; padding:6px 30px 6px 10px;
  background:linear-gradient(180deg, rgba(255,255,255,.06), rgba(0,0,0,.18));
  color:var(--dms-text); font-weight:600; font-size:14px; cursor:pointer;
  position:relative;
}
.select-wrap{position:relative}
.select-wrap:after{
  content:"▾"; position:absolute; right:10px; top:50%; transform:translateY(-50%); pointer-events:none; color:var(--dms-muted);
}
.stats{display:flex;gap:8px;align-items:center;justify-content:flex-end;flex-wrap:wrap}
.badge{border:1px solid var(--dms-border);background:rgba(255,255,255,.05);border-radius:10px;padding:5px 8px;color:var(--dms-muted)}
.badge b{color:var(--dms-text)}
.starbar{display:flex; gap:5px}
.star{width:18px;height:18px;filter:grayscale(1) opacity(.5)}
.star.on{filter:none}
.main{display:flex; flex-direction:column; gap:8px; padding:10px; height:100%}
.objectives{
  display:flex; gap:8px; flex-wrap:wrap;
  border:1px solid var(--dms-border); background:rgba(255,255,255,.04);
  border-radius:12px; padding:8px; min-height:44px;
}
.obj{display:flex; align-items:center; gap:8px; border:1px solid var(--dms-border);
  background:rgba(255,255,255,.04); border-radius:10px; padding:6px 8px}
.obj .emoji{font-size:18px;line-height:1}
.obj .req{margin-left:auto; font-weight:700}
.board-wrap{position:relative; flex:1 1 auto; display:flex; align-items:center; justify-content:center; min-height:220px}
.board{
  aspect-ratio:1/1;
  display:grid; grid-template-columns:repeat(9,1fr); grid-template-rows:repeat(9,1fr);
  gap:6px; padding:8px; background:rgba(255,255,255,.03);
  border:1px solid var(--dms-border); border-radius:16px; touch-action:manipulation;
}
.tile{
  position:relative; border-radius:12px;
  background:linear-gradient(180deg, rgba(255,255,255,.05), rgba(0,0,0,.16));
  border:1px solid var(--dms-border); display:flex; align-items:center; justify-content:center;
  user-select:none; cursor:pointer; box-shadow:var(--tile-glow);
  transition:transform .08s ease, filter .12s ease, box-shadow .12s ease;
}
.tile:hover{filter:brightness(1.05)}
.tile.selected{outline:2px solid var(--primary-color); box-shadow:0 0 0 3px rgba(138,125,255,.22) inset; transform:scale(1.04)}
.candy{position:relative; width:82%; height:82%; display:flex; align-items:center; justify-content:center}
.fruit{font-size:clamp(18px,5.2vw,36px); line-height:1}
.ov{position:absolute; inset:auto; pointer-events:none}
.ov.stripeH{left:10%; right:10%; top:50%; height:18%; transform:translateY(-50%);
  background:repeating-linear-gradient(90deg, rgba(255,255,255,.9), rgba(255,255,255,.9) 6px, transparent 6px, transparent 12px);
  border-radius:6px}
.ov.stripeV{top:10%; bottom:10%; left:50%; width:18%; transform:translateX(-50%);
  background:repeating-linear-gradient(0deg, rgba(255,255,255,.9), rgba(255,255,255,.9) 6px, transparent 6px, transparent 12px);
  border-radius:6px}
.ov.wrap{
  width:86%; height:86%; border:2px solid rgba(255,255,255,.9); border-radius:10px;
  box-shadow:inset 0 0 0 4px rgba(255,255,255,.6);
}
.ov.color{
  width:32%; height:32%; right:6%; top:6%;
  background:rgba(255,255,255,.92); color:#000; font-weight:900; border-radius:50%;
  display:flex; align-items:center; justify-content:center; font-size:14px;
}
.modal-overlay{
  position:fixed; inset:0;
  display:none;               /* masqué par défaut */
  align-items:center; justify-content:center;
  background:rgba(0,0,0,.45);
  z-index:2147483647;         /* au-dessus de tout */
}
.modal-overlay.open{ display:flex; }  /* visible quand .open est posée */
@keyframes shake {0%,100%{transform:translateX(0)} 25%{transform:translateX(-3px)} 50%{transform:translateX(3px)} 75%{transform:translateX(-2px)}}
.shake{animation:shake .18s linear}
.fade{opacity:.35; transform:scale(.85); transition:opacity .15s, transform .15s}
</style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div class="header">
      <div class="title">
        <div class="big">FruitsX3+</div>
        <div class="starbar" id="starbar">
          <svg class="star" viewBox="0 0 24 24"><path fill="currentColor" d="M12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
          <svg class="star" viewBox="0 0 24 24"><path fill="currentColor" d="M12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
          <svg class="star" viewBox="0 0 24 24"><path fill="currentColor" d="M12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
        </div>
      </div>
      <div class="controls">
        <div class="select-wrap">
          <select id="styleSelect" class="select" title="Apparence des pièces">
            <option value="fruits">Fruits</option>
            <option value="boules">Boules</option>
            <option value="cubes">Cubes</option>
            <option value="croix">Croix</option>
          </select>
        </div>
        <button class="btn primary" id="btnNew">Nouvelle partie</button>
        <button class="btn" id="btnHint">Indice</button>
        <button class="btn" id="btnUndo">Annuler</button>
        <button class="btn" id="btnPause">Pause</button>
        <button class="btn" id="btnSound">Sons: <span id="soundState"><?php echo !empty($progress['sound'])?'ON':'OFF'; ?></span></button>
        <button class="btn iconbtn" id="btnHelp" type="button" title="Aide">📜</button>
      </div>
      <div class="stats">
        <div class="badge">Niveau : <b id="level"><?php echo (int)($progress['level']??1); ?></b></div>
        <div class="badge">Coups : <b id="moves">0</b></div>
        <div class="badge">Score : <b id="score">0</b></div>
        <div class="badge">Meilleur : <b id="best"><?php echo (int)($progress['best']??0); ?></b></div>
      </div>
    </div>
    <div class="main">
      <div class="objectives" id="objList"></div>
      <div class="board-wrap">
        <div class="board" id="board" aria-label="Grille de jeu"></div>
      </div>
    </div>
  </div>
</div>
<div class="modal-overlay" id="helpModal">
  <div class="modal">
    <header>
      <span>Aide</span>
      <button class="btn iconbtn" id="btnCloseHelp" title="Fermer">Fermer</button>
    </header>
    <div class="content">
      <h4>But du jeu</h4>
      Aligner au moins <b>3 pièces identiques</b> (ligne ou colonne). Les pièces alignées disparaissent, tout retombe et de nouvelles apparaissent.
      <h4>Coups & étoiles</h4>
      Chaque échange valide consomme 1 coup. En fin de niveau, tu gagnes <b>1 à 3 étoiles</b> selon les coups restants.
      <h4>Pièces spéciales (bombes)</h4>
      • <b>4 en ligne</b> → <b>rayé</b> (balaye sa ligne/colonne).<br>
      • <b>5 en ligne</b> → <b>bombe couleur</b> (supprime toutes les pièces de la même couleur/fruit).<br>
      • <b>Forme L/T</b> → <b>emballé</b> (explose en <b>3×3</b>).
      <h4>Contrôles</h4>
      Clique une case puis une <b>adjacente</b>. <b>Indice</b> coûte 1 coup. <b>Annuler</b> annule le dernier échange réussi. <b>Pause</b> fige le jeu. <b>Sons</b> ON/OFF.
    </div>
  </div>
</div>
<script>
const SIZE = 9;
const TYPES = [
  {id:'CH', emoji:'🍒', col:'var(--c-red)',    deep:'var(--c-red-deep)'},
  {id:'LE', emoji:'🍋', col:'var(--c-yellow)', deep:'var(--c-yellow-deep)'},
  {id:'GR', emoji:'🍇', col:'var(--c-purple)', deep:'var(--c-purple-deep)'},
  {id:'AP', emoji:'🍏', col:'var(--c-green)',  deep:'var(--c-green-deep)'},
  {id:'OR', emoji:'🍊', col:'var(--c-orange)', deep:'var(--c-orange-deep)'},
  {id:'ST', emoji:'🍓', col:'var(--c-pink)',   deep:'var(--c-pink-deep)'}
];
const KIND_NORMAL='N', KIND_STRIPE='S', KIND_WRAP='W', KIND_COLOR='C';
const LEVELS = [
  { moves: 28, goals: {CH:10, LE:10, GR:10} },
  { moves: 26, goals: {AP:12, OR:12, ST:12} },
  { moves: 26, goals: {CH:12, AP:12, GR:12} },
  { moves: 24, goals: {LE:15, OR:15, ST:10} },
  { moves: 24, goals: {CH:15, GR:15, AP:10} },
  { moves: 22, goals: {OR:18, ST:18} },
  { moves: 22, goals: {CH:18, LE:18} },
  { moves: 20, goals: {AP:20, GR:20} },
  { moves: 20, goals: {CH:20, OR:20, ST:20} },
  { moves: 18, goals: {CH:25, LE:25, GR:25, AP:25} },
];
const scoreEl = document.getElementById('score');
const movesEl = document.getElementById('moves');
const bestEl  = document.getElementById('best');
const levelEl = document.getElementById('level');
const boardEl = document.getElementById('board');
const objList = document.getElementById('objList');
const starbar = document.getElementById('starbar');
const btnNew   = document.getElementById('btnNew');
const btnHint  = document.getElementById('btnHint');
const btnUndo  = document.getElementById('btnUndo');
const btnPause = document.getElementById('btnPause');
const btnSound = document.getElementById('btnSound');
const soundState = document.getElementById('soundState');
const btnHelp  = document.getElementById('btnHelp');
const helpModal= document.getElementById('helpModal');
const btnCloseHelp = document.getElementById('btnCloseHelp');
const styleSelect = document.getElementById('styleSelect');
let GRID = [];
let score=0, moves=0, level=Number(levelEl.textContent)||1;
let busy=false, first=null, history=null;
let goals={}, progress={}, soundOn = (soundState.textContent==='ON');
let paused=false;
const STYLE_DEFAULT = localStorage.getItem('candyStyle') || 'fruits';
styleSelect.value = STYLE_DEFAULT;
let style = styleSelect.value;
styleSelect.addEventListener('change', ()=>{
  style = styleSelect.value;
  localStorage.setItem('candyStyle', style);
  renderObjectives();
  render();
});
function fitBoard(){
  const wrap = boardEl.parentElement;
  const w = wrap.clientWidth - 2, h = wrap.clientHeight - 2;
  const size = Math.max(200, Math.min(w, h)); // carré
  boardEl.style.width  = size + 'px';
  boardEl.style.height = size + 'px';
}
new ResizeObserver(fitBoard).observe(document.querySelector('.board-wrap'));
window.addEventListener('load', fitBoard);
window.addEventListener('resize', fitBoard);
const rand = (n)=> Math.floor(Math.random()*n);
const inBounds = (r,c)=> r>=0 && c>=0 && r<SIZE && c<SIZE;
const cloneGrid = (g)=> g.map(row=>row.map(cell=>({...cell})));
const typeOf = (id)=> TYPES.find(t=>t.id===id);
const uid = ()=> Math.random().toString(36).slice(2);
let actx=null; function beep(f=440, d=0.07, g=0.04){
  if(!soundOn) return;
  if(!actx){ try{ actx=new (window.AudioContext||window.webkitAudioContext)(); }catch(e){ return; } }
  const o=actx.createOscillator(), v=actx.createGain(); o.type='sine'; o.frequency.value=f; v.gain.value=g;
  o.connect(v); v.connect(actx.destination); o.start(); setTimeout(()=>{o.stop();o.disconnect();v.disconnect()}, d*1000);
}
function objectiveIconHTML(id){
  const t = typeOf(id);
  if (style==='fruits') return `<span class="emoji">${t.emoji}</span>`;
  if (style==='boules') return `
    <svg viewBox="0 0 100 100" style="width:20px;height:20px">
      <defs><radialGradient id="g-${id}" cx="50%" cy="35%"><stop offset="0%" stop-color="#fff" stop-opacity=".6"/><stop offset="35%" stop-color="${t.col}"/><stop offset="100%" stop-color="${t.deep}"/></radialGradient></defs>
      <circle cx="50" cy="50" r="36" fill="url(#g-${id})"/>
    </svg>`;
  if (style==='cubes') return `
    <svg viewBox="0 0 100 100" style="width:20px;height:20px">
      <defs><linearGradient id="q-${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="${t.col}"/><stop offset="100%" stop-color="${t.deep}"/></linearGradient></defs>
      <rect x="20" y="20" width="60" height="60" rx="12" fill="url(#q-${id})"/>
    </svg>`;
  // croix
  return `
    <svg viewBox="0 0 100 100" style="width:20px;height:20px">
      <defs><linearGradient id="x-${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="${t.col}"/><stop offset="100%" stop-color="${t.deep}"/></linearGradient></defs>
      <path d="M40 20 h20 v20 h20 v20 H60 v20 H40 V60 H20 V40 h20z" fill="url(#x-${id})" />
    </svg>`;
}
function candyHTML(cell){
  const t = typeOf(cell.color);
  let base = '';
  if (style==='fruits'){
    base = `<span class="fruit">${t.emoji}</span>`;
  } else if (style==='boules'){
    base = `<svg class="candy" viewBox="0 0 100 100">
      <defs><radialGradient id="${cell.id}-b" cx="50%" cy="35%"><stop offset="0%" stop-color="#fff" stop-opacity=".6"/><stop offset="35%" stop-color="${t.col}"/><stop offset="100%" stop-color="${t.deep}"/></radialGradient></defs>
      <circle cx="50" cy="50" r="36" fill="url(#${cell.id}-b)"/></svg>`;
  } else if (style==='cubes'){
    base = `<svg class="candy" viewBox="0 0 100 100">
      <defs><linearGradient id="${cell.id}-q" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="${t.col}"/><stop offset="100%" stop-color="${t.deep}"/></linearGradient></defs>
      <rect x="20" y="20" width="60" height="60" rx="14" fill="url(#${cell.id}-q)"/></svg>`;
  } else { // croix
    base = `<svg class="candy" viewBox="0 0 100 100">
      <defs><linearGradient id="${cell.id}-x" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="${t.col}"/><stop offset="100%" stop-color="${t.deep}"/></linearGradient></defs>
      <path d="M40 18 h20 v22 h22 v20 H60 v22 H40 V60 H18 V40 h22z" fill="url(#${cell.id}-x)"/></svg>`;
  }
  if (cell.kind===KIND_COLOR) return `<div class="candy">${base}<span class="ov color">★</span></div>`;
  if (cell.kind===KIND_WRAP)  return `<div class="candy">${base}<span class="ov wrap"></span></div>`;
  if (cell.kind===KIND_STRIPE){
    return `<div class="candy">${base}<span class="ov ${cell.dir==='H'?'stripeH':'stripeV'}"></span></div>`;
  }
  return `<div class="candy">${base}</div>`;
}
function randomColor(){ return TYPES[rand(TYPES.length)].id; }
function makeCell(color, kind=KIND_NORMAL, dir=null){ return { id:uid(), color, kind, dir }; }
function generateGrid(){
  GRID = Array.from({length:SIZE}, ()=> Array.from({length:SIZE}, ()=> makeCell(randomColor())));
  for(let r=0;r<SIZE;r++){
    for(let c=0;c<SIZE;c++){
      let tries=0;
      while(createsInitialMatch(r,c) && tries<12){
        GRID[r][c] = makeCell(randomColor()); tries++;
      }
    }
  }
}
function createsInitialMatch(r,c){
  const col=GRID[r][c].color;
  const left1 = c>=1 && GRID[r][c-1].color===col;
  const left2 = c>=2 && GRID[r][c-2].color===col;
  const up1   = r>=1 && GRID[r-1][c].color===col;
  const up2   = r>=2 && GRID[r-2][c].color===col;
  return (left1 && left2) || (up1 && up2);
}
function render(){
  boardEl.innerHTML='';
  for(let r=0;r<SIZE;r++){
    for(let c=0;c<SIZE;c++){
      const tile = document.createElement('div');
      tile.className='tile'; tile.dataset.r=r; tile.dataset.c=c;
      tile.innerHTML = candyHTML(GRID[r][c]);
      tile.addEventListener('click', onTileClick);
      boardEl.appendChild(tile);
    }
  }
  fitBoard();
}
function onTileClick(e){
  if (busy || paused) return;
  const t = e.currentTarget, r = +t.dataset.r, c = +t.dataset.c;
  const sel = boardEl.querySelector('.tile.selected');
  if (!sel){ first={r,c}; t.classList.add('selected'); beep(520); return; }
  const r2=+sel.dataset.r, c2=+sel.dataset.c;
  if (r===r2 && c===c2){ sel.classList.remove('selected'); first=null; return; }
  if (Math.abs(r-r2)+Math.abs(c-c2)!==1){
    sel.classList.remove('selected'); first=null; t.classList.add('shake'); setTimeout(()=>t.classList.remove('shake'),200); beep(260,0.06,0.03); return;
  }
  attemptSwap({r:r2,c:c2},{r,c});
}
function swapCells(a,b){ [GRID[a.r][a.c], GRID[b.r][b.c]] = [GRID[b.r][b.c], GRID[a.r][a.c]]; }
function findMatches(grid=GRID){
  const mark = Array.from({length:SIZE}, ()=> Array.from({length:SIZE}, ()=> false));
  let clusters=[];
  for(let r=0;r<SIZE;r++){
    let run=1;
    for(let c=1;c<=SIZE;c++){
      const same = c<SIZE && grid[r][c].color===grid[r][c-1].color;
      if (same) run++;
      else{
        if (run>=3){ const cells=[]; for(let k=1;k<=run;k++){ mark[r][c-k]=true; cells.push({r,c:c-k}); } clusters.push({type:'line',dir:'H',cells}); }
        run=1;
      }
    }
  }
  for(let c=0;c<SIZE;c++){
    let run=1;
    for(let r=1;r<=SIZE;r++){
      const same = r<SIZE && grid[r][c].color===grid[r-1][c].color;
      if (same) run++;
      else{
        if (run>=3){ const cells=[]; for(let k=1;k<=run;k++){ mark[r-k][c]=true; cells.push({r:r-k,c}); } clusters.push({type:'line',dir:'V',cells}); }
        run=1;
      }
    }
  }
  const wrapCenters=[];
  for(let r=0;r<SIZE;r++){
    for(let c=0;c<SIZE;c++){
      if(!mark[r][c]) continue;
      const col=grid[r][c].color;
      const h = (c>=1 && grid[r][c-1].color===col) + (c+1<SIZE && grid[r][c+1].color===col) + (c>=2 && grid[r][c-2].color===col) + (c+2<SIZE && grid[r][c+2].color===col);
      const v = (r>=1 && grid[r-1][c].color===col) + (r+1<SIZE && grid[r+1][c].color===col) + (r>=2 && grid[r-2][c].color===col) + (r+2<SIZE && grid[r+2][c].color===col);
      if (h>=2 && v>=2) wrapCenters.push({r,c});
    }
  }
  const specials=[];
  for(const cl of clusters){
    const L = cl.cells.length;
    if (L===4){ specials.push({kind:KIND_STRIPE, dir:cl.dir==='H'?'H':'V', pos:cl.cells[Math.floor(L/2)]}); }
    else if (L>=5){ specials.push({kind:KIND_COLOR, dir:null, pos:cl.cells[Math.floor(L/2)]}); }
  }
  for(const w of wrapCenters) specials.push({kind:KIND_WRAP, dir:null, pos:w});
  return {any:clusters.length>0, clusters, specials};
}

function applyCrush(){
  return new Promise(resolve=>{
    const {any, clusters, specials} = findMatches(GRID);
    if (!any){ resolve(false); return; }
    const remove = Array.from({length:SIZE}, ()=> Array.from({length:SIZE}, ()=> false));
    for(const cl of clusters) for(const ce of cl.cells) remove[ce.r][ce.c]=true;
    for(const sp of specials){
      const {r,c} = sp.pos;
      GRID[r][c] = makeCell(GRID[r][c].color, sp.kind, sp.dir||null);
      remove[r][c] = false;
    }
    let crushed=0, colorsCount={};
    for(let r=0;r<SIZE;r++) for(let c=0;c<SIZE;c++){
      if (remove[r][c]){ crushed++; const col=GRID[r][c].color; colorsCount[col]=(colorsCount[col]||0)+1; }
    }
    score += crushed*12 + Math.max(0, crushed-3)*6; scoreEl.textContent=String(score);
    updateGoals(colorsCount);
    const children = boardEl.children;
    for(let r=0;r<SIZE;r++) for(let c=0;c<SIZE;c++){ if(remove[r][c]) children[r*SIZE+c].classList.add('fade'); }
    beep(760,0.08,0.05);
    setTimeout(()=>{
      for(let c=0;c<SIZE;c++){
        let write=SIZE-1;
        for(let r=SIZE-1;r>=0;r--){
          if(!remove[r][c]){ GRID[write][c]=GRID[r][c]; write--; }
        }
        for(let r=write;r>=0;r--) GRID[r][c]=makeCell(randomColor());
      }
      render();
      resolve(true);
    }, 180);
  });
}
function triggerSpecialAt(r,c){
  const cell = GRID[r][c];
  if (cell.kind===KIND_STRIPE){
    if (cell.dir==='H'){ for(let cc=0;cc<SIZE;cc++) GRID[r][cc]=makeCell(GRID[r][cc].color); }
    else { for(let rr=0;rr<SIZE;rr++) GRID[rr][c]=makeCell(GRID[rr][c].color); }
    beep(680,0.08,0.05); return true;
  }
  if (cell.kind===KIND_WRAP){
    for(let rr=r-1; rr<=r+1; rr++) for(let cc=c-1; cc<=c+1; cc++) if(inBounds(rr,cc)) GRID[rr][cc]=makeCell(GRID[rr][cc].color);
    beep(520,0.08,0.05); return true;
  }
  return false;
}
function colorBomb(r,c,targetColor){
  let removed=0;
  for(let rr=0;rr<SIZE;rr++) for(let cc=0;cc<SIZE;cc++){
    if (GRID[rr][cc].color===targetColor){ GRID[rr][cc]=makeCell(GRID[rr][cc].color); removed++; }
  }
  if(removed>0){ score+=removed*15; scoreEl.textContent=String(score); beep(820,0.1,0.06); }
}
async function attemptSwap(a,b){
  busy=true;
  const before = cloneGrid(GRID); const beforeScore=score, beforeMoves=moves;
  const A=GRID[a.r][a.c], B=GRID[b.r][b.c];
  swapCells(a,b); render();
  let usedSpecial=false;
  if (A.kind===KIND_COLOR && B.kind!==KIND_COLOR){ colorBomb(b.r,b.c,B.color); usedSpecial=true; }
  else if (B.kind===KIND_COLOR && A.kind!==KIND_COLOR){ colorBomb(a.r,a.c,A.color); usedSpecial=true; }
  else if (A.kind===KIND_COLOR && B.kind===KIND_COLOR){
    for(let rr=0;rr<SIZE;rr++) for(let cc=0;cc<SIZE;cc++) GRID[rr][cc]=makeCell(GRID[rr][cc].color);
    score+=120; scoreEl.textContent=String(score); usedSpecial=true; beep(880,0.12,0.07);
  } else {
    usedSpecial = triggerSpecialAt(b.r,b.c) || triggerSpecialAt(a.r,a.c);
  }
  const {any} = findMatches(GRID);
  if (any || usedSpecial){
    moves = Math.max(0, moves-1); movesEl.textContent=String(moves);
    history = {grid:before, score:beforeScore, moves:beforeMoves};
    while(await applyCrush()){}
    checkState();
  } else {
    swapCells(a,b); render(); beep(240,0.06,0.03);
  }
  const sel = boardEl.querySelector('.tile.selected'); if (sel) sel.classList.remove('selected');
  first=null; busy=false;
}
function showHint(){
  if (busy || paused || moves<=0) return;
  for(let r=0;r<SIZE;r++) for(let c=0;c<SIZE;c++){
    const dirs=[[0,1],[1,0]];
    for(const [dr,dc] of dirs){
      const r2=r+dr, c2=c+dc; if(!inBounds(r2,c2)) continue;
      const tmp=cloneGrid(GRID);
      [tmp[r][c], tmp[r2][c2]]=[tmp[r2][c2], tmp[r][c]];
      if (findMatches(tmp).any){
        const a = boardEl.children[r*SIZE+c], b = boardEl.children[r2*SIZE+c2];
        a.classList.add('selected'); b.classList.add('selected'); setTimeout(()=>{a.classList.remove('selected');b.classList.remove('selected')},750);
        moves--; movesEl.textContent=String(moves); beep(500,0.05,0.03);
        checkState(); return;
      }
    }
  }
  regenIfStuck();
}
function undo(){
  if (!history || busy || paused) return;
  GRID = history.grid; score=history.score; moves=history.moves;
  history=null; render(); scoreEl.textContent=String(score); movesEl.textContent=String(moves); beep(380,0.05,0.03);
}
function renderObjectives(){
  objList.innerHTML='';
  for(const k of Object.keys(goals)){
    const box = document.createElement('div'); box.className='obj';
    box.innerHTML = `${objectiveIconHTML(k)}<div style="color:var(--dms-muted);font-size:14px">${k}</div>
                     <div class="req" id="req-${k}">${Math.min(progress[k]||0,goals[k])} / ${goals[k]}</div>`;
    objList.appendChild(box);
  }
}
function setupLevel(lv){
  const conf = LEVELS[(lv-1)%LEVELS.length];
  moves = conf.moves; movesEl.textContent=String(moves);
  goals = JSON.parse(JSON.stringify(conf.goals));
  progress={}; for(const k in goals) progress[k]=0;
  renderObjectives();
}
function updateGoals(map){
  let changed=false;
  for(const k in map){ if(goals[k]!=null){ progress[k]=(progress[k]||0)+map[k]; changed=true; } }
  if (changed){ for(const k in goals){ const el=document.getElementById('req-'+k); if(el) el.textContent=`${Math.min(progress[k],goals[k])} / ${goals[k]}`; } }
}
function goalsDone(){ for(const k in goals) if((progress[k]||0)<goals[k]) return false; return true; }
function starCount(){
  const base = LEVELS[(level-1)%LEVELS.length].moves;
  if (moves>=Math.floor(base*0.45)) return 3; if (moves>=Math.floor(base*0.22)) return 2; return 1;
}
function updateStarsUI(n){ [...starbar.children].forEach((s,i)=> s.classList.toggle('on', i<n)); }
function hasPossibleMove(){
  for(let r=0;r<SIZE;r++) for(let c=0;c<SIZE;c++){
    const dirs=[[0,1],[1,0]];
    for(const [dr,dc] of dirs){
      const r2=r+dr, c2=c+dc; if(!inBounds(r2,c2)) continue;
      const tmp=cloneGrid(GRID);
      [tmp[r][c], tmp[r2][c2]]=[tmp[r2][c2], tmp[r][c]];
      if (findMatches(tmp).any) return true;
    }
  }
  return false;
}
function regenIfStuck(){ let guard=0; do{ generateGrid(); guard++; if(guard>50) break; } while(!hasPossibleMove()); render(); }
function checkState(){
  updateStarsUI(starCount());
  if (goalsDone()){
    const stars = starCount(); const gain = 200*stars + moves*10;
    score += gain; scoreEl.textContent=String(score);
    saveProgress({ score, best:Math.max(Number(bestEl.textContent||0),score), level:level+1, sound:soundOn })
      .then(({best})=>{ if(typeof best==='number') bestEl.textContent=String(best); })
      .finally(()=>{ alert(`🌟 Niveau ${level} réussi !\nÉtoiles: ${stars}\nBonus: +${gain}`); level++; levelEl.textContent=String(level); startLevel(); });
    return;
  }
  if (moves<=0){
    saveProgress({ score, best:Math.max(Number(bestEl.textContent||0),score), level, sound:soundOn });
    alert(`Fin de partie.\nObjectifs non atteints.`); startLevel(); return;
  }
  if (!hasPossibleMove()) regenIfStuck();
}
async function saveProgress(payload){
  try{
    const res = await fetch('candysave.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    if(!res.ok) throw new Error('HTTP '+res.status);
    return await res.json();
  }catch(e){ console.warn('save error',e); return {}; }
}
function togglePause(){ paused=!paused; btnPause.textContent = paused?'Reprendre':'Pause'; }
function toggleSound(){ soundOn=!soundOn; soundState.textContent=soundOn?'ON':'OFF'; saveProgress({ level, best:Number(bestEl.textContent||0), score, sound:soundOn }); }
function openHelp(){ helpModal.classList.add('open'); }
function closeHelp(){ helpModal.classList.remove('open'); }
btnHelp.addEventListener('click', openHelp);
btnCloseHelp.addEventListener('click', closeHelp);
helpModal.addEventListener('click', (e)=>{ if(e.target===helpModal) closeHelp(); });
document.addEventListener('keydown', (e)=>{ if(e.key==='Escape' && helpModal.classList.contains('open')) closeHelp(); });
function startLevel(){
  history=null; score=0; scoreEl.textContent='0';
  setupLevel(level);
  generateGrid(); render();
  (async()=>{ while(await applyCrush()){} if(!hasPossibleMove()) regenIfStuck(); updateStarsUI(starCount()); })();
}
btnNew.addEventListener('click', ()=> startLevel());
btnHint.addEventListener('click', ()=> showHint());
btnUndo.addEventListener('click', ()=> undo());
btnPause.addEventListener('click', ()=> togglePause());
btnSound.addEventListener('click', ()=> toggleSound());
startLevel();
</script>
</body>
</html>
