<?php
if (session_status()===PHP_SESSION_NONE) session_start();
header('Content-Type: application/json; charset=utf-8');
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { echo json_encode(['ok'=>false,'error'=>'not_logged']); exit; }
$in = json_decode(file_get_contents('php://input'), true) ?: [];
$score = (int)($in['score'] ?? 0);
$best  = (int)($in['best']  ?? 0);
$level = max(1, (int)($in['level'] ?? 1));
$sound = !empty($in['sound']);
$dir = __DIR__ . "/../../users/profiles/$email";
@mkdir($dir, 0775, true);
$file = $dir . "/candy.json";
$data = ['best'=>0,'level'=>1,'sound'=>true,'updated'=>date('c')];
if (is_file($file)) {
  $j = json_decode(@file_get_contents($file), true);
  if (is_array($j)) $data = array_merge($data, $j);
}
$data['best']  = max((int)$data['best'], $best, $score);
$data['level'] = max((int)$data['level'], $level);
$data['sound'] = !!$sound;
$data['updated'] = date('c');
file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
echo json_encode(['ok'=>true, 'best'=>(int)$data['best'], 'level'=>(int)$data['level']]);
