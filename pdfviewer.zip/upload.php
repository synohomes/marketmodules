<?php
session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) exit('⛔ Non connecté');
$userDir = __DIR__ . "/../../users/profiles/$email";
$pdfDir = "$userDir/PDF";
if (!is_dir($pdfDir)) @mkdir($pdfDir, 0775, true);
if (!is_writable($pdfDir)) exit("Erreur : Dossier PDF non accessible en écriture.");
$theme = 'default';
$themeFile = "$userDir/theme.json";
if (file_exists($themeFile)) {
    $themeData = json_decode(file_get_contents($themeFile), true);
    if (!empty($themeData['theme']) && file_exists("../../theme/{$themeData['theme']}/style.css")) {
        $theme = basename($themeData['theme']);
    }
}
$upload_errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_FILES['pdfs'])) {
    foreach ($_FILES['pdfs']['tmp_name'] as $i => $tmp) {
        $name = basename($_FILES['pdfs']['name'][$i]);
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if ($_FILES['pdfs']['error'][$i] !== UPLOAD_ERR_OK) continue;
        if ($ext !== 'pdf') {
            $upload_errors[] = "$name : pas un PDF.";
            continue;
        }
        if (!move_uploaded_file($tmp, "$pdfDir/$name")) {
            $upload_errors[] = "$name : échec de l'upload.";
        }
    }
    if (empty($upload_errors)) {
        header("Location: ../../dashboard.php");
        exit;
    }
}
if (isset($_GET['delete'])) {
    $file = basename($_GET['delete']);
    $target = "$pdfDir/$file";
    if (file_exists($target)) unlink($target);

    header("Location: ../../dashboard.php");
    exit;
}
$pdfs = [];
foreach (scandir($pdfDir) as $f) {
    if (strtolower(pathinfo($f, PATHINFO_EXTENSION)) === 'pdf') {
        $pdfs[] = $f;
    }
}
sort($pdfs);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Lecteur PDF</title>
<link rel="stylesheet" href="../../theme/<?= htmlspecialchars($theme) ?>/style.css">
<style>
.pdf-item{display:flex;justify-content:space-between;align-items:center;background:#111;color:white;padding:6px 10px;border-radius:6px;margin-bottom:6px}
.pdf-item button{background:red;border:none;padding:4px 8px;color:white;cursor:pointer;border-radius:4px}
iframe{width:100%;height:600px;border:1px solid #444;background:white}
.close-btn{float:right;margin-top:-40px;margin-right:10px;background:crimson;color:white;padding:3px 7px;border:none;border-radius:5px;cursor:pointer}
</style>
</head>
<body>
<div class="section">
<h2>Fichiers PDF</h2>

<div class="pdf-list">
<?php foreach ($pdfs as $file): ?>
    <div class="pdf-item">
        <span onclick="openPDF('<?= rawurlencode($file) ?>')"><?= htmlspecialchars($file) ?></span>
        <button onclick="deletePDF('<?= rawurlencode($file) ?>')">🗑</button>
    </div>
<?php endforeach; ?>
<?php if (empty($pdfs)) echo "<div style='color:gray'>Aucun PDF trouvé.</div>"; ?>
</div>

<form action="" method="post" enctype="multipart/form-data">
    <input type="file" name="pdfs[]" multiple accept="application/pdf" required>
    <button type="submit"> Envoyer</button>
</form>

<div id="pdf-viewer" style="margin-top:20px;">
    <button class="close-btn" onclick="closePDF()" style="display:none;">✖</button>
    <iframe id="pdf-frame" src="" style="display:none;"></iframe>
</div>
</div>

<script>
function openPDF(file){
    const iframe=document.getElementById('pdf-frame');
    const path="../../users/profiles/<?= rawurlencode($email) ?>/PDF/"+file;
    iframe.src=path;
    iframe.style.display='block';
    document.querySelector('.close-btn').style.display='inline-block';
    localStorage.setItem('lastPdf',file);
}
function closePDF(){
    const iframe=document.getElementById('pdf-frame');
    iframe.src="";
    iframe.style.display='none';
    document.querySelector('.close-btn').style.display='none';
    localStorage.removeItem('lastPdf');
}
function deletePDF(file){
    if(confirm("Supprimer ce PDF ?")){
        window.location="?delete="+file;
    }
}
window.onload=function(){
    const last=localStorage.getItem('lastPdf');
    if(last) openPDF(last);
}
</script>
</body>
</html>
