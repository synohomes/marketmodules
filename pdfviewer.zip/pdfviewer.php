<?php
session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { exit('⛔ Non connecté'); }
@umask(0002);
$userDir = __DIR__ . "/../../users/profiles/$email";
$pdfDir  = "$userDir/PDF";
if (!is_dir($pdfDir) && !@mkdir($pdfDir, 0775, true)) {
    exit("Erreur : Impossible de créer le répertoire PDF.");
}
if (!is_writable($pdfDir)) { exit("Erreur : Dossier PDF non accessible en écriture."); }
$theme = 'default';
$themeFile = "$userDir/theme.json";
if (is_file($themeFile)) {
    $themeData = json_decode(@file_get_contents($themeFile), true);
    if (!empty($themeData['theme']) && is_file(__DIR__ . "/../../theme/{$themeData['theme']}/style.css")) {
        $theme = basename($themeData['theme']);
    }
}
$siteRoot     = rtrim(dirname(dirname(dirname($_SERVER['SCRIPT_NAME']))), '/'); // /domydesk
$fileBaseUrl  = $siteRoot . '/users/profiles/' . rawurlencode($email) . '/PDF/';
$dashboardUrl = $siteRoot . '/dashboard.php';
if (isset($_GET['delete'])) {
    $file   = basename($_GET['delete']);
    $target = $pdfDir . "/" . $file;
    if (is_file($target) && strtolower(pathinfo($target, PATHINFO_EXTENSION)) === 'pdf') {
        @unlink($target);
    }
    echo '<!doctype html><html><head><meta charset="utf-8">
    <script>
      try { (window.top || window.parent || window).location.href = ' . json_encode($dashboardUrl) . '; }
      catch(e){ window.location.href = ' . json_encode($dashboardUrl) . '; }
    </script>
    <noscript><meta http-equiv="refresh" content="0;url=' . htmlspecialchars($dashboardUrl, ENT_QUOTES) . '"></noscript>
    </head><body></body></html>';
    exit;
}
$pdfs = [];
if (is_dir($pdfDir)) {
    foreach (scandir($pdfDir) as $f) {
        if ($f==='.'||$f==='..') continue;
        $p = $pdfDir . '/' . $f;
        if (is_file($p) && strtolower(pathinfo($f, PATHINFO_EXTENSION))==='pdf') $pdfs[] = $f;
    }
}
sort($pdfs);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Lecteur PDF</title>
<link rel="stylesheet" href="../../theme/<?= htmlspecialchars($theme) ?>/style.css">
<style>
  .pdf-list{ margin-bottom:16px; }
  .pdf-item{
    display:flex; justify-content:space-between; align-items:center;
    padding:10px 12px; border-radius:10px; margin-bottom:6px;
    background: var(--card-bg, var(--section-bg, transparent));
    color: var(--text-color, #fff);
    border: 1px solid var(--card-border, var(--primary-dark, transparent));
    min-height: 44px;
    box-shadow: 0 2px 0 var(--card-border, rgba(255,255,255,.12));
  }
  .pdf-item .name{
    cursor:pointer; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
    max-width:70%; line-height:1.2;
  }
  .pdf-item .actions{ display:flex; align-items:center; gap:10px; }
  .icon-ghost{
    background: none; border: none; padding: 0; margin: 0;
    width: 28px; height: 28px; display:inline-flex; align-items:center; justify-content:center;
    color: var(--btn-danger-fg, var(--danger-color, var(--primary-color, #fff)));
    cursor:pointer; font-size: 18px; line-height: 1;
  }
  .icon-ghost:hover{
    color: var(--btn-danger-hover, var(--primary-dark, #ddd));
    transform: translateY(-1px);
  }
  .pdf-inline{ margin-top:10px; }
  .pdf-inline object{
    display:block; width:100%; height:75vh;
    border-radius:10px;
    background: var(--surface-bg, #fff);
    border: 1px solid var(--surface-border, var(--primary-dark, #2a2a2a));
  }
  .viewer-bar{ display:none; gap:8px; margin:8px 0; }
  .btn{
    background: var(--btn-bg, var(--primary-color, #2563eb));
    color: var(--btn-fg, #fff);
    border: 1px solid var(--btn-border, transparent);
    border-radius: 8px; cursor:pointer;
    padding: 6px 10px; line-height:1;
  }
  .btn.red{ background: var(--btn-danger-bg, var(--danger-color, #c0392b)); color: var(--btn-danger-fg, #fff); }
  .overlay{
    position:fixed; inset:0; display:none;
    align-items:center; justify-content:center; z-index:99999;
    background: rgba(0,0,0,.8);
  }
  .overlay-inner{
    width:96vw; height:94vh; display:flex; flex-direction:column; overflow:hidden;
    border-radius:10px; background: var(--surface-bg, #000);
    box-shadow:0 10px 40px rgba(0,0,0,.6);
  }
  .ov-top{
    display:flex; justify-content:flex-end; gap:8px; align-items:center;
    padding:8px 10px; border-bottom:1px solid var(--surface-border, #222);
    background: var(--surface-header-bg, #0b0b0b);
  }
  .overlay object{ flex:1; width:100%; border:0; background: var(--surface-bg, #111); }
</style>
</head>
<body>
<div class="section">
  <h2>Fichiers PDF</h2>
  <div class="pdf-list">
    <?php foreach ($pdfs as $file): $encoded = rawurlencode($file); ?>
      <div class="pdf-item">
        <span class="name" onclick="openPDF('<?= $encoded ?>')" title="<?= htmlspecialchars($file) ?>">
          <?= htmlspecialchars($file) ?>
        </span>
        <div class="actions">
          <button class="icon-ghost" onclick="deletePDF('<?= $encoded ?>')" title="Supprimer">🗑</button>
        </div>
      </div>
    <?php endforeach; ?>
    <?php if (empty($pdfs)) echo "<div style='color:gray'>Aucun PDF trouvé.</div>"; ?>
  </div>
  <form action="modules/pdfviewer/upload.php" method="post" enctype="multipart/form-data" style="margin:6px 0 12px">
    <input type="file" name="pdfs[]" multiple accept="application/pdf" required>
    <button class="btn" type="submit">Envoyer</button>
  </form>
  <div class="viewer-bar" id="viewerBar">
    <button class="btn" onclick="openFull()">Plein écran</button>
    <button class="btn red" onclick="closePDF()">Fermer</button>
  </div>
  <div id="pdf-inline" class="pdf-inline" hidden>
    <object id="pdfObject" data="" type="application/pdf"></object>
  </div>
</div>
<div class="overlay" id="overlay">
  <div class="overlay-inner">
    <div class="ov-top">
      <button class="btn" onclick="openNewTab()">Ouvrir dans un onglet</button>
      <button class="btn red" onclick="closeFull()">Fermer</button>
    </div>
    <object id="overlayObj" data="" type="application/pdf"></object>
  </div>
</div>
<script>
let currentFile = null;
let currentAbs  = null;
function forceReloadObject(objectId, url){
  const objOld = document.getElementById(objectId);
  const parent = objOld.parentNode;
  const objNew = objOld.cloneNode(false);
  objNew.id = objectId;
  objNew.type = 'application/pdf';
  objNew.style.cssText = objOld.style.cssText;
  objNew.data = url + (url.includes('?') ? '&' : '?') + 't=' + Date.now();
  parent.replaceChild(objNew, objOld);
  return objNew;
}
function openPDF(encodedFile){
  currentFile = encodedFile;
  currentAbs  = "<?= $fileBaseUrl ?>" + encodedFile;

  document.getElementById('pdf-inline').hidden = false;
  document.getElementById('viewerBar').style.display = 'flex';

  const url = currentAbs + '#zoom=page-width';
  forceReloadObject('pdfObject', url);
  localStorage.setItem('lastPdf', encodedFile);
}
function openFull(){
  if (!currentAbs) return;
  const ov  = document.getElementById('overlay');
  const url = currentAbs + '#zoom=page-width';
  forceReloadObject('overlayObj', url);
  ov.style.display = 'flex';
}
function closePDF(){
  forceReloadObject('pdfObject', 'about:blank');
  document.getElementById('pdf-inline').hidden = true;
  document.getElementById('viewerBar').style.display = 'none';
  localStorage.removeItem('lastPdf');
  currentFile = null; currentAbs = null;
}
function closeFull(){
  forceReloadObject('overlayObj', 'about:blank');
  document.getElementById('overlay').style.display = 'none';
}
function openNewTab(){
  if (!currentAbs) return;
  const url = currentAbs + '#zoom=page-width';
  window.open(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(), '_blank');
}
function deletePDF(file){
  if (!confirm("Supprimer ce PDF ?")) return;
  window.location = "modules/pdfviewer/pdfviewer.php?delete=" + file;
}
window.addEventListener('load', () => {
  const last = localStorage.getItem('lastPdf');
  if (last) openPDF(last);
});
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeFull(); });
</script>
</body>
</html>
