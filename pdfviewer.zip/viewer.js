const urlParams = new URLSearchParams(window.location.search);
const file = urlParams.get('file');
const canvas = document.getElementById('pdf-canvas');
const ctx = canvas.getContext('2d');

if (file) {
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'pdf.worker.js';
    pdfjsLib.getDocument(file).promise.then(function (pdf) {
        pdf.getPage(1).then(function (page) {
            const scale = 1.5;
            const viewport = page.getViewport({ scale: scale });
            canvas.height = viewport.height;
            canvas.width = viewport.width;
            const renderContext = {
                canvasContext: ctx,
                viewport: viewport
            };
            page.render(renderContext);
        });
    }).catch(function (err) {
        ctx.font = "16px sans-serif";
        ctx.fillStyle = "red";
        ctx.fillText("Erreur de chargement du PDF : " + err.message, 10, 50);
    });
}
