<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { echo "<div style='color:#f66;padding:10px'>⛔ Non connecté</div>"; return; }

/* ---------- chemins ---------- */
$cfgFile   = __DIR__ . "/../../users/profiles/$email/inventaire_fields.json";
$dataDir   = __DIR__ . "/../../users/profiles/$email/inventaires/";
@mkdir($dataDir, 0775, true);

$date        = date('Y-m-d');
$dataFile    = $dataDir . "inventaires_$date.json";
$globalFile  = $dataDir . "inventaire_global.json";

/* ---------- helpers ---------- */
function read_json($f){ return file_exists($f) ? (json_decode(file_get_contents($f), true) ?: []) : []; }
function write_json($f,$arr){ return file_put_contents($f, json_encode($arr, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE), LOCK_EX)!==false; }
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

/* ---------- bootstrap ---------- */
if (!file_exists($cfgFile)) write_json($cfgFile, []);
if (!file_exists($dataFile)) write_json($dataFile, []);
if (!file_exists($globalFile)) write_json($globalFile, []);

/* ---------- data ---------- */
$fields = read_json($cfgFile);            // [{name,type,size}]
$data   = read_json($dataFile);           // articles du jour
$actionBase = (isset($_GET['module']) && $_GET['module']==='inventaire') ? '?module=inventaire' : '';

/* ---------- rendu liste compacte (2 lignes) ---------- */
function render_list($data, $fields){
    $f1 = $fields[0]['name'] ?? null;
    $f2 = $fields[1]['name'] ?? null;

    ob_start(); ?>
    <?php if (empty($data)): ?>
      <p style="color:#aaa">Aucun article pour aujourd’hui.</p>
    <?php else: ?>
      <ul id="inv-list" style="list-style:none;padding:0;margin:8px 0;display:flex;flex-direction:column;gap:6px">
        <?php foreach ($data as $i => $article):
          $v1 = $f1 ? ($article[$f1] ?? '') : '';
          $v2 = $f2 ? ($article[$f2] ?? '') : '';
          $json = htmlspecialchars(json_encode($article, JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8');
        ?>
        <li style="background:#1e1e1e;border:1px solid #3a3a3a;border-radius:8px;padding:8px 10px;display:flex;align-items:center;justify-content:space-between;gap:12px">
          <div style="display:flex;flex-direction:column;gap:2px;min-width:0">
            <div style="font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
              <?= $f1 ? h($f1).": " : "" ?><span><?= h($v1) ?></span>
            </div>
            <div style="font-size:.9rem;opacity:.85;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
              <?= $f2 ? h($f2).": " : "" ?><span><?= h($v2) ?></span>
            </div>
          </div>
          <div style="flex:0 0 auto;display:flex;gap:6px">
            <button class="inv-edit" data-idx="<?= (int)$i ?>" data-item="<?= $json ?>" title="Modifier"
                    style="background:transparent;border:1px solid #4a4a4a;border-radius:8px;padding:6px;cursor:pointer">✏️</button>
            <button class="inv-del" data-idx="<?= (int)$i ?>" title="Supprimer"
                    style="background:transparent;border:1px solid #804040;border-radius:8px;padding:6px;cursor:pointer">🗑️</button>
          </div>
        </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
    <?php
    return ob_get_clean();
}

/* ---------- AJAX ops ---------- */
$isAjax = strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'fetch';

if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['op'] ?? '')==='delete') {
    $data = read_json($dataFile);
    $idx = (int)($_POST['idx'] ?? -1);
    if (isset($data[$idx])) { unset($data[$idx]); $data = array_values($data); write_json($dataFile,$data); }
    $fields = read_json($cfgFile);
    echo json_encode(["ok"=>true, "html"=>render_list($data,$fields)], JSON_UNESCAPED_UNICODE); exit;
}

if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['op'] ?? '')==='save') {
    $fields = read_json($cfgFile);
    $data   = read_json($dataFile);
    $global = read_json($globalFile);

    $editIndex = is_numeric($_POST['edit_index'] ?? null) ? (int)$_POST['edit_index'] : -1;

    // Reconstruction depuis f[index]
    $vals = $_POST['f'] ?? [];
    $article = ['date'=>$date];
    foreach ($fields as $i => $f){
        $fname = $f['name'] ?? '';
        if ($fname==='') continue;
        $article[$fname] = trim($vals[$i] ?? '');
    }

    if ($editIndex>=0 && isset($data[$editIndex])) {
        $data[$editIndex] = $article;
    } else {
        $data[] = $article;
        $global[] = $article;
        write_json($globalFile, $global);
    }
    write_json($dataFile, $data);

    echo json_encode(["ok"=>true, "html"=>render_list($data,$fields)], JSON_UNESCAPED_UNICODE); exit;
}

/* ---------- UI ---------- */
// tailles par champ
$sizeMap = [];
foreach ($fields as $f){
  $name = $f['name'] ?? '';
  $sz   = ($f['size'] ?? 'short') === 'long' ? 50 : 20;
  if (($f['type'] ?? 'text') === 'number' || ($f['type'] ?? '') === 'date') $sz = 14;
  $sizeMap[$name] = $sz;
}
?>
<div class="module-content" style="color:#fff">
  <h2 style="color:#49a6e9;margin:0 0 8px">📦 Inventaire du <?= h(date('d/m/Y')) ?></h2>

  <?php if (empty($fields)): ?>
    <div style="color:orange;margin-top:8px">Aucun champ défini. Configurez-les dans <code>inventairecfg.php</code>.</div>
  <?php else: ?>
    <form id="inv-form" method="post" action="<?= h($_SERVER['PHP_SELF'].$actionBase) ?>"
          style="display:flex;flex-wrap:wrap;gap:10px;margin:10px 0 8px">
      <input type="hidden" name="op" value="save">
      <input type="hidden" name="edit_index" id="inv-edit-index" value="-1">
      <?php foreach ($fields as $i => $f): 
        $label = $f['name'] ?? '';
        $ftype = in_array(($f['type'] ?? 'text'), ['text','number','date'], true) ? $f['type'] : 'text';
        $sz    = $sizeMap[$label] ?? 20; ?>
        <label style="display:flex;flex-direction:column;gap:4px;min-width:180px;max-width:320px">
          <span style="font-size:.9rem;opacity:.9"><?= h($label) ?></span>
          <!-- IMPORTANT: on poste sous f[index] pour éviter les soucis d'espaces/accents -->
          <input name="f[<?= (int)$i ?>]" type="<?= h($ftype) ?>" size="<?= (int)$sz ?>"
                 style="padding:6px 8px;border:1px solid #444;border-radius:8px;background:#111;color:#fff;max-width:100%">
        </label>
      <?php endforeach; ?>
      <div style="align-self:flex-end;display:flex;gap:8px">
        <button type="submit" id="inv-save" title="Ajouter / sauvegarder"
                style="padding:6px 10px;border:1px solid #2e7d32;background:#1b5e20;color:#fff;border-radius:8px;cursor:pointer">
          ✅ Ajouter
        </button>
        <button type="button" id="inv-reset" title="Réinitialiser"
                style="padding:6px 10px;border:1px solid #555;background:#222;color:#ddd;border-radius:8px;cursor:pointer">
          ↺
        </button>
      </div>
    </form>
  <?php endif; ?>

  <h3 style="margin:8px 0 4px;color:#fff">📁 Articles</h3>
  <div id="inv-wrap-list"><?= render_list($data,$fields) ?></div>
<div style="margin:8px 0;display:flex;gap:10px;flex-wrap:wrap">
  <button type="button" class="btn-pdf" data-scope="day"    data-date="<?=h(date('Y-m-d'))?>"
          style="padding:6px 10px;border:1px solid #444;border-radius:8px;background:transparent;color:inherit;cursor:pointer">📄 PDF (jour)</button>
  <button type="button" class="btn-pdf" data-scope="global"
          style="padding:6px 10px;border:1px solid #444;border-radius:8px;background:transparent;color:inherit;cursor:pointer">📄 PDF (global)</button>
</div>
</div>

<script>
(function(){
  const root   = document.currentScript.closest('.module-content');
  const form   = root.querySelector('#inv-form');
  const listEl = root.querySelector('#inv-wrap-list');
  const idxEl  = root.querySelector('#inv-edit-index');

  function clearForm(){
    form.querySelectorAll('input[name^="f["]').forEach(i=> i.value = '');
    idxEl.value = -1;
    form.querySelector('#inv-save').textContent = '✅ Ajouter';
  }

  root.querySelector('#inv-reset')?.addEventListener('click', clearForm);

  // Éditer (✏️) : on mappe par libellé → inputs par index
  root.addEventListener('click', (e)=>{
    const editBtn = e.target.closest('.inv-edit');
    if (editBtn){
      const idx  = editBtn.getAttribute('data-idx');
      const item = JSON.parse(editBtn.getAttribute('data-item') || '{}');
      // Remplit les inputs f[i] selon l'ordre des champs
      const inputs = form.querySelectorAll('input[name^="f["]');
      inputs.forEach((inp, i)=>{
        const label = <?= json_encode(array_map(fn($f)=>$f['name']??'', $fields), JSON_UNESCAPED_UNICODE) ?>[i] || '';
        inp.value = label && item[label] !== undefined ? item[label] : '';
      });
      idxEl.value = idx;
      form.querySelector('#inv-save').textContent = '💾 Sauvegarder';
    }
    const delBtn = e.target.closest('.inv-del');
    if (delBtn){
      const idx = delBtn.getAttribute('data-idx');
      if (!confirm('Supprimer cet article ?')) return;
      const fd = new FormData(); fd.append('op','delete'); fd.append('idx', idx);
      fetch(form.action, { method:'POST', body:fd, headers:{'X-Requested-With':'fetch'} })
        .then(r=>r.json()).then(j=>{ if(j.ok&&j.html){ listEl.innerHTML=j.html; clearForm(); }})
        .catch(()=>alert('Erreur suppression'));
    }
  });

  // Sauvegarde AJAX
  form?.addEventListener('submit', (e)=>{
    e.preventDefault();
    const fd = new FormData(form);
    fetch(form.action, { method:'POST', body:fd, headers:{'X-Requested-With':'fetch'} })
      .then(r=>r.json()).then(j=>{
        if (j.ok && j.html){ listEl.innerHTML = j.html; clearForm(); }
        else alert('Erreur enregistrement');
      }).catch(()=>alert('Erreur réseau'));
  });
  
  (function(){
  const root = document.currentScript.closest('.module-content');

  // --- PDF popup
  const pdfModal = root.querySelector('#inv-pdf-modal');
  const pdfFrame = root.querySelector('#inv-pdf-frame');
  const btnPrint = root.querySelector('#inv-pdf-print');
  const btnClose = root.querySelector('#inv-pdf-close');
  const linkDl   = root.querySelector('#inv-pdf-dl');

  function openPdf(scope, date){
    // URL inline pour l’iframe
    const base = 'modules/inventaire/inventaire_export_pdf.php';
    const url  = scope==='global' ? `${base}?scope=global` : `${base}?scope=day&date=${encodeURIComponent(date)}`;
    const urlDl= url + '&download=1';
    pdfFrame.src = url;
    linkDl.href  = urlDl;
    linkDl.setAttribute('download', scope==='global' ? 'inventaire_global.pdf' : `inventaire_${date}.pdf`);
    pdfModal.style.display = 'flex';
  }

  root.addEventListener('click', (e)=>{
    const b = e.target.closest('.btn-pdf');
    if (b){
      openPdf(b.dataset.scope, b.dataset.date || '');
    }
  });

  btnPrint?.addEventListener('click', ()=>{ 
    // imprime le contenu de l’iframe
    try { pdfFrame.contentWindow.focus(); pdfFrame.contentWindow.print(); } catch(e){ alert('Impression non disponible'); }
  });
  btnClose?.addEventListener('click', ()=>{ pdfModal.style.display='none'; pdfFrame.src='about:blank'; });

})();



})();
</script>
<!-- Popup PDF confiné dans le module (REMPLACE l'ancien bloc) -->
<div id="inv-pdf-modal" style="display:none;position:absolute;inset:0;z-index:30;
  background:color-mix(in srgb, var(--primary-dark, #000) 40%, transparent);
  backdrop-filter:saturate(140%) blur(2px); align-items:center; justify-content:center">
  <div style="background:var(--panel-bg, var(--bg, #0f0f0f)); border:1px solid var(--border-color,#444);
    border-radius:12px; width:min(960px,95%); height:min(80vh,95%); display:flex; flex-direction:column; overflow:hidden;
    box-shadow:0 8px 28px rgba(0,0,0,.4)">
    <div style="display:flex; align-items:center; justify-content:space-between; gap:8px;
      padding:8px 10px; border-bottom:1px solid var(--border-color,#333); background:var(--header-bg, transparent);">
      <div style="display:flex; gap:8px; align-items:center">
        <button id="inv-pdf-print"
          style="padding:6px 10px; border:1px solid var(--border-color,#444); border-radius:8px;
          background:var(--btn-bg, transparent); color:var(--text-color,#fff); cursor:pointer">🖨️ Imprimer</button>
        <a id="inv-pdf-dl" href="#" download
          style="padding:6px 10px; border:1px solid var(--border-color,#444); border-radius:8px;
          text-decoration:none; color:var(--text-color,#fff); background:var(--btn-bg, transparent)">⬇️ Télécharger</a>
      </div>
      <button id="inv-pdf-close"
        style="padding:6px 10px; border:1px solid var(--border-color,#444); border-radius:8px;
        background:var(--btn-bg, transparent); color:var(--text-color,#fff); cursor:pointer">✖</button>
    </div>
    <iframe id="inv-pdf-frame" src="about:blank" style="flex:1;border:0;background:var(--bg,#111)"></iframe>
  </div>
</div>
