<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) exit;

$date = $_POST['date_inventaire'] ?? date('Y-m-d');
$dir = __DIR__ . "/../../users/profiles/$email/inventaires";
$file = "$dir/inventaires_$date.json";
$configFile = "$dir/inventaire_config.json";

if (!is_dir($dir)) mkdir($dir, 0775, true);

$cfg = is_file($configFile) ? json_decode(file_get_contents($configFile), true) : [];
if (!is_array($cfg)) $cfg = [];

$data = is_file($file) ? json_decode(file_get_contents($file), true) : [];
if (!is_array($data)) $data = [];

$entry = [];
foreach ($cfg as $field) {
    $label = $field['label'];
    $entry[$label] = $_POST[$label] ?? '';
}

$data[] = $entry;
file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
echo "OK";
