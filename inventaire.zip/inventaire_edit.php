<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) {
    echo "<div style='color:red;padding:10px'>⛔ Non connecté</div>";
    return;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : -1;
if ($id < 0) {
    echo "<div style='color:red;padding:10px'>⛔ ID invalide</div>";
    return;
}

$cfgFile = __DIR__ . "/../../users/profiles/$email/inventaire_fields.json";
$dataDir = __DIR__ . "/../../users/profiles/$email/inventaires/";
$dataFile = $dataDir . "inventaires_" . date('Y-m-d') . ".json";

$fields = file_exists($cfgFile) ? json_decode(file_get_contents($cfgFile), true) : [];
$data = file_exists($dataFile) ? json_decode(file_get_contents($dataFile), true) : [];

if (!isset($data[$id])) {
    echo "<div style='color:red;padding:10px'>⛔ Article non trouvé</div>";
    return;
}

// Enregistrement
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($fields as $f) {
        $key = $f['name'];
        $data[$id][$key] = $_POST[$key] ?? '';
    }
    file_put_contents($dataFile, json_encode($data, JSON_PRETTY_PRINT));
    header("Location: ../../dashboard.php?module=inventaire&edited=1");
    exit;
}

// Formulaire
$article = $data[$id];
?>

<div style="background:#222;color:#fff;padding:20px;border-radius:10px;width:90%;max-width:800px;margin:auto;margin-top:40px">
    <h2 style="color:#49a6e9;margin-bottom:20px">✏️ Modifier l’article</h2>

    <form method="post">
        <?php foreach ($fields as $f): 
            $name = $f['name'];
            $value = $article[$name] ?? '';
        ?>
            <div style="margin-bottom:15px">
                <label><?= htmlspecialchars($name) ?> :</label><br>
                <input type="<?= $f['type'] ?>" name="<?= htmlspecialchars($name) ?>"
                    value="<?= htmlspecialchars($value) ?>"
                    style="width:100%;padding:8px;border-radius:5px;border:1px solid #444;background:#111;color:#fff">
            </div>
        <?php endforeach ?>

        <button type="submit" style="margin-top:10px;padding:10px 15px;border:none;background:#28a745;color:#fff;border-radius:5px">💾 Enregistrer</button>
        <a href="../../dashboard.php?module=inventaire" style="margin-left:10px;color:#ccc">⬅️ Retour</a>
    </form>
</div>
