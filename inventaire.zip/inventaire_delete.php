<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) exit;

$date = $_POST['date_inventaire'] ?? '';
$index = isset($_POST['index']) ? (int)$_POST['index'] : -1;

if ($date === '' || $index < 0) exit("Paramètres invalides");

$dir = __DIR__ . "/../../users/profiles/$email/inventaires";
$file = "$dir/inventaires_$date.json";

$data = is_file($file) ? json_decode(file_get_contents($file), true) : [];

if (!isset($data[$index])) exit("Introuvable");

array_splice($data, $index, 1);
file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
echo "Supprimé";
