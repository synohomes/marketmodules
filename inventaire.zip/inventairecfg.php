<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { echo "<div style='color:red;padding:10px'>⛔ Non connecté</div>"; return; }

$cfgFile = __DIR__ . "/../../users/profiles/$email/inventaire_fields.json";
@mkdir(dirname($cfgFile), 0775, true);
if (!file_exists($cfgFile)) file_put_contents($cfgFile, '[]');

$fields = json_decode(file_get_contents($cfgFile), true);
if (!is_array($fields)) $fields = [];

// include vs autonome
$actionBase = (isset($_GET['module']) && $_GET['module']==='inventaire') ? '?module=inventaire' : '';

// Add
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['__op'] ?? '')==='add'){
    $name = trim($_POST['name'] ?? '');
    $type = $_POST['type'] ?? 'text';
    $size = ($_POST['size'] ?? 'short') === 'long' ? 'long' : 'short';
    if ($name !== '' && in_array($type, ['text','number','date'], true)) {
        $fields[] = ['name'=>$name, 'type'=>$type, 'size'=>$size];
        file_put_contents($cfgFile, json_encode($fields, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE), LOCK_EX);
    }
    header("Location: " . $_SERVER['PHP_SELF'] . $actionBase); exit;
}

// Delete
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['__op'] ?? '')==='del'){
    $idx = isset($_POST['idx']) ? (int)$_POST['idx'] : -1;
    if ($idx>=0 && $idx<count($fields)){
        unset($fields[$idx]); $fields = array_values($fields);
        file_put_contents($cfgFile, json_encode($fields, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE), LOCK_EX);
    }
    header("Location: " . $_SERVER['PHP_SELF'] . $actionBase); exit;
}
?>
<div style="color:#fff;padding:20px;border-radius:10px;width:90%;max-width:820px;margin:auto">
  <h2 style="color:#49a6e9;margin-bottom:15px">⚙️ Configuration de l'inventaire</h2>

  <form method="post" action="<?= htmlspecialchars($_SERVER['PHP_SELF'].$actionBase) ?>"
        style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px">
    <input type="hidden" name="__op" value="add">
    <input type="text" name="name" placeholder="Nom du champ" required
           style="flex:1;min-width:160px;padding:8px;border-radius:6px;border:1px solid #444;background:#111;color:#fff">
    <select name="type" style="padding:8px;border-radius:6px;border:1px solid #444;background:#111;color:#fff">
      <option value="text">Texte</option>
      <option value="number">Nombre</option>
      <option value="date">Date</option>
    </select>
    <select name="size" title="Taille du champ" style="padding:8px;border-radius:6px;border:1px solid #444;background:#111;color:#fff">
      <option value="short">Court (20)</option>
      <option value="long">Grand (50)</option>
    </select>
    <button type="submit" style="background:#28a745;color:white;border:none;padding:8px 14px;border-radius:6px;cursor:pointer">
      + Ajouter
    </button>
  </form>

  <?php if (empty($fields)): ?>
    <p>Aucun champ défini.</p>
  <?php else: ?>
    <ul style="list-style:none;padding:0;display:flex;flex-direction:column;gap:8px">
      <?php foreach ($fields as $i=>$f): ?>
        <li style="padding:8px 10px;background:#333;border-radius:8px;display:flex;align-items:center;justify-content:space-between;gap:10px">
          <div style="display:flex;gap:12px;flex-wrap:wrap">
            <strong><?= htmlspecialchars($f['name'] ?? '') ?></strong>
            <span>(<?= htmlspecialchars($f['type'] ?? '') ?>)</span>
            <span style="opacity:.9">taille: <?= ($f['size'] ?? 'short')==='long'?'50':'20' ?></span>
          </div>
          <form method="post" action="<?= htmlspecialchars($_SERVER['PHP_SELF'].$actionBase) ?>"
                onsubmit="return confirm('Supprimer ce champ ?')" style="margin:0">
            <input type="hidden" name="__op" value="del">
            <input type="hidden" name="idx" value="<?= (int)$i ?>">
            <button type="submit" title="Supprimer"
                    style="background:#a94442;color:#fff;border:none;padding:6px 10px;border-radius:6px;cursor:pointer">🗑️</button>
          </form>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</div>
