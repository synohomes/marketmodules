<?php
/* modules/inventaire/inventaire_export_pdf.php
 * PDF inline en popup + respect du thème (variables CSS mappées → couleurs Dompdf)
 */
if (session_status()===PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { http_response_code(403); exit("⛔"); }

$profiles = __DIR__ . "/../../users/profiles/$email/";
$themeJson = $profiles . "theme.json";
$themeName = 'default';
if (is_file($themeJson)) {
  $t = json_decode(file_get_contents($themeJson), true);
  if (!empty($t['theme'])) $themeName = basename($t['theme']);
}
$themeCssPath = __DIR__ . "/../../theme/$themeName/style.css"; // chemin fichier
$themeCssHref = "../../theme/$themeName/style.css";             // pour fallback HTML

$baseDir = $profiles . "inventaires/";
@mkdir($baseDir, 0775, true);

$scope = ($_GET['scope'] ?? 'day') === 'global' ? 'global' : 'day';
$date  = $_GET['date']  ?? date('Y-m-d');
$dl    = isset($_GET['download']);
$fname = "inventaire_".($scope==='global'?'global':$date).".pdf";

$dataFile = $scope==='global' ? $baseDir . "inventaire_global.json" : $baseDir . "inventaires_{$date}.json";
$cfgFile  = $profiles . "inventaire_fields.json";

function read_json($f){ return is_file($f) ? (json_decode(file_get_contents($f), true) ?: []) : []; }
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

/* ---------- données ---------- */
$fields = read_json($cfgFile);
$data   = read_json($dataFile);
if (!$data) {
  header('Content-Type:text/html; charset=utf-8');
  echo "<div style='padding:12px'>Aucune donnée à exporter.</div>";
  exit;
}

/* ---------- colonnes ---------- */
$cols = ['date']; foreach ($fields as $f){ if (!empty($f['name'])) $cols[] = $f['name']; }

$title   = 'Inventaire ' . ($scope==='global' ? '— Global' : ('du ' . date('d/m/Y', strtotime($date))));
$thead   = '<tr>' . implode('', array_map(fn($c)=>'<th class="inv-th">'.h($c).'</th>', $cols)) . '</tr>';
$rowsHtml = '';
foreach ($data as $row){
  $cells=''; foreach ($cols as $c) $cells .= '<td class="inv-td">'.h($row[$c] ?? '').'</td>';
  $rowsHtml .= '<tr>'.$cells.'</tr>';
}
$bodyHtml = '
  <h1 class="inv-title">'.$title.'</h1>
  <table class="inv-table"><thead>'.$thead.'</thead><tbody>'.$rowsHtml.'</tbody></table>
';

/* ---------- lecture & mapping des couleurs du thème ---------- */
$cssRaw = is_file($themeCssPath) ? @file_get_contents($themeCssPath) : '';

function css_var($css, $name, $fallback){
  if (!$css) return $fallback;
  $re = '/'.preg_quote($name,'/').'\s*:\s*([^;]+);/i';
  if (preg_match($re, $css, $m)) return trim($m[1]);
  return $fallback;
}
function to_hex($c, $fallback='#222222'){
  $c = trim($c);
  // #RGB / #RRGGBB
  if (preg_match('/^#([0-9a-f]{3})$/i',$c,$m)){
    $r = hexdec($m[1][0].$m[1][0]); $g = hexdec($m[1][1].$m[1][1]); $b = hexdec($m[1][2].$m[1][2]);
    return sprintf('#%02X%02X%02X',$r,$g,$b);
  }
  if (preg_match('/^#([0-9a-f]{6})$/i',$c,$m)) return '#'.strtoupper($m[1]);
  // rgb/rgba
  if (preg_match('/rgba?\s*\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)/i',$c,$m)){
    $r = max(0,min(255,(int)round($m[1]))); $g=max(0,min(255,(int)round($m[2]))); $b=max(0,min(255,(int)round($m[3])));
    return sprintf('#%02X%02X%02X',$r,$g,$b);
  }
  // sinon: renvoyer fallback
  return $fallback;
}

$bgVar        = css_var($cssRaw, '--bg', '#0f0f0f');
$textVar      = css_var($cssRaw, '--text-color', '#eeeeee');
$primaryVar   = css_var($cssRaw, '--primary-color', '#8cc8ff');
$primaryDVar  = css_var($cssRaw, '--primary-dark', '#355a7c');
$borderVar    = css_var($cssRaw, '--border-color', $primaryDVar);

$COLORS = [
  'bg'          => to_hex($bgVar, '#0f0f0f'),
  'text'        => to_hex($textVar, '#eeeeee'),
  'primary'     => to_hex($primaryVar, '#8cc8ff'),
  'primaryDark' => to_hex($primaryDVar, '#355a7c'),
  'border'      => to_hex($borderVar, '#444444'),
];

/* ---------- Dompdf ? -> PDF thémé ---------- */
$dompdfAvailable = false;
if (class_exists('\\Dompdf\\Dompdf')) $dompdfAvailable = true;
else {
  $autoload = __DIR__ . "/../../vendor/autoload.php";
  if (is_file($autoload)) { require_once $autoload; $dompdfAvailable = class_exists('\\Dompdf\\Dompdf'); }
}

if ($dompdfAvailable){
  // CSS thémé sans variables (Dompdf ne gère pas var())
  $pdfCss = '
    <style>
      body{font-family:DejaVu Sans, Arial, sans-serif;font-size:12px;color:'.$COLORS['text'].';background:'.$COLORS['bg'].'}
      h1.inv-title{font-size:18px;margin:0 0 10px;color:'.$COLORS['text'].'}
      table.inv-table{border-collapse:collapse;width:100%}
      .inv-th{padding:6px;border:1px solid '.$COLORS['border'].';background:'.$COLORS['primaryDark'].';color:'.$COLORS['text'].';text-align:left}
      .inv-td{padding:6px;border:1px solid '.$COLORS['border'].';color:'.$COLORS['text'].';background:transparent}
    </style>';
  $html = $pdfCss . $bodyHtml;

  $dompdf = new \Dompdf\Dompdf();
  $dompdf->loadHtml($html);
  $dompdf->setPaper('A4', 'landscape');
  $dompdf->render();
  $pdf = $dompdf->output();

  header('Content-Type: application/pdf');
  header('Content-Length: '.strlen($pdf));
  header('Content-Disposition: '.($dl?'attachment':'inline').'; filename="'.$fname.'"');
  echo $pdf; exit;
}

/* ---------- Fallback HTML (dans l’iframe) : on charge directement le CSS du thème ---------- */
header('Content-Type:text/html; charset=utf-8');
?>
<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8">
<title><?=h($title)?></title>
<link rel="stylesheet" href="<?=h($themeCssHref)?>">
<style>
  body{padding:16px; background:var(--bg, <?=h($COLORS['bg'])?>); color:var(--text-color, <?=h($COLORS['text'])?>); font-family:Arial, sans-serif}
  h1.inv-title{color:var(--text-color, <?=h($COLORS['text'])?>); font-size:18px; margin:0 0 12px}
  table.inv-table{width:100%; border-collapse:collapse;}
  .inv-th{padding:8px; border:1px solid var(--border-color, <?=h($COLORS['border'])?>);
         background: var(--primary-dark, <?=h($COLORS['primaryDark'])?>); color:var(--text-color, <?=h($COLORS['text'])?>); text-align:left}
  .inv-td{padding:6px; border:1px solid var(--border-color, <?=h($COLORS['border'])?>); background:transparent; color:var(--text-color, <?=h($COLORS['text'])?>)}
  @media print { body{padding:0} }
</style>
</head><body>
<?=$bodyHtml?>
</body></html>
