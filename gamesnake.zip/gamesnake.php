<?php
// domydesk/modules/gamesnake/gamesnake.php
if (session_status() === PHP_SESSION_NONE) session_start();
$user = $_SESSION['user']['email'] ?? '';

/* ================== API SCORES (AJAX) ================== */
if (isset($_GET['snake_api']) && $user) {
    header('Content-Type: application/json; charset=utf-8');

    $baseDir = __DIR__ . "/../../users/profiles/$user/Games/snake/";
    if (!is_dir($baseDir)) {
        @mkdir($baseDir, 0775, true);
    }

    $scoresFile = $baseDir . "scores_single.json";
    $scores = [];
    if (is_file($scoresFile)) {
        $json = file_get_contents($scoresFile);
        $tmp = json_decode($json, true);
        if (is_array($tmp)) $scores = $tmp;
    }

    $action = $_GET['snake_api'];

    if ($action === 'save' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $raw = file_get_contents('php://input');
        $data = json_decode($raw, true);
        $score = isset($data['score']) ? (int)$data['score'] : 0;
        $duration = isset($data['duration']) ? (int)$data['duration'] : 0;

        if ($score > 0) {
            array_unshift($scores, [
                'score'    => $score,
                'duration' => $duration,
                'time'     => date('Y-m-d H:i:s'),
            ]);
            // Limite à 50 entrées
            $scores = array_slice($scores, 0, 50);
            file_put_contents($scoresFile, json_encode($scores, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }
        echo json_encode(['ok' => true]);
        exit;
    }

    if ($action === 'list') {
        echo json_encode(['ok' => true, 'scores' => $scores]);
        exit;
    }

    echo json_encode(['ok' => false, 'error' => 'Action invalide']);
    exit;
}

// URL API pour les appels fetch depuis dashboard.php
$apiBase = 'modules/gamesnake/gamesnake.php';
?>
<!-- ================== HTML / CSS MODULE GAMESNAKE ================== -->
<div class="gamesnake-wrapper" data-api="<?php echo htmlspecialchars($apiBase, ENT_QUOTES, 'UTF-8'); ?>">
<div class="gamesnake-header">
    <div class="gamesnake-title">🐍 GameSnake</div>

    <div class="gamesnake-actions">
        <button id="gamesnake-scan" class="gamesnake-small-btn">🔍 Scan</button>
        <button id="gamesnake-duel" class="gamesnake-small-btn">⚔️ Duel</button>
    </div>

    <div class="gamesnake-stats">
        <span>Score : <span id="gamesnake-score">0</span></span>
        <span>Meilleur : <span id="gamesnake-best">0</span></span>
        <span>Vitesse : <span id="gamesnake-speed">1</span>x</span>
    </div>
</div>

    <div class="gamesnake-controls">
        <button type="button" id="gamesnake-btn-start">Nouvelle partie</button>
        <button type="button" id="gamesnake-btn-pause">Pause</button>
        <button type="button" id="gamesnake-btn-speed">+ Vitesse</button>
        <span class="gamesnake-helper">Flèches ou ZQSD / WASD.</span>
    </div>

    <div class="gamesnake-main">
        <div class="gamesnake-canvas-container">
            <canvas id="gamesnake-canvas"></canvas>
        </div>
        <div class="gamesnake-scores">
            <div class="gamesnake-scores-title">Dernières parties</div>
            <div id="gamesnake-scores-list" class="gamesnake-scores-list">
                <div class="gamesnake-score-line gamesnake-score-empty">Aucune partie enregistrée.</div>
            </div>
        </div>
    </div>

    <div class="gamesnake-footer">
        <span>Astuce : ne touche ni les murs, ni ta propre queue.</span>
    </div>
</div>

<style>
/* ================== STYLES SCOPÉS AU MODULE GAMESNAKE ================== */
.gamesnake-wrapper {
    font-family: inherit;
    color: inherit;
    background: rgba(0,0,0,0.25);
    border-radius: 8px;
    padding: 10px;
    box-sizing: border-box;
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.gamesnake-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 8px;
    font-size: 0.9rem;
}

.gamesnake-title {
    font-weight: 600;
}

.gamesnake-stats {
    display: flex;
    gap: 12px;
    font-size: 0.85rem;
}

.gamesnake-controls {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
    font-size: 0.8rem;
}

.gamesnake-controls button {
    border: none;
    border-radius: 999px;
    padding: 4px 10px;
    cursor: pointer;
    font-size: 0.8rem;
    background: rgba(255,255,255,0.1);
    color: inherit;
    transition: transform 0.1s ease, background 0.1s ease;
}
.gamesnake-controls button:hover {
    transform: translateY(-1px);
    background: rgba(255,255,255,0.18);
}

.gamesnake-helper {
    opacity: 0.7;
}

/* zone principale : canvas + scores */
.gamesnake-main {
    flex: 1;
    display: flex;
    gap: 8px;
    min-height: 120px;
}

.gamesnake-canvas-container {
    flex: 3;
    display: flex;
    align-items: center;
    justify-content: center;
    min-width: 0;
}

#gamesnake-canvas {
    width: 100%;
    height: 100%;
    max-width: 500px;
    max-height: 500px;
    background: rgba(0,0,0,0.4);
    border-radius: 6px;
    display: block;
}

/* panneau scores */
.gamesnake-scores {
    flex: 2;
    min-width: 160px;
    max-width: 260px;
    background: rgba(0,0,0,0.35);
    border-radius: 6px;
    padding: 6px;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    font-size: 0.75rem;
    gap: 4px;
}

.gamesnake-scores-title {
    font-weight: 600;
    font-size: 0.8rem;
    margin-bottom: 2px;
}

.gamesnake-scores-list {
    flex: 1;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.gamesnake-score-line {
    display: flex;
    justify-content: space-between;
    gap: 6px;
    background: rgba(255,255,255,0.03);
    border-radius: 4px;
    padding: 2px 4px;
}

.gamesnake-score-line span {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.gamesnake-score-empty {
    opacity: 0.7;
}

.gamesnake-footer {
    font-size: 0.75rem;
    opacity: 0.7;
}

/* responsive : si trop étroit, scores en dessous */
@media (max-width: 600px) {
    .gamesnake-main {
        flex-direction: column;
    }
    .gamesnake-scores {
        max-width: none;
        width: 100%;
    }
	.gamesnake-actions {
    display: flex;
    gap: 8px;
    align-items: center;
}

.gamesnake-small-btn {
    border: none;
    border-radius: 999px;
    padding: 4px 12px;
    font-size: 0.75rem;
    cursor: pointer;
    background: rgba(255,255,255,0.08);
    color: inherit;
    transition: 0.15s ease;
}

.gamesnake-small-btn:hover {
    background: rgba(255,255,255,0.16);
    transform: translateY(-1px);
}

}
</style>

<!-- ================== SCRIPT JS MODULE GAMESNAKE ================== -->
<script>
(function() {
    const wrapper  = document.querySelector('.gamesnake-wrapper');
    const apiBase  = wrapper ? wrapper.getAttribute('data-api') : null;

    const canvas   = document.getElementById('gamesnake-canvas');
    const ctx      = canvas.getContext('2d');
    const scoreEl  = document.getElementById('gamesnake-score');
    const bestEl   = document.getElementById('gamesnake-best');
    const speedEl  = document.getElementById('gamesnake-speed');
    const btnStart = document.getElementById('gamesnake-btn-start');
    const btnPause = document.getElementById('gamesnake-btn-pause');
    const btnSpeed = document.getElementById('gamesnake-btn-speed');
    const listEl   = document.getElementById('gamesnake-scores-list');

    const GRID_SIZE = 20;
    let tileSize    = 20;
    let snake       = [];
    let direction   = { x: 1, y: 0 };
    let food        = { x: 5, y: 5 };
    let score       = 0;
    let best        = 0;
    let running     = false;
    let paused      = false;
    let baseSpeed   = 120;
    let speedFactor = 1;
    let lastTime    = 0;
    let accum       = 0;
    let startTime   = 0; // durée de la partie (ms)

    const STORAGE_KEY = 'gamesnake-best-score';
    const bestStored  = window.localStorage ? localStorage.getItem(STORAGE_KEY) : null;
    if (bestStored && !isNaN(bestStored)) {
        best = parseInt(bestStored, 10) || 0;
        bestEl.textContent = best;
    }

    // ----------------- Son Game Over -----------------
    let audioCtx = null;
    function playGameOverSound() {
        try {
            if (!audioCtx) {
                audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            }
            const osc  = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.type = 'square';
            osc.frequency.setValueAtTime(220, audioCtx.currentTime);
            gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.start();
            osc.frequency.exponentialRampToValueAtTime(110, audioCtx.currentTime + 0.25);
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.25);
            osc.stop(audioCtx.currentTime + 0.25);
        } catch (e) {}
    }

    // ----------------- Canvas -----------------
    function resizeCanvas() {
        if (!canvas) return;
        const container = canvas.parentElement;
        if (!container) return;
        const size = Math.min(container.clientWidth || 300, container.clientHeight || 300);
        const finalSize = size > 0 ? size : 300;
        canvas.width = finalSize;
        canvas.height = finalSize;
        tileSize = Math.floor(finalSize / GRID_SIZE);
    }
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // ----------------- Partie -----------------
    function newGame() {
        score = 0;
        scoreEl.textContent = score;
        speedFactor = 1;
        speedEl.textContent = speedFactor.toFixed(1);
        direction = { x: 1, y: 0 };

        snake = [
            { x: 5, y: 10 },
            { x: 4, y: 10 },
            { x: 3, y: 10 }
        ];
        placeFood();
        running = true;
        paused  = false;
        btnPause.textContent = 'Pause';
        startTime = performance.now();
    }

    function placeFood() {
        let valid = false;
        while (!valid) {
            const x = Math.floor(Math.random() * GRID_SIZE);
            const y = Math.floor(Math.random() * GRID_SIZE);
            const collision = snake.some(seg => seg.x === x && seg.y === y);
            if (!collision) {
                food.x = x;
                food.y = y;
                valid = true;
            }
        }
    }

    function update(dt) {
        if (!running || paused) return;

        accum += dt;
        const interval = baseSpeed / speedFactor;
        if (accum < interval) return;
        accum = 0;

        const head = snake[0];
        const newHead = {
            x: head.x + direction.x,
            y: head.y + direction.y
        };

        // Collision murs
        if (
            newHead.x < 0 || newHead.x >= GRID_SIZE ||
            newHead.y < 0 || newHead.y >= GRID_SIZE
        ) {
            gameOver();
            return;
        }

        // Collision avec soi-même
        if (snake.some(seg => seg.x === newHead.x && seg.y === newHead.y)) {
            gameOver();
            return;
        }

        snake.unshift(newHead);

        // Manger
        if (newHead.x === food.x && newHead.y === food.y) {
            score += 10;
            scoreEl.textContent = score;
            if (score > best) {
                best = score;
                bestEl.textContent = best;
                if (window.localStorage) {
                    localStorage.setItem(STORAGE_KEY, best);
                }
            }
            placeFood();
        } else {
            snake.pop();
        }
    }

    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Food
        ctx.fillStyle = '#ffcc33';
        ctx.beginPath();
        ctx.arc(
            (food.x + 0.5) * tileSize,
            (food.y + 0.5) * tileSize,
            tileSize * 0.35,
            0, Math.PI * 2
        );
        ctx.fill();

        // Snake
        for (let i = 0; i < snake.length; i++) {
            const seg = snake[i];
            const isHead = (i === 0);
            ctx.fillStyle = isHead ? '#4caf50' : '#81c784';
            const x = seg.x * tileSize;
            const y = seg.y * tileSize;
            const padding = 2;
            ctx.fillRect(
                x + padding,
                y + padding,
                tileSize - padding * 2,
                tileSize - padding * 2
            );
        }

        if (!running) {
            ctx.fillStyle = 'rgba(0,0,0,0.6)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold ' + Math.floor(canvas.width / 18) + 'px sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText('Game Over', canvas.width / 2, canvas.height / 2 - 10);
            ctx.font = 'normal ' + Math.floor(canvas.width / 26) + 'px sans-serif';
            ctx.fillText('Clique "Nouvelle partie"', canvas.width / 2, canvas.height / 2 + 20);
        }
    }

    function gameLoop(timestamp) {
        const dt = timestamp - lastTime;
        lastTime = timestamp;

        update(dt);
        draw();

        requestAnimationFrame(gameLoop);
    }
    requestAnimationFrame(gameLoop);

    function gameOver() {
        if (!running) return;
        running = false;
        playGameOverSound();
        saveScore();
    }
	
	// === Boutons Scan & Duel (UI uniquement) ===
const btnScan = document.getElementById('gamesnake-scan');
const btnDuel = document.getElementById('gamesnake-duel');

btnScan.addEventListener('click', () => {
    alert("🔍 Scan des joueurs (bientôt disponible)");
});

btnDuel.addEventListener('click', () => {
    alert("⚔️ Mode Duel — Disponible en Février ⭐");
	alert("⚔️ Une Zone, deux objectifs à travers la surface. ⚔️");
});

    // ----------------- Sauvegarde & affichage des scores -----------------
    function saveScore() {
        if (!window.fetch || score <= 0 || !apiBase) return;
        const duration = startTime ? Math.round(performance.now() - startTime) : 0;
        fetch(apiBase + '?snake_api=save', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ score, duration })
        }).then(() => {
            loadScores();
        }).catch(() => {});
    }

    function loadScores() {
        if (!window.fetch || !apiBase) return;
        fetch(apiBase + '?snake_api=list')
            .then(r => r.json())
            .then(data => {
                if (!data.ok || !Array.isArray(data.scores)) return;
                const scores = data.scores;
                listEl.innerHTML = '';
                if (!scores.length) {
                    const line = document.createElement('div');
                    line.className = 'gamesnake-score-line gamesnake-score-empty';
                    line.textContent = 'Aucune partie enregistrée.';
                    listEl.appendChild(line);
                    return;
                }
                scores.slice(0,5).forEach(item => {
                    const line = document.createElement('div');
                    line.className = 'gamesnake-score-line';
                    const left = document.createElement('span');
                    const right = document.createElement('span');
                    left.textContent  = item.time || '';
                    right.textContent = (item.score || 0) + ' pts';
                    line.appendChild(left);
                    line.appendChild(right);
                    listEl.appendChild(line);
                });
            })
            .catch(() => {});
    }
    loadScores();

    // ----------------- CONTROLES CLAVIER (Flèches + ZQSD + WASD) -----------------
    window.addEventListener('keydown', function(e) {
        const key = e.key;
        const k   = key.toLowerCase();

        if (!running && key === 'Enter') {
            newGame();
            return;
        }

        if ((key === 'ArrowUp' || k === 'z' || k === 'w') && direction.y !== 1) {
            direction = { x: 0, y: -1 };
        }
        else if ((key === 'ArrowDown' || k === 's') && direction.y !== -1) {
            direction = { x: 0, y: 1 };
        }
        else if ((key === 'ArrowLeft' || k === 'q' || k === 'a') && direction.x !== 1) {
            direction = { x: -1, y: 0 };
        }
        else if ((key === 'ArrowRight' || k === 'd') && direction.x !== -1) {
            direction = { x: 1, y: 0 };
        }
    });

    // ----------------- Boutons -----------------
    btnStart.addEventListener('click', function() {
        newGame();
    });

    btnPause.addEventListener('click', function() {
        if (!running) return;
        paused = !paused;
        btnPause.textContent = paused ? 'Reprendre' : 'Pause';
    });

    btnSpeed.addEventListener('click', function() {
        speedFactor += 0.5;
        if (speedFactor > 3) speedFactor = 1;
        speedEl.textContent = speedFactor.toFixed(1);
    });

})();
</script>
