<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) exit;

$cfgFile = __DIR__ . "/../../users/profiles/{$email}/meteo.json";

// === Lecture des données météo
$meteoData = [];
if (file_exists($cfgFile)) {
    $decoded = json_decode(file_get_contents($cfgFile), true);
    if (isset($decoded['ville'])) {
        $meteoData[] = $decoded; 
    } elseif (is_array($decoded)) {
        $meteoData = $decoded;
    }
}
// === TRAITEMENT DES FORMULAIRES (AJOUT / SUPPRESSION)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $changed = false;

    if (isset($_POST['ville'], $_POST['lang'], $_POST['unite'])) {
        $ville = trim($_POST['ville']);
        $lang  = $_POST['lang'];
        $unite = $_POST['unite'];

        $exists = false;
        foreach ($meteoData as $item) {
            if ($item['ville'] === $ville && $item['lang'] === $lang && $item['unite'] === $unite) {
                $exists = true;
                break;
            }
        }

        if (!$exists) {
            $meteoData[] = ['ville' => $ville, 'lang' => $lang, 'unite' => $unite];
            $changed = true;
        }
    }

    if (isset($_POST['delete']) && is_numeric($_POST['delete'])) {
        unset($meteoData[(int)$_POST['delete']]);
        $meteoData = array_values($meteoData);
        $changed = true;
    }

    if ($changed) {
        file_put_contents($cfgFile, json_encode($meteoData, JSON_PRETTY_PRINT));
    }

    echo "<script>location.href = location.href;</script>";
    exit;
}
?>

<div class="section">
  <h2>🌤️ MODULE METEO</h2>
  <form method="post" style="display:flex;flex-wrap:wrap;gap:10px;align-items:center">
    <input type="text" name="ville" placeholder="Ex: Annecy, France" required>
    <select name="lang">
      <option value="fr">fr</option>
      <option value="en">en</option>
    </select>
    <select name="unite">
      <option value="metric">Celsius</option>
      <option value="imperial">Fahrenheit</option>
    </select>
    <button>Ajouter</button>
  </form>

  <table style="margin-top:10px;width:100%;border-collapse:collapse">
    <tr style="background:#222;color:#fff">
      <th>Ville</th><th>Langue</th><th>Unité</th><th>Action</th>
    </tr>
    <?php
    if (!empty($meteoData)) {
        foreach ($meteoData as $index => $item) {
            echo "<tr>";
            echo "<td>".htmlspecialchars($item['ville'] ?? '')."</td>";
            echo "<td>".htmlspecialchars($item['lang'] ?? '')."</td>";
            echo "<td>".htmlspecialchars($item['unite'] ?? '')."</td>";
            echo "<td><form method='post' style='margin:0'><button name='delete' value='$index'>❌</button></form></td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='4'>Aucune ville configurée.</td></tr>";
    }
    ?>
  </table>
</div>
