<?php
session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) exit("Non connecté");

$profilePath = __DIR__ . "/../../users/profiles/$email/meteo.json";

$config = file_exists($profilePath) ? json_decode(file_get_contents($profilePath), true) : [
    "villes" => [], "unite" => "metric", "lang" => "fr"
];

$villes = $config['villes'] ?? [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_POST['newville'])) {
        $new = trim($_POST['newville']);
        if (!in_array($new, $villes)) $villes[] = $new;
    }
    if (!empty($_POST['delete'])) {
        $villes = array_values(array_filter($villes, fn($v) => $v !== $_POST['delete']));
    }
    $config['villes'] = $villes;
    file_put_contents($profilePath, json_encode($config, JSON_PRETTY_PRINT));
}

header("Location: ../../dashboard.php");
exit;
