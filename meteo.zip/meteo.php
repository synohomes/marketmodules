<?php
session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) return;

$cfgFile = __DIR__ . "/../../users/profiles/$email/meteo.json";
$cfg = is_file($cfgFile) ? json_decode(file_get_contents($cfgFile), true) : [];
if (!is_array($cfg)) $cfg = [];

echo "<div class='module-content'>";
foreach ($cfg as $entry) {
    $ville = $entry['ville'] ?? '';
    $lang  = $entry['lang'] ?? 'fr';

    $url = "https://wttr.in/" . urlencode($ville) . "?format=j1";
    $json = @file_get_contents($url);
    if (!$json) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $json = curl_exec($ch);
        curl_close($ch);
    }

    $data = json_decode($json, true);
    if (!isset($data['current_condition'][0])) continue;

    $c = $data['current_condition'][0];
    $desc     = $c['lang_' . $lang][0]['value'] ?? $c['weatherDesc'][0]['value'] ?? '';
    $temp     = $c['temp_C'] ?? '??';
    $wind     = $c['windspeedKmph'] ?? '?';
    $humidity = $c['humidity'] ?? '?';

    echo "<div style='display:flex;align-items:center;gap:10px;margin-bottom:8px;background:#222;padding:6px;border-radius:6px'>
        <div>
            <strong>" . htmlspecialchars($ville) . "</strong><br>
            🌡 {$temp}°C | 💨 {$wind} km/h | 💧 {$humidity}%<br>
            <small>" . htmlspecialchars($desc) . "</small>
        </div>
    </div>";
}
echo "</div>";
