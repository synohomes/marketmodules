<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/ha_store.php';

function dmd_ha_cfg_h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function dmd_ha_cfg_asset_ver(string $file): string { $p = __DIR__ . '/' . $file; return file_exists($p) ? (string)filemtime($p) : (string)time(); }
function dmd_ha_cfg_label(string $entity): string {
    $name = preg_replace('/^[^.]+\./', '', (string)$entity);
    $name = str_replace(['_', '-'], ' ', $name);
    return mb_convert_case($name, MB_CASE_TITLE, 'UTF-8');
}
function dmd_ha_cfg_domain(string $entity): string { return strstr($entity, '.', true) ?: 'entity'; }

$all = ha_load_all();
$instances = $all['instances'] ?? [];
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id = trim((string)($_POST['id'] ?? ''));
        if ($id === '') $id = bin2hex(random_bytes(4));

        $name = trim((string)($_POST['name'] ?? '')) ?: ('Home Assistant ' . $id);
        $base = rtrim(trim((string)($_POST['base_url'] ?? '')), '/');
        $token = trim((string)($_POST['token'] ?? ''));
        $tokenEnc = $instances[$id]['token_enc'] ?? '';
        if ($token !== '') $tokenEnc = ha_encrypt($token);

        $cams = array_values(array_unique(array_filter(array_map('trim', explode(',', (string)($_POST['cameras_list'] ?? ''))))));
        $ents = array_values(array_unique(array_filter(array_map('trim', explode(',', (string)($_POST['entities_list'] ?? ''))))));

        $instances[$id] = [
            'name'      => $name,
            'base_url'  => $base,
            'token_enc' => $tokenEnc,
            'cameras'   => $cams,
            'sensors'   => $ents,
        ];
        $all['instances'] = $instances;
        ha_save_all($all);
        $message = 'Instance enregistrée.';
        $messageType = 'success';
        $_GET['id'] = $id;
    }

    if ($action === 'delete') {
        $id = trim((string)($_POST['id'] ?? ''));
        if ($id !== '' && isset($instances[$id])) {
            unset($instances[$id]);
            $all['instances'] = $instances;
            ha_save_all($all);
            $message = 'Instance supprimée.';
            $messageType = 'danger';
        }
        $_GET['id'] = array_key_first($instances) ?: '';
    }

    $all = ha_load_all();
    $instances = $all['instances'] ?? [];
}

$selectedId = isset($_GET['id']) ? trim((string)$_GET['id']) : (array_key_first($instances) ?: '');
$isNew = $selectedId === '' || !isset($instances[$selectedId]);
$current = $isNew ? [
    'name' => '',
    'base_url' => '',
    'token_enc' => '',
    'cameras' => [],
    'sensors' => [],
] : $instances[$selectedId];

$tokenPlain = !empty($current['token_enc']) ? ha_decrypt($current['token_enc']) : '';
$savedCams = array_values($current['cameras'] ?? []);
$savedEnts = array_values($current['sensors'] ?? []);
$totalCams = 0;
$totalEnts = 0;
foreach ($instances as $inst) {
    $totalCams += count($inst['cameras'] ?? []);
    $totalEnts += count($inst['sensors'] ?? []);
}
?>
<link rel="stylesheet" href="modules/ha/ha.css?v=<?=dmd_ha_cfg_asset_ver('ha.css')?>">
<div class="dmd-ha dmd-ha-config" data-module="dmd-ha-config">
  <aside class="dmd-ha-panel dmd-ha-side">
    <div class="dmd-ha-side-head">
      <div class="dmd-ha-kicker">Configuration</div>
      <h2 class="dmd-ha-title">DMD-HA</h2>
      <p class="dmd-ha-subtitle">Instances Home Assistant et sélection dashboard.</p>
      <div class="dmd-ha-metrics dmd-ha-config-metrics">
        <span class="dmd-ha-pill"><?=count($instances)?> instance<?=count($instances)>1?'s':''?></span>
        <span class="dmd-ha-pill"><?=$totalCams?> cam</span>
        <span class="dmd-ha-pill"><?=$totalEnts?> entités</span>
      </div>
    </div>
    <div class="dmd-ha-side-list">
      <a class="dmd-ha-btn" href="?module=ha&id=">Nouvelle instance</a>
      <?php if (!$instances): ?>
        <div class="dmd-ha-preview">Aucune instance.</div>
      <?php endif; ?>
      <?php foreach ($instances as $id => $inst): ?>
        <a class="dmd-ha-instance-link <?=$id === $selectedId ? 'active' : ''?>" href="?module=ha&id=<?=urlencode($id)?>">
          <strong><?=dmd_ha_cfg_h($inst['name'] ?: $id)?></strong>
          <span><?=dmd_ha_cfg_h($inst['base_url'] ?? '')?></span>
        </a>
      <?php endforeach; ?>
    </div>
  </aside>

  <main class="dmd-ha-panel dmd-ha-main">
    <div class="dmd-ha-config-head">
      <div>
        <div class="dmd-ha-kicker"><?=$isNew ? 'Nouvelle instance' : 'Instance sélectionnée'?></div>
        <h2 class="dmd-ha-title"><?=dmd_ha_cfg_h($current['name'] ?: 'Home Assistant')?></h2>
      </div>
      <?php if ($message): ?>
        <div class="dmd-ha-badge <?=dmd_ha_cfg_h($messageType)?>"><?=dmd_ha_cfg_h($message)?></div>
      <?php endif; ?>
    </div>

    <form id="dmd-ha-form" class="dmd-ha-form" method="post">
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" value="<?=dmd_ha_cfg_h($isNew ? '' : $selectedId)?>">
      <input type="hidden" name="cameras_list" id="dmd-ha-cameras-list">
      <input type="hidden" name="entities_list" id="dmd-ha-entities-list">

      <section class="dmd-ha-form-section dmd-ha-connection-card">
        <div class="dmd-ha-form-titleline">
          <h3>Connexion</h3>
          <span class="dmd-ha-form-note">Token stocké chiffré</span>
        </div>
        <div class="dmd-ha-field-grid compact">
          <div class="dmd-ha-field">
            <label for="dmd-ha-name">Nom</label>
            <input id="dmd-ha-name" type="text" name="name" value="<?=dmd_ha_cfg_h($current['name'] ?? '')?>" placeholder="Maison, Bureau, NASDEV...">
          </div>
          <div class="dmd-ha-field">
            <label for="dmd-ha-url">URL</label>
            <input id="dmd-ha-url" type="text" name="base_url" value="<?=dmd_ha_cfg_h($current['base_url'] ?? '')?>" placeholder="http://10.0.0.10:8123">
          </div>
          <div class="dmd-ha-field full">
            <label for="dmd-ha-token">Long-Lived Token</label>
            <input id="dmd-ha-token" type="password" name="token" value="<?=dmd_ha_cfg_h($tokenPlain)?>" placeholder="Coller le token Home Assistant">
          </div>
        </div>
        <div class="dmd-ha-actions dmd-ha-form-actions">
          <button type="button" id="dmd-ha-test" class="dmd-ha-btn">Tester</button>
          <button type="button" id="dmd-ha-load" class="dmd-ha-btn">Charger les entités</button>
          <button type="submit" class="dmd-ha-btn primary">Enregistrer</button>
          <?php if (!$isNew): ?>
            <button type="button" id="dmd-ha-delete-btn" class="dmd-ha-btn danger">Supprimer</button>
          <?php endif; ?>
          <span id="dmd-ha-status" class="dmd-ha-status"></span>
        </div>
      </section>

      <section class="dmd-ha-form-section">
        <div class="dmd-ha-form-titleline">
          <h3>Caméras <span class="dmd-ha-count" id="dmd-ha-camera-count">0</span></h3>
          <div class="dmd-ha-inline-actions">
            <button type="button" class="dmd-ha-btn small" data-select="cameras" data-mode="all">Tout</button>
            <button type="button" class="dmd-ha-btn small" data-select="cameras" data-mode="none">Aucun</button>
            <button type="button" class="dmd-ha-btn small" data-select="cameras" data-mode="invert">Inverser</button>
          </div>
        </div>
        <div class="dmd-ha-picker-toolbar table-mode">
          <input id="dmd-ha-camera-filter" class="dmd-ha-search" type="search" placeholder="Rechercher une caméra...">
        </div>
        <div class="dmd-ha-table-wrap">
          <table class="dmd-ha-table" id="dmd-ha-camera-table">
            <thead><tr><th></th><th>Nom</th><th>Domaine</th><th>Valeur</th><th>Entity ID</th></tr></thead>
            <tbody id="dmd-ha-camera-grid"></tbody>
          </table>
        </div>
      </section>

      <section class="dmd-ha-form-section">
        <div class="dmd-ha-form-titleline">
          <h3>Entités <span class="dmd-ha-count" id="dmd-ha-entity-count">0</span></h3>
          <div class="dmd-ha-inline-actions">
            <button type="button" class="dmd-ha-btn small" data-select="entities" data-mode="all">Tout</button>
            <button type="button" class="dmd-ha-btn small" data-select="entities" data-mode="none">Aucun</button>
            <button type="button" class="dmd-ha-btn small" data-select="entities" data-mode="invert">Inverser</button>
          </div>
        </div>
        <div class="dmd-ha-picker-toolbar table-mode two">
          <input id="dmd-ha-entity-filter" class="dmd-ha-search" type="search" placeholder="Rechercher capteur, bouton, météo, NAS...">
          <select id="dmd-ha-domain-filter" class="dmd-ha-search"><option value="">Tous les domaines</option></select>
        </div>
        <div class="dmd-ha-table-wrap big">
          <table class="dmd-ha-table" id="dmd-ha-entity-table">
            <thead><tr><th></th><th>Nom</th><th>Domaine</th><th>Valeur</th><th>Entity ID</th></tr></thead>
            <tbody id="dmd-ha-entity-grid"></tbody>
          </table>
        </div>
      </section>

      <section class="dmd-ha-form-section">
        <div class="dmd-ha-form-titleline"><h3>Catalogue</h3></div>
        <div id="dmd-ha-preview" class="dmd-ha-preview">Charge les entités pour voir les intégrations détectées.</div>
      </section>
    </form>

    <?php if (!$isNew): ?>
      <form id="dmd-ha-delete-form" method="post" class="dmd-ha-hidden">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" value="<?=dmd_ha_cfg_h($selectedId)?>">
      </form>
    <?php endif; ?>
  </main>
</div>

<script>
(() => {
  const savedCameras = new Set(<?=json_encode($savedCams, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)?>);
  const savedEntities = new Set(<?=json_encode($savedEnts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)?>);
  const apiCandidates = ['modules/ha/ha_api.php', 'ha/ha_api.php', 'ha_api.php', '../modules/ha/ha_api.php'];
  let apiBase = null;
  let cameras = [...savedCameras].map(id => ({id, label:niceLabel(id), domain:'camera', value:'—', platform:'sélection'}));
  let entities = [...savedEntities].map(id => ({id, label:niceLabel(id), domain:domainOf(id), value:'—', platform:'sélection'}));

  const el = {
    url: document.getElementById('dmd-ha-url'),
    token: document.getElementById('dmd-ha-token'),
    status: document.getElementById('dmd-ha-status'),
    cameraGrid: document.getElementById('dmd-ha-camera-grid'),
    entityGrid: document.getElementById('dmd-ha-entity-grid'),
    cameraFilter: document.getElementById('dmd-ha-camera-filter'),
    entityFilter: document.getElementById('dmd-ha-entity-filter'),
    domainFilter: document.getElementById('dmd-ha-domain-filter'),
    cameraCount: document.getElementById('dmd-ha-camera-count'),
    entityCount: document.getElementById('dmd-ha-entity-count'),
    preview: document.getElementById('dmd-ha-preview'),
    cameraHidden: document.getElementById('dmd-ha-cameras-list'),
    entityHidden: document.getElementById('dmd-ha-entities-list'),
    form: document.getElementById('dmd-ha-form')
  };

  function domainOf(id){ return String(id || '').split('.')[0] || 'entity'; }
  function niceLabel(id){ return String(id || '').replace(/^[^.]+\./, '').replace(/[_-]/g, ' ').replace(/\b\w/g, c => c.toUpperCase()); }
  function escapeHtml(value){ return String(value ?? '').replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[char])); }
  function setStatus(text){ el.status.textContent = text || ''; }
  function params(){
    const base = (el.url.value || '').trim();
    const token = (el.token.value || '').trim();
    if (!base || !token) throw new Error('Renseigne l’URL et le token.');
    return {base, token};
  }
  async function pickApi(){
    if (apiBase) return apiBase;
    for (const candidate of apiCandidates) {
      try {
        const response = await fetch(candidate, {method:'GET', cache:'no-store'});
        if ([200, 400, 403].includes(response.status)) { apiBase = candidate; return candidate; }
      } catch (e) {}
    }
    throw new Error('ha_api.php introuvable');
  }

  function cleanNumber(value, maxDecimals = 2){
    const n = Number(value);
    if (!Number.isFinite(n)) return String(value ?? '');
    const decimals = Math.abs(n) >= 100 ? 0 : maxDecimals;
    return new Intl.NumberFormat('fr-FR', {maximumFractionDigits: decimals}).format(n);
  }
  function formatStorage(value, unit){
    let n = Number(String(value).replace(',', '.'));
    if (!Number.isFinite(n)) return `${value ?? '—'} ${unit || ''}`.trim();
    const u = String(unit || '').trim().toLowerCase();
    if (['mb','mib','mo'].includes(u)) return Math.abs(n) >= 1024 ? `${cleanNumber(n/1024,2)} Go` : `${cleanNumber(n,1)} Mo`;
    if (['gb','gib','go'].includes(u)) return `${cleanNumber(n,2)} Go`;
    if (['tb','tib','to'].includes(u)) return Math.abs(n) < 1 ? `${cleanNumber(n*1024,2)} Go` : `${cleanNumber(n,2)} To`;
    if (['b','bytes','octets'].includes(u)) return formatStorage(n/1024/1024, 'MB');
    if (['kb','kib','ko'].includes(u)) return formatStorage(n/1024, 'MB');
    return `${cleanNumber(n,2)} ${unit || ''}`.trim();
  }
  function prettyValue(raw, unit){
    const u = String(unit || '').trim();
    const lowUnit = u.toLowerCase();
    if (['mb','mib','mo','gb','gib','go','tb','tib','to','b','bytes','octets','kb','kib','ko'].includes(lowUnit)) return formatStorage(raw, u);
    const n = Number(String(raw).replace(',', '.'));
    if (Number.isFinite(n)) {
      if (u === '%') return `${cleanNumber(n,1)} %`;
      if (u) return `${cleanNumber(n,2)} ${u}`;
      return cleanNumber(n,2);
    }
    return String(raw || '—');
  }
  function itemValue(item){
    return item.value && item.value !== '—' ? item.value : '—';
  }
  function selectedIds(type){
    const grid = type === 'cameras' ? el.cameraGrid : el.entityGrid;
    return [...grid.querySelectorAll('input[type="checkbox"]:checked')].map(input => input.value);
  }
  function syncHidden(){
    el.cameraHidden.value = selectedIds('cameras').join(',');
    el.entityHidden.value = selectedIds('entities').join(',');
    el.cameraCount.textContent = selectedIds('cameras').length;
    el.entityCount.textContent = selectedIds('entities').length;
  }
  function rebuildDomainFilter(){
    const current = el.domainFilter.value;
    const domains = [...new Set(entities.map(x => x.domain || domainOf(x.id)))].sort();
    el.domainFilter.innerHTML = '<option value="">Tous les domaines</option>' + domains.map(d => `<option value="${escapeHtml(d)}">${escapeHtml(d)}</option>`).join('');
    if (domains.includes(current)) el.domainFilter.value = current;
  }
  function filterRows(type){
    const grid = type === 'cameras' ? el.cameraGrid : el.entityGrid;
    const input = type === 'cameras' ? el.cameraFilter : el.entityFilter;
    const q = (input.value || '').toLowerCase().trim();
    const domain = type === 'entities' ? (el.domainFilter.value || '') : '';
    [...grid.querySelectorAll('.dmd-ha-row')].forEach(row => {
      const haystack = (row.dataset.search || '').toLowerCase();
      const okText = !q || haystack.includes(q);
      const okDomain = !domain || row.dataset.domain === domain;
      row.style.display = okText && okDomain ? '' : 'none';
    });
  }
  function renderRows(type){
    const grid = type === 'cameras' ? el.cameraGrid : el.entityGrid;
    const list = type === 'cameras' ? cameras : entities;
    const selected = type === 'cameras' ? savedCameras : savedEntities;
    grid.innerHTML = '';
    if (!list.length) {
      grid.innerHTML = '<tr class="dmd-ha-row-empty"><td colspan="5">Aucun élément chargé.</td></tr>';
      syncHidden();
      return;
    }
    list.forEach(item => {
      const label = item.label || niceLabel(item.id);
      const domain = item.domain || domainOf(item.id);
      const platform = item.platform || 'home assistant';
      const tr = document.createElement('tr');
      tr.className = 'dmd-ha-row';
      tr.dataset.domain = domain;
      tr.dataset.search = `${label} ${item.id} ${domain} ${platform} ${itemValue(item)}`;
      tr.innerHTML = `
        <td class="check"><input type="checkbox" value="${escapeHtml(item.id)}" ${selected.has(item.id) ? 'checked' : ''}></td>
        <td class="name"><strong>${escapeHtml(label)}</strong><span>${escapeHtml(platform)}</span></td>
        <td><span class="dmd-ha-tag">${escapeHtml(domain)}</span></td>
        <td class="value">${escapeHtml(itemValue(item))}</td>
        <td class="entity"><code>${escapeHtml(item.id)}</code></td>`;
      const checkbox = tr.querySelector('input');
      checkbox.addEventListener('change', () => {
        tr.classList.toggle('is-selected', checkbox.checked);
        syncHidden();
      });
      tr.addEventListener('click', e => {
        if (e.target.tagName === 'INPUT') return;
        checkbox.checked = !checkbox.checked;
        checkbox.dispatchEvent(new Event('change'));
      });
      tr.classList.toggle('is-selected', checkbox.checked);
      grid.appendChild(tr);
    });
    if (type === 'entities') rebuildDomainFilter();
    filterRows(type);
    syncHidden();
  }
  function applySelection(type, mode){
    const grid = type === 'cameras' ? el.cameraGrid : el.entityGrid;
    [...grid.querySelectorAll('.dmd-ha-row')].forEach(row => {
      if (row.style.display === 'none') return;
      const input = row.querySelector('input[type="checkbox"]');
      if (!input) return;
      if (mode === 'all') input.checked = true;
      if (mode === 'none') input.checked = false;
      if (mode === 'invert') input.checked = !input.checked;
      row.classList.toggle('is-selected', input.checked);
    });
    syncHidden();
  }

  document.getElementById('dmd-ha-test')?.addEventListener('click', async () => {
    try {
      const {base, token} = params();
      const api = await pickApi();
      setStatus('Test en cours...');
      const response = await fetch(`${api}?a=ping&base_url=${encodeURIComponent(base)}&token=${encodeURIComponent(token)}`, {cache:'no-store'});
      const data = await response.json().catch(() => null);
      if (!response.ok) throw new Error('Connexion refusée');
      const ok = data?.api_status?.code >= 200 && data?.api_status?.code < 300;
      setStatus(ok ? 'Connexion OK.' : 'Réponse reçue, API non validée.');
    } catch (error) { setStatus(error.message || 'Erreur de connexion.'); }
  });

  document.getElementById('dmd-ha-load')?.addEventListener('click', async () => {
    try {
      const {base, token} = params();
      const api = await pickApi();
      setStatus('Chargement...');
      const response = await fetch(`${api}?a=list_by_integration&base_url=${encodeURIComponent(base)}&token=${encodeURIComponent(token)}`, {cache:'no-store'});
      const text = await response.text();
      if (!response.ok) throw new Error('Impossible de charger les entités.');
      const data = JSON.parse(text);
      const camMap = new Map();
      const entMap = new Map();
      const platforms = [];
      (data.integrations || []).forEach(group => {
        const platform = group.platform || 'home assistant';
        const count = Number(group.count || 0);
        platforms.push(`${platform} (${count})`);
        (group.cameras || []).forEach(id => camMap.set(id, {id, label:niceLabel(id), domain:'camera', value:'—', platform}));
        (group.others || []).forEach(id => entMap.set(id, {id, label:niceLabel(id), domain:domainOf(id), value:'—', platform}));
      });
      try {
        const statesRes = await fetch(`${api}?a=get_states_raw&base_url=${encodeURIComponent(base)}&token=${encodeURIComponent(token)}`, {cache:'no-store'});
        if (statesRes.ok) {
          const states = await statesRes.json();
          const rows = Array.isArray(states) ? states : Object.values(states || {});
          rows.forEach(st => {
            const id = st.entity_id;
            if (!id) return;
            const unit = st.attributes?.unit_of_measurement || st.attributes?.unit || '';
            const friendly = st.attributes?.friendly_name || niceLabel(id);
            const row = {id, label:friendly, domain:domainOf(id), value:prettyValue(st.state, unit), platform:'home assistant'};
            if (domainOf(id) === 'camera') camMap.set(id, {...row, domain:'camera'});
            else if (entMap.has(id)) entMap.set(id, {...entMap.get(id), ...row});
          });
        }
      } catch(e) {}
      cameras = [...camMap.values()].sort((a,b) => a.label.localeCompare(b.label));
      entities = [...entMap.values()].sort((a,b) => a.domain.localeCompare(b.domain) || a.label.localeCompare(b.label));
      [...savedCameras].forEach(id => { if (!camMap.has(id)) cameras.unshift({id, label:niceLabel(id), domain:'camera', value:'—', platform:'sélection'}); });
      [...savedEntities].forEach(id => { if (!entMap.has(id)) entities.unshift({id, label:niceLabel(id), domain:domainOf(id), value:'—', platform:'sélection'}); });
      renderRows('cameras');
      renderRows('entities');
      el.preview.textContent = platforms.length ? platforms.join(' · ') : 'Catalogue chargé.';
      setStatus(`${cameras.length} caméras et ${entities.length} entités chargées.`);
    } catch (error) { setStatus(error.message || 'Erreur de chargement.'); }
  });

  el.cameraFilter?.addEventListener('input', () => filterRows('cameras'));
  el.entityFilter?.addEventListener('input', () => filterRows('entities'));
  el.domainFilter?.addEventListener('change', () => filterRows('entities'));
  document.querySelectorAll('[data-select]').forEach(button => button.addEventListener('click', () => applySelection(button.dataset.select, button.dataset.mode)));
  el.form?.addEventListener('submit', syncHidden);
  document.getElementById('dmd-ha-delete-btn')?.addEventListener('click', () => {
    if (confirm('Supprimer cette instance Home Assistant ?')) document.getElementById('dmd-ha-delete-form')?.submit();
  });

  renderRows('cameras');
  renderRows('entities');
})();
</script>
