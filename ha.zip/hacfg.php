<?php
if (session_status()===PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/ha_store.php';
function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES); }
$all = ha_load_all();
$instances = $all['instances'] ?? [];
$sel = $_GET['id'] ?? (array_key_first($instances) ?? '');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $act = $_POST['action'] ?? '';
  if ($act === 'save') {
    $id   = $_POST['id'] ?: bin2hex(random_bytes(4));
    $name = trim($_POST['name'] ?: ("HA $id"));
    $base = rtrim(trim($_POST['base_url'] ?? ''), '/');
    $tok  = trim($_POST['token'] ?? '');
    $token_enc = $instances[$id]['token_enc'] ?? '';
    if ($tok !== '') $token_enc = ha_encrypt($tok); 
    $cams = array_values(array_filter(array_map('trim', explode(',', $_POST['cameras_list'] ?? ''))));
    $ents = array_values(array_filter(array_map('trim', explode(',', $_POST['entities_list'] ?? ''))));
    $instances[$id] = [
      'name'      => $name,
      'base_url'  => $base,
      'token_enc' => $token_enc,
      'cameras'   => $cams,
      'sensors'   => $ents, 
    ];
    $all['instances'] = $instances; ha_save_all($all);
    $sel = $id;
    echo "<div style='color:#6f6;padding:6px'>✅ Instance enregistrée</div>";
  }
  if ($act === 'delete') {
    $id = $_POST['id'] ?? '';
    if ($id && isset($instances[$id])) {
      unset($instances[$id]); $all['instances'] = $instances; ha_save_all($all);
      echo "<div style='color:#f88;padding:6px'>🗑️ Instance supprimée</div>";
    }
    $sel = array_key_first($instances) ?? '';
  }
  $all = ha_load_all(); $instances = $all['instances'] ?? [];
}
$cur = ($sel && isset($instances[$sel])) ? $instances[$sel] :
       ['name'=>'','base_url'=>'','token_enc'=>'','cameras'=>[],'sensors'=>[]];
$token_plain = $cur['token_enc'] ? ha_decrypt($cur['token_enc']) : '';
$savedCams = $cur['cameras'] ?? [];
$savedEnts = $cur['sensors'] ?? [];
?>
<div class="section">
  <h2 style="margin-top:0">Home Assistant — Instances</h2>
  <form method="get" style="display:flex;gap:8px;align-items:center;margin-bottom:10px">
    <select name="id" onchange="this.form.submit()" style="padding:6px;border-radius:8px">
      <?php foreach($instances as $id=>$i): ?>
        <option value="<?=$id?>" <?=$id===$sel?'selected':''?>><?=h($i['name'] ?: $id)?></option>
      <?php endforeach; ?>
      <?php if(!$instances): ?><option value="">(aucune)</option><?php endif; ?>
    </select>
    <a href="?module=ha&id=" style="padding:6px 10px;border:1px solid rgba(255,255,255,.2);border-radius:8px;text-decoration:none">➕ Nouvelle</a>
  </form>
  <form id="ha-form" method="post" style="display:grid;gap:12px">
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?=h($sel)?>">
    <label>Nom de l’instance
      <input type="text" name="name" value="<?=h($cur['name'])?>" placeholder="Maison / Bureau" style="width:100%">
    </label>
    <label>URL Home Assistant
      <input type="text" name="base_url" value="<?=h($cur['base_url'])?>" placeholder="http://100.x.y.z:8123" style="width:100%">
    </label>
    <label>Long-Lived Token (laisse vide pour garder l’actuel)
      <input type="text" name="token" value="<?=h($token_plain)?>" placeholder="eyJ..." style="width:100%">
    </label>
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
      <button type="button" id="btn-ping" class="btn">🩺 Tester</button>
      <button type="button" id="btn-load" class="btn">🔎 Charger la liste</button>
      <button type="submit" class="btn">💾 Enregistrer</button>
      <?php if($sel && isset($instances[$sel])): ?>
        <button class="btn" form="ha-del" style="background:#7c2d2d;border:1px solid #a33">🗑️ Supprimer</button>
      <?php endif; ?>
      <small id="ha-status" style="opacity:.8"></small>
    </div>
    <div style="border:1px solid rgba(255,255,255,.12);border-radius:10px;padding:10px">
      <div style="font-weight:600;margin-bottom:8px">Sélection pour le dashboard</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
        <div>
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
            <strong>Caméras</strong>
            <input type="text" id="filter-cam" placeholder="Filtrer…" style="flex:1;padding:6px;border-radius:8px;border:1px solid rgba(255,255,255,.1)">
            <button type="button" id="cam-all"  class="btn sm">Tout</button>
            <button type="button" id="cam-none" class="btn sm">Aucun</button>
          </div>
          <select id="sel-cam" multiple size="10" style="width:100%;border-radius:8px;border:1px solid rgba(255,255,255,.1)"></select>
        </div>
        <div>
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
            <strong>Entités (non-caméras)</strong>
            <input type="text" id="filter-ent" placeholder="Filtrer…" style="flex:1;padding:6px;border-radius:8px;border:1px solid rgba(255,255,255,.1)">
            <button type="button" id="ent-all"  class="btn sm">Tout</button>
            <button type="button" id="ent-none" class="btn sm">Aucun</button>
          </div>
          <select id="sel-ent" multiple size="10" style="width:100%;border-radius:8px;border:1px solid rgba(255,255,255,.1)"></select>
        </div>
      </div>
      <input type="hidden" name="cameras_list"  id="cameras_list">
      <input type="hidden" name="entities_list" id="entities_list">
    </div>
  </form>
  <?php if($sel && isset($instances[$sel])): ?>
  <form id="ha-del" method="post" style="display:none">
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="id" value="<?=h($sel)?>">
  </form>
  <?php endif; ?>
  <hr style="border-color:rgba(255,255,255,.1)">
  <div>
    <div style="font-weight:600;margin-bottom:6px">🔌 Intégrations détectées (aperçu)</div>
    <div id="int-preview" style="opacity:.8">Clique sur <b>Charger la liste</b> ou <b>Tester</b>.</div>
  </div>
</div>
<style>.btn{border:none;border-radius:8px;padding:8px 12px;cursor:pointer;border:1px solid rgba(255,255,255,.15);} .btn.sm{padding:4px 8px}</style>
<script>
(()=> {
  let apiBase=null;
  const probes=['modules/ha/ha_api.php','ha/ha_api.php','ha_api.php','../modules/ha/ha_api.php'];
  async function pick(){ if(apiBase) return apiBase;
    for(const p of probes){ try{ const r=await fetch(p,{method:'GET',cache:'no-store'}); if([200,400,403].includes(r.status)){ apiBase=p; return p; } }catch(e){} }
    alert('❌ ha_api.php introuvable'); throw new Error('no api');
  }
  const status = document.getElementById('ha-status');
  const prev   = document.getElementById('int-preview');
  const selCam = document.getElementById('sel-cam');
  const selEnt = document.getElementById('sel-ent');
  const savedCams = <?=json_encode($savedCams)?>;
  const savedEnts = <?=json_encode($savedEnts)?>;
  function fillSelect(el, items, selected){ el.innerHTML=''; items.forEach(v=>{ const o=document.createElement('option'); o.value=o.textContent=v; if(selected.includes(v)) o.selected=true; el.appendChild(o); }); }
  function filterSelect(el,q){ const qq=(q||'').toLowerCase(); [...el.options].forEach(o=>o.style.display=o.value.toLowerCase().includes(qq)?'':'none'); }
  function selectVisible(el,yes){ [...el.options].forEach(o=>{ if(o.style.display!=='none') o.selected=!!yes; }); }
  function getSelectedVisible(el){ return [...el.options].filter(o=>o.selected && o.style.display!=='none').map(o=>o.value); }
  document.getElementById('btn-ping')?.addEventListener('click', async ()=>{
    const base=document.querySelector('input[name="base_url"]').value.trim();
    const tok =document.querySelector('input[name="token"]').value.trim();
    if(!base||!tok){ alert('Renseigne URL + token'); return; }
    const api=await pick(); status.textContent='Test…';
    try{ const r=await fetch(`${api}?a=ping&base_url=${encodeURIComponent(base)}&token=${encodeURIComponent(tok)}`,{cache:'no-store'}); console.log('PING',await r.text()); status.textContent=r.ok?'✅ OK':'❌ KO'; }catch(e){ status.textContent='❌'; }
  });
  document.getElementById('btn-load')?.addEventListener('click', async ()=>{
    const base=document.querySelector('input[name="base_url"]').value.trim();
    const tok =document.querySelector('input[name="token"]').value.trim();
    if(!base||!tok){ alert('Renseigne URL + token'); return; }
    const api=await pick(); status.textContent='Chargement…';
    try{
      const r=await fetch(`${api}?a=list_by_integration&base_url=${encodeURIComponent(base)}&token=${encodeURIComponent(tok)}`,{cache:'no-store'});
      const txt=await r.text();
      if(!r.ok){ console.error('list_by_integration',txt); alert('❌ Impossible de lister (voir Console).'); status.textContent=''; return; }
      const data=JSON.parse(txt);
      let cams=[], others=[];
      (data.integrations||[]).forEach(g=>{ cams.push(...(g.cameras||[])); others.push(...(g.others||[])); });
      cams=[...new Set(cams)].sort(); others=[...new Set(others)].sort();
      fillSelect(selCam, cams, savedCams);
      fillSelect(selEnt, others, savedEnts);
      status.textContent='✅ Liste chargée';
      prev.textContent = `${(data.integrations||[]).length} intégrations trouvées` + (data.fallback?' (mode domaines)':'');
    }catch(e){ console.error(e); status.textContent='❌'; }
  });
  document.getElementById('filter-cam')?.addEventListener('input', e=>filterSelect(selCam,e.target.value));
  document.getElementById('filter-ent')?.addEventListener('input', e=>filterSelect(selEnt,e.target.value));
  document.getElementById('cam-all') ?.addEventListener('click', ()=>selectVisible(selCam,true));
  document.getElementById('cam-none')?.addEventListener('click', ()=>selectVisible(selCam,false));
  document.getElementById('ent-all') ?.addEventListener('click', ()=>selectVisible(selEnt,true));
  document.getElementById('ent-none')?.addEventListener('click', ()=>selectVisible(selEnt,false));
  fillSelect(selCam, savedCams, savedCams);
  fillSelect(selEnt, savedEnts, savedEnts);
  document.getElementById('ha-form')?.addEventListener('submit', ()=>{
    document.getElementById('cameras_list').value  = getSelectedVisible(selCam).join(',');
    document.getElementById('entities_list').value = getSelectedVisible(selEnt).join(',');
  });
})();
</script>
