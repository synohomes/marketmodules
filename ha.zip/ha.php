<?php
if (session_status()===PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/ha_store.php';
$all = ha_load_all();
$instances = $all['instances'] ?? [];
if (!$instances) { echo '<div style="padding:12px">⚠️ Aucune instance configurée.</div>'; return; }
$proxy = 'modules/ha/ha_api.php';
$nonce = bin2hex(random_bytes(6));
?>
<style>
.ha-live-modal{position:fixed;inset:0;background:rgba(0,0,0,.75);display:none;align-items:center;justify-content:center;z-index:9999}
.ha-live-box{background:#111;border:1px solid rgba(255,255,255,.2);border-radius:12px;max-width:92vw;max-height:90vh;display:flex;flex-direction:column;overflow:hidden}
.ha-live-head{display:flex;align-items:center;justify-content:space-between;padding:8px 12px;background:#1a1a1a}
.ha-live-body{padding:0}
.ha-live-body img{display:block;max-width:92vw;max-height:82vh;object-fit:contain}
.ha-chip{font-size:12px;opacity:.75}
.ha-badge{font-size:12px;opacity:.7;margin-bottom:6px}
</style>
<div class="ha-wrap" style="display:flex;flex-direction:column;gap:14px">
  <?php foreach ($instances as $id=>$inst):
    $cams = $inst['cameras'] ?? [];
    $ents = $inst['sensors'] ?? [];
    $hasSel = (count($cams)+count($ents))>0;
  ?>
  <details open style="border:1px solid rgba(255,255,255,.12);border-radius:10px;overflow:hidden">
    <summary style="padding:10px 12px;cursor:pointer;font-weight:700;display:flex;justify-content:space-between;align-items:center">
      <span>🏠 <?=htmlspecialchars($inst['name'] ?: ('HA '.$id))?> — <?=htmlspecialchars($inst['base_url'] ?? '')?></span>
      <span class="ha-chip"><?= $hasSel ? (count($cams).' cam • '.count($ents).' entités') : 'mode intégrations auto' ?></span>
    </summary>
    <div style="padding:10px 12px;display:flex;flex-direction:column;gap:12px">
      <?php if ($hasSel): ?>
        <?php if ($cams): ?>
        <div>
          <div style="font-weight:600;margin-bottom:6px">📷 Caméras</div>
          <div class="grid-cam" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px">
            <?php foreach ($cams as $cam): ?>
            <div class="ha-cam" data-inst="<?=htmlspecialchars($id)?>" data-entity="<?=htmlspecialchars($cam)?>" style="border:1px solid rgba(255,255,255,.12);border-radius:10px;overflow:hidden;cursor:pointer;position:relative">
              <div style="font-size:12px;padding:6px;opacity:.85;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?=htmlspecialchars($cam)?></div>
              <img loading="lazy" alt="snapshot" style="display:block;width:100%;height:150px;object-fit:cover"
                   src="<?=$proxy?>?a=camera_snapshot&id=<?=urlencode($id)?>&entity_id=<?=urlencode($cam)?>&_k=<?=$nonce?>">
              <div style="position:absolute;right:8px;bottom:8px;background:rgba(0,0,0,.55);padding:2px 6px;border-radius:8px;font-size:12px">LIVE</div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
        <?php endif; ?>
        <?php if ($ents): ?>
        <div>
          <div style="font-weight:600;margin-bottom:6px">📊 Entités</div>
          <div class="grid-sens" data-inst="<?=htmlspecialchars($id)?>" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:10px">
            <?php foreach ($ents as $ent): ?>
            <div class="ha-card" data-entity="<?=htmlspecialchars($ent)?>" style="border:1px solid rgba(255,255,255,.12);border-radius:10px;padding:10px">
              <div style="font-size:12px;opacity:.8;margin-bottom:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?=htmlspecialchars($ent)?></div>
              <div class="ha-s-val" style="font-size:18px;font-weight:700">…</div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
        <?php endif; ?>
      <?php else: ?>
        <div class="int-list" data-inst="<?=htmlspecialchars($id)?>">
          <div class="ha-badge">Mode domaines (fallback)</div>
          <div style="opacity:.7">Chargement des intégrations…</div>
        </div>
      <?php endif; ?>
    </div>
  </details>
  <?php endforeach; ?>
</div>
<div id="ha-live" class="ha-live-modal">
  <div class="ha-live-box">
    <div class="ha-live-head">
      <div id="ha-live-title">Live</div>
      <button id="ha-live-close" class="btn" style="padding:6px 10px;border:1px solid rgba(255,255,255,.25);border-radius:8px;cursor:pointer">✕ Fermer</button>
    </div>
    <div class="ha-live-body">
      <img id="ha-live-img" alt="live">
    </div>
  </div>
</div>
<script>
(()=> {
  const proxy = <?=json_encode($proxy)?>;
  async function refreshSensors(scope=document){
    scope.querySelectorAll('.grid-sens').forEach(async block=>{
      const inst = block.dataset.inst;
      const cards = block.querySelectorAll('.ha-card');
      if(!cards.length) return;
      const ents = [...cards].map(c=>c.dataset.entity);
      let data = null;
      try{
        const url = `${proxy}?a=get_states&id=${encodeURIComponent(inst)}&entities=${encodeURIComponent(ents.join(','))}`;
        const res = await fetch(url, {cache:'no-store'});
        if(!res.ok){
          console.warn('[HA] get_states HTTP', res.status, await res.text());
          cards.forEach(c=>c.querySelector('.ha-s-val').textContent='⛔');
          return;
        }
        data = await res.json();
      }catch(e){
        console.error('[HA] get_states error', e);
        cards.forEach(c=>c.querySelector('.ha-s-val').textContent='⛔');
        return;
      }
      cards.forEach(card=>{
        const ent = card.dataset.entity;
        const vEl = card.querySelector('.ha-s-val');
        const info = data?.[ent];
        if(!info){ vEl.textContent = '—'; return; }
        const dom  = ent.split('.')[0];
        const val  = (info.state ?? '').toString();
        const attr = info.attributes || {};
        const unit = attr.unit_of_measurement || attr.unit || '';
        if (val === 'unavailable' || val === 'unknown') {
          vEl.textContent = '…';
          vEl.title = `(${val})`;
          vEl.parentElement.style.opacity = .6;
          return;
        } else {
          vEl.parentElement.style.opacity = 1;
          vEl.title = '';
        }
        switch(dom){
          case 'binary_sensor':
          case 'switch':
          case 'input_boolean':
          case 'light':
            vEl.textContent = (val.toLowerCase()==='on') ? 'ON' : 'OFF';
            break;
          case 'device_tracker':
            vEl.textContent = val; // home / not_home / zone
            break;
          default:
            vEl.textContent = unit ? `${val} ${unit}` : (val || '—');
        }
      });
    });
  }
  function refreshCams(scope=document){
    scope.querySelectorAll('.grid-cam img').forEach(img=>{
      const base = img.src.split('&_t=')[0];
      img.src = base + '&_t=' + performance.now(); 
    });
  }
  refreshSensors(); refreshCams();
  setInterval(()=>refreshSensors(), 8000); 
  setInterval(()=>refreshCams(), 2000);  
  async function loadIntegrationsFor(instId, container){
    try{
      const r = await fetch(`${proxy}?a=list_by_integration&id=${encodeURIComponent(instId)}`, {cache:'no-store'});
      const txt = await r.text();
      if(!r.ok){ container.innerHTML = '<div style="color:#f88">Erreur API</div>'; console.error(txt); return; }
      const data = JSON.parse(txt);
      const list = data.integrations || [];
      container.innerHTML = data.fallback ? '<div class="ha-badge">Mode domaines (fallback)</div>' : '';
      list.forEach(integ=>{
        const wrap = document.createElement('details');
        wrap.style.cssText='border:1px solid rgba(255,255,255,.12);border-radius:10px;overflow:hidden;margin:2px 0';
        const summary = document.createElement('summary');
        summary.style.cssText='padding:8px 10px;cursor:pointer;font-weight:600;display:flex;justify-content:space-between;align-items:center';
        summary.innerHTML = `<span>${integ.platform}</span><span style="opacity:.7">(${integ.count})</span>`;
        wrap.appendChild(summary);
        const body = document.createElement('div');
        body.style.cssText='padding:10px;display:flex;flex-direction:column;gap:10px';
        if ((integ.cameras||[]).length){
          const camBlock = document.createElement('div');
          camBlock.innerHTML = `<div style="font-weight:600;margin-bottom:6px">📷 Caméras</div>`;
          const grid = document.createElement('div');
          grid.className='grid-cam';
          grid.style.cssText='display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px';
          (integ.cameras||[]).forEach(cam=>{
            const card = document.createElement('div');
            card.className='ha-cam'; card.dataset.inst=instId; card.dataset.entity=cam;
            card.style.cssText='border:1px solid rgba(255,255,255,.12);border-radius:10px;overflow:hidden;cursor:pointer;position:relative';
            card.innerHTML =
              `<div style="font-size:12px;padding:6px;opacity:.85;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${cam}</div>
               <img loading="lazy" alt="snapshot" style="display:block;width:100%;height:150px;object-fit:cover"
                    src="${proxy}?a=camera_snapshot&id=${encodeURIComponent(instId)}&entity_id=${encodeURIComponent(cam)}">
               <div style="position:absolute;right:8px;bottom:8px;background:rgba(0,0,0,.55);padding:2px 6px;border-radius:8px;font-size:12px">LIVE</div>`;
            grid.appendChild(card);
          });
          camBlock.appendChild(grid); body.appendChild(camBlock);
        }
        if ((integ.others||[]).length){
          const senBlock = document.createElement('div');
          senBlock.innerHTML = `<div style="font-weight:600;margin-bottom:6px">🔎 Entités</div>`;
          const grid = document.createElement('div');
          grid.className='grid-sens'; grid.dataset.inst=instId;
          grid.style.cssText='display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:10px';
          (integ.others||[]).forEach(ent=>{
            const card=document.createElement('div');
            card.className='ha-card'; card.dataset.entity=ent;
            card.innerHTML =
              `<div style="border:1px solid rgba(255,255,255,.12);border-radius:10px;padding:10px">
                 <div style="font-size:12px;opacity:.8;margin-bottom:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${ent}</div>
                 <div class="ha-s-val" style="font-size:18px;font-weight:700">…</div>
               </div>`;
            grid.appendChild(card);
          });
          senBlock.appendChild(grid); body.appendChild(senBlock);
        }
        if (!(integ.cameras||[]).length && !(integ.others||[]).length){
          body.innerHTML = '<div style="opacity:.7">Aucune entité.</div>';
        }
        wrap.appendChild(body); container.appendChild(wrap);
      });
      refreshSensors(container);
      setInterval(()=>refreshSensors(container), 8000);
      setInterval(()=>refreshCams(container), 2000);
      bindLiveClicks(container);
    }catch(e){
      container.innerHTML = '<div style="color:#f88">Erreur de chargement</div>';
      console.error(e);
    }
  }
  document.querySelectorAll('.int-list').forEach(div=>{
    const instId = div.dataset.inst;
    loadIntegrationsFor(instId, div);
  });
  const modal = document.getElementById('ha-live');
  const liveImg = document.getElementById('ha-live-img');
  const liveTitle = document.getElementById('ha-live-title');
  document.getElementById('ha-live-close')?.addEventListener('click', closeLive);
  modal.addEventListener('click', e=>{ if(e.target===modal) closeLive(); });
  function openLive(inst, entity){
    liveTitle.textContent = entity + ' — live';
    liveImg.src = `${proxy}?a=camera_stream&id=${encodeURIComponent(inst)}&entity_id=${encodeURIComponent(entity)}&_t=${Date.now()}`;
    modal.style.display = 'flex';
  }
  function closeLive(){ modal.style.display='none'; liveImg.src='about:blank'; }

  function bindLiveClicks(scope=document){
    scope.querySelectorAll('.ha-cam').forEach(card=>{
      card.addEventListener('click', ()=> openLive(card.dataset.inst, card.dataset.entity));
    });
  }
  bindLiveClicks();
})();
</script>
