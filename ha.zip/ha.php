<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/ha_store.php';

function dmd_ha_h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function dmd_ha_asset_ver(string $file): string { $p = __DIR__ . '/' . $file; return file_exists($p) ? (string)filemtime($p) : (string)time(); }
function dmd_ha_domain(string $entity): string { return strstr($entity, '.', true) ?: 'entity'; }
function dmd_ha_label(string $entity): string {
    $name = preg_replace('/^[^.]+\./', '', (string)$entity);
    $name = str_replace(['_', '-'], ' ', $name);
    return mb_convert_case($name, MB_CASE_TITLE, 'UTF-8');
}
function dmd_ha_category(string $entity): string {
    $domain = dmd_ha_domain($entity);
    if ($domain === 'camera') return 'Caméras';
    if (in_array($domain, ['switch', 'button', 'input_button', 'light', 'cover', 'lock', 'fan', 'climate'], true)) return 'Contrôles';
    if (in_array($domain, ['sensor', 'binary_sensor'], true)) return 'Capteurs';
    if (in_array($domain, ['weather', 'sun'], true)) return 'Météo';
    if (in_array($domain, ['device_tracker', 'person', 'zone'], true)) return 'Présence';
    return 'Autres';
}

$all = ha_load_all();
$instances = $all['instances'] ?? [];
$proxy = 'modules/ha/ha_api.php';
$nonce = bin2hex(random_bytes(6));
$totalCams = 0;
$totalEnts = 0;
foreach ($instances as $inst) {
    $totalCams += count($inst['cameras'] ?? []);
    $totalEnts += count($inst['sensors'] ?? []);
}
?>
<link rel="stylesheet" href="modules/ha/ha.css?v=<?=dmd_ha_asset_ver('ha.css')?>">
<div class="dmd-ha dmd-ha-dashboard" data-module="dmd-ha">
  <div class="dmd-ha-shell">
    <?php if (!$instances): ?>
      <div class="dmd-ha-empty">
        <strong>DMD-HA n’est pas encore configuré.</strong><br>
        Ajoute une instance Home Assistant depuis la configuration du module, puis sélectionne les éléments utiles.
      </div>
    <?php return; endif; ?>

    <section class="dmd-ha-hero dmd-ha-hero-compact">
      <div>
        <div class="dmd-ha-kicker">DMD-HA</div>
        <h2 class="dmd-ha-title">Home Assistant</h2>
        <p class="dmd-ha-subtitle">Vue dashboard propre avec valeurs normalisées automatiquement.</p>
      </div>
      <div class="dmd-ha-metrics" aria-label="Statistiques Home Assistant">
        <span class="dmd-ha-pill"><?=count($instances)?> instance<?=count($instances) > 1 ? 's' : ''?></span>
        <span class="dmd-ha-pill"><?=$totalCams?> caméra<?=$totalCams > 1 ? 's' : ''?></span>
        <span class="dmd-ha-pill"><?=$totalEnts?> entité<?=$totalEnts > 1 ? 's' : ''?></span>
      </div>
    </section>

    <?php foreach ($instances as $id => $inst):
      $name = trim((string)($inst['name'] ?? '')) ?: ('Home Assistant ' . $id);
      $base = trim((string)($inst['base_url'] ?? ''));
      $cams = array_values(array_filter($inst['cameras'] ?? []));
      $ents = array_values(array_filter($inst['sensors'] ?? []));
      $groups = [];
      foreach ($ents as $ent) $groups[dmd_ha_category($ent)][] = $ent;
      $order = ['Contrôles', 'Capteurs', 'Météo', 'Présence', 'Autres'];
    ?>
      <section class="dmd-ha-instance" data-instance="<?=dmd_ha_h($id)?>">
        <header class="dmd-ha-instance-head">
          <div class="dmd-ha-instance-name">
            <div class="dmd-ha-home-dot">HA</div>
            <div class="dmd-ha-instance-text">
              <div class="dmd-ha-instance-title"><?=dmd_ha_h($name)?></div>
              <div class="dmd-ha-instance-url"><?=dmd_ha_h($base)?></div>
            </div>
          </div>
          <div class="dmd-ha-instance-badges">
            <span class="dmd-ha-badge"><?=count($cams)?> cam</span>
            <span class="dmd-ha-badge"><?=count($ents)?> entités</span>
          </div>
        </header>

        <div class="dmd-ha-body">
          <?php if (!$cams && !$ents): ?>
            <div class="dmd-ha-empty">Aucune entité sélectionnée pour cette instance.</div>
          <?php endif; ?>

          <?php if ($cams): ?>
            <div class="dmd-ha-section">
              <h3 class="dmd-ha-section-title">Caméras <span class="dmd-ha-section-hint">clic pour agrandir</span></h3>
              <div class="dmd-ha-cam-grid">
                <?php foreach ($cams as $cam): ?>
                  <article class="dmd-ha-cam" data-inst="<?=dmd_ha_h($id)?>" data-entity="<?=dmd_ha_h($cam)?>" title="<?=dmd_ha_h($cam)?>">
                    <div class="dmd-ha-cam-top">
                      <div class="dmd-ha-cam-name"><?=dmd_ha_h(dmd_ha_label($cam))?></div>
                      <span class="dmd-ha-live-chip">LIVE</span>
                    </div>
                    <div class="dmd-ha-cam-frame">
                      <img loading="lazy" alt="Snapshot <?=dmd_ha_h(dmd_ha_label($cam))?>" src="<?=$proxy?>?a=camera_snapshot&id=<?=urlencode($id)?>&entity_id=<?=urlencode($cam)?>&_k=<?=$nonce?>">
                    </div>
                  </article>
                <?php endforeach; ?>
              </div>
            </div>
          <?php endif; ?>

          <?php foreach ($order as $category): if (empty($groups[$category])) continue; ?>
            <div class="dmd-ha-section">
              <h3 class="dmd-ha-section-title"><?=dmd_ha_h($category)?></h3>
              <div class="dmd-ha-entity-grid" data-inst="<?=dmd_ha_h($id)?>">
                <?php foreach ($groups[$category] as $ent): $domain = dmd_ha_domain($ent); ?>
                  <article class="dmd-ha-entity" data-entity="<?=dmd_ha_h($ent)?>" title="<?=dmd_ha_h($ent)?>">
                    <div class="dmd-ha-entity-top">
                      <div class="dmd-ha-entity-name"><?=dmd_ha_h(dmd_ha_label($ent))?></div>
                      <span class="dmd-ha-domain"><?=dmd_ha_h($domain)?></span>
                    </div>
                    <div class="dmd-ha-value">…</div>
                    <div class="dmd-ha-unit"></div>
                    <div class="dmd-ha-entity-id"><?=dmd_ha_h($ent)?></div>
                  </article>
                <?php endforeach; ?>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      </section>
    <?php endforeach; ?>
  </div>
</div>

<div id="dmd-ha-live" class="dmd-ha dmd-ha-live-modal" aria-hidden="true">
  <div class="dmd-ha-live-box" role="dialog" aria-modal="true">
    <div class="dmd-ha-live-head">
      <div id="dmd-ha-live-title" class="dmd-ha-live-title">Live caméra</div>
      <button type="button" id="dmd-ha-live-close" class="dmd-ha-btn small">Fermer</button>
    </div>
    <div class="dmd-ha-live-body">
      <img id="dmd-ha-live-img" alt="Flux live Home Assistant">
    </div>
  </div>
</div>

<script>
(() => {
  const proxy = <?=json_encode($proxy, JSON_UNESCAPED_SLASHES)?>;
  const live = document.getElementById('dmd-ha-live');
  const liveImg = document.getElementById('dmd-ha-live-img');
  const liveTitle = document.getElementById('dmd-ha-live-title');
  const closeBtn = document.getElementById('dmd-ha-live-close');

  function cleanNumber(value, maxDecimals = 2){
    const n = Number(value);
    if (!Number.isFinite(n)) return String(value ?? '');
    const decimals = Math.abs(n) >= 100 ? 0 : maxDecimals;
    return new Intl.NumberFormat('fr-FR', {maximumFractionDigits: decimals}).format(n);
  }
  function formatStorage(value, unit){
    let n = Number(String(value).replace(',', '.'));
    if (!Number.isFinite(n)) return {value:String(value || '—'), unit:unit || ''};
    const u = String(unit || '').trim().toLowerCase();
    if (['b','byte','bytes','octet','octets'].includes(u)) {
      n = n / 1024 / 1024;
      return formatStorage(n, 'MB');
    }
    if (['kb','kib','ko'].includes(u)) {
      n = n / 1024;
      return formatStorage(n, 'MB');
    }
    if (['mb','mib','mo'].includes(u)) {
      if (Math.abs(n) >= 1024) return {value:cleanNumber(n / 1024, 2), unit:'Go'};
      return {value:cleanNumber(n, 1), unit:'Mo'};
    }
    if (['gb','gib','go'].includes(u)) return {value:cleanNumber(n, 2), unit:'Go'};
    if (['tb','tib','to'].includes(u)) {
      if (Math.abs(n) < 1) return {value:cleanNumber(n * 1024, 2), unit:'Go'};
      return {value:cleanNumber(n, 2), unit:'To'};
    }
    return {value:cleanNumber(n, 2), unit:unit || ''};
  }
  function formatGenericNumber(value, unit){
    const n = Number(String(value).replace(',', '.'));
    if (!Number.isFinite(n)) return {value:String(value || '—'), unit:unit || ''};
    const u = String(unit || '').trim();
    if (u === '%') return {value:cleanNumber(n, 1), unit:'%'};
    if (['°C','°F','W','V','A','Hz','ms','s','min','h'].includes(u)) return {value:cleanNumber(n, 1), unit:u};
    if (u) return {value:cleanNumber(n, 2), unit:u};
    return {value:cleanNumber(n, 2), unit:''};
  }
  function prettyValue(entityId, info){
    if (!info) return {value:'—', unit:'', state:''};
    const raw = String(info.state ?? '');
    const attrs = info.attributes || {};
    const unit = attrs.unit_of_measurement || attrs.unit || '';
    const domain = String(entityId).split('.')[0];
    const low = raw.toLowerCase();
    if (raw === 'unavailable' || raw === 'unknown') return {value:'—', unit:'indispo', state:'unknown'};
    if (['switch','input_boolean','binary_sensor','light','button'].includes(domain)) {
      return {value: low === 'on' ? 'ON' : (low === 'off' ? 'OFF' : raw), unit:'', state:low};
    }
    const storage = formatStorage(raw, unit);
    if (storage.unit !== unit || ['mb','mib','mo','gb','gib','go','tb','tib','to','b','bytes','octets','kb','kib','ko'].includes(String(unit).toLowerCase())) {
      return {...storage, state:low};
    }
    return {...formatGenericNumber(raw, unit), state:low};
  }

  async function refreshSensors(scope = document){
    const groups = scope.querySelectorAll('.dmd-ha-entity-grid');
    groups.forEach(async group => {
      const inst = group.dataset.inst;
      const cards = [...group.querySelectorAll('.dmd-ha-entity')];
      if (!inst || !cards.length) return;
      const entities = cards.map(card => card.dataset.entity).filter(Boolean);
      try {
        const url = `${proxy}?a=get_states&id=${encodeURIComponent(inst)}&entities=${encodeURIComponent(entities.join(','))}`;
        const res = await fetch(url, {cache:'no-store'});
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const data = await res.json();
        cards.forEach(card => {
          const entityId = card.dataset.entity;
          const valueEl = card.querySelector('.dmd-ha-value');
          const unitEl = card.querySelector('.dmd-ha-unit');
          const labelEl = card.querySelector('.dmd-ha-entity-name');
          const info = data?.[entityId] || null;
          const pv = prettyValue(entityId, info);
          valueEl.textContent = pv.value;
          if (unitEl) unitEl.textContent = pv.unit || '';
          card.classList.toggle('dmd-ha-state-on', pv.state === 'on' || pv.state === 'home');
          card.classList.toggle('dmd-ha-state-off', pv.state === 'off' || pv.state === 'not_home');
          card.classList.toggle('dmd-ha-state-unknown', pv.state === 'unknown');
          if (info?.attributes?.friendly_name) labelEl.textContent = info.attributes.friendly_name;
        });
      } catch (err) {
        cards.forEach(card => {
          const valueEl = card.querySelector('.dmd-ha-value');
          if (valueEl) valueEl.textContent = '—';
        });
      }
    });
  }

  function refreshCameras(scope = document){
    scope.querySelectorAll('.dmd-ha-cam-frame img').forEach(img => {
      const base = img.src.split('&_t=')[0];
      img.src = base + '&_t=' + Date.now();
    });
  }

  document.addEventListener('click', event => {
    const card = event.target.closest('.dmd-ha-cam');
    if (!card || !live || !liveImg) return;
    const inst = card.dataset.inst;
    const entity = card.dataset.entity;
    const title = card.querySelector('.dmd-ha-cam-name')?.textContent || entity;
    liveTitle.textContent = title;
    liveImg.src = `${proxy}?a=camera_stream&id=${encodeURIComponent(inst)}&entity_id=${encodeURIComponent(entity)}&_t=${Date.now()}`;
    live.style.display = 'flex';
    live.setAttribute('aria-hidden', 'false');
  });

  function closeLive(){
    if (!live || !liveImg) return;
    live.style.display = 'none';
    live.setAttribute('aria-hidden', 'true');
    liveImg.removeAttribute('src');
  }
  closeBtn?.addEventListener('click', closeLive);
  live?.addEventListener('click', event => { if (event.target === live) closeLive(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape') closeLive(); });

  refreshSensors();
  refreshCameras();
  setInterval(refreshSensors, 8000);
  setInterval(refreshCameras, 5000);
})();
</script>
