<?php
if (session_status()===PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/ha_store.php';
$all = ha_load_all();
$instances = $all['instances'] ?? [];
if (!$instances) { echo '<div style="padding:12px">⚠️ Aucune instance configurée (profile_edit → Home Assistant).</div>'; return; }
$proxy = "modules/ha/ha_api.php";
$nonce = bin2hex(random_bytes(6));
?>
<div class="ha-int-wrap" style="display:flex;flex-direction:column;gap:16px">
  <?php foreach ($instances as $id=>$inst): ?>
  <details open style="border:1px solid rgba(255,255,255,.14);border-radius:10px;overflow:hidden">
    <summary style="padding:10px 12px;cursor:pointer;font-weight:700;display:flex;justify-content:space-between;align-items:center">
      <span>🏠 <?=htmlspecialchars($inst['name'] ?: ('HA '.$id))?> — <?=htmlspecialchars($inst['base_url'] ?? '')?></span>
      <span id="cnt-<?=$id?>" style="opacity:.75;font-weight:500">chargement…</span>
    </summary>
    <div class="int-list" data-inst="<?=htmlspecialchars($id)?>" style="padding:10px 12px;display:flex;flex-direction:column;gap:10px">
      <div style="opacity:.7">Recherche des intégrations…</div>
    </div>
  </details>
  <?php endforeach; ?>
</div>
<script>
(()=> {
  const proxy = <?=json_encode($proxy)?>;
  const nonce = <?=json_encode($nonce)?>;
  function makeInteg(instId, integ){
    const wrap = document.createElement('details');
    wrap.open = false;
    wrap.style.cssText = 'border:1px solid rgba(255,255,255,.12);border-radius:10px;overflow:hidden;margin:2px 0';
    const summary = document.createElement('summary');
    summary.style.cssText = 'padding:8px 10px;cursor:pointer;font-weight:600;display:flex;justify-content:space-between;align-items:center';
    summary.innerHTML = `<span>${integ.platform}</span><span style="opacity:.7">(${integ.count})</span>`;
    wrap.appendChild(summary);
    const body = document.createElement('div');
    body.style.cssText = 'padding:10px;display:flex;flex-direction:column;gap:10px';
    if ((integ.cameras||[]).length){
      const camBlock = document.createElement('div');
      camBlock.innerHTML = `<div style="font-weight:600;margin-bottom:6px">📷 Caméras</div>`;
      const grid = document.createElement('div');
      grid.className='grid-cam'; grid.style.cssText='display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px';
      (integ.cameras||[]).forEach(cam=>{
        const card=document.createElement('div');
        card.style.cssText='border:1px solid rgba(255,255,255,.12);border-radius:10px;overflow:hidden';
        card.innerHTML = `<div style="font-size:12px;padding:6px;opacity:.85;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${cam}</div>
          <img loading="lazy" alt="snapshot" style="display:block;width:100%;height:140px;object-fit:cover"
               src="${proxy}?a=camera_snapshot&id=${encodeURIComponent(instId)}&entity_id=${encodeURIComponent(cam)}&_k=${nonce}">`;
        grid.appendChild(card);
      });
      camBlock.appendChild(grid); body.appendChild(camBlock);
    }
    if ((integ.others||[]).length){
      const senBlock = document.createElement('div');
      senBlock.innerHTML = `<div style="font-weight:600;margin-bottom:6px">🔎 Entités</div>`;
      const grid = document.createElement('div');
      grid.className='grid-sens'; grid.dataset.inst=instId;
      grid.style.cssText='display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px';
      (integ.others||[]).forEach(ent=>{
        const card=document.createElement('div');
        card.className='ha-card'; card.dataset.entity=ent;
        card.innerHTML = `<div style="border:1px solid rgba(255,255,255,.12);border-radius:10px;padding:10px">
            <div style="font-size:12px;opacity:.8;margin-bottom:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${ent}</div>
            <div class="ha-s-val" style="font-size:18px;font-weight:700">…</div>
          </div>`;
        grid.appendChild(card);
      });
      senBlock.appendChild(grid); body.appendChild(senBlock);
    }
    if (!(integ.cameras||[]).length && !(integ.others||[]).length){
      body.innerHTML = `<div style="opacity:.7">Aucune entité.</div>`;
    }
    wrap.appendChild(body);
    return wrap;
  }
  async function loadIntegrationsFor(instId){
    const container=document.querySelector(`.int-list[data-inst="${instId}"]`);
    if(!container) return;
    try{
      const r=await fetch(`${proxy}?a=list_by_integration&id=${encodeURIComponent(instId)}`,{cache:'no-store'});
      const txt=await r.text(); if(!r.ok){ container.innerHTML='<div style="color:#f88">Erreur API</div>'; console.error(txt); return; }
      const data=JSON.parse(txt); const list=data.integrations||[];
      document.getElementById(`cnt-${instId}`).textContent=`${list.length} intégrations`;
      container.innerHTML='';
      list.forEach(integ=>container.appendChild(makeInteg(instId, integ)));s
      refreshSensors(container); setInterval(()=>refreshSensors(container),8000);
      setInterval(()=>refreshCams(container),10000);
    }catch(e){ container.innerHTML='<div style="color:#f88">Erreur chargement</div>'; console.error(e); }
  }
  function refreshSensors(scope){
    scope.querySelectorAll('.grid-sens').forEach(async block=>{
      const inst = block.dataset.inst;
      const cards=[...block.querySelectorAll('.ha-card')];
      if(!cards.length) return;
      const ents=cards.map(c=>c.dataset.entity);
      try{
        const res=await fetch(`${proxy}?a=get_states&id=${encodeURIComponent(inst)}&entities=${encodeURIComponent(ents.join(','))}`,{cache:'no-store'});
        if(!res.ok) return;
        const data=await res.json();
        cards.forEach(card=>{
          const ent=card.dataset.entity; const info=data[ent]; const v=card.querySelector('.ha-s-val');
          if(info){
            const dom=ent.split('.')[0]; const unit=info.attributes?.unit_of_measurement || info.attributes?.unit || '';
            if(dom==='binary_sensor'){ v.textContent = (''+info.state).toLowerCase()==='on'?'ON':'OFF'; }
            else v.textContent = `${info.state??'—'}${unit?' '+unit:''}`;
          } else v.textContent='—';
        });
      }catch(e){}
    });
  }
  function refreshCams(scope){
    scope.querySelectorAll('.grid-cam img').forEach(img=>{
      const base=img.src.split('&_t=')[0]; img.src=base+'&_t='+Date.now();
    });
  }
  document.querySelectorAll('.int-list').forEach(div=>loadIntegrationsFor(div.dataset.inst));
})();
</script>
