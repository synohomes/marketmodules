<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/ha_store.php';
function dmd_ha_int_h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function dmd_ha_int_asset_ver(string $file): string { $p = __DIR__ . '/' . $file; return file_exists($p) ? (string)filemtime($p) : (string)time(); }
$all = ha_load_all();
$instances = $all['instances'] ?? [];
$proxy = 'modules/ha/ha_api.php';
?>
<link rel="stylesheet" href="modules/ha/ha.css?v=<?=dmd_ha_int_asset_ver('ha.css')?>">
<div class="dmd-ha">
  <div class="dmd-ha-shell">
    <?php if (!$instances): ?>
      <div class="dmd-ha-empty">Aucune instance configurée. Configure d’abord DMD-HA dans les paramètres du module.</div>
    <?php return; endif; ?>

    <section class="dmd-ha-hero">
      <div>
        <div class="dmd-ha-kicker">Catalogue</div>
        <h2 class="dmd-ha-title">Intégrations Home Assistant</h2>
        <p class="dmd-ha-subtitle">Vue de contrôle des intégrations détectées par instance.</p>
      </div>
    </section>

    <?php foreach ($instances as $id => $inst): ?>
      <section class="dmd-ha-instance">
        <header class="dmd-ha-instance-head">
          <div class="dmd-ha-instance-name">
            <div class="dmd-ha-home-dot">HA</div>
            <div>
              <div class="dmd-ha-instance-title"><?=dmd_ha_int_h($inst['name'] ?: ('Home Assistant ' . $id))?></div>
              <div class="dmd-ha-instance-url"><?=dmd_ha_int_h($inst['base_url'] ?? '')?></div>
            </div>
          </div>
          <div class="dmd-ha-instance-badges"><span id="dmd-ha-count-<?=dmd_ha_int_h($id)?>" class="dmd-ha-badge">chargement</span></div>
        </header>
        <div class="dmd-ha-body">
          <div class="dmd-ha-integration-list" data-inst="<?=dmd_ha_int_h($id)?>">
            <div class="dmd-ha-preview">Recherche des intégrations...</div>
          </div>
        </div>
      </section>
    <?php endforeach; ?>
  </div>
</div>
<script>
(() => {
  const proxy = <?=json_encode($proxy, JSON_UNESCAPED_SLASHES)?>;
  function escapeHtml(value){ return String(value ?? '').replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[char])); }
  function label(id){ return String(id || '').replace(/^[^.]+\./,'').replace(/_/g,' ').replace(/\b\w/g,c=>c.toUpperCase()); }
  async function load(container){
    const inst = container.dataset.inst;
    try{
      const res = await fetch(`${proxy}?a=list_by_integration&id=${encodeURIComponent(inst)}`, {cache:'no-store'});
      if(!res.ok) throw new Error('API');
      const data = await res.json();
      const list = data.integrations || [];
      const count = document.getElementById(`dmd-ha-count-${inst}`);
      if(count) count.textContent = `${list.length} intégrations`;
      container.innerHTML = '';
      if(!list.length){ container.innerHTML = '<div class="dmd-ha-preview">Aucune intégration détectée.</div>'; return; }
      list.forEach(group => {
        const details = document.createElement('details');
        details.className = 'dmd-ha-integration';
        details.innerHTML = `<summary><span>${escapeHtml(group.platform || 'Intégration')}</span><span class="dmd-ha-badge">${Number(group.count || 0)} entités</span></summary><div class="dmd-ha-integration-body"></div>`;
        const body = details.querySelector('.dmd-ha-integration-body');
        if((group.cameras || []).length){
          const section = document.createElement('div');
          section.innerHTML = '<h3 class="dmd-ha-section-title">Caméras</h3><div class="dmd-ha-mini-grid"></div>';
          const grid = section.querySelector('.dmd-ha-mini-grid');
          (group.cameras || []).forEach(id => grid.insertAdjacentHTML('beforeend', `<div class="dmd-ha-mini-card"><div class="dmd-ha-mini-title">${escapeHtml(label(id))}</div><div class="dmd-ha-mini-id">${escapeHtml(id)}</div></div>`));
          body.appendChild(section);
        }
        if((group.others || []).length){
          const section = document.createElement('div');
          section.innerHTML = '<h3 class="dmd-ha-section-title">Entités</h3><div class="dmd-ha-mini-grid"></div>';
          const grid = section.querySelector('.dmd-ha-mini-grid');
          (group.others || []).slice(0, 80).forEach(id => grid.insertAdjacentHTML('beforeend', `<div class="dmd-ha-mini-card"><div class="dmd-ha-mini-title">${escapeHtml(label(id))}</div><div class="dmd-ha-mini-id">${escapeHtml(id)}</div></div>`));
          if((group.others || []).length > 80) grid.insertAdjacentHTML('beforeend', `<div class="dmd-ha-mini-card"><div class="dmd-ha-mini-title">+${(group.others || []).length - 80}</div><div class="dmd-ha-mini-id">autres entités masquées</div></div>`);
          body.appendChild(section);
        }
        container.appendChild(details);
      });
    }catch(e){ container.innerHTML = '<div class="dmd-ha-empty">Erreur lors du chargement des intégrations.</div>'; }
  }
  document.querySelectorAll('.dmd-ha-integration-list').forEach(load);
})();
</script>
