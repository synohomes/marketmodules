<?php
if (session_status()===PHP_SESSION_NONE) session_start();
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
require_once __DIR__ . '/ha_store.php';
$all    = ha_load_all();
$instId = $_GET['id'] ?? null;
$inst   = ($instId !== null && isset($all['instances'][$instId])) ? $all['instances'][$instId] : null;
$base   = rtrim(trim($_GET['base_url'] ?? ($inst['base_url'] ?? '')), '/');
$token  = trim($_GET['token']     ?? ($inst ? ha_decrypt($inst['token_enc'] ?? '') : ''));
if (!$base || !$token) { http_response_code(400); exit('Bad config'); }
function ha_request($method, $url, $token, $body=null, $accept='application/json'){
  $ch = curl_init($url);
  $headers = [
    "Authorization: Bearer $token",
    "Accept: $accept",
    "User-Agent: DoMyDesk-HA/2.1"
  ];
  if ($body !== null) {
    $headers[] = "Content-Type: application/json";
    curl_setopt($ch, CURLOPT_POSTFIELDS, is_string($body) ? $body : json_encode($body));
  }
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER=>true,
    CURLOPT_FOLLOWLOCATION=>true,
    CURLOPT_TIMEOUT=>15,
    CURLOPT_HTTPHEADER=>$headers,
    CURLOPT_CUSTOMREQUEST=>strtoupper($method),
    CURLOPT_SSL_VERIFYPEER=>0,
    CURLOPT_SSL_VERIFYHOST=>0,
  ]);
  $res  = curl_exec($ch);
  $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  $err  = curl_error($ch);
  curl_close($ch);
  return [$code,$res,$err];
}
$a = $_GET['a'] ?? '';
if ($a==='ping') {
  [$c1,$r1,$e1] = ha_request('GET', $base.'/api', $token);
  [$c2,$r2,$e2] = ha_request('GET', $base.'/api/config', $token);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode([
    'base_url'=>$base,
    'api_status'=>['code'=>$c1,'err'=>$e1,'body'=>substr((string)$r1,0,200)],
    'config'    =>['code'=>$c2,'err'=>$e2,'body'=>substr((string)$r2,0,200)],
  ], JSON_UNESCAPED_UNICODE);
  exit;
}
if ($a==='get_states') {
  $entities = array_values(array_filter(array_map('trim', explode(',', $_GET['entities'] ?? ''))));
  $out = [];
  foreach ($entities as $ent) {
    [$c,$r] = ha_request('GET', $base.'/api/states/'.rawurlencode($ent), $token);
    if ($c>=200 && $c<300) {
      $j = json_decode($r, true) ?: [];
      $out[$ent] = ['state'=>$j['state'] ?? null, 'attributes'=>$j['attributes'] ?? []];
    } else $out[$ent] = null;
  }
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode($out, JSON_UNESCAPED_UNICODE); exit;
}
if ($a==='camera_snapshot') {
  $ent = trim($_GET['entity_id'] ?? '');
  [$c,$r] = ha_request('GET', $base.'/api/camera_proxy/'.rawurlencode($ent), $token, null, 'image/jpeg');
  if ($c>=200 && $c<300 && $r) { header('Content-Type: image/jpeg'); echo $r; }
  else { header('Content-Type: image/svg+xml'); echo '<svg xmlns="http://www.w3.org/2000/svg" width="160" height="120"><rect width="160" height="120" fill="#111"/><text x="10" y="65" fill="#999" font-size="14">N/A</text></svg>'; }
  exit;
}
if ($a==='camera_stream') {
  $entity = trim($_GET['entity_id'] ?? '');
  if (!preg_match('/^camera\.[a-zA-Z0-9_]+$/', $entity)) { http_response_code(400); exit('Bad entity'); }
  @ini_set('output_buffering','0');
  @ini_set('zlib.output_compression','0');
  while (ob_get_level()) { @ob_end_clean(); }
  ob_implicit_flush(true);
  header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
  header('Pragma: no-cache');
  header('Expires: 0');
  header('Connection: keep-alive');
  header('X-Accel-Buffering: no');
  $url = $base . '/api/camera_proxy_stream/' . rawurlencode($entity);
  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_HTTPHEADER     => ["Authorization: Bearer $token", "Accept: multipart/x-mixed-replace"],
    CURLOPT_RETURNTRANSFER => false,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_SSL_VERIFYPEER => 0,
    CURLOPT_SSL_VERIFYHOST => 0,
    CURLOPT_TIMEOUT        => 0,
    CURLOPT_BUFFERSIZE     => 1024,
    CURLOPT_HEADERFUNCTION => function($ch, $hdr) {
      $h = strtolower($hdr);
      if (strpos($h,'content-type:')===0 || strpos($h,'cache-control:')===0 || strpos($h,'pragma:')===0 || strpos($h,'content-length:')===0) {
        header(trim($hdr), false);
      }
      return strlen($hdr);
    },
    CURLOPT_WRITEFUNCTION  => function($ch, $data){
      echo $data; @flush(); @ob_flush(); return strlen($data);
    },
  ]);

  $ok = curl_exec($ch);
  if ($ok === false) {
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Stream error: ' . curl_error($ch);
  }
  curl_close($ch);
  exit;
}
if ($a==='list_entities') {
  [$c,$r] = ha_request('GET', $base.'/api/states', $token);
  if (!($c>=200 && $c<300)) { http_response_code(502); echo json_encode(['error'=>true,'code'=>$c]); exit; }
  $all=json_decode($r,true)?:[]; $cams=[]; $others=[];
  foreach($all as $e){ $id=$e['entity_id']??''; if(strpos($id,'camera.')===0) $cams[]=$id; else $others[]=$id; }
  sort($cams); sort($others);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['cameras'=>$cams,'sensors'=>$others], JSON_UNESCAPED_UNICODE); exit;
}
if ($a==='list_by_integration') {
  [$c,$r,$err] = ha_request('GET', $base.'/api/config/entity_registry/list', $token);
  if ($c>=200 && $c<300) {
    $reg=json_decode($r,true)?:[]; $map=[];
    foreach($reg as $e){
      $id=$e['entity_id']??''; $plat=$e['platform']??'autre'; if(!$id)continue;
      if(!isset($map[$plat])) $map[$plat]=['cameras'=>[],'others'=>[]];
      if(strpos($id,'camera.')===0) $map[$plat]['cameras'][]=$id; else $map[$plat]['others'][]=$id;
    }
    $out=[]; foreach($map as $p=>$L){ sort($L['cameras']); sort($L['others']); $out[]=['platform'=>$p,'count'=>count($L['cameras'])+count($L['others']),'cameras'=>$L['cameras'],'others'=>$L['others']]; }
    usort($out, fn($a,$b)=>strcmp($a['platform'],$b['platform']));
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['integrations'=>$out,'fallback'=>false], JSON_UNESCAPED_UNICODE); exit;
  }
  [$c2,$r2,$e2]=ha_request('GET',$base.'/api/states',$token);
  if(!($c2>=200 && $c2<300)){
    http_response_code(502); header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error'=>true,'where'=>'fallback_states','code'=>$c2,'curl'=>$e2]); exit;
  }
  $all=json_decode($r2,true)?:[]; $map=[];
  foreach($all as $e){
    $id=$e['entity_id']??''; if(!$id)continue;
    $dom=strstr($id,'.',true)?:'other';
    $plat='domain:'.$dom;
    if(!isset($map[$plat])) $map[$plat]=['cameras'=>[],'others'=>[]];
    if($dom==='camera') $map[$plat]['cameras'][]=$id; else $map[$plat]['others'][]=$id;
  }
  $out=[]; foreach($map as $p=>$L){ sort($L['cameras']); sort($L['others']); $out[]=['platform'=>$p,'count'=>count($L['cameras'])+count($L['others']),'cameras'=>$L['cameras'],'others'=>$L['others']]; }
  usort($out, fn($a,$b)=>strcmp($a['platform'],$b['platform']));
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['integrations'=>$out,'fallback'=>true], JSON_UNESCAPED_UNICODE); exit;
}
http_response_code(400);
echo 'Unknown action';
