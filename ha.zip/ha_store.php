<?php
if (session_status() === PHP_SESSION_NONE) session_start();
function ha_user_email(): string {
  $email = $_SESSION['user']['email'] ?? '';
  if (!$email) { http_response_code(403); exit('Forbidden'); }
  return $email;
}
function ha_profile_dir(): string {
  $dir = __DIR__ . '/../../users/profiles/' . ha_user_email() . '/';
  @mkdir($dir, 0775, true);
  return $dir;
}
function ha_dir(): string {
  $dir = ha_profile_dir() . 'ha/';
  @mkdir($dir, 0775, true);
  return $dir;
}
function ha_secret_path(): string { return ha_dir().'secret.key'; }
function ha_secret(): string {
  $p = ha_secret_path();
  if (!file_exists($p)) { @file_put_contents($p, bin2hex(random_bytes(32)), LOCK_EX); @chmod($p, 0600); }
  return trim(@file_get_contents($p) ?: '');
}
function ha_encrypt(string $plain): string {
  if ($plain === '') return '';
  $key = substr(hash('sha256', ha_secret(), true), 0, 32);
  $iv  = random_bytes(16);
  $ct  = openssl_encrypt($plain, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
  return base64_encode($iv.$ct);
}
function ha_decrypt(string $blob): string {
  if ($blob === '') return '';
  $raw = base64_decode($blob, true);
  if ($raw === false || strlen($raw) < 17) return '';
  $iv  = substr($raw, 0, 16);
  $ct  = substr($raw, 16);
  $key = substr(hash('sha256', ha_secret(), true), 0, 32);
  $pt  = openssl_decrypt($ct, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
  return $pt === false ? '' : $pt;
}
function ha_cfg_path(): string { return ha_dir().'instances.json'; }
function ha_load_all(): array {
  $cfgPath = ha_cfg_path();
  if (!file_exists($cfgPath)) {
    $oldMono = ha_profile_dir().'ha.json';
    if (file_exists($oldMono)) {
      $old = json_decode(@file_get_contents($oldMono), true) ?: [];
      $id  = bin2hex(random_bytes(4));
      $data = [
        'instances' => [
          $id => [
            'name'      => 'HA',
            'base_url'  => rtrim($old['base_url'] ?? '', '/'),
            'token_enc' => ha_encrypt($old['token'] ?? ''),
            'cameras'   => is_array($old['cameras'] ?? null) ? $old['cameras'] : [],
            'sensors'   => is_array($old['sensors'] ?? null) ? $old['sensors'] : [],
          ]
        ]
      ];
      @file_put_contents($cfgPath, json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
    }
  }
  $globalKey = __DIR__ . '/../../users/keys/ha.secret';
  if (file_exists($globalKey) && !file_exists(ha_secret_path())) {
    @copy($globalKey, ha_secret_path()); @chmod(ha_secret_path(), 0600);
  }
  if (!file_exists($cfgPath)) return ['instances'=>[]];
  $j = json_decode(@file_get_contents($cfgPath), true);
  return is_array($j) ? $j : ['instances'=>[]];
}
function ha_save_all(array $cfg): void {
  @file_put_contents(ha_cfg_path(), json_encode($cfg, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
}
