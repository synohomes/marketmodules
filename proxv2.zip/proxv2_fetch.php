<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
$cfgDir   = __DIR__ . "/cfg/serveurs/";
$cacheDir = __DIR__ . "/cache/";
@mkdir($cacheDir, 0775, true);
function pve_api($ip, $port, $token, $secret, $endpoint) {
  $url = "https://$ip:$port/api2/json/$endpoint";
  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_HTTPHEADER => ["Authorization: PVEAPIToken=$token=$secret"],
    CURLOPT_TIMEOUT => 10
  ]);
  $resp = curl_exec($ch);
  $err  = curl_error($ch);
  curl_close($ch);
  if ($err) return ['error' => $err];
  $j = json_decode($resp, true);
  return $j['data'] ?? [];
}
function save_cache($cacheDir, $name, $data) {
  $safe = preg_replace('/[^a-zA-Z0-9_-]/', '_', $name);
  $file = "$cacheDir/$safe.json";
  $data['ts'] = time();
  file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}
if (!is_dir($cfgDir)) {
  echo "⚠️ Aucun dossier de configuration trouvé.";
  exit;
}
$servers = glob($cfgDir . "*.json");
if (empty($servers)) {
  echo "⚠️ Aucun serveur défini.";
  exit;
}
foreach ($servers as $f) {
  $cfg = json_decode(file_get_contents($f), true);
  if (!$cfg || empty($cfg['ip']) || empty($cfg['token_id']) || empty($cfg['secret'])) {
    echo "⛔ Fichier invalide : " . basename($f) . "<br>";
    continue;
  }
  $name  = $cfg['name'] ?? basename($f, '.json');
  $ip    = $cfg['ip'];
  $port  = $cfg['port'] ?? 8006;
  $token = $cfg['token_id'];
  $secret= $cfg['secret'];

  $result = [
    'node'   => null,
    'status' => null,
    'vms'    => [],
    'error'  => null
  ];
  $ver = pve_api($ip, $port, $token, $secret, "version");
  if (isset($ver['error'])) {
    $result['error'] = ['where'=>'version','code'=>$ver['error']];
    save_cache($cacheDir, $name, $result);
    echo "❌ Erreur version pour $name<br>";
    continue;
  }
  $nodes = pve_api($ip, $port, $token, $secret, "nodes");
  if (!is_array($nodes) || empty($nodes)) {
    $result['error'] = ['where'=>'nodes','code'=>'vide'];
    save_cache($cacheDir, $name, $result);
    echo "⚠️ Aucun node trouvé sur $name<br>";
    continue;
  }
  $nodeName = $nodes[0]['node'] ?? $name;
  $result['node'] = $nodeName;
  $status = pve_api($ip, $port, $token, $secret, "nodes/$nodeName/status");
  if (isset($status['error'])) $result['error'] = ['where'=>'status','code'=>$status['error']];
  else $result['status'] = $status;
  $vms = pve_api($ip, $port, $token, $secret, "nodes/$nodeName/qemu");
  if (isset($vms['error'])) $result['error'] = ['where'=>'vms','code'=>$vms['error']];
  else $result['vms'] = $vms;
  save_cache($cacheDir, $name, $result);
  echo "✔️ Cache mis à jour pour <b>$name</b> (node : <b>$nodeName</b>)<br>";
}
echo "<hr>✅ Terminé à " . date('H:i:s');
?>
