<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$ENABLE_CONSOLE = true;
$CACHE_TTL = 120;

$cfgDir   = __DIR__ . "/cfg/serveurs";
$cacheDir = __DIR__ . "/cache";

if (!is_dir($cacheDir)) {
  @mkdir($cacheDir, 0775, true);
}

$servers = [];
if (is_dir($cfgDir)) {
  foreach (glob($cfgDir . "/*.json") as $f) {
    $data = json_decode((string)@file_get_contents($f), true);
    if (is_array($data) && !empty($data['name'])) {
      $servers[] = $data;
    }
  }
}

function proxv2_e($value) {
  return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function proxv2_safe_name($name) {
  return preg_replace('/[^a-zA-Z0-9_-]/', '_', (string)$name);
}

function proxv2_read_cache($cacheDir, $name) {
  $safe = proxv2_safe_name($name);
  $f = $cacheDir . "/" . $safe . ".json";

  if (!is_file($f)) {
    return null;
  }

  $data = json_decode((string)@file_get_contents($f), true);
  return is_array($data) ? $data : null;
}

function proxv2_ago($ts) {
  $d = time() - (int)$ts;

  if ($d < 60) {
    return $d . 's';
  }

  if ($d < 3600) {
    return floor($d / 60) . 'm';
  }

  if ($d < 86400) {
    return floor($d / 3600) . 'h';
  }

  return floor($d / 86400) . 'j';
}

function proxv2_bytes_to_gb($bytes, $decimals = 1) {
  $bytes = (float)$bytes;
  if ($bytes <= 0) {
    return '0';
  }

  return number_format($bytes / (1024 * 1024 * 1024), $decimals, '.', ' ');
}

function proxv2_bytes_to_mb($bytes, $decimals = 1) {
  $bytes = (float)$bytes;
  if ($bytes <= 0) {
    return '0';
  }

  return number_format($bytes / (1024 * 1024), $decimals, '.', ' ');
}

function proxv2_pct($value, $decimals = 1) {
  return round(((float)$value) * 100, $decimals);
}

function proxv2_json_attr($data) {
  return htmlspecialchars(
    json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
    ENT_QUOTES,
    'UTF-8'
  );
}

if (empty($servers)) {
  echo "<link rel='stylesheet' href='modules/proxv2/proxv2.css?v=2'>";
  echo "<div class='proxv2-empty'>Aucun serveur Proxmox configuré.</div>";
  return;
}

echo "<link rel='stylesheet' href='modules/proxv2/proxv2.css?v=2'>";

$needUpdate = false;
?>

<div class="proxv2-root" data-proxv2-root>
<?php foreach ($servers as $srv): ?>
  <?php
    $srvName = $srv['name'] ?? ($srv['ip'] ?? 'pve');
    $srvIp = $srv['ip'] ?? '-';
    $cache = proxv2_read_cache($cacheDir, $srvName);

    $stale = true;
    if ($cache && isset($cache['ts'])) {
      $stale = (time() - (int)$cache['ts'] > $CACHE_TTL);
    }

    if (!$cache || $stale) {
      $needUpdate = true;
    }

    $status = $cache['status'] ?? null;
    $cpuUsage = 0;
    $memUsedGb = '0';
    $memTotalGb = '0';

    if (is_array($status)) {
      $cpuUsage = isset($status['cpu']) ? proxv2_pct($status['cpu']) : 0;
      $memUsedGb = isset($status['memory']['used']) ? proxv2_bytes_to_gb($status['memory']['used'], 1) : '0';
      $memTotalGb = isset($status['memory']['total']) ? proxv2_bytes_to_gb($status['memory']['total'], 1) : '0';
    }

    $vmsArr = $cache['vms'] ?? [];
    if (is_array($vmsArr)) {
      usort($vmsArr, function($a, $b) {
        if (($a['status'] ?? '') !== ($b['status'] ?? '')) {
          return (($a['status'] ?? '') === 'running') ? -1 : 1;
        }

        return ((int)($a['vmid'] ?? 0)) <=> ((int)($b['vmid'] ?? 0));
      });
    } else {
      $vmsArr = [];
    }

    $runningCount = 0;
    foreach ($vmsArr as $vmCount) {
      if (($vmCount['status'] ?? '') === 'running') {
        $runningCount++;
      }
    }
  ?>

  <section class="proxv2-server-card" data-server-card data-server="<?= proxv2_e($srvName) ?>">
    <header class="proxv2-server-head">
      <button type="button" class="proxv2-server-title" data-server-toggle aria-label="Afficher ou masquer les machines virtuelles">
        <span class="proxv2-server-icon">▣</span>
        <span class="proxv2-server-name"><?= proxv2_e($srvName) ?></span>
        <span class="proxv2-server-ip"><?= proxv2_e($srvIp) ?></span>
      </button>

      <div class="proxv2-server-tools">
        <?php if ($cache && isset($cache['ts'])): ?>
          <span class="proxv2-cache-badge <?= $stale ? 'is-stale' : 'is-fresh' ?>">
            cache <?= proxv2_e(proxv2_ago($cache['ts'])) ?>
          </span>
        <?php else: ?>
          <span class="proxv2-cache-badge is-stale">initialisation</span>
        <?php endif; ?>

        <button type="button" class="proxv2-refresh-btn" data-proxv2-refresh>↻ maj</button>
        <span class="proxv2-server-chevron">⌄</span>
      </div>
    </header>

    <div class="proxv2-server-body">
      <?php if (!empty($cache['error'])): ?>
        <div class="proxv2-api-warning">
          ⚠️ Erreur API <?= proxv2_e($cache['error']['where'] ?? '?') ?> — <?= proxv2_e($cache['error']['code'] ?? '?') ?>.
          Affichage basé sur le dernier cache disponible.
        </div>
      <?php endif; ?>

      <?php if (!$cache): ?>
        <div class="proxv2-loading">Chargement des données…</div>
        <div class="proxv2-vm-grid">
          <div class="proxv2-skeleton"></div>
          <div class="proxv2-skeleton"></div>
          <div class="proxv2-skeleton"></div>
        </div>
      <?php else: ?>
        <div class="proxv2-server-metrics">
          <div class="proxv2-metric">
            <span class="proxv2-metric-label">RAM utilisée</span>
            <strong><?= proxv2_e($memUsedGb) ?> / <?= proxv2_e($memTotalGb) ?> Go</strong>
          </div>
          <div class="proxv2-metric">
            <span class="proxv2-metric-label">CPU utilisé</span>
            <strong><?= proxv2_e($cpuUsage) ?>%</strong>
          </div>
          <div class="proxv2-metric">
            <span class="proxv2-metric-label">Machines virtuelles</span>
            <strong><?= count($vmsArr) ?> dont <?= $runningCount ?> actives</strong>
          </div>
        </div>

        <?php if (empty($vmsArr)): ?>
          <div class="proxv2-empty">Aucune machine virtuelle dans le cache.</div>
        <?php else: ?>
          <div class="proxv2-vm-grid">
            <?php foreach ($vmsArr as $vm): ?>
              <?php
                $vmid = (int)($vm['vmid'] ?? 0);
                $name = trim((string)($vm['name'] ?? ('VM-' . ($vmid ?: '?'))));
                $running = (($vm['status'] ?? '') === 'running');
                $statusText = $running ? 'running' : (($vm['status'] ?? '') ?: 'stopped');

                $typeForVm = strtolower((string)($vm['type'] ?? 'qemu'));
                if ($typeForVm !== 'lxc') {
                  $typeForVm = 'qemu';
                }

                $nodeForAction = $srvName;
                $realNode = $cache['node'] ?? $srvName;

                $cpu = isset($vm['cpu']) ? proxv2_pct($vm['cpu']) : 0;
                $ramUsedMb = isset($vm['mem']) ? proxv2_bytes_to_mb($vm['mem'], 1) : '0';
                $ramMaxMb = (isset($vm['maxmem']) && (float)$vm['maxmem'] > 0) ? proxv2_bytes_to_mb($vm['maxmem'], 1) : '0';
                $ramPct = ((float)($vm['maxmem'] ?? 0) > 0) ? round(((float)($vm['mem'] ?? 0) / (float)$vm['maxmem']) * 100, 1) : 0;

                $diskUsedGb = isset($vm['disk']) ? proxv2_bytes_to_gb($vm['disk'], 1) : '0';
                $diskMaxGb = (isset($vm['maxdisk']) && (float)$vm['maxdisk'] > 0) ? proxv2_bytes_to_gb($vm['maxdisk'], 1) : '0';
                $diskPct = ((float)($vm['maxdisk'] ?? 0) > 0) ? round(((float)($vm['disk'] ?? 0) / (float)$vm['maxdisk']) * 100, 1) : 0;

                $vmPayload = [
                  'server' => $srvName,
                  'server_ip' => $srvIp,
                  'node' => $nodeForAction,
                  'real_node' => $realNode,
                  'vmid' => $vmid,
                  'name' => $name,
                  'status' => $statusText,
                  'running' => $running,
                  'type' => $typeForVm,
                  'cpu' => $cpu,
                  'ram_used' => $ramUsedMb,
                  'ram_total' => $ramMaxMb,
                  'ram_pct' => $ramPct,
                  'disk_used' => $diskUsedGb,
                  'disk_total' => $diskMaxGb,
                  'disk_pct' => $diskPct
                ];
              ?>

              <button
                type="button"
                class="proxv2-vm-tile <?= $running ? 'is-running' : 'is-stopped' ?>"
                data-vm-card
                data-vm="<?= proxv2_json_attr($vmPayload) ?>"
                title="Ouvrir les options de <?= proxv2_e($name) ?>"
              >
                <span class="proxv2-vm-topline">
                  <span class="proxv2-vm-status-dot"></span>
                  <span class="proxv2-vm-id">#<?= $vmid ?></span>
                  <span class="proxv2-vm-state"><?= proxv2_e($statusText) ?></span>
                </span>

                <span class="proxv2-vm-name"><?= proxv2_e($name) ?></span>

                <span class="proxv2-vm-mini-metrics">
                  <span>CPU <?= proxv2_e($cpu) ?>%</span>
                  <span>RAM <?= proxv2_e($ramPct) ?>%</span>
                </span>
              </button>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      <?php endif; ?>
    </div>
  </section>
<?php endforeach; ?>

  <div class="proxv2-toast" data-proxv2-toast></div>
</div>

<div class="proxv2-modal" data-proxv2-modal aria-hidden="true">
  <div class="proxv2-modal-backdrop" data-proxv2-close></div>

  <section class="proxv2-modal-window" role="dialog" aria-modal="true" aria-labelledby="proxv2-modal-title">
    <header class="proxv2-modal-head">
      <div>
        <span class="proxv2-modal-kicker">Machine virtuelle</span>
        <h3 id="proxv2-modal-title">VM</h3>
      </div>
      <button type="button" class="proxv2-modal-close" data-proxv2-close aria-label="Fermer">×</button>
    </header>

    <div class="proxv2-modal-body">
      <div class="proxv2-modal-summary">
        <div>
          <span class="proxv2-detail-label">Serveur</span>
          <strong data-modal-server>-</strong>
        </div>
        <div>
          <span class="proxv2-detail-label">Node Proxmox</span>
          <strong data-modal-real-node>-</strong>
        </div>
        <div>
          <span class="proxv2-detail-label">Type</span>
          <strong data-modal-type>-</strong>
        </div>
        <div>
          <span class="proxv2-detail-label">Statut</span>
          <strong data-modal-status>-</strong>
        </div>
      </div>

      <div class="proxv2-resource-grid">
        <div class="proxv2-resource-card">
          <span class="proxv2-detail-label">CPU</span>
          <strong data-modal-cpu>0%</strong>
          <div class="proxv2-progress"><span data-modal-cpu-bar></span></div>
        </div>

        <div class="proxv2-resource-card">
          <span class="proxv2-detail-label">RAM</span>
          <strong data-modal-ram>0 / 0 Mo</strong>
          <div class="proxv2-progress"><span data-modal-ram-bar></span></div>
        </div>

        <div class="proxv2-resource-card">
          <span class="proxv2-detail-label">Disque</span>
          <strong data-modal-disk>0 / 0 Go</strong>
          <div class="proxv2-progress"><span data-modal-disk-bar></span></div>
        </div>
      </div>

      <div class="proxv2-actions">
        <button type="button" data-modal-action="start">Démarrer</button>
        <button type="button" data-modal-action="shutdown">Éteindre proprement</button>
        <button type="button" data-modal-action="stop">Stop forcé</button>
        <button type="button" data-modal-action="reboot">Redémarrer</button>
        <button type="button" data-modal-action="reset">Reset</button>
        <button type="button" data-modal-remote>Remote</button>
      </div>

      <div class="proxv2-premium-note">
        Remote / noVNC est prévu pour la version Proxv3 Premium.
      </div>
    </div>
  </section>
</div>

<div id="pv1-desktop"></div>
<div id="pv1-console" aria-modal="true" role="dialog">
  <div class="title">
    <span id="pv1-cap">Console</span>
    <button class="close" type="button">×</button>
  </div>
  <div class="body">
    <iframe id="pv1-iframe" src="about:blank" allow="clipboard-read; clipboard-write"></iframe>
  </div>
  <div class="grip" title="Redimensionner"></div>
</div>

<script>
(function(){
  const root = document.querySelector('[data-proxv2-root]');
  if (!root) return;

  const modal = document.querySelector('[data-proxv2-modal]');
  const toastBox = document.querySelector('[data-proxv2-toast]');
  const desktop = document.getElementById('pv1-desktop');
  const consoleWin = document.getElementById('pv1-console');
  const consoleCap = document.getElementById('pv1-cap');
  const consoleFrame = document.getElementById('pv1-iframe');

  let currentVm = null;

  function toast(message) {
    if (!toastBox) return;
    toastBox.textContent = message;
    toastBox.classList.add('is-visible');
    clearTimeout(window.__proxv2_toast);
    window.__proxv2_toast = setTimeout(() => {
      toastBox.classList.remove('is-visible');
    }, 2200);
  }

  function clampPct(value) {
    const n = Number(value);
    if (!Number.isFinite(n)) return 0;
    return Math.max(0, Math.min(100, n));
  }

  function setText(selector, value) {
    const el = modal.querySelector(selector);
    if (el) el.textContent = value;
  }

  function setBar(selector, value) {
    const el = modal.querySelector(selector);
    if (el) el.style.width = clampPct(value) + '%';
  }

  function updateActionState(vm) {
    const running = !!vm.running;

    modal.querySelectorAll('[data-modal-action]').forEach((button) => {
      const action = button.getAttribute('data-modal-action');

      if (action === 'start') {
        button.disabled = running;
      } else {
        button.disabled = !running;
      }
    });
  }

  function openVmModal(vm) {
    currentVm = vm;

    setText('#proxv2-modal-title', `#${vm.vmid} — ${vm.name}`);
    setText('[data-modal-server]', vm.server || '-');
    setText('[data-modal-real-node]', vm.real_node || '-');
    setText('[data-modal-type]', vm.type || 'qemu');
    setText('[data-modal-status]', vm.status || '-');

    setText('[data-modal-cpu]', `${vm.cpu || 0}%`);
    setText('[data-modal-ram]', `${vm.ram_used || 0} / ${vm.ram_total || 0} Mo`);
    setText('[data-modal-disk]', `${vm.disk_used || 0} / ${vm.disk_total || 0} Go`);

    setBar('[data-modal-cpu-bar]', vm.cpu || 0);
    setBar('[data-modal-ram-bar]', vm.ram_pct || 0);
    setBar('[data-modal-disk-bar]', vm.disk_pct || 0);

    updateActionState(vm);

    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
  }

  function closeVmModal() {
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
    currentVm = null;
  }

  async function runVmAction(action) {
    if (!currentVm) return;

    if (['stop', 'reset'].includes(action)) {
      if (!confirm(`Confirmer ${action.toUpperCase()} sur la VM #${currentVm.vmid} ?`)) {
        return;
      }
    }

    const buttons = Array.from(modal.querySelectorAll('[data-modal-action]'));
    buttons.forEach((button) => button.disabled = true);

    try {
      const response = await fetch('modules/proxv2/action.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          node: currentVm.node,
          vmid: currentVm.vmid,
          type: currentVm.type || 'qemu',
          action
        })
      });

      const payload = await response.json().catch(() => null);

      if (!response.ok || !payload || !payload.ok) {
        throw new Error((payload && payload.error) ? payload.error : `HTTP ${response.status}`);
      }

      toast(`✅ ${action} lancé sur VM #${currentVm.vmid}`);
      closeVmModal();
      setTimeout(() => location.reload(), 1200);
    } catch (error) {
      toast(`❌ ${error.message}`);
      updateActionState(currentVm);
    }
  }

  function openConsole(vm) {
    if (!consoleWin || !consoleFrame) return;

    consoleCap.textContent = `Console VM #${vm.vmid} (${vm.server})`;
    consoleFrame.src = `modules/proxv2/console.php?node=${encodeURIComponent(vm.node)}&vmid=${encodeURIComponent(vm.vmid)}&type=${encodeURIComponent(vm.type || 'qemu')}`;
    consoleWin.style.display = 'block';
    ensureConsoleDesktopBounds();
  }

  root.addEventListener('click', (event) => {
    const refresh = event.target.closest('[data-proxv2-refresh]');
    if (!refresh) return;

    event.preventDefault();
    event.stopPropagation();

    toast('⏳ Mise à jour du cache...');
    fetch('modules/proxv2/proxv2_fetch.php?t=' + Date.now(), {cache:'no-store'})
      .then(() => setTimeout(() => location.reload(), 600))
      .catch((error) => toast('❌ ' + error.message));
  });

  root.addEventListener('click', (event) => {
    const toggle = event.target.closest('[data-server-toggle]');
    if (!toggle) return;

    const card = toggle.closest('[data-server-card]');
    if (!card) return;

    card.classList.toggle('is-collapsed');
  });

  root.addEventListener('click', (event) => {
    const tile = event.target.closest('[data-vm-card]');
    if (!tile) return;

    try {
      const vm = JSON.parse(tile.getAttribute('data-vm') || '{}');
      openVmModal(vm);
    } catch (error) {
      toast('❌ Données VM illisibles');
    }
  });

  modal.addEventListener('click', (event) => {
    if (event.target.closest('[data-proxv2-close]')) {
      closeVmModal();
      return;
    }

    const actionButton = event.target.closest('[data-modal-action]');
    if (actionButton && !actionButton.disabled) {
      runVmAction(actionButton.getAttribute('data-modal-action'));
      return;
    }

    const remoteButton = event.target.closest('[data-modal-remote]');
    if (remoteButton && currentVm) {
      openConsole(currentVm);
    }
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && modal.classList.contains('is-open')) {
      closeVmModal();
    }
  });

  if (consoleWin) {
    const closeButton = consoleWin.querySelector('.close');
    const bar = consoleWin.querySelector('.title');
    const grip = consoleWin.querySelector('.grip');

    if (consoleWin.parentElement !== document.body) {
      document.body.appendChild(consoleWin);
    }

    if (desktop && desktop.parentElement !== document.body) {
      document.body.appendChild(desktop);
    }

    if (closeButton) {
      closeButton.addEventListener('click', () => {
        consoleFrame.src = 'about:blank';
        consoleWin.style.display = 'none';
      });
    }

    let drag = null;
    if (bar) {
      bar.addEventListener('mousedown', (event) => {
        const r = consoleWin.getBoundingClientRect();
        drag = {
          ox: event.clientX,
          oy: event.clientY,
          left: r.left + window.scrollX,
          top: r.top + window.scrollY
        };
        event.preventDefault();
      });
    }

    window.addEventListener('mousemove', (event) => {
      if (!drag) return;

      consoleWin.style.left = (drag.left + event.clientX - drag.ox) + 'px';
      consoleWin.style.top = (drag.top + event.clientY - drag.oy) + 'px';
      ensureConsoleDesktopBounds();
    });

    window.addEventListener('mouseup', () => {
      drag = null;
    });

    let resize = null;
    if (grip) {
      grip.addEventListener('mousedown', (event) => {
        const r = consoleWin.getBoundingClientRect();
        resize = {
          ox: event.clientX,
          oy: event.clientY,
          w: r.width,
          h: r.height
        };
        event.preventDefault();
      });
    }

    window.addEventListener('mousemove', (event) => {
      if (!resize) return;

      consoleWin.style.width = Math.max(520, resize.w + event.clientX - resize.ox) + 'px';
      consoleWin.style.height = Math.max(320, resize.h + event.clientY - resize.oy) + 'px';
      ensureConsoleDesktopBounds();
    });

    window.addEventListener('mouseup', () => {
      resize = null;
    });
  }

  function ensureConsoleDesktopBounds() {
    if (!desktop || !consoleWin) return;

    const r = consoleWin.getBoundingClientRect();
    const right = r.left + window.scrollX + r.width + 40;
    const bottom = r.top + window.scrollY + r.height + 40;

    if (right > desktop.offsetWidth) {
      desktop.style.width = right + 'px';
    }

    if (bottom > desktop.offsetHeight) {
      desktop.style.height = bottom + 'px';
    }
  }

  const NEED_UPDATE = <?= $needUpdate ? 'true' : 'false'; ?>;
  if (NEED_UPDATE) {
    const key = 'proxv2_last_bg_refresh';
    const now = Date.now();
    const ttl = 15000;
    const last = parseInt(sessionStorage.getItem(key) || '0', 10);

    if (now - last >= ttl) {
      sessionStorage.setItem(key, String(now));
      fetch('modules/proxv2/proxv2_fetch.php?t=' + Date.now(), {cache:'no-store'})
        .then(() => setTimeout(() => location.reload(), 700))
        .catch(() => {});
    }
  }
})();
</script>
