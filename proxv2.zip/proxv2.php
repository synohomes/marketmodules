<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
$ENABLE_CONSOLE   = true;   
$SHOW_CREATE_FORM = true;  
$CACHE_TTL        = 120;   
$cfgDir   = __DIR__ . "/cfg/serveurs";
$cacheDir = __DIR__ . "/cache";
if (!is_dir($cacheDir)) @mkdir($cacheDir, 0775, true);
$servers = [];
if (is_dir($cfgDir)) {
  foreach (glob($cfgDir . "/*.json") as $f) {
    $data = json_decode(@file_get_contents($f), true);
    if (is_array($data) && !empty($data['name'])) {
      $servers[] = $data;
    }
  }
}
if (empty($servers)) {
  echo "<div style='color:#ccc'>Aucun serveur Proxmox configuré.</div>";
  return;
}
function read_cache($cacheDir, $name) {
  $safe = preg_replace('/[^a-zA-Z0-9_-]/', '_', $name);
  $f = "$cacheDir/{$safe}.json";
  if (!file_exists($f)) return null;
  $data = json_decode(@file_get_contents($f), true);
  return is_array($data) ? $data : null;
}
function ago($ts){
  $d = time() - (int)$ts;
  if ($d < 60)   return $d.'s';
  if ($d < 3600) return floor($d/60).'m';
  return floor($d/3600).'h';
}
?>
<style>
.proxcard{background:#1a1a1a;border:1px solid #444;border-radius:8px;margin:10px 0;padding:10px;color:#ccc;position:relative}
.proxtitle{font-weight:bold;color:#fff;font-size:14px;margin-bottom:8px;cursor:pointer;user-select:none;position:relative}
.proxtitle::after{content:'▼';position:absolute;right:10px;transition:transform .2s ease}
.proxtitle.collapsed::after{transform:rotate(-90deg)}
.proxinfo{margin-left:10px;margin-bottom:6px}
.vmgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px;margin-top:6px}
.vmitem{background:#222;padding:10px;border-radius:8px;display:flex;flex-direction:column;align-items:stretch;justify-content:flex-start;min-height:130px;box-sizing:border-box}
.vmhead{display:flex;align-items:center;gap:8px;margin-bottom:6px}
.vmstatus{width:10px;height:10px;border-radius:50%;flex:0 0 10px}
.vmid{font-size:12px;color:#9bd;opacity:.9}
.vmname{font-size:14px;color:#eee;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1}
.vmmets{font-size:12px;line-height:1.3;margin-bottom:8px}
.vmmets .ram{color:#ccc}
.vmmets .cpu{color:#ccc}
.vmctrl{margin-top:auto;display:flex;gap:8px;flex-wrap:wrap}
.vmctrl button{background:#333;color:#ddd;border:none;font-size:12px;padding:6px 10px;border-radius:6px;flex:0 0 auto;cursor:not-allowed}
.vmctrl button.active{background:#2b7a3f;color:#fff;cursor:pointer}
.vmctrl button.active[disabled]{opacity:.55;cursor:not-allowed}
.badge{font-size:11px;color:#aaa;margin-left:8px}
.badge.stale{color:#f90}
.hidden{display:none}
.skel{background:repeating-linear-gradient(90deg,#2a2a2a,#2a2a2a 8px,#333 8px,#333 16px);height:90px;border-radius:6px}
.pv1-drawer-toggle{
  margin:8px 10px 10px 10px; display:flex; align-items:center; gap:8px;
  background:#181818; border:1px solid #333; color:#ddd; padding:8px 10px;
  border-radius:8px; cursor:pointer; user-select:none;
}
.pv1-drawer-toggle .chev{margin-left:auto; transition:transform .2s ease; opacity:.8}
.pv1-drawer.open + .pv1-drawer-toggle .chev{transform:rotate(180deg)}
.pv1-drawer{ margin:8px 10px; border:1px dashed #3a3a3a; border-radius:10px; overflow:hidden; max-height:0; transition:max-height .25s ease; }
.pv1-drawer.open{max-height:900px}
.pv1-form{background:#151515; padding:12px;}
.pv1-form h4{margin:0 0 10px 0;color:#ddd;font-size:14px;display:flex;align-items:center;gap:8px}
.pv1-grid{display:grid;gap:10px;grid-template-columns: repeat(auto-fit,minmax(180px,1fr));}
.pv1-field{display:flex;flex-direction:column;gap:6px}
.pv1-field label{font-size:12px;color:#bbb}
.pv1-field input,.pv1-field select{background:#202020;border:1px solid #3a3a3a;border-radius:6px;color:#ddd;padding:6px 8px;font-size:13px}
.pv1-actions{margin-top:10px;display:flex;gap:8px;align-items:center}
.pv1-btn{background:#2b2;border:none;color:#fff;border-radius:8px;padding:8px 12px;cursor:not-allowed;opacity:.7}
.pv1-chip{font-size:12px;color:#ccc;background:#222;border:1px solid #333;border-radius:999px;padding:4px 8px}
.pv1-note{color:#f0c040;font-size:12px}
.pv1-toast{
  position:absolute; right:16px; bottom:16px; background:#111; color:#eee;
  border:1px solid #333; padding:10px 12px; border-radius:10px; box-shadow:0 10px 30px rgba(0,0,0,.4);
  font-size:13px; display:none; z-index:1000;
}
#pv1-desktop{position:absolute; left:0; top:0; min-width:100%; min-height:100%; pointer-events:none; z-index:9998;}
#pv1-console{
  position:absolute; left:24px; top:24px; width:980px; height:600px;
  background:#111; border:1px solid #2b2b2b; border-radius:10px;
  box-shadow:0 25px 80px rgba(0,0,0,.65);
  z-index:9999; display:none; overflow:hidden; pointer-events:auto;
}
#pv1-console .title{
  display:flex; align-items:center; gap:10px;
  padding:10px 12px; background:#181818; color:#e8e8e8;
  border-bottom:1px solid #262626; font-weight:600; cursor:move; user-select:none;
}
#pv1-console .title .close{ margin-left:auto; background:#222; color:#ddd; border:1px solid #333; border-radius:8px; padding:6px 10px; cursor:pointer; }
#pv1-console .body{width:100%; height:calc(100% - 46px)}
#pv1-console iframe{width:100%; height:100%; border:0; background:#000}
#pv1-console .grip{position:absolute; right:8px; bottom:8px; width:14px; height:14px; cursor:nwse-resize; opacity:.7}
#pv1-console .grip::after{content:''; position:absolute; right:0; bottom:0; width:100%; height:100%; border-right:2px solid #666; border-bottom:2px solid #666;}
</style>
<script>
function toggleVMs(el){
  const g = el.nextElementSibling;
  if (g && g.classList.contains('vmbox')) {
    g.classList.toggle('hidden');
    el.classList.toggle('collapsed');
  }
}
</script>
<?php
$needUpdate = false;
foreach ($servers as $srv) {
  $srvName = $srv['name'] ?? ($srv['ip'] ?? 'pve');
  $cache   = read_cache($cacheDir, $srvName);
  $stale   = true;
  if ($cache && isset($cache['ts'])) $stale = (time() - $cache['ts'] > $CACHE_TTL);
  if (!$cache || $stale) $needUpdate = true;
  echo "<div class='proxcard'>";
  echo "<div class='proxtitle' onclick='toggleVMs(this)'>🖥️ "
     . htmlspecialchars($srvName)
     . " (" . htmlspecialchars($srv['ip'] ?? '-') . ")";
  if ($cache && isset($cache['ts'])) {
    $cls = $stale ? "badge stale" : "badge";
    echo "<span class='$cls'>cache " . ago($cache['ts']) . "</span>";
  } else {
    echo "<span class='badge stale'>initialisation…</span>";
  }
  echo " <button class='badge' style='margin-left:8px;border:1px solid #333;background:#222;padding:2px 6px;border-radius:6px;cursor:pointer' ".
     "onclick=\"(async()=>{await fetch('modules/proxv2/proxv2_fetch.php?t='+Date.now(),{cache:'no-store'});location.reload();})()\">↻ maj</button>";
  echo "</div>";
  echo "<div class='vmbox'>";
  if (!empty($cache['error'])) {
    $w = htmlspecialchars($cache['error']['where'] ?? '?');
    $c = htmlspecialchars((string)($cache['error']['code'] ?? '?'));
    echo "<div class='proxinfo' style='color:#f90'>⚠️ Erreur API ($w) — code $c. Affichage basé sur le dernier cache disponible.</div>";
  }
  if (!$cache) {
    echo "<div class='proxinfo'>Chargement des données…</div>";
    echo "<div class='vmgrid'><div class='skel'></div><div class='skel'></div><div class='skel'></div></div>";
    echo "</div></div>";
    continue;
  }
  $status = $cache['status'] ?? null;
  if ($status) {
    $cpuUsage = isset($status['cpu']) ? round($status['cpu'] * 100, 1) : 0;
    $memUsed  = isset($status['memory']['used'])  ? round($status['memory']['used']  / (1024*1024*1024), 1) : 0;
    $memTotal = isset($status['memory']['total']) ? round($status['memory']['total'] / (1024*1024*1024), 1) : 0;
    echo "<div class='proxinfo'>🧠 RAM utilisée : {$memUsed} / {$memTotal} Go</div>";
    echo "<div class='proxinfo'>⚙️ CPU utilisé : {$cpuUsage}%</div>";
  }
  $vmsArr = $cache['vms'] ?? [];
  if ($vmsArr) {
    echo "<div class='proxinfo'>💾 Machines virtuelles :</div><div class='vmgrid'>";
    usort($vmsArr, function($a,$b){
      if (($a['status']??'') !== ($b['status']??'')) return (($a['status']??'')==='running')?-1:1;
      return ($a['vmid']??0) <=> ($b['vmid']??0);
    });
    foreach ($vmsArr as $vm) {
      $name    = trim($vm['name'] ?? ("VM-".($vm['vmid']??'?')));
      $short   = (mb_strlen($name)>28) ? (mb_substr($name,0,28).'…') : $name;
      $vmid    = (int)($vm['vmid'] ?? 0);
      $running = (($vm['status']??'')==='running');
      $color   = $running ? "#22c55e" : "#ef4444";
      $cpu = isset($vm['cpu']) ? round($vm['cpu']*100,1) : 0;
      $ramUsed = isset($vm['mem']) ? round($vm['mem']/(1024*1024),1) : 0;
      $ramMax  = (isset($vm['maxmem']) && $vm['maxmem']>0) ? round($vm['maxmem']/(1024*1024),1) : 0;
      $ramStr  = $ramMax ? "$ramUsed / $ramMax Mo" : "$ramUsed Mo";
      $ramWarn = ($ramMax>0 && ($ramUsed/$ramMax)>0.8);
      $nodeForVm = $vm['node'] ?? ($cache['node'] ?? $srvName);
      $typeForVm = strtolower($vm['type'] ?? 'qemu'); if ($typeForVm!=='lxc') $typeForVm='qemu';
      echo "<div class='vmitem'>";
      echo "  <div class='vmhead'>
                <span class='vmstatus' style='background:{$color}'></span>
                <span class='vmid'>#{$vmid}</span>
                <span class='vmname' title='".htmlspecialchars($name,ENT_QUOTES)."'>".htmlspecialchars($short,ENT_QUOTES)."</span>
              </div>";
      $ramColor = $ramWarn ? "#f59e0b" : "#ccc";
      $cpuColor = ($cpu>80) ? "#f59e0b" : "#ccc";
      echo "  <div class='vmmets'>
                <div class='ram' style='color:{$ramColor}'>RAM : {$ramStr}</div>
                <div class='cpu' style='color:{$cpuColor}'>CPU : {$cpu}%</div>
              </div>";
      echo "  <div class='vmctrl'>";
      if ($ENABLE_CONSOLE) {
        $btnClass = $running ? "active pv1-console-btn" : "";
        $disabled = $running ? "" : "disabled";
        echo "    <button type='button' class='{$btnClass}'
                         data-node='".htmlspecialchars($nodeForVm,ENT_QUOTES)."'
                         data-vmid='{$vmid}'
                         data-type='{$typeForVm}' {$disabled}>🖥️</button>";
      }
      $attr = "data-node='".htmlspecialchars($nodeForVm,ENT_QUOTES)."' data-vmid='{$vmid}' data-type='{$typeForVm}'";
      echo "    <button type='button' class='active' {$attr} data-action='start'    ".($running?'disabled':'').">▶️ Start</button>";
      echo "    <button type='button' class='active' {$attr} data-action='shutdown' ".(!$running?'disabled':'').">⏻ Shutdown</button>";
      echo "    <button type='button' class='active' {$attr} data-action='stop'     ".(!$running?'disabled':'').">⛔ Stop</button>";
      echo "    <button type='button' class='active' {$attr} data-action='reboot'   ".(!$running?'disabled':'').">🔁 Reboot</button>";
      echo "    <button type='button' class='active' {$attr} data-action='reset'    ".(!$running?'disabled':'').">♻️ Reset</button>";
      echo "  </div>";
      echo "</div>";
    }
    echo "</div>";
  }
  echo "<div class='pv1-toast' data-toast>OK.</div>";
  echo "</div></div>";
}
?>
<div id="pv1-desktop"></div>
<div id="pv1-console" aria-modal="true" role="dialog">
  <div class="title"><span id="pv1-cap">Console</span><button class="close" type="button">✖</button></div>
  <div class="body"><iframe id="pv1-iframe" src="about:blank" allow="clipboard-read; clipboard-write"></iframe></div>
  <div class="grip" title="Redimensionner"></div>
</div>
<script>
(function(){
  const root    = document.currentScript.closest('.module, .module-container, body');
  const desktop = document.getElementById('pv1-desktop');
  const win     = document.getElementById('pv1-console');
  const cap     = document.getElementById('pv1-cap');
  const ifr     = document.getElementById('pv1-iframe');
  const bar     = win.querySelector('.title');
  const btnX    = win.querySelector('.close');
  const grip    = win.querySelector('.grip');
  if (desktop.parentElement !== document.body) document.body.appendChild(desktop);
  if (win.parentElement !== document.body) document.body.appendChild(win);
  const toast = (scope, txt)=>{
    const t = scope.querySelector('[data-toast]') || document.querySelector('[data-toast]');
    if (!t) return; t.textContent = txt; t.style.display='block';
    clearTimeout(window.__pv1_toast_t); window.__pv1_toast_t=setTimeout(()=>{t.style.display='none'},1800);
  };
  function openConsole(node, vmid, type){
    cap.textContent = `Console VM #${vmid} (${node})`;
    ifr.src = `modules/proxv2/console.php?node=${encodeURIComponent(node)}&vmid=${encodeURIComponent(vmid)}&type=${encodeURIComponent(type||'qemu')}`;
    win.style.display = 'block';
    ensureDesktopBounds();
  }
  function closeConsole(){ ifr.src='about:blank'; win.style.display='none'; }
  btnX.addEventListener('click', closeConsole);
  let drag=null;
  bar.addEventListener('mousedown', (e)=>{
    const r = win.getBoundingClientRect();
    const s = getScrollXY();
    drag = {ox:e.clientX, oy:e.clientY, left:r.left+s.x, top:r.top+s.y};
    e.preventDefault();
  });
  window.addEventListener('mousemove', (e)=>{
    if (!drag) return;
    const dx = e.clientX - drag.ox, dy = e.clientY - drag.oy;
    win.style.left = (drag.left + dx) + 'px';
    win.style.top  = (drag.top  + dy) + 'px';
    ensureDesktopBounds();
  });
  window.addEventListener('mouseup', ()=> drag=null);
  let rs=null;
  grip.addEventListener('mousedown', (e)=>{
    const r = win.getBoundingClientRect();
    const s = getScrollXY();
    rs = {ox:e.clientX, oy:e.clientY, w:r.width, h:r.height, left:r.left+s.x, top:r.top+s.y};
    e.preventDefault();
  });
  window.addEventListener('mousemove', (e)=>{
    if (!rs) return;
    const dx = e.clientX - rs.ox, dy = e.clientY - rs.oy;
    win.style.width  = Math.max(520, rs.w + dx) + 'px';
    win.style.height = Math.max(320, rs.h + dy) + 'px';
    ensureDesktopBounds();
  });
  window.addEventListener('mouseup', ()=> rs=null);
  function getScrollXY(){
    return {
      x: window.pageXOffset || document.documentElement.scrollLeft || 0,
      y: window.pageYOffset || document.documentElement.scrollTop  || 0
    };
  }
  function ensureDesktopBounds(){
    const r = win.getBoundingClientRect();
    const s = getScrollXY();
    const right  = r.left + s.x + r.width  + 40;
    const bottom = r.top  + s.y + r.height + 40;
    if (right  > desktop.offsetWidth)  desktop.style.width  = right + 'px';
    if (bottom > desktop.offsetHeight) desktop.style.height = bottom + 'px';
  }
  root.addEventListener('click', (e)=>{
    const b = e.target.closest('.pv1-console-btn.active');
    if (!b) return;
    e.preventDefault(); e.stopPropagation();
    openConsole(b.getAttribute('data-node'), b.getAttribute('data-vmid'), b.getAttribute('data-type')||'qemu');
  });
  root.addEventListener('click', async (e)=>{
    const act = e.target.closest('button.active[data-action]');
    if (!act) return;
    if (act.disabled) return;

    const action = act.getAttribute('data-action');
    const vmid   = act.getAttribute('data-vmid');
    const type   = act.getAttribute('data-type') || 'qemu';
    const card = act.closest('.proxcard');
    let node = card ? card.querySelector('.proxtitle')?.textContent.trim() : '';
    node = node.replace(/^🖥️\s*/, '').split(' ')[0];
    if (!node) {
      alert("Nom de serveur introuvable dans l'interface.");
      return;
    }
    if (['stop','reset'].includes(action) && !confirm(`Confirmer ${action.toUpperCase()} VM #${vmid} ?`)) return;
    const grp  = act.closest('.vmctrl');
    const btns = grp ? Array.from(grp.querySelectorAll('button.active[data-action]')) : [];
    btns.forEach(b=> b.disabled = true);
    try {
      const r = await fetch('modules/proxv2/action.php', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({node, vmid, type, action})
      });
      const j = await r.json().catch(()=>null);
      if (!r.ok || !j || !j.ok) throw new Error((j && j.error) ? j.error : `HTTP ${r.status}`);
      toast(root, `✅ ${action} #${vmid} sur ${node}`);
      setTimeout(()=> location.reload(), 1200);
    } catch(err) {
      toast(root, `❌ ${err.message}`);
      btns.forEach(b=> b.disabled = false);
    }
  });
  root.addEventListener('click', (e)=>{
    const tog = e.target.closest('[data-drawer-toggle]');
    if (!tog) return;
    const id = tog.getAttribute('data-drawer-toggle');
    const drawer = root.querySelector('#'+CSS.escape(id));
    if (!drawer) return;
    drawer.classList.toggle('open');
    const chev = tog.querySelector('.chev');
    if (chev) chev.style.transform = drawer.classList.contains('open') ? 'rotate(180deg)' : 'none';
  });
  const NEED = <?php echo $needUpdate ? 'true' : 'false'; ?>;
  if (NEED) {
    const KEY='proxv2_last_bg_refresh', NOW=Date.now(), TTL=15000;
    const last = parseInt(sessionStorage.getItem(KEY)||'0',10);
    if (NOW - last >= TTL) {
      sessionStorage.setItem(KEY, String(NOW));
      fetch('modules/proxv2/proxv2_fetch.php?t=' + Date.now(), {cache:'no-store'})
        .then(()=> setTimeout(()=>location.reload(), 700))
        .catch(()=>{});
    }
  }
})();
</script>
