<?php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

if (
  !isset($_SESSION['user']['email']) ||
  ($_SESSION['user']['role_system'] ?? '') !== 'admin'
) {
  http_response_code(403);
  die("Accès réservé à l’administrateur.");
}

error_reporting(E_ALL);
ini_set('display_errors', 1);
$node = $_GET['node'] ?? '';
$vmid = (int)($_GET['vmid'] ?? 0);
$type = $_GET['type'] ?? 'qemu';
if (!$node || !$vmid) die("Paramètres manquants");
$cfgDir = __DIR__ . "/cfg/serveurs/";
$server = null;
foreach (glob($cfgDir . "*.json") as $f) {
  $d = json_decode(@file_get_contents($f), true);
  if (strcasecmp($d['name'] ?? '', $node) === 0) { $server = $d; break; }
}
if (!$server) die("Serveur introuvable");
$keyFile = __DIR__ . "/cfg/.proxv2.key";

function proxv2_crypto_key_console($keyFile) {
  $raw = trim((string)@file_get_contents($keyFile));
  if ($raw === '') return '';
  return hash('sha256', $raw, true);
}

function proxv2_decrypt_secret_console($server, $keyFile) {
  if (!is_array($server)) return '';

  if (!empty($server['secret'])) {
    return (string)$server['secret'];
  }

  if (empty($server['secret_enc'])) return '';

  $decoded = base64_decode($server['secret_enc'], true);
  if ($decoded === false) return '';

  $payload = json_decode($decoded, true);
  if (!is_array($payload)) return '';

  $iv = base64_decode($payload['iv'] ?? '', true);
  $tag = base64_decode($payload['tag'] ?? '', true);
  $data = base64_decode($payload['data'] ?? '', true);

  if ($iv === false || $tag === false || $data === false) return '';

  $key = proxv2_crypto_key_console($keyFile);
  if ($key === '') return '';

  $plain = openssl_decrypt(
    $data,
    'aes-256-gcm',
    $key,
    OPENSSL_RAW_DATA,
    $iv,
    $tag
  );

  return $plain === false ? '' : $plain;
}

$ip = $server['ip'] ?? '';
$port = (int)($server['port'] ?? 8006);

if ($port <= 0 || $port > 65535) {
  $port = 8006;
}
$token = $server['token_id'] ?? '';
$secret = proxv2_decrypt_secret_console($server, $keyFile);

if (!$ip || !$token || !$secret) {
  die("Données API manquantes.");
}
$cacheDir = __DIR__ . "/cache/";
$realNode = null;

$cacheFile = $cacheDir . preg_replace('/[^a-zA-Z0-9_-]/', '_', $server['name'] ?? $node) . ".json";

if (is_file($cacheFile)) {
  $cache = json_decode((string)@file_get_contents($cacheFile), true);
  if (is_array($cache) && !empty($cache['node'])) {
    $realNode = $cache['node'];
  }
}

if (!$realNode) {
  $realNode = $node;
}
$url = "https://$ip:$port/api2/json/nodes/" . rawurlencode($realNode) . "/" . rawurlencode($type) . "/" . rawurlencode($vmid) . "/vncproxy";
$ch = curl_init($url);
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_POST => true,
  CURLOPT_POSTFIELDS => "websocket=1",
  CURLOPT_SSL_VERIFYPEER => false,
  CURLOPT_SSL_VERIFYHOST => false,
  CURLOPT_HTTPHEADER => ["Authorization: PVEAPIToken=$token=$secret"]
]);
$res = curl_exec($ch);
curl_close($ch);
$j = json_decode($res, true);
$d = $j['data'] ?? null;
if (!$d) die("Erreur de proxy : $res");
$ws = "wss://$ip:$port/api2/json/nodes/" . rawurlencode($realNode) . "/vncwebsocket?port={$d['port']}&vncticket=" . urlencode($d['ticket']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Console VM #<?= htmlspecialchars($vmid) ?></title>
<style>
html,body{margin:0;height:100%;background:#000;}
iframe{width:100%;height:100%;border:0;}
</style>
</head>
<body>
<iframe src="novnc/vnc.html?autoconnect=true&path=<?= htmlspecialchars($ws) ?>"></iframe>
</body>
</html>
