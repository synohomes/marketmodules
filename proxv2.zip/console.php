<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
$node = isset($_GET['node']) ? trim($_GET['node']) : '';
$vmid = isset($_GET['vmid']) ? (int)$_GET['vmid'] : 0;
$type = isset($_GET['type']) ? strtolower($_GET['type']) : 'qemu';
if ($type !== 'lxc') $type = 'qemu';
function html_error($msg, $http=200){
  http_response_code($http);
  echo "<!doctype html><meta charset='utf-8'><style>
        body{margin:0;background:#000;color:#ddd;font-family:system-ui,Segoe UI,Roboto,Arial,sans-serif}
        .bar{background:#111;border-bottom:1px solid #222;padding:8px 12px;font-weight:600}
        .box{margin:12px;background:#111;border:1px solid #333;border-radius:8px;padding:12px}
        .pill{display:inline-block;background:#333;border:1px solid #444;padding:2px 8px;border-radius:999px;font-size:12px;margin-left:8px}
        </style>
        <div class='bar'>Console VNC <span class='pill'>erreur</span></div>
        <div class='box'>".htmlspecialchars($msg,ENT_QUOTES)."</div>";
  exit;
}
if ($node === '' || $vmid <= 0) {
  html_error("Requête invalide. Il faut appeler la page avec ?node=...&vmid=...&type=qemu|lxc", 400);
}
$cfgFile = __DIR__ . "/cfg/proxv2.json";
$servers = file_exists($cfgFile) ? json_decode(@file_get_contents($cfgFile), true) : [];
if (!is_array($servers)) $servers = [];
$server = null;
foreach ($servers as $s) {
  $name = $s['name'] ?? '';
  $ip   = $s['ip']   ?? '';
  if (($name && strcasecmp($name,$node)===0) || ($ip && strcasecmp($ip,$node)===0)) { $server = $s; break; }
}
if (!$server && $servers) $server = $servers[0];
if (!$server) html_error("Serveur introuvable dans cfg/proxv2.json", 500);
$ip        = $server['ip']   ?? '127.0.0.1';
$port      = (int)($server['port'] ?? 8006);
$tokenId   = $server['token_id'] ?? '';
$secret    = $server['secret']   ?? '';
$encrypted = !empty($server['encrypted']);
if ($encrypted) {
  $keyFile = "/var/lib/domydesk_keys/proxv2.key";
  if (extension_loaded('sodium') && file_exists($keyFile)) {
    $raw = base64_decode($secret, true);
    if ($raw !== false && strlen($raw) > SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) {
      $nonce = substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
      $ct    = substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
      $key   = file_get_contents($keyFile);
      $dec   = sodium_crypto_secretbox_open($ct, $nonce, $key);
      if ($dec !== false) $secret = $dec;
    }
  }
}
if ($tokenId === '' || $secret === '') html_error("Token API manquant dans cfg/proxv2.json", 500);
$base = "https://{$ip}:{$port}/api2/json";
$url  = "{$base}/nodes/".rawurlencode($node)."/{$type}/{$vmid}/vncproxy";
$ch = curl_init($url);
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_POST           => true,
  CURLOPT_POSTFIELDS     => http_build_query(['websocket'=>1]),
  CURLOPT_HTTPHEADER     => [
    "Authorization: PVEAPIToken={$tokenId}={$secret}",
    "Content-Type: application/x-www-form-urlencoded"
  ],
  CURLOPT_SSL_VERIFYPEER => false,
  CURLOPT_SSL_VERIFYHOST => false,
  CURLOPT_TIMEOUT        => 12,
  CURLOPT_CONNECTTIMEOUT => 6,
]);
$resp = curl_exec($ch);
$http = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
$err  = curl_error($ch);
curl_close($ch);
if ($http !== 200 || !$resp) html_error("vncproxy échoue: ".($err ?: "HTTP $http"), 502);
$j = json_decode($resp, true);
$data = $j['data'] ?? null;
if (!$data) html_error("Réponse vncproxy invalide", 502);
$wsPort = $data['port']   ?? null;
$ticket = $data['ticket'] ?? null;
if (!$wsPort || !$ticket) html_error("Ticket/port manquants (vncproxy)", 502);

$WS_VIA_PROXY = true;            
$proxyBase    = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'wss://' : 'ws://')
                . $_SERVER['HTTP_HOST'] . '/pve/api2/json';
$directBase   = "wss://{$ip}:{$port}/api2/json";
$wsBase       = $WS_VIA_PROXY ? $proxyBase : $directBase;
$wsUrl = $wsBase . "/nodes/" . rawurlencode($node)
       . "/vncwebsocket?port={$wsPort}&vncticket=" . rawurlencode($ticket);
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>noVNC<?= (int)$vmid ?> (<?= htmlspecialchars($node,ENT_QUOTES) ?>)</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    html,body{height:100%;margin:0;background:#000;color:#ddd;font-family:system-ui,Segoe UI,Roboto,Arial,sans-serif}
    #bar{background:#111;border-bottom:1px solid #222;padding:6px 10px;font-size:14px}
    #screen{width:100%;height:calc(100% - 36px);background:#000}
    .pill{display:inline-block;background:#333;border:1px solid #444;padding:2px 8px;border-radius:999px;font-size:12px;margin-left:8px}
    #err{position:absolute;top:8px;left:8px;background:#222;border:1px solid #444;border-radius:6px;padding:6px 10px;color:#eee;display:none;max-width:90%}
  </style>
</head>
<body>
  <div id="bar">Console VM<?= (int)$vmid ?> — <?= htmlspecialchars($node,ENT_QUOTES) ?><span class="pill">noVNC</span></div>
  <div id="screen" role="application" aria-label="VNC"></div>
  <div id="err"></div>
  <script type="module">
    import RFB from './novnc/core/rfb.js';

    const screen = document.getElementById('screen');
    const errBox = document.getElementById('err');
    const wsUrl  = <?= json_encode($wsUrl, JSON_UNESCAPED_SLASHES) ?>;

    function showErr(t){ errBox.textContent = t; errBox.style.display='block'; }

    try{
      const rfb = new RFB(screen, wsUrl, { credentials: {} });
      rfb.viewOnly      = false;
      rfb.scaleViewport = true;
      rfb.resizeSession = true;

      rfb.addEventListener('connect', ()=>{ errBox.style.display='none'; });
      rfb.addEventListener('disconnect', (e)=>{ showErr('Déconnecté'); console.log('disconnect', e); });
      rfb.addEventListener('securityfailure', (e)=>{ showErr('Échec sécurité WebSocket (Origin/CORS).'); console.error(e); });
    }catch(e){
      showErr('Erreur noVNC: ' + (e && e.message ? e.message : String(e)));
      console.error(e);
    }
  </script>
</body>
</html>
