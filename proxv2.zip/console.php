<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
$node = $_GET['node'] ?? '';
$vmid = (int)($_GET['vmid'] ?? 0);
$type = $_GET['type'] ?? 'qemu';
if (!$node || !$vmid) die("Paramètres manquants");
$cfgDir = __DIR__ . "/cfg/serveurs/";
$server = null;
foreach (glob($cfgDir . "*.json") as $f) {
  $d = json_decode(@file_get_contents($f), true);
  if (strcasecmp($d['name'] ?? '', $node) === 0) { $server = $d; break; }
}
if (!$server) die("Serveur introuvable");
$ip = $server['ip']; $port = $server['port'] ?? 8006;
$token = $server['token_id']; $secret = $server['secret'];
$url = "https://$ip:$port/api2/json/nodes/$node/$type/$vmid/vncproxy";
$ch = curl_init($url);
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_POST => true,
  CURLOPT_POSTFIELDS => "websocket=1",
  CURLOPT_SSL_VERIFYPEER => false,
  CURLOPT_SSL_VERIFYHOST => false,
  CURLOPT_HTTPHEADER => ["Authorization: PVEAPIToken=$token=$secret"]
]);
$res = curl_exec($ch);
curl_close($ch);
$j = json_decode($res, true);
$d = $j['data'] ?? null;
if (!$d) die("Erreur de proxy : $res");
$ws = "wss://$ip:$port/api2/json/nodes/$node/vncwebsocket?port={$d['port']}&vncticket=" . urlencode($d['ticket']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Console VM #<?= htmlspecialchars($vmid) ?></title>
<style>
html,body{margin:0;height:100%;background:#000;}
iframe{width:100%;height:100%;border:0;}
</style>
</head>
<body>
<iframe src="novnc/vnc.html?autoconnect=true&path=<?= htmlspecialchars($ws) ?>"></iframe>
</body>
</html>
