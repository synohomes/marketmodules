<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['user']['email']) || ($_SESSION['user']['role_system'] ?? '') !== 'admin') {
  echo "<div style='color:#f66;padding:10px'>⛔ Accès réservé à l’administrateur.</div>";
  exit;
}
error_reporting(E_ALL);
ini_set('display_errors', 1);
$cfgFile = __DIR__ . "/cfg/proxv2.json";
@is_dir(dirname($cfgFile)) || @mkdir(dirname($cfgFile), 0775, true);
$keyDir  = "/var/lib/domydesk_keys";
$keyFile = $keyDir . "/proxv2.key";
function flash($txt, $type='ok'){
  $col = ($type==='ok') ? '#9f9' : (($type==='warn') ? '#ffb84d' : '#f66');
  echo "<div style='margin:10px 0;padding:10px;border:1px solid rgba(255,255,255,.15);border-radius:8px;background:#12171d;color:$col'>{$txt}</div>";
}
$servers = file_exists($cfgFile) ? json_decode(@file_get_contents($cfgFile), true) : [];
if (!is_array($servers)) $servers = [];
if (($_POST['op'] ?? '') === 'delete_server') {
  $idx = (int)($_POST['idx'] ?? -1);
  if ($idx >= 0 && isset($servers[$idx])) {
    array_splice($servers, $idx, 1);
    @file_put_contents($cfgFile, json_encode($servers, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
    flash("🗑️ Serveur supprimé.", 'ok');
  } else {
    flash("❌ Index invalide pour la suppression.", 'err');
  }
}
if (($_POST['op'] ?? '') === 'save_servers') {
  $encrypt = !empty($_POST['encrypt_api']);
  $key = null;
  if ($encrypt) {
    if (!extension_loaded('sodium')) {
      flash("❌ Libsodium absente : chiffrement désactivé.", 'err');
      $encrypt = false;
    } else {
      if (!is_dir($keyDir)) @mkdir($keyDir, 0700, true);
      if (!file_exists($keyFile)) {
        $key = sodium_crypto_secretbox_keygen();
        @file_put_contents($keyFile, $key);
        @chmod($keyFile, 0600);
      } else {
        $key = @file_get_contents($keyFile);
      }
    }
  }
  $names = $_POST['name'] ?? [];
  $ips   = $_POST['ip'] ?? [];
  $ports = $_POST['port'] ?? [];
  $tids  = $_POST['token_id'] ?? [];
  $secs  = $_POST['secret'] ?? [];
  $dels  = $_POST['__del'] ?? [];
  $out = [];
  $n = max(count($names), count($ips), count($ports), count($tids), count($secs), count($dels));
  for ($i=0; $i<$n; $i++) {
    $nm = trim($names[$i] ?? '');
    $ip = trim($ips[$i] ?? '');
    if (($dels[$i] ?? '') === '1') continue;    
    if ($nm==='' && $ip==='') continue;  
    $srv = [
      'name'      => $nm,
      'ip'        => $ip,
      'port'      => trim($ports[$i] ?? '8006'),
      'token_id'  => trim($tids[$i] ?? ''),
      'secret'    => trim($secs[$i] ?? ''),
      'encrypted' => (bool)$encrypt,
    ];
    if ($encrypt && $srv['secret']!=='') {
      $nonce  = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
      $cipher = sodium_crypto_secretbox($srv['secret'], $nonce, $key);
      $srv['secret'] = base64_encode($nonce.$cipher);
    }
    $out[] = $srv;
  }
  @file_put_contents($cfgFile, json_encode($out, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
  $servers = $out;
  $msg = "✅ Enregistré.";
  if ($encrypt) $msg .= " 🔐 Clé : <code>{$keyFile}</code>";
  flash($msg, 'ok');
}
if (($_POST['op'] ?? '') === 'syno_proxy') {
  $synoHost = trim($_POST['syno_host'] ?? '');
  $synoUser = trim($_POST['syno_user'] ?? '');
  $synoPass = (string)($_POST['syno_pass'] ?? '');
  $pveIp    = trim($_POST['pve_ip'] ?? '');
  $pvePort  = (int)($_POST['pve_port'] ?? 8006);
  $path     = '/pve'; 
  $scheme   = 'https';
  if ($synoHost==='' || $synoUser==='' || $synoPass==='' || $pveIp==='') {
    flash("❌ Champs requis manquants pour l’assistant DSM.", 'err');
  } else {
    $base = "https://{$synoHost}/webapi";
    $authUrl = $base . "/auth.cgi?api=SYNO.API.Auth&method=login&version=6"
            . "&account=" . urlencode($synoUser)
            . "&passwd="  . urlencode($synoPass)
            . "&session=core&format=cookie";
    $ch = curl_init($authUrl);
    curl_setopt_array($ch, [
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_SSL_VERIFYPEER => false,
      CURLOPT_SSL_VERIFYHOST => false,
      CURLOPT_HEADER         => true,
      CURLOPT_FOLLOWLOCATION => false,
    ]);
    $resp = curl_exec($ch); $err = curl_error($ch);
    $http = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    if ($http!==200 || !$resp) {
      flash("❌ Connexion DSM : ".htmlspecialchars($err ?: "HTTP $http"), 'err');
    } else {
      preg_match_all('/Set-Cookie:\s*([^;]+)/i', $resp, $m);
      $cookies = implode('; ', $m[1] ?? []);
      if (stripos($cookies, 'id=')===false && stripos($cookies, 'sid=')===false) {
        flash("❌ Auth DSM échouée (compte / 2FA / droits).", 'err');
      } else {
        $call = function($url, $post=null) use($cookies){
          $ch = curl_init($url);
          curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_HTTPHEADER     => ["Cookie: $cookies", "Content-Type: application/x-www-form-urlencoded"],
            CURLOPT_POST           => $post!==null,
            CURLOPT_POSTFIELDS     => $post ? http_build_query($post) : null,
          ]);
          $body = curl_exec($ch); $err = curl_error($ch);
          $http = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
          curl_close($ch);
          return [$http, $body, $err];
        };
        $rpApi  = 'SYNO.Core.AppPortal.ReverseProxy';
        $rpVers = 1;
        list($http,$body,$err) = $call($base."/entry.cgi?api={$rpApi}&version={$rpVers}&method=list");
        $okApi = ($http===200 && $body && strpos($body,'"success":true')!==false);
        if (!$okApi) {
          flash("⚠️ L’API ReverseProxy DSM ne répond pas sur ce modèle/firmware. Je te donne la procédure manuelle en bas.", 'warn');
        } else {
          $j = json_decode($body, true);
          $exists = false; $ruleId = null;
          if (!empty($j['data']['list']) && is_array($j['data']['list'])) {
            foreach ($j['data']['list'] as $r) {
              $src = $r['source']['path'] ?? '';
              if ($src===$path || $src===rtrim($path,'/').'/*') { $exists=true; $ruleId=$r['id']??null; break; }
            }
          }
          if ($exists) {
            flash("✅ Règle Reverse-Proxy déjà présente pour <code>{$path}</code>.", 'ok');
          } else {
            // 4) Créer la règle
            $payload = [
              'api'     => $rpApi,
              'version' => $rpVers,
              'method'  => 'create',
              'source'  => json_encode([
                'fqdn'   => '',
                'scheme' => 'https',
                'port'   => 443,
                'path'   => $path,
              ]),
              'destination' => json_encode([
                'scheme' => $scheme, // https
                'host'   => $pveIp,
                'port'   => $pvePort,
                'path'   => '/',
              ]),
              'custom_headers' => json_encode([
                ['name'=>'Upgrade','value'=>'$http_upgrade'],
                ['name'=>'Connection','value'=>'upgrade'],
              ]),
              'enabled' => 'true',
              'http2'   => 'true',
            ];
            list($http2,$body2,$err2) = $call($base."/entry.cgi", $payload);
            $okCreate = ($http2===200 && $body2 && strpos($body2,'"success":true')!==false);
            if ($okCreate) {
              flash("✅ Règle créée <code>{$path} → {$scheme}://{$pveIp}:{$pvePort}/</code>.", 'ok');
              @list($http3,$body3,$err3) = $call($base."/entry.cgi?api=SYNO.Core.WebService.Nginx&version=1&method=reload");
              flash("🔁 Nginx rechargé.", 'ok');
            } else {
              flash("❌ Échec de création Reverse-Proxy (variantes DSM). Procédure manuelle ci-dessous.", 'err');
            }
          }
        }
        echo "<div style='margin:10px 0;color:#ccc'>ℹ️ Vérifie que <code>modules/proxv2/console.php</code> construit bien l’URL WebSocket comme <code>wss://TON_NAS/pve/api2/json/nodes/.../vncwebsocket?...&vncticket=...</code>.</div>";
      }
    }
  }
}

?>
<style>
  .wrap{display:flex;gap:18px;align-items:flex-start;flex-wrap:wrap}
  .pane{flex:1 1 560px;min-width:520px;background:#0f151b;border:1px solid #243243;border-radius:12px;padding:14px;color:#dfe8f3}
  h2{margin:0 0 10px 0;color:#92d4ff;font-size:18px}
  .small{font-size:12px;color:#9fb}
  table{width:100%;border-collapse:collapse}
  th,td{border-bottom:1px solid #223040;padding:6px;vertical-align:middle}
  input[type=text],input[type=password],input[type=number]{width:100%;background:#12171d;border:1px solid #2b3846;border-radius:8px;color:#e6eef7;padding:8px;box-sizing:border-box}
  .btn{background:#224d8a;color:#fff;border:0;border-radius:8px;padding:8px 12px;cursor:pointer}
  .btn.save{background:#2b7a3f}
  .btn.del{background:#3b1f1f}
  .grid{display:grid;grid-template-columns:180px 1fr;gap:8px;align-items:center}
  code{background:#1b2330;border:1px solid #2e3a49;border-radius:6px;padding:2px 6px}
  .procv2-apercu{
    flex:1 1 320px; min-width:300px;
    background:#0f151b; border:1px solid #2d3a4a; border-radius:10px;
    padding:12px; color:#cfe7ff; cursor:pointer; font-size:14px;
    max-height:460px; overflow:auto;
  }
  .procv2-apercu:hover{ background:#111a22 }
  #proxv2_help{
    display:none; position:fixed; inset:0; z-index:9999;
    background:rgba(0,0,0,.6); padding:24px 12px; box-sizing:border-box;
    overflow:auto;
  }
  #proxv2_help .box{
    position:relative; margin:0 auto; max-width:980px; max-height:90vh; overflow:auto;
    background:#0f151b; border:1px solid #2d3a4a; border-radius:12px; padding:18px; color:#e6eef7;
  }
  #proxv2_help .close{
    position:absolute; top:10px; right:12px;
    background:#224d8a; color:#fff; border:1px solid #2d3a4a; border-radius:8px;
    padding:6px 10px; cursor:pointer;
  }
  #proxv2_help h1{ color:#92d4ff; font-size:20px; margin:0 0 12px }
  #proxv2_help h2{ color:#76c3ff; font-size:16px; margin:14px 0 8px }
  #proxv2_help ul{ margin:6px 0 8px 18px }
  #proxv2_help code{ background:#1b2330; border:1px solid #2e3a49; border-radius:6px; padding:2px 6px }
  #proxv2_help pre{
    max-width:100%; overflow:auto; background:#0b0f14; border:1px solid #2e3a49;
    border-radius:8px; padding:10px; white-space:pre-wrap; word-break:break-word; color:#d7eaff;
  }
  #proxv2_help .note{ font-size:12px; color:#9fb }
  #proxv2_help .grid2{ display:grid; grid-template-columns:220px 1fr; gap:8px; align-items:start }
</style>

<div class="wrap">
  <div class="pane">
    <h2>Serveurs Proxmox (V2)</h2>
    <div style="margin:6px 0 10px;display:flex;gap:8px;flex-wrap:wrap">
      <button type="button" class="btn" onclick="openProxHelp()">📘 Procédure complète</button>
    </div>
    <form method="post" action="">
      <input type="hidden" name="op" value="save_servers">
      <table>
        <thead>
          <tr>
            <th>Nom</th><th>IP</th><th>Port</th><th>Token ID</th><th>Secret</th><th>Action</th>
          </tr>
        </thead>
        <tbody id="srvrows">
        <?php if (empty($servers)): ?>
          <tr>
            <td><input name="name[]"     type="text" placeholder="PVE1"></td>
            <td><input name="ip[]"       type="text" placeholder="192.168.1.10"></td>
            <td><input name="port[]"     type="number" value="8006"></td>
            <td><input name="token_id[]" type="text" placeholder="user@pve!token"></td>
            <td><input name="secret[]"   type="password" placeholder="secret ici"></td>
            <td>
              <input type="hidden" name="__del[]" value="0">
              <button type="button" class="btn del" onclick="delRow(this)">🗑️</button>
            </td>
          </tr>
        <?php else: foreach ($servers as $i => $s): ?>
          <tr>
            <td><input name="name[]"     type="text" value="<?=htmlspecialchars($s['name']??'')?>"></td>
            <td><input name="ip[]"       type="text" value="<?=htmlspecialchars($s['ip']??'')?>"></td>
            <td><input name="port[]"     type="number" value="<?=htmlspecialchars($s['port']??'8006')?>"></td>
            <td><input name="token_id[]" type="text" value="<?=htmlspecialchars($s['token_id']??'')?>"></td>
            <td><input name="secret[]"   type="password" placeholder="<?=!empty($s['encrypted'])?'(chiffré)':''?>"></td>
            <td style="white-space:nowrap">
              <input type="hidden" name="__del[]" value="0">
              <button type="button" class="btn del" title="Marquer pour suppression" onclick="delRow(this)">🗑️</button>
              <form method="post" action="" style="display:inline" onsubmit="return confirm('Supprimer ce serveur définitivement ?')">
                <input type="hidden" name="op" value="delete_server">
                <input type="hidden" name="idx" value="<?= (int)$i ?>">
                <button class="btn del" type="submit" title="Supprimer définitivement">✖</button>
              </form>
            </td>
          </tr>
        <?php endforeach; endif; ?>
        </tbody>
      </table>

      <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn" type="button" onclick="addRow()">Ajouter un serveur</button>
      </div>

      <label class="small" style="display:flex;align-items:center;gap:8px;margin-top:10px">
        <input type="checkbox" name="encrypt_api" value="1"> Chiffrer les secrets (libsodium)
      </label>
      <div class="small">La clé sera stockée dans <code><?=htmlspecialchars($keyFile)?></code>.</div>

      <div style="margin-top:10px">
        <button class="btn save" type="submit">💾 Enregistrer</button>
      </div>
    </form>
  </div>
  <div class="pane">
    <h2>Assistant proxy Synology (DSM) → Proxmox</h2>
    <div class="small" style="margin-bottom:8px">
      Crée une règle <code>/pve</code> sur le NAS pour relayer vers <code>https://IP_PROXMOX:8006</code> (compatible WebSocket).
      Si l’API DSM n’est pas dispo, la procédure manuelle est affichée après soumission.
    </div>
    <form method="post" action="">
      <input type="hidden" name="op" value="syno_proxy">
      <div class="grid">
        <label>NAS (hôte / FQDN) :</label>
        <input name="syno_host" type="text" placeholder="nas.mondomaine.tld ou 192.168.1.21" required>
        <label>Admin DSM :</label>
        <input name="syno_user" type="text" placeholder="admin (ou compte admin DSM)" required>
        <label>Mot de passe DSM :</label>
        <input name="syno_pass" type="password" placeholder="••••••" required>
        <label>Proxmox IP :</label>
        <input name="pve_ip" type="text" placeholder="192.168.1.10" required>
        <label>Proxmox port :</label>
        <input name="pve_port" type="number" value="8006" required>
      </div>
      <div style="margin-top:10px">
        <button class="btn save" type="submit">Créer / Valider le proxy</button>
      </div>
      <div class="small" style="margin-top:8px;color:#aaa">
        Le compte DSM est utilisé uniquement pour cet appel local, aucun identifiant n’est stocké.
        Si DSM a une 2FA, désactive-la temporairement pour cette opération ou utilise un compte admin sans 2FA.
      </div>
    </form>
  </div>
  <div class="procv2-apercu" onclick="openProxHelp()" title="Clique pour la procédure complète">
    <h3 style="margin:0 0 6px;color:#92d4ff">📘 Procédure complète Proxmox (V2)</h3>
    <p style="margin:0 0 6px">1) Créer l’utilisateur & API Token Proxmox</p>
    <p style="margin:0 0 6px">2) Permissions minimales (datacenter)</p>
    <p style="margin:0 0 6px">3) Tester l’API (curl)</p>
    <p style="margin:0 0 6px">4) Reverse-proxy DSM (WebSocket)</p>
    <p class="small">Clique pour tout le détail, copies d’URL et commandes.</p>
  </div>
</div>
<?php
$cfgFile = __DIR__ . "/cfg/proxv2.json";  // <- chemin unique V2
echo "<div style='margin:8px 0;padding:8px;border:1px solid #2d3a4a;border-radius:8px;background:#0f141a;color:#cde'>
       📁 Fichier de configuration (V2) : <code>" . htmlspecialchars(realpath($cfgFile) ?: $cfgFile) . "</code><br>";
if (!file_exists($cfgFile)) {
  echo "⚠️ Le fichier n’existe pas encore. Il sera créé à l’enregistrement.";
} else {
  $t = @file_get_contents($cfgFile);
  echo ($t === false)
    ? "❌ Lecture impossible (droits ?)"
    : "✅ Lecture OK (" . strlen($t) . " octets)";
}
$w = @file_put_contents($cfgFile, file_exists($cfgFile)?file_get_contents($cfgFile):"[]", LOCK_EX);
echo ($w === false)
  ? "<br>❌ Test d’écriture KO (droits ?)"
  : "<br>✅ Test d’écriture OK";
echo "</div>";
?>
<div id="proxv2_help">
  <div class="box">
    <button class="close" onclick="closeProxHelp()">Fermer</button>
    <h1>Procédure complète — Intégration Proxmox (V2)</h1>
    <h2>0) Pré-requis</h2>
    <ul>
      <li>Accès <b>admin</b> à Proxmox (PVE 7/8).</li>
      <li>DoMyDesk accessible via HTTPS (certificat valide recommandé).</li>
      <li>Optionnel : NAS Synology pour reverse-proxy public.</li>
    </ul>
    <h2>1) Créer l’utilisateur Proxmox (si besoin)</h2>
    <ul>
      <li>Interface PVE : <b>Datacenter → Permissions → Users</b></li>
      <li><b>User</b> : <code>dmd-integ</code> — <b>Realm</b> : <code>pve</code></li>
      <li>Mot de passe fort (ou compte existant dédié intégration)</li>
    </ul>
    <h2>2) Créer un API Token</h2>
    <ul>
      <li>Interface PVE : <b>Datacenter → Permissions → API Tokens</b></li>
      <li><b>User</b> : <code>dmd-integ@pve</code> — <b>Token ID</b> : <code>proxv2</code></li>
      <li><b>Privilege Separation</b> : ✅ (recommandé)</li>
      <li>Récupère <b>Token ID</b> = <code>dmd-integ@pve!proxv2</code>, et <b>Secret</b> (affiché une seule fois)</li>
    </ul>
    <h2>3) Donner des permissions minimales</h2>
    <div class="grid2">
      <div>Si tu veux lister nœuds/VMs, console VNC :</div>
      <div>
        <ul>
          <li><b>Datacenter → Permissions</b> → <b>Add</b></li>
          <li><b>Path</b> : <code>/</code> (ou scope restreint), <b>User</b> : <code>dmd-integ@pve</code></li>
          <li><b>Role</b> : <code>PVEAuditor</code> (lecture) <i>ou</i> <code>Administrator</code> si besoin d’actions</li>
          <li><b>Propagate</b> : ✅</li>
        </ul>
        <p class="note">Pour la console VNC via API, des permissions sur <code>/nodes/*/qemu/*</code> peuvent être nécessaires selon usage.</p>
      </div>
    </div>
    <h2>4) Tester l’API (depuis DoMyDesk ou ta machine)</h2>
    <pre><code>curl -k \
  -H "Authorization: PVEAPIToken=dmd-integ@pve!proxv2=SECRET" \
  https://IP_PVE:8006/api2/json/version</code></pre>
    <p>Réponse attendue : <code>{"data":{"version":"8.x",...}}</code></p>
    <h2>5) Renseigner l’accès dans DoMyDesk (pane “Serveurs Proxmox V2”)</h2>
    <ul>
      <li><b>Nom</b> (libre), <b>IP</b> (ou FQDN), <b>Port</b> (8006 par défaut)</li>
      <li><b>Token ID</b> : <code>dmd-integ@pve!proxv2</code></li>
      <li><b>Secret</b> : la clé générée par Proxmox</li>
      <li>Option <b>🔒 Chiffrer</b> : stocke le secret chiffré (libsodium) et la clé dans <code>/var/lib/domydesk_keys/proxv2.key</code></li>
    </ul>
    <h2>6) Reverse-proxy NAS Synology (DSM) → Proxmox (optionnel/public)</h2>
    <ul>
      <li>DSM : <b>Panneau de config → Portail d’applications → Proxy inversé</b></li>
      <li><b>Créer</b> une règle :
        <ul>
          <li><b>Source</b> : <b>HTTPS</b>, Hôte = ton domaine, <b>Port</b> 443, <b>Chemin</b> <code>/pve</code></li>
          <li><b>Destination</b> : <b>HTTPS</b>, Hôte = <code>IP_PVE</code>, Port = <code>8006</code>, Chemin = <code>/</code></li>
        </ul>
      </li>
      <li><b>En-têtes personnalisés</b> :
        <ul>
          <li><code>Upgrade: $http_upgrade</code></li>
          <li><code>Connection: upgrade</code></li>
        </ul>
      </li>
      <li>Active <b>HTTP/2</b> et conserve le certificat valide côté NAS.</li>
    </ul>
    <p class="note">Dans DoMyDesk, l’URL websocket devra ressembler à
      <code>wss://TON_NAS/pve/api2/json/nodes/&lt;node&gt;/qemu/&lt;vmid&gt;/vncwebsocket?port=...&amp;vncticket=...</code>
    </p>
    <h2>7) Tests rapides</h2>
    <pre><code># Liste des nœuds
curl -k -H "Authorization: PVEAPIToken=dmd-integ@pve!proxv2=SECRET" \
  https://IP_PVE:8006/api2/json/nodes
# Liste des VMs d’un nœud
curl -k -H "Authorization: PVEAPIToken=dmd-integ@pve!proxv2=SECRET" \
  https://IP_PVE:8006/api2/json/nodes/NODE/qemu</code></pre>
    <h2>8) Dépannage</h2>
    <ul>
      <li><b>401/403</b> : Token ou Secret incorrect, rôle insuffisant, Realm mauvais.</li>
      <li><b>SSL</b> : Cert non valide → utiliser <code>-k</code> (test) ou un cert valide.</li>
      <li><b>WebSocket</b> : reverse-proxy sans en-têtes Upgrade/Connection.</li>
      <li><b>Chiffrement</b> : vérifier droits sur <code>/var/lib/domydesk_keys</code> (0700) et fichier clé (0600).</li>
    </ul>
    <h2>9) Sécurité</h2>
    <ul>
      <li>Créer un <b>compte dédié</b> et limiter les permissions au strict nécessaire.</li>
      <li>Garder le <b>Secret</b> hors des logs ; préférer le chiffrement côté serveur.</li>
      <li>Activer 2FA sur les comptes humains (pas sur le token).</li>
    </ul>
  </div>
</div>
<script>
function addRow(){
  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td><input name="name[]"     type="text" placeholder="PVE2"></td>
    <td><input name="ip[]"       type="text" placeholder="192.168.1.11"></td>
    <td><input name="port[]"     type="number" value="8006"></td>
    <td><input name="token_id[]" type="text" placeholder="user@pve!token"></td>
    <td><input name="secret[]"   type="password" placeholder="secret ici"></td>
    <td>
      <input type="hidden" name="__del[]" value="0">
      <button type="button" class="btn del" onclick="delRow(this)" title="Marquer pour suppression">🗑️</button>
    </td>`;
  document.getElementById('srvrows').appendChild(tr);
}
function delRow(btn){
  const tr = btn.closest('tr');
  const del = tr.querySelector('input[name="__del[]"]');
  if (del) del.value = '1';
  tr.style.opacity = .45;
  tr.style.textDecoration = 'line-through';
}
function openProxHelp(){
  const m = document.getElementById('proxv2_help');
  if (m) m.style.display = 'block';
}
function closeProxHelp(){
  const m = document.getElementById('proxv2_help');
  if (m) m.style.display = 'none';
}
document.addEventListener('keydown', (e)=>{ if(e.key==='Escape') closeProxHelp(); });
document.getElementById('proxv2_help')?.addEventListener('click', (e)=>{
  if (e.target.id === 'proxv2_help') closeProxHelp();
});
</script>
