<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['user']['email']) || ($_SESSION['user']['role_system'] ?? '') !== 'admin') {
  echo "<div class='section'>⛔ Accès réservé à l’administrateur.</div>";
  exit;
}
error_reporting(E_ALL);
ini_set('display_errors', 1);
$baseDir = __DIR__ . '/cfg';
$servDir = $baseDir . '/serveurs';
$keyFile = $baseDir . '/.proxv2.key';

if (!is_dir($servDir)) @mkdir($servDir, 0775, true);

function safefn($name){
  return preg_replace('/[^a-zA-Z0-9_\-]/','_',strtolower(trim($name)));
}

function proxv2_ensure_security_files($baseDir, $servDir, $keyFile){
  if (!is_dir($baseDir)) @mkdir($baseDir, 0775, true);
  if (!is_dir($servDir)) @mkdir($servDir, 0775, true);

  foreach ([$baseDir, $servDir] as $dir) {
    $ht = $dir . '/.htaccess';
    if (!is_file($ht)) {
      @file_put_contents($ht, "Require all denied\n");
    }
  }

  if (!is_file($keyFile)) {
    @file_put_contents($keyFile, bin2hex(random_bytes(32)));
    @chmod($keyFile, 0640);
  }
}

function proxv2_crypto_key($keyFile){
  $raw = trim((string)@file_get_contents($keyFile));
  if ($raw === '') {
    $raw = bin2hex(random_bytes(32));
    @file_put_contents($keyFile, $raw);
    @chmod($keyFile, 0640);
  }

  return hash('sha256', $raw, true);
}

function proxv2_encrypt_secret($secret, $keyFile){
  $secret = (string)$secret;
  if ($secret === '') return '';

  $key = proxv2_crypto_key($keyFile);
  $iv = random_bytes(12);
  $tag = '';

  $cipher = openssl_encrypt(
    $secret,
    'aes-256-gcm',
    $key,
    OPENSSL_RAW_DATA,
    $iv,
    $tag
  );

  if ($cipher === false) return '';

  return base64_encode(json_encode([
    'v' => 1,
    'alg' => 'aes-256-gcm',
    'iv' => base64_encode($iv),
    'tag' => base64_encode($tag),
    'data' => base64_encode($cipher)
  ]));
}

function proxv2_decrypt_secret($serverData, $keyFile){
  if (!is_array($serverData)) return '';

  // Ancien format non sécurisé : compatibilité temporaire
  if (!empty($serverData['secret'])) {
    return (string)$serverData['secret'];
  }

  if (empty($serverData['secret_enc'])) return '';

  $payload = json_decode(base64_decode($serverData['secret_enc']), true);
  if (!is_array($payload)) return '';

  $key = proxv2_crypto_key($keyFile);
  $iv = base64_decode($payload['iv'] ?? '', true);
  $tag = base64_decode($payload['tag'] ?? '', true);
  $data = base64_decode($payload['data'] ?? '', true);

  if ($iv === false || $tag === false || $data === false) return '';

  $plain = openssl_decrypt(
    $data,
    'aes-256-gcm',
    $key,
    OPENSSL_RAW_DATA,
    $iv,
    $tag
  );

  return $plain === false ? '' : $plain;
}

function proxv2_migrate_server_file($file, $keyFile){
  $j = json_decode((string)@file_get_contents($file), true);
  if (!is_array($j)) return null;

  // Migration automatique : secret clair -> secret_enc
  if (!empty($j['secret']) && empty($j['secret_enc'])) {
    $j['secret_enc'] = proxv2_encrypt_secret($j['secret'], $keyFile);
    unset($j['secret']);
    $j['updated'] = date('c');
    @file_put_contents($file, json_encode($j, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
  }

  return $j;
}

function listServers($servDir, $keyFile){
  $out = [];

  foreach (glob($servDir.'/*.json') as $f) {
    $j = proxv2_migrate_server_file($f, $keyFile);
    if (is_array($j) && !empty($j['name'])) {
      unset($j['secret'], $j['secret_enc']);
      $j['has_secret'] = true;
      $out[] = $j;
    }
  }

  return $out;
}

proxv2_ensure_security_files($baseDir, $servDir, $keyFile);
function proxv2_log($action, $target = '', $status = 'info', $details = '', $extra = []) {
  $root = dirname(__DIR__, 2);
  $logDir = $root . '/data/logs';

  if (!is_dir($logDir)) {
    @mkdir($logDir, 0775, true);
  }

  $logFile = $logDir . '/proxv2.json';

  $entry = [
    'date' => date('Y-m-d H:i:s'),
    'module' => 'proxv2',
    'user' => $_SESSION['user']['email'] ?? 'unknown',
    'role_system' => $_SESSION['user']['role_system'] ?? '',
    'action' => $action,
    'target' => $target,
    'status' => $status,
    'details' => $details,
    'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
  ];

  if (is_array($extra) && !empty($extra)) {
    $entry['extra'] = $extra;
  }

  @file_put_contents(
    $logFile,
    json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . PHP_EOL,
    FILE_APPEND | LOCK_EX
  );
}
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['op']??'')==='add'){
  $name = trim($_POST['name'] ?? '');
  $ip = trim($_POST['ip'] ?? '');
  $port = trim($_POST['port'] ?? '8006');
  $token = trim($_POST['token_id'] ?? '');
  $secret = trim($_POST['secret'] ?? '');

  if ($name === '' || $ip === '') {
    echo "<div class='section'>❌ Nom et IP requis.</div>";
  } else {
    $fn = $servDir . '/' . safefn($name) . '.json';

    $data = [
      'name' => $name,
      'ip' => $ip,
      'port' => $port,
      'token_id' => $token,
      'secret_enc' => proxv2_encrypt_secret($secret, $keyFile),
      'created' => date('c'),
      'updated' => date('c')
    ];

    file_put_contents($fn, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
	proxv2_log(
  'server_add',
  $name,
  'success',
  'Ajout d’un serveur Proxmox',
  [
    'server_name' => $name,
    'server_ip' => $ip,
    'server_port' => $port,
    'token_id' => $token
  ]
);
    header('Location: '.$_SERVER['REQUEST_URI']);
    exit;
  }
}
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['op']??'')==='delete'){
  $name=safefn($_POST['name']??'');
  $fn=$servDir.'/'.$name.'.json';
if (is_file($fn)) {
  $old = json_decode((string)@file_get_contents($fn), true);
  @unlink($fn);

  proxv2_log(
    'server_delete',
    $name,
    'success',
    'Suppression d’un serveur Proxmox',
    [
      'server_name' => $old['name'] ?? $name,
      'server_ip' => $old['ip'] ?? '',
      'server_port' => $old['port'] ?? '',
      'token_id' => $old['token_id'] ?? ''
    ]
  );

  header('Location: '.$_SERVER['REQUEST_URI']);
  exit;
}
  
  else echo "<div class='section'>❌ Serveur introuvable.</div>";
}
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['op']??'')==='edit'){
  $name = safefn($_POST['name'] ?? '');
  $field = $_POST['field'] ?? '';
  $value = $_POST['value'] ?? '';

  $allowedFields = ['name', 'ip', 'port', 'token_id'];
  if (!in_array($field, $allowedFields, true)) {
    echo 'err';
    exit;
  }

  $fn = $servDir . '/' . $name . '.json';
  if (!is_file($fn)) {
    echo 'err';
    exit;
  }

  $j = proxv2_migrate_server_file($fn, $keyFile);
  if (!is_array($j)) {
    echo 'err';
    exit;
  }

  $j[$field] = $value;
  $j['updated'] = date('c');

  echo (@file_put_contents($fn, json_encode($j, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) !== false) ? 'ok' : 'err';
  exit;
}
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['op']??'')==='editfull'){
  $oldname = safefn($_POST['oldname'] ?? '');
  $fnOld = $servDir . '/' . $oldname . '.json';

  if (!is_file($fnOld)) {
    echo "❌ Serveur introuvable.";
    exit;
  }

  $data = proxv2_migrate_server_file($fnOld, $keyFile);
  if (!is_array($data)) {
    echo "❌ Fichier serveur invalide.";
    exit;
  }

  $data['name'] = trim($_POST['name'] ?? $data['name']);
  $data['ip'] = trim($_POST['ip'] ?? $data['ip']);
  $data['port'] = trim($_POST['port'] ?? $data['port']);
  $data['token_id'] = trim($_POST['token_id'] ?? $data['token_id']);

  $newSecret = trim($_POST['secret'] ?? '');

  // Si le champ secret est vide, on conserve l’ancien secret_enc.
  if ($newSecret !== '') {
    $data['secret_enc'] = proxv2_encrypt_secret($newSecret, $keyFile);
  }

  unset($data['secret']);

  $data['updated'] = date('c');

  $newFile = $servDir . '/' . safefn($data['name']) . '.json';

  if ($fnOld !== $newFile && is_file($fnOld)) {
    @rename($fnOld, $newFile);
  }

  file_put_contents($newFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
proxv2_log(
  'server_edit',
  $data['name'] ?? $oldname,
  'success',
  'Modification d’un serveur Proxmox',
  [
    'old_name' => $oldname,
    'new_name' => $data['name'] ?? '',
    'server_ip' => $data['ip'] ?? '',
    'server_port' => $data['port'] ?? '',
    'token_id' => $data['token_id'] ?? '',
    'secret_changed' => $newSecret !== ''
  ]
);
  echo "ok";
  exit;
}
if (isset($_GET['ajax']) && $_GET['ajax'] === 'get_server') {
  header('Content-Type: application/json; charset=utf-8');

  $name = safefn($_GET['name'] ?? '');
  $fn = $servDir . '/' . $name . '.json';

  if (!is_file($fn)) {
    echo json_encode(['success' => false, 'error' => 'Serveur introuvable']);
    exit;
  }

  $j = proxv2_migrate_server_file($fn, $keyFile);

  if (!is_array($j)) {
    echo json_encode(['success' => false, 'error' => 'JSON invalide']);
    exit;
  }

  echo json_encode([
    'success' => true,
    'server' => [
      'name' => $j['name'] ?? '',
      'ip' => $j['ip'] ?? '',
      'port' => $j['port'] ?? '8006',
      'token_id' => $j['token_id'] ?? '',
      'has_secret' => !empty($j['secret_enc'])
    ]
  ], JSON_UNESCAPED_UNICODE);

  exit;
}

$servers = listServers($servDir, $keyFile);
?>
<?php
if (isset($_GET['op']) || isset($_POST['op'])) {
  $op = $_GET['op'] ?? $_POST['op'];
  $srvName = $_GET['srv'] ?? $_POST['srv'] ?? '';
  $srvFile = __DIR__ . '/cfg/serveurs/' . safefn($srvName) . '.json';
  if (!is_file($srvFile)) { echo json_encode(['error'=>'Serveur non trouvé']); exit; }
  $s = json_decode(file_get_contents($srvFile), true);
  $s = proxv2_migrate_server_file($srvFile, $keyFile);
$ip = $s['ip'] ?? '';
$port = $s['port'] ?? '8006';
$token = $s['token_id'] ?? '';
$secret = proxv2_decrypt_secret($s, $keyFile);
  function pveApi($ip,$port,$token,$secret,$endpoint,$method='GET',$data=null){
    $url="https://$ip:$port/api2/json/$endpoint";
    $ch=curl_init($url);
    curl_setopt_array($ch,[
      CURLOPT_RETURNTRANSFER=>true,
      CURLOPT_SSL_VERIFYPEER=>false,
      CURLOPT_SSL_VERIFYHOST=>false,
      CURLOPT_HTTPHEADER=>["Authorization: PVEAPIToken=$token=$secret"]
    ]);
    if($method==='POST'){
      curl_setopt($ch,CURLOPT_POST,true);
      curl_setopt($ch,CURLOPT_POSTFIELDS,is_array($data)?http_build_query($data):$data);
    }
    $resp=curl_exec($ch); $err=curl_error($ch); curl_close($ch);
    if($err)return['error'=>$err];
    $j=json_decode($resp,true);
    return $j['data']??$j;
  }
  if($op==='listiso'){
  $out = [];
  $nodes = pveApi($ip, $port, $token, $secret, 'nodes');
  foreach($nodes as $node){
    $n = $node['node'] ?? '';
    $storages = pveApi($ip, $port, $token, $secret, "nodes/$n/storage");
    foreach($storages as $st){
      $sid = $st['storage'] ?? '';
      $isos = pveApi($ip, $port, $token, $secret, "nodes/$n/storage/$sid/content");
      if(!is_array($isos)) continue;
      foreach($isos as $f){
        if(($f['content'] ?? '') === 'iso'){
          $out[] = [
            'volid' => $f['volid'],
            'storage' => $sid,
            'node' => $n
          ];
        }
      }
    }
  }
  header('Content-Type: application/json');
  echo json_encode($out, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
  exit;
}
  if($op==='liststorage'){
    $out=[];
    $nodes=pveApi($ip,$port,$token,$secret,'nodes');
    foreach($nodes as $node){
      $n=$node['node']??'';
      $storages=pveApi($ip,$port,$token,$secret,"nodes/$n/storage");
      foreach($storages as $s){
        $out[]=['id'=>$s['storage']??'?','type'=>$s['type']??'?'];
      }
    }
    header('Content-Type: application/json');
    echo json_encode($out);
    exit;
  }
  if($op==='listbridges'){
    $out=[];
    $nodes=pveApi($ip,$port,$token,$secret,'nodes');
    foreach($nodes as $node){
      $n=$node['node']??'';
      $ifs=pveApi($ip,$port,$token,$secret,"nodes/$n/network");
      foreach($ifs as $i){
        if(($i['type']??'')==='bridge') $out[]=$i['iface'];
      }
    }
    header('Content-Type: application/json');
    echo json_encode($out);
    exit;
  }
if($op==='listvlans'){
  $out = [];
  $nodes = pveApi($ip, $port, $token, $secret, 'nodes');
  foreach($nodes as $node){
    $n = $node['node'] ?? '';
    $ifs = pveApi($ip, $port, $token, $secret, "nodes/$n/network");
    if(!is_array($ifs)) continue;
    foreach($ifs as $v){
      if(isset($v['tag']) && is_numeric($v['tag'])) {
        $out[] = $v['tag'];
        continue;
      }
      $iface = $v['iface'] ?? '';
      if(preg_match('/vlan(\d+)/i',$iface,$m)) $out[] = intval($m[1]);
      elseif(preg_match('/\.(\d{2,4})$/',$iface,$m)) $out[] = intval($m[1]);
      elseif(preg_match('/vmbr(\d{2,4})$/',$iface,$m)) $out[] = intval($m[1]);
    }
  }
  $out = array_unique(array_filter($out));
  sort($out, SORT_NUMERIC);
  header('Content-Type: application/json');
  echo json_encode($out, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
  exit;
}
  if($op==='uploadiso'){
    if(!isset($_FILES['isoFile'])){echo"❌ Aucun fichier ISO reçu.";exit;}
    $tmp=$_FILES['isoFile']['tmp_name'];$name=basename($_FILES['isoFile']['name']);
    $nodes=pveApi($ip,$port,$token,$secret,'nodes');$node=$nodes[0]['node']??'';
    $url="https://$ip:$port/api2/json/nodes/$node/storage/local/upload";
    $ch=curl_init($url);$cfile=new CURLFile($tmp,$_FILES['isoFile']['type'],$name);
    $post=['content'=>'iso','filename'=>$name,'file'=>$cfile];
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_SSL_VERIFYPEER=>false,CURLOPT_SSL_VERIFYHOST=>false,
      CURLOPT_HTTPHEADER=>["Authorization: PVEAPIToken=$token=$secret"],CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$post]);
    $resp=curl_exec($ch);$err=curl_error($ch);curl_close($ch);
    echo $err?"❌ Erreur upload: $err":"✅ ISO $name envoyé.";exit;
  }
  if($op==='createvm'){
    $nodes=pveApi($ip,$port,$token,$secret,'nodes');$node=$nodes[0]['node']??'';
    $vmname=$_POST['vmname']??'NewVM';$cpu=$_POST['cpu']??2;$ram=$_POST['ram']??2048;$disk=$_POST['disk']??20;
    $iso=$_POST['iso']??'';$bridge=$_POST['bridge']??'vmbr0';$vlan=$_POST['vlan']??0;
    $payload=['vmid'=>rand(100,999),'name'=>$vmname,'cores'=>$cpu,'memory'=>$ram,
      'ide2'=>$iso.',media=cdrom','sata0'=>'local-lvm:'.$disk,
      'net0'=>"virtio,bridge=$bridge".($vlan?(",tag=$vlan"):""),
      'ostype'=>'l26','scsihw'=>'virtio-scsi-pci','boot'=>'cdn','bootdisk'=>'sata0'];
    $res=pveApi($ip,$port,$token,$secret,"nodes/$node/qemu",'POST',$payload);
    echo isset($res['error'])?"❌ ".$res['error']:"✅ VM $vmname créée sur $node.";exit;
  }
if($op==='listvms'){
  $out=[];
  $nodes = pveApi($ip,$port,$token,$secret,'nodes');
  if(!is_array($nodes)) $nodes = [];
  foreach($nodes as $node){
    $n = $node['node'] ?? '';
    $vms = pveApi($ip,$port,$token,$secret,"nodes/$n/qemu");
    if(is_array($vms)){
      foreach($vms as $vm){
        $out[] = [
          'id' => $vm['vmid'] ?? '?',
          'name' => $vm['name'] ?? '(sans nom)',
          'status' => $vm['status'] ?? 'unknown',
          'node' => $n
        ];
      }
    }
  }
  header('Content-Type: application/json');
  echo json_encode($out, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
  exit;
}
}
?>
<div class="section" style="margin-top:10px;">
<style>
.proxmox-form {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px 20px;
  max-width: 900px;
  margin: 10px auto 20px;
}
.proxmox-form input {
  width: 100%;
  padding: 8px 10px;
  background: rgba(255,255,255,0.05);
  border: 1px solid rgba(255,255,255,0.1);
  color: var(--text);
  border-radius: 6px;
  transition: border .2s;
}
.proxmox-form input:focus {
  outline: none;
  border-color: var(--primary-color);
}
.proxmox-buttons {
  grid-column: span 2;
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  margin-top: 4px;
}
#srvtable {
  width: 100%;
  border-collapse: collapse;
  margin-top: 10px;
}
#srvtable th, #srvtable td {
  border-bottom: 1px solid rgba(255,255,255,0.1);
  padding: 6px 10px;
  text-align: left;
  color: var(--text);
}
#srvtable th {
  font-weight: 600;
  color: var(--primary-color);
}
#srvtable td button {
  margin: 0 2px;
}
</style>
<div class="section" style="margin-top:10px;">
  <h2>Vos serveurs Proxmox</h2>
  <form method="post">
    <input type="hidden" name="op" value="add">
    <div class="proxmox-form">
      <input name="name" type="text" placeholder="Nom (PVE1)" required>
      <input name="ip" type="text" placeholder="IP ou FQDN" required>
      <input name="port" type="number" value="8006">
      <input name="token_id" type="text" placeholder="user@pve!token">
      <input name="secret" type="password" placeholder="secret">

      <div class="proxmox-buttons">
        <button class="btn save" type="submit">💾</button>
        <button class="btn" type="button" onclick="openHelp()">❔</button>
      </div>
    </div>
  </form>
  <h3>Liste des serveurs</h3>
  <table id="srvtable">
    <thead>
      <tr><th>Nom</th><th>IP</th><th>Port</th><th>Token</th><th>Actions</th></tr>
    </thead>
    <tbody>
    <?php if(empty($servers)): ?>
      <tr><td colspan="5"><i>Aucun serveur enregistré.</i></td></tr>
    <?php else: foreach($servers as $s): ?>
      <tr data-name="<?=htmlspecialchars($s['name'])?>">
        <td class="edit" data-field="name"><?=htmlspecialchars($s['name'])?></td>
        <td class="edit" data-field="ip"><?=htmlspecialchars($s['ip'])?></td>
        <td class="edit" data-field="port"><?=htmlspecialchars($s['port'])?></td>
        <td class="edit" data-field="token_id"><?=htmlspecialchars($s['token_id'])?></td>
        <td style="white-space:nowrap">
          <button class="btn" onclick="viewServ('<?=safefn($s['name'])?>')" title="Voir">👁️</button>
          <form method="post" style="display:inline" onsubmit="return confirm('Supprimer ce serveur ?')">
            <input type="hidden" name="op" value="delete">
            <input type="hidden" name="name" value="<?=htmlspecialchars($s['name'])?>">
            <button class="btn del" title="Supprimer">🗑️</button>
          </form>
        </td>
      </tr>
    <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>
<div id="helpBox" class="popup" style="display:none;">
  <div class="box">
    <button class="close" onclick="closeHelp()">✖</button>
    <h2>Procédure d’intégration Proxmox</h2>
    <ul>
      <li>Connectez-vous à <code>https://IP:8006</code></li>
      <li>Créez un utilisateur dédié (ex : <b>dmd-integ@pve</b>)</li>
      <li>Créez un token API et notez <b>Token ID</b> + <b>Secret</b></li>
      <li>Attribuez le rôle <b>PVEAuditor</b> ou <b>Administrator</b></li>
      <li>Test : <code>curl -k -H "Authorization: PVEAPIToken=USER!TOKEN=SECRET" https://IP:8006/api2/json/version</code></li>
    </ul>
  </div>
</div>
<div id="viewBox" class="popup" style="display:none;">
  <div class="box" style="max-width:600px;">
    <button class="close" onclick="closeView()">✖</button>
    <h2>Éditer le serveur</h2>
    <form id="editServerForm" onsubmit="return saveServer(event)">
      <input type="hidden" name="op" value="editfull">
      <input type="hidden" id="oldname" name="oldname">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px 20px;">
        <div>
          <label>Nom :</label>
          <input type="text" id="edit_name" name="name" required>
        </div>
        <div>
          <label>IP / FQDN :</label>
          <input type="text" id="edit_ip" name="ip" required>
        </div>
        <div>
          <label>Port :</label>
          <input type="number" id="edit_port" name="port" value="8006">
        </div>
        <div>
          <label>Token ID :</label>
          <input type="text" id="edit_token" name="token_id">
        </div>
        <div>
          <label>Secret :</label>
          <input type="password" id="edit_secret" name="secret" placeholder="Laisser vide pour conserver le secret existant">
        </div>
        <div style="grid-column:span 2;text-align:center;margin-top:10px;">
          <button type="submit" class="btn save">💾 Enregistrer</button>
        </div>
      </div>
    </form>
    <div id="editMsg" style="margin-top:10px;text-align:center;font-weight:bold;"></div>
  </div>
</div>
<script>
function openHelp(){ document.getElementById('helpBox').style.display='block'; }
function closeHelp(){ document.getElementById('helpBox').style.display='none'; }
function closeView(){
  document.getElementById('viewBox').style.display = 'none';
}
async function saveServer(e){
  e.preventDefault();
  const f = new FormData(document.getElementById('editServerForm'));
  const resp = await fetch('proxv2cfg.php', { method: 'POST', body: f });
  const txt = await resp.text();
  const msg = document.getElementById('editMsg');
  if (txt.includes('ok')) {
    msg.textContent = "✅ Modifications enregistrées !";
    setTimeout(() => location.reload(), 800);
  } else {
    msg.textContent = "❌ Erreur : " + txt;
  }
}
</script>
<script>
function closeView(){ document.getElementById('viewBox').style.display = 'none'; }
async function saveServer(e){
  e.preventDefault();
  const f = new FormData(document.getElementById('editServerForm'));
  const resp = await fetch('proxv2cfg.php', {method:'POST', body:f});
  const txt = await resp.text();
  const msg = document.getElementById('editMsg');
  if (txt.includes('ok')) {
    msg.textContent = "✅ Modifications enregistrées !";
    setTimeout(()=>location.reload(), 1000);
  } else {
    msg.textContent = "❌ Erreur : " + txt;
  }
}
</script>
<style>
.popup {
  position: fixed;
  inset: 0;
  display: none;
  justify-content: center;
  align-items: center;
  background: rgba(0,0,0,0.6);
  z-index: 9999;
}
.popup .box {
  background: var(--card, #222);
  border-radius: 10px;
  padding: 20px;
  color: var(--text, #fff);
  box-shadow: 0 0 10px rgba(0,0,0,0.5);
  min-width: 400px;
}
.popup .close {
  float: right;
  background: none;
  border: none;
  font-size: 18px;
  color: #fff;
  cursor: pointer;
}
</style>
<script>
function openHelp(){ document.getElementById('helpBox').style.display='flex'; }
function closeHelp(){ document.getElementById('helpBox').style.display='none'; }
async function viewServ(name){
  try {
    const res = await fetch('proxv2cfg.php?ajax=get_server&name=' + encodeURIComponent(name) + '&nocache=' + Date.now());
    if (!res.ok) throw new Error("Serveur introuvable !");

    const payload = await res.json();

    if (!payload.success) {
      throw new Error(payload.error || "Erreur inconnue");
    }

    const j = payload.server;

    document.getElementById('oldname').value = name;
    document.getElementById('edit_name').value = j.name || '';
    document.getElementById('edit_ip').value = j.ip || '';
    document.getElementById('edit_port').value = j.port || 8006;
    document.getElementById('edit_token').value = j.token_id || '';
    document.getElementById('edit_secret').value = '';
    document.getElementById('editMsg').textContent = j.has_secret
      ? '🔐 Secret déjà enregistré. Laisser vide pour le conserver.'
      : '⚠️ Aucun secret enregistré.';

    document.getElementById('viewBox').style.display = 'flex';
  } catch(e){
    alert("Erreur : " + e.message);
  }
}
function closeView(){
  document.getElementById('viewBox').style.display = 'none';
}
async function saveServer(e){
  e.preventDefault();
  const f = new FormData(document.getElementById('editServerForm'));
  const msg = document.getElementById('editMsg');
  msg.textContent = "⏳ Sauvegarde...";
  try {
    const r = await fetch('proxv2cfg.php', { method:'POST', body:f });
    const t = await r.text();
    if (t.includes('ok')) {
      msg.textContent = "✅ Modifications enregistrées !";
      setTimeout(()=>location.reload(), 1000);
    } else {
      msg.textContent = "❌ Erreur : " + t;
    }
  } catch(err){
    msg.textContent = "⚠️ Erreur réseau : " + err;
  }
}
</script>
<div class="section" style="margin-top:20px;">
  <h2>Création d’une VM</h2>
   <label>Cette partie de module est toujours en développement, vous n'êtes pas à l'abri de quelques bugs.</label>
<style>
.vm-form-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px 40px;
  align-items: center;
  max-width: 900px;
  margin: auto;
}
.vm-form-grid label {
  color: var(--text);
  font-weight: 500;
  display: block;
  margin-bottom: 4px;
}
.vm-form-grid select,
.vm-form-grid input[type="text"],
.vm-form-grid input[type="number"],
.vm-form-grid input[type="range"] {
  width: 100%;
  padding: 6px 10px;
  background: rgba(255,255,255,0.05);
  border: 1px solid rgba(255,255,255,0.1);
  color: var(--text);
  border-radius: 6px;
  transition: all .2s ease-in-out;
}
/* === Correction menus déroulants sombres === */
select, select option {
  background-color: var(--card, #1e1e1e) !important;
  color: var(--text, #fff) !important;
}
select:focus {
  outline: none;
  border-color: var(--primary-color, #00aaff) !important;
  box-shadow: 0 0 5px var(--primary-color, #00aaff);
}
option {
  background-color: var(--card, #1e1e1e);
  color: var(--text, #fff);
  border: none;
}
.vm-form-grid select:hover,
.vm-form-grid input:hover {
  border-color: var(--primary-color);
}
.vm-form-grid span {
  font-size: 0.9em;
  opacity: 0.8;
}
.vm-form-actions {
  grid-column: span 2;
  text-align: center;
  margin-top: 20px;
}
</style>
<div class="section" style="margin-top:20px;">
  <form id="createVMForm" onsubmit="return createVM(event)">
    <div class="vm-form-grid">
      <div>
        <label>Serveur :</label>
        <select id="serverSelect" name="srv" required onchange="loadServerData()">
          <option value="">Sélectionner...</option>
          <?php foreach (glob(__DIR__.'/cfg/serveurs/*.json') as $f){
            $s=json_decode(file_get_contents($f),true);
            echo "<option value='".basename($f,'.json')."'>".htmlspecialchars($s['name'])."</option>";
          } ?>
        </select>
      </div>
      <div>
        <label>Type système :</label>
        <select name="ostype">
          <option value="l26">Linux</option>
          <option value="win11">Windows</option>
          <option value="other">Autre</option>
        </select>
      </div>
      <div>
        <label>Stockage ISO :</label>
        <select id="storageIsoSelect" name="storage_iso"></select>
      </div>
      <div>
        <label>Stockage VM :</label>
        <select id="storageVmSelect" name="storage_vm"></select>
      </div>
      <div>
        <label>Nom VM :</label>
        <input type="text" name="vmname" required>
      </div>
      <div>
        <label>ID VM (optionnel) :</label>
        <input type="number" name="vmid" placeholder="ex: 500" min="100">
      </div>
      <div>
        <label>CPU (cores) :</label>
        <input type="number" name="cpu" value="2" min="1" max="32" step="1">
      </div>
      <div>
        <label>Disque (Go) :</label>
        <input type="number" name="disk" value="20" min="10" max="1000">
      </div>
      <div>
        <label>RAM (Mo) :</label>
        <input type="range" name="ram" min="1024" max="32768" step="1024" value="2048"
               oninput="this.nextElementSibling.textContent=this.value+' Mo'">
        <span>2048 Mo</span>
      </div>
      <div>
        <label>Bridge :</label>
        <select id="bridgeSelect" name="bridge"></select>
      </div>
      <div>
        <label>ISO :</label>
        <div style="display:flex;gap:6px;align-items:center;">
          <select id="isoSelect" name="iso" style="flex:1;"></select>
          <button type="button" class="btn" onclick="openIsoManager()">📀</button>
        </div>
      </div>
      <div>
  <label>VLAN (optionnel) :</label>
  <select id="vlanSelect" name="vlan">
    <option value="">Aucun VLAN</option>
  </select>
</div>
      <div class="vm-form-actions">
        <button type="submit" class="btn save">Créer la VM 🖥️</button>
      </div>
    </div>
  </form>
  <div id="vmResult" style="margin-top:10px;text-align:center;color:var(--text);font-weight:bold;"></div>
</div>
  <div id="vmResult" style="margin-top:10px;color:var(--text);font-weight:bold;"></div>
</div>
<div class="section" id="vmListSection" style="margin-top:30px;display:none;">
  <h3>Liste des machines virtuelles</h3>
  <table id="vmTable" style="width:100%;border-collapse:collapse;">
    <thead>
      <tr>
        <th style="text-align:left;">ID</th>
        <th style="text-align:left;">Nom</th>
        <th style="text-align:left;">Nœud</th>
        <th style="text-align:left;">Statut</th>
      </tr>
    </thead>
    <tbody id="vmTableBody">
      <tr><td colspan="4"><i>Sélectionne un serveur pour afficher la liste.</i></td></tr>
    </tbody>
  </table>
</div>
<script>
function openIsoManager(){
  const srv=document.getElementById('serverSelect').value;
  if(!srv){alert("Sélectionne un serveur.");return;}
  document.getElementById('isoBox').style.display='block';loadIsoList();
}
function closeIsoManager(){document.getElementById('isoBox').style.display='none';}
function loadIsoList(){
  const srv=document.getElementById('serverSelect').value;
  fetch('?op=listiso&srv='+srv)
  .then(r=>r.json())
  .then(list=>{
    const ul=document.getElementById('isoList');ul.innerHTML='';
    if(!list||!list.length){ul.innerHTML='<li>Aucun ISO trouvé.</li>';return;}
    list.forEach(i=>ul.innerHTML+='<li>'+i+'</li>');
    const sel=document.getElementById('isoSelect');sel.innerHTML='';
    list.forEach(i=>{const o=document.createElement('option');o.value=i;o.textContent=i;sel.appendChild(o);});
  });
}
function uploadIso(){
  const srv=document.getElementById('serverSelect').value;
  const fd=new FormData(document.getElementById('isoUploadForm'));
  fd.append('op','uploadiso');fd.append('srv',srv);
  const p=document.getElementById('isoProgress');p.style.display='block';
  fetch('?op=uploadiso',{method:'POST',body:fd})
    .then(r=>r.text()).then(t=>{p.style.display='none';alert(t);loadIsoList();});
}
function createVM(e){
  e.preventDefault();
  const f=new FormData(document.getElementById('createVMForm'));f.append('op','createvm');
  document.getElementById('vmResult').innerHTML='⏳ Création en cours...';
  fetch('',{method:'POST',body:f}).then(r=>r.text())
  .then(t=>{document.getElementById('vmResult').innerHTML=t;});
}
</script>
<script>
async function loadServerData(){
  const srv=document.getElementById('serverSelect').value;
  if(!srv) return;
  try{
    const stR=await fetch('proxv2cfg.php?op=liststorage&srv='+srv);
    const stor=await stR.json();
    const sIso=document.getElementById('storageIsoSelect');
    const sVm=document.getElementById('storageVmSelect');
    sIso.innerHTML=''; sVm.innerHTML='';
    (stor||[]).forEach(s=>{
      const o1=document.createElement('option');
      o1.value=s.id; o1.textContent=s.id+' ('+(s.type||'?')+')';
      sIso.appendChild(o1);
      const o2=document.createElement('option');
      o2.value=s.id; o2.textContent=s.id+' ('+(s.type||'?')+')';
      sVm.appendChild(o2);
    });
  }catch(e){console.error('Erreur stockage',e);}
  try{
    const isoR=await fetch('proxv2cfg.php?op=listiso&srv='+srv);
    const iso=await isoR.json();
    const isoSel=document.getElementById('isoSelect');
    isoSel.innerHTML='';
(iso||[]).forEach(i=>{
  const o=document.createElement('option');
  o.value=i.volid || i;
  o.textContent = (i.volid || i) + (i.storage ? " ("+i.storage+")" : "");
  isoSel.appendChild(o);
});
  }catch(e){console.error('Erreur ISO',e);}
  try{
    const brR=await fetch('proxv2cfg.php?op=listbridges&srv='+srv);
    const br=await brR.json();
    const brSel=document.getElementById('bridgeSelect');
    brSel.innerHTML='';
    (br||[]).forEach(b=>{
      const o=document.createElement('option');
      o.value=b;o.textContent=b;brSel.appendChild(o);
    });
  }catch(e){console.error('Erreur bridges',e);}
  try {
  const vlR = await fetch('proxv2cfg.php?op=listvlans&srv=' + srv);
  const vl = await vlR.json();
  const vlSel = document.getElementById('vlanSelect');
  vlSel.innerHTML = '<option value="">Aucun VLAN</option>';
  (vl || []).forEach(v => {
    const o = document.createElement('option');
    o.value = v;
    o.textContent = v;
    vlSel.appendChild(o);
  });
} catch(e) {
  console.error('Erreur VLAN', e);
}
  try{
    const vmR=await fetch('proxv2cfg.php?op=listvms&srv='+srv);
    const vms = await vmR.json();
    const tableBody = document.getElementById('vmTableBody');
    const section = document.getElementById('vmListSection');
    tableBody.innerHTML = '';
    if(!vms.length){
      tableBody.innerHTML = '<tr><td colspan="4"><i>Aucune VM trouvée.</i></td></tr>';
    } else {
      vms.forEach(vm=>{
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>${vm.id}</td>
          <td>${vm.name}</td>
          <td>${vm.node}</td>
          <td>${vm.status=='running'?'🟢':'🔴'} ${vm.status}</td>
        `;
        tableBody.appendChild(tr);
      });
    }
    section.style.display = 'block';
  }catch(e){
    console.error('Erreur liste VM', e);
  }
}
async function createVM(e){
  e.preventDefault();
  const f=new FormData(document.getElementById('createVMForm'));
  f.append('op','createvm');
  document.getElementById('vmResult').textContent='⏳ Création en cours...';
  const r=await fetch('proxv2cfg.php',{method:'POST',body:f});
  const t=await r.text();
  document.getElementById('vmResult').textContent=t;
}
</script>