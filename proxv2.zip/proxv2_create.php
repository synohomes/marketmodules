<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');
$op  = $_REQUEST['op'] ?? '';
$srv = $_REQUEST['srv'] ?? '';
if (!$srv) { echo json_encode(["error"=>"Aucun serveur spécifié."]); exit; }
$cfgFile = __DIR__ . "/cfg/serveurs/$srv.json";
if (!is_file($cfgFile)) {
  echo json_encode(["error"=>"Serveur introuvable ($srv)"]);
  exit;
}
$cfg = json_decode(file_get_contents($cfgFile), true);
$ip     = $cfg['ip'] ?? '';
$port   = $cfg['port'] ?? 8006;
$token  = $cfg['token_id'] ?? '';
$secret = $cfg['secret'] ?? '';
$node   = $cfg['node'] ?? ''; 
function prox($ip, $port, $token, $secret, $endpoint, $method='GET', $data=null) {
  $url = "https://$ip:$port/api2/json/$endpoint";
  $ch = curl_init($url);
  $headers = [
    "Authorization: PVEAPIToken=$token=$secret",
    "Content-Type: application/json"
  ];
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_CUSTOMREQUEST => $method,
    CURLOPT_HTTPHEADER => $headers
  ]);
  if ($data) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
  $resp = curl_exec($ch);
  $err  = curl_error($ch);
  curl_close($ch);
  if ($err) return ["error"=>$err];
  $j = json_decode($resp, true);
  return $j ?: ["error"=>"Invalid JSON","raw"=>$resp];
}
if (!$node) {
  $nodes = prox($ip, $port, $token, $secret, "nodes");
  if (!empty($nodes['data'][0]['node'])) {
    $node = $nodes['data'][0]['node'];
  } else {
    echo json_encode(["error"=>"Impossible de détecter le node Proxmox"]);
    exit;
  }
}
if ($op === 'listiso') {
  $list = [];
  $storages = prox($ip, $port, $token, $secret, "nodes/$node/storage");
  foreach (($storages['data'] ?? []) as $store) {
    $storeid = $store['storage'] ?? '';
    if (!$storeid) continue;
    $data = prox($ip, $port, $token, $secret, "nodes/$node/storage/$storeid/content");
    foreach (($data['data'] ?? []) as $item) {
      if (!empty($item['volid']) && str_ends_with($item['volid'], '.iso')) {
        $list[] = basename($item['volid']);
      }
    }
  }
  echo json_encode(array_values(array_unique($list)));
  exit;
}
if ($op === 'listbridges') {
  $data = prox($ip, $port, $token, $secret, "nodes/$node/network");
  $bridges = [];
  foreach (($data['data'] ?? []) as $net) {
    if (($net['type'] ?? '') === 'bridge') $bridges[] = $net['iface'];
  }
  echo json_encode($bridges);
  exit;
}
if ($op === 'listvlans') {
  $data = prox($ip, $port, $token, $secret, "nodes/$node/network");
  $vlans = [];
  foreach (($data['data'] ?? []) as $net) {
    if (isset($net['type']) && $net['type'] === 'vlan') {
      $vlans[] = $net['iface'];
    } elseif (isset($net['iface']) && preg_match('/vlan/i', $net['iface'])) {
      $vlans[] = $net['iface'];
    }
  }
  echo json_encode(array_values(array_unique($vlans)));
  exit;
}
if ($op === 'createvm') {
  $vmname = $_POST['vmname'] ?? '';
  $cpu    = (int)($_POST['cpu'] ?? 2);
  $ram    = (int)($_POST['ram'] ?? 2048);
  $disk   = (int)($_POST['disk'] ?? 20);
  $iso    = $_POST['iso'] ?? '';
  $bridge = $_POST['bridge'] ?? 'vmbr0';
  $vlan   = (int)($_POST['vlan'] ?? 0);
  $ostype = $_POST['ostype'] ?? 'l26';
  if (!$vmname || !$iso) {
    echo json_encode(["error"=>"Nom et ISO obligatoires."]);
    exit;
  }
  $payload = [
    "name" => $vmname,
    "sockets" => 1,
    "cores" => $cpu,
    "memory" => $ram,
    "ide2" => "local:iso/$iso,media=cdrom",
    "scsihw" => "virtio-scsi-pci",
    "scsi0" => "local-lvm:$disk",
    "net0" => "virtio,bridge=$bridge".($vlan ? ",tag=$vlan" : ""),
    "ostype" => $ostype,
    "agent" => 1
  ];
  $res = prox($ip, $port, $token, $secret, "nodes/$node/qemu", "POST", $payload);
  if (!empty($res['data'])) echo json_encode(["ok"=>true, "id"=>$res['data']]);
  else echo json_encode(["error"=>$res]);
  exit;
}
echo json_encode(["error"=>"Opération inconnue ($op)"]);
