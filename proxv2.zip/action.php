<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) $input = $_POST;
$node   = trim($input['node'] ?? '');
$vmid   = (int)($input['vmid'] ?? 0);
$type   = strtolower(trim($input['type'] ?? 'qemu'));
$action = strtolower(trim($input['action'] ?? ''));
if (!$node || !$vmid || !$action) {
    echo json_encode(['ok'=>false, 'error'=>'Requête incomplète']);
    exit;
}
$cfgDir = __DIR__ . "/cfg/serveurs/";
$cacheDir = __DIR__ . "/cache/";
if (!is_dir($cfgDir)) {
    echo json_encode(['ok'=>false, 'error'=>'Dossier cfg/serveurs/ introuvable']);
    exit;
}
$cfgFile = $cfgDir . $node . ".json";
if (!file_exists($cfgFile)) {
    $found = null;
    foreach (glob($cfgDir . "*.json") as $f) {
        $data = json_decode(file_get_contents($f), true);
        if (is_array($data) && strcasecmp($data['name'] ?? '', $node) === 0) {
            $found = $f;
            break;
        }
    }
    if ($found) $cfgFile = $found;
}
if (!file_exists($cfgFile)) {
    echo json_encode(['ok'=>false, 'error'=>"Serveur introuvable pour node='$node'"]);
    exit;
}
$cfg = json_decode(file_get_contents($cfgFile), true);
if (!$cfg) {
    echo json_encode(['ok'=>false, 'error'=>'Fichier JSON invalide']);
    exit;
}
$ip      = $cfg['ip'] ?? '';
$port    = (int)($cfg['port'] ?? 8006);
$tokenId = $cfg['token_id'] ?? ($cfg['token'] ?? '');
$secret  = $cfg['secret'] ?? '';
if (!$ip || !$tokenId || !$secret) {
    echo json_encode(['ok'=>false, 'error'=>'Données API manquantes']);
    exit;
}
$cacheFile = $cacheDir . preg_replace('/[^a-zA-Z0-9_-]/','_',$cfg['name']).".json";
$realNode = null;
if (file_exists($cacheFile)) {
    $cache = json_decode(file_get_contents($cacheFile), true);
    $realNode = $cache['node'] ?? null;
}
if (!$realNode) $realNode = $cfg['name'];
$base = "https://{$ip}:{$port}/api2/json";
$url  = "{$base}/nodes/" . rawurlencode($realNode) . "/{$type}/{$vmid}/status/" . rawurlencode($action);
$ch = curl_init($url);
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_SSL_VERIFYPEER => false,
  CURLOPT_SSL_VERIFYHOST => false,
  CURLOPT_POST           => true,
  CURLOPT_POSTFIELDS     => '',
  CURLOPT_HTTPHEADER     => ["Authorization: PVEAPIToken={$tokenId}={$secret}"],
  CURLOPT_TIMEOUT        => 10,
]);
$resp = curl_exec($ch);
$err  = curl_error($ch);
$http = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);
if ($err) {
    echo json_encode(['ok'=>false, 'error'=>$err]);
    exit;
}
if ($http >= 300) {
    echo json_encode(['ok'=>false, 'error'=>"HTTP $http → $resp"]);
    exit;
}
echo json_encode(['ok'=>true, 'action'=>$action, 'vmid'=>$vmid]);
?>
