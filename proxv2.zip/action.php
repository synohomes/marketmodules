<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (
    !isset($_SESSION['user']['email']) ||
    ($_SESSION['user']['role_system'] ?? '') !== 'admin'
) {
    header('Content-Type: application/json');
    echo json_encode([
        'ok' => false,
        'error' => 'Accès réservé à l’administrateur'
    ]);
    exit;
}

function proxv2_log($action, $target = '', $status = 'info', $details = '', $extra = []) {
    $root = dirname(__DIR__, 2);
    $logDir = $root . '/data/logs';

    if (!is_dir($logDir)) {
        @mkdir($logDir, 0775, true);
    }

    $logFile = $logDir . '/proxv2.json';

    $entry = [
        'date' => date('Y-m-d H:i:s'),
        'module' => 'proxv2',
        'user' => $_SESSION['user']['email'] ?? 'unknown',
        'role_system' => $_SESSION['user']['role_system'] ?? '',
        'action' => $action,
        'target' => $target,
        'status' => $status,
        'details' => $details,
        'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
    ];

    if (is_array($extra) && !empty($extra)) {
        $entry['extra'] = $extra;
    }

    @file_put_contents(
        $logFile,
        json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . PHP_EOL,
        FILE_APPEND | LOCK_EX
    );
}
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) $input = $_POST;
$node   = trim($input['node'] ?? '');
$vmid   = (int)($input['vmid'] ?? 0);
$type   = strtolower(trim($input['type'] ?? 'qemu'));
$action = strtolower(trim($input['action'] ?? ''));
if (!$node || !$vmid || !$action) {
    echo json_encode(['ok'=>false, 'error'=>'Requête incomplète']);
    exit;
}
$cfgDir = __DIR__ . "/cfg/serveurs/";
$cacheDir = __DIR__ . "/cache/";
if (!is_dir($cfgDir)) {
    echo json_encode(['ok'=>false, 'error'=>'Dossier cfg/serveurs/ introuvable']);
    exit;
}
$cfgFile = $cfgDir . $node . ".json";
if (!file_exists($cfgFile)) {
    $found = null;
    foreach (glob($cfgDir . "*.json") as $f) {
        $data = json_decode(file_get_contents($f), true);
        if (is_array($data) && strcasecmp($data['name'] ?? '', $node) === 0) {
            $found = $f;
            break;
        }
    }
    if ($found) $cfgFile = $found;
}
if (!file_exists($cfgFile)) {
    echo json_encode(['ok'=>false, 'error'=>"Serveur introuvable pour node='$node'"]);
    exit;
}
$cfg = json_decode(file_get_contents($cfgFile), true);
if (!$cfg) {
    echo json_encode(['ok'=>false, 'error'=>'Fichier JSON invalide']);
    exit;
}
$keyFile = __DIR__ . "/cfg/.proxv2.key";

function proxv2_crypto_key_action($keyFile) {
    $raw = trim((string)@file_get_contents($keyFile));
    if ($raw === '') return '';
    return hash('sha256', $raw, true);
}

function proxv2_decrypt_secret_action($cfg, $keyFile) {
    if (!is_array($cfg)) return '';

    // Compatibilité avec les anciens fichiers JSON non chiffrés
    if (!empty($cfg['secret'])) {
        return (string)$cfg['secret'];
    }

    if (empty($cfg['secret_enc'])) return '';

    $decoded = base64_decode($cfg['secret_enc'], true);
    if ($decoded === false) return '';

    $payload = json_decode($decoded, true);
    if (!is_array($payload)) return '';

    $iv = base64_decode($payload['iv'] ?? '', true);
    $tag = base64_decode($payload['tag'] ?? '', true);
    $data = base64_decode($payload['data'] ?? '', true);

    if ($iv === false || $tag === false || $data === false) return '';

    $key = proxv2_crypto_key_action($keyFile);
    if ($key === '') return '';

    $plain = openssl_decrypt(
        $data,
        'aes-256-gcm',
        $key,
        OPENSSL_RAW_DATA,
        $iv,
        $tag
    );

    return $plain === false ? '' : $plain;
}

$ip      = $cfg['ip'] ?? '';
$port    = (int)($cfg['port'] ?? 8006);
$tokenId = $cfg['token_id'] ?? ($cfg['token'] ?? '');
$secret  = proxv2_decrypt_secret_action($cfg, $keyFile);

if (!$ip || !$tokenId || !$secret) {
    echo json_encode(['ok'=>false, 'error'=>'Données API manquantes']);
    exit;
}
$cacheFile = $cacheDir . preg_replace('/[^a-zA-Z0-9_-]/','_',$cfg['name']).".json";
$realNode = null;
if (file_exists($cacheFile)) {
    $cache = json_decode(file_get_contents($cacheFile), true);
    $realNode = $cache['node'] ?? null;
}
if (!$realNode) $realNode = $cfg['name'];
$base = "https://{$ip}:{$port}/api2/json";
$url  = "{$base}/nodes/" . rawurlencode($realNode) . "/{$type}/{$vmid}/status/" . rawurlencode($action);
$ch = curl_init($url);
curl_setopt_array($ch, [
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_SSL_VERIFYPEER => false,
  CURLOPT_SSL_VERIFYHOST => false,
  CURLOPT_POST           => true,
  CURLOPT_POSTFIELDS     => '',
  CURLOPT_HTTPHEADER     => ["Authorization: PVEAPIToken={$tokenId}={$secret}"],
  CURLOPT_TIMEOUT        => 10,
]);
$resp = curl_exec($ch);
$err  = curl_error($ch);
$http = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);
$target = 'VM ' . $vmid;

$logExtra = [
    'server' => $cfg['name'] ?? $node,
    'server_ip' => $ip,
    'node_requested' => $node,
    'node_real' => $realNode,
    'vmid' => $vmid,
    'type' => $type,
    'action' => $action,
    'http_code' => $http
];

if ($err) {
    proxv2_log(
        'vm_' . $action,
        $target,
        'error',
        'Erreur CURL pendant l’action VM',
        $logExtra + ['error' => $err]
    );

    echo json_encode(['ok'=>false, 'error'=>$err]);
    exit;
}

if ($http >= 300) {
    proxv2_log(
        'vm_' . $action,
        $target,
        'error',
        'Erreur HTTP Proxmox pendant l’action VM',
        $logExtra + ['response' => $resp]
    );

    echo json_encode(['ok'=>false, 'error'=>"HTTP $http → $resp"]);
    exit;
}

proxv2_log(
    'vm_' . $action,
    $target,
    'success',
    'Action VM exécutée',
    $logExtra
);

echo json_encode(['ok'=>true, 'action'=>$action, 'vmid'=>$vmid]);
?>
