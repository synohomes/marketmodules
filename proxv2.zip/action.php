<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json; charset=utf-8');
function bad($code, $msg){ http_response_code($code); echo json_encode(['ok'=>false,'error'=>$msg], JSON_UNESCAPED_UNICODE); exit; }
function read_json_body(){
  $raw = file_get_contents('php://input');
  if ($raw === false) return null;
  $j = json_decode($raw, true);
  return is_array($j) ? $j : null;
}
$in = $_POST;
if (empty($in)) $in = read_json_body() ?: [];
$node   = isset($in['node'])   ? preg_replace('~[^A-Za-z0-9._-]~','', (string)$in['node']) : '';
$vmid   = isset($in['vmid'])   ? (int)$in['vmid'] : 0;
$action = isset($in['action']) ? strtolower((string)$in['action']) : '';
$type   = isset($in['type'])   ? strtolower((string)$in['type']) : 'qemu'; // qemu|lxc
if ($type !== 'lxc') $type = 'qemu';
$allowed = ['start','stop','shutdown','reboot','reset'];
if (!$node || !$vmid || !in_array($action, $allowed, true)) {
  bad(400, "Paramètres invalides.");
}
$cfgFile = __DIR__ . "/cfg/proxv2.json";
if (!file_exists($cfgFile)) bad(500, "Config Proxmox manquante.");
$servers = json_decode(@file_get_contents($cfgFile), true);
if (!is_array($servers) || !count($servers)) bad(500, "Config Proxmox invalide.");
$node_lc = strtolower($node);
$server = null;
foreach ($servers as $s) {
  $sname = strtolower(trim($s['name'] ?? ''));
  $sip   = trim($s['ip'] ?? '');
  if ($sname && $sname === $node_lc) { $server = $s; break; }
  if ($sip   && $sip   === $node)    { $server = $s; break; }
}
if (!$server) $server = $servers[0];
$host = rtrim($server['host'] ?? '', '/');
$ip   = trim($server['ip'] ?? '');
$port = (string)($server['port'] ?? '8006');
if (!$host) {
  if (!$ip) bad(500, "Config serveur incomplète : host/ip manquant.");
  $host = "https://".$ip.":".$port;
}
$verify = isset($server['verify_ssl']) ? (bool)$server['verify_ssl'] : false;
$token_id     = $server['token_id']     ?? '';
$token_secret = $server['token_secret'] ?? ($server['secret'] ?? '');
if (!$token_id || !$token_secret) bad(500, "Config serveur incomplète : token_id/token_secret manquant.");
$endpoint = $host . "/api2/json/nodes/{$node}/{$type}/{$vmid}/status/" . $action;
$postfields = [];
$ch = curl_init($endpoint);
curl_setopt_array($ch, [
  CURLOPT_POST            => true,
  CURLOPT_HTTPHEADER      => ["Authorization: PVEAPIToken={$token_id}={$token_secret}"],
  CURLOPT_POSTFIELDS      => http_build_query($postfields),
  CURLOPT_RETURNTRANSFER  => true,
  CURLOPT_SSL_VERIFYPEER  => $verify,
  CURLOPT_SSL_VERIFYHOST  => $verify ? 2 : 0,
  CURLOPT_TIMEOUT         => 15,
]);
$resp = curl_exec($ch);
$err  = curl_error($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
if ($code !== 200 || !$resp) {
  bad(502, "Action '{$action}' échouée ($code): " . ($err ?: $resp));
}
$j = json_decode($resp, true);
if (!is_array($j) || !array_key_exists('data', $j)) {
  bad(502, "Réponse inattendue Proxmox.");
}
echo json_encode(['ok'=>true,'data'=>$j['data'] ?? null], JSON_UNESCAPED_UNICODE);
