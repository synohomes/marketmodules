<?php
/* modules/map/map.php — charge Leaflet local dynamiquement (compatible innerHTML) */
if (session_status()===PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { echo "<div style='color:#f66;padding:10px'>⛔ Non connecté</div>"; return; }

$userCfg = __DIR__ . "/../../users/profiles/$email/map.json";
$cfg = (file_exists($userCfg) ? json_decode(@file_get_contents($userCfg), true) : []) ?: [];

$lat  = isset($cfg['lat'])  ? floatval($cfg['lat'])  : 48.8566;
$lng  = isset($cfg['lng'])  ? floatval($cfg['lng'])  : 2.3522;
$zoom = isset($cfg['zoom']) ? intval($cfg['zoom'])   : 12;

// chemins *depuis le dashboard* (contenu injecté)
$leafletCss = "modules/map/lib/leaflet/leaflet.css";
$leafletJs  = "modules/map/lib/leaflet/leaflet.js";
?>
<style>
  .map-wrap { position: relative; width:100%; height:100%; }
  #mapid { width:100%; height:100%; min-height:320px; border-radius:8px; }
  .loc-status { position:absolute; z-index:1000; top:8px; right:10px; font-size:12px;
                padding:4px 8px; background:rgba(0,0,0,.35); color:#fff; border-radius:6px; }
  .leaflet-container { background:#1a1a1a; }
</style>

<div class="map-wrap">
  <div id="mapid" aria-label="Carte"></div>
  <div class="loc-status" id="locStatus"></div>
</div>

<script>
(function(){
  const CSS_HREF = "<?= htmlspecialchars($leafletCss) ?>";
  const JS_SRC   = "<?= htmlspecialchars($leafletJs) ?>";

  // Charge CSS + JS dans <head> si absents (support injection innerHTML)
  function ensureLeaflet(){
    return new Promise((resolve, reject)=>{
      // CSS
      if (!document.querySelector('link[data-leaflet="css"]')) {
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = CSS_HREF;
        link.setAttribute('data-leaflet','css');
        document.head.appendChild(link);
      }
      // Déjà présent ?
      if (window.L && typeof L.map === 'function') { resolve(); return; }
      // JS
      const existing = document.querySelector('script[data-leaflet="js"]');
      if (existing) {
        // Si déjà en cours de chargement, attendre que L soit dispo
        waitForLeaflet(resolve, reject);
      } else {
        const s = document.createElement('script');
        s.src = JS_SRC;
        s.async = false;
        s.setAttribute('data-leaflet','js');
        s.onload = ()=> waitForLeaflet(resolve, reject);
        s.onerror = ()=> reject(new Error("Échec de chargement Leaflet"));
        document.head.appendChild(s);
      }
    });
  }

  function waitForLeaflet(resolve, reject){
    const t0 = Date.now();
    (function poll(){
      if (window.L && typeof L.map === 'function') { resolve(); return; }
      if (Date.now() - t0 > 5000) { reject(new Error("Leaflet non chargé")); return; }
      setTimeout(poll, 50);
    })();
  }

  function showError(msg){
    document.querySelector('.map-wrap').innerHTML =
      "<div style='padding:10px;color:#f66'>❌ " + msg + "</div>";
  }

  ensureLeaflet().then(initMap).catch(e=> showError(e.message));

  function initMap(){
    const map = L.map('mapid', { zoomControl:true }).setView([<?= $lat ?>, <?= $lng ?>], <?= $zoom ?>);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    let marker = L.marker([<?= $lat ?>, <?= $lng ?>]).addTo(map)
      .bindPopup("Position par défaut").openPopup();

    const statusEl = document.getElementById('locStatus');

    // Bouton "📍 Ma position"
    const LocateControl = L.Control.extend({
      onAdd: function() {
        const btn = L.DomUtil.create('button');
        btn.type = 'button'; btn.title = 'Utiliser ma position'; btn.textContent = '📍 Ma position';
        Object.assign(btn.style, {
          padding:'6px 10px', borderRadius:'8px', border:'none', cursor:'pointer',
          background:'var(--primary-color, #444)', color:'#fff'
        });
        btn.onmouseenter=()=>btn.style.filter='brightness(1.1)';
        btn.onmouseleave=()=>btn.style.filter='none';
        L.DomEvent.on(btn,'click',(e)=>{ L.DomEvent.stopPropagation(e); askGeolocation(true); });
        return btn;
      }
    });
    (new LocateControl({position:'topleft'})).addTo(map);

    // ResizeObserver pour les modules redimensionnables
    const ro = new ResizeObserver(() => { map.invalidateSize(); });
    ro.observe(document.querySelector('.map-wrap'));
    setTimeout(()=> map.invalidateSize(), 100);

    function askGeolocation(showFeedback){
      if (!('geolocation' in navigator)) { if (showFeedback) status('❌ Géoloc non supportée.'); return; }
      const isLocalhost = location.hostname === 'localhost' || location.hostname === '127.0.0.1';
      if (location.protocol !== 'https:' && !isLocalhost) { if (showFeedback) status('⚠️ HTTPS requis.'); return; }
      navigator.geolocation.getCurrentPosition(
        (pos)=>{
          const { latitude, longitude, accuracy } = pos.coords;
          const ll = [latitude, longitude];
          map.setView(ll, Math.max(map.getZoom(), 14));
          marker.setLatLng(ll).setPopupContent("📍 Ma position (~" + Math.round(accuracy) + "m)").openPopup();
          if (showFeedback) status('✅ Position détectée.');
        },
        (err)=>{
          if (!showFeedback) return;
          status(err.code===1 ? '❌ Permission refusée.' :
                err.code===2 ? '❌ Position indisponible.' :
                err.code===3 ? '⏱️ Délai dépassé.' : '❌ Erreur géoloc.');
        },
        { enableHighAccuracy:true, timeout:8000, maximumAge:0 }
      );
    }
    function status(msg){ statusEl.textContent = msg; clearTimeout(status._t); status._t=setTimeout(()=>statusEl.textContent='', 5000); }
  }
})();
</script>
