<?php
return [
  "meta" => [
    "title" => "Infrastructure Maison",
    "subtitle" => "Doc statique – lisible & imprimable"
  ],
  "legend" => [
    ["label"=>"LAN serveurs","class"=>"vl-1"],
    ["label"=>"VLAN222 Users","class"=>"vl-222"],
    ["label"=>"VLAN333 Médias","class"=>"vl-333"],
  ],
  "topology" => [
    "wan" => [
      ["name"=>"Free", "cidr"=>"192.168.2.1/24"],
    ],
    "gw" => [
      "name"=>"pfSense",
      "meta"=>"GW VLANs, NAT, règles FW",
      "detail"=>"LAN: 10.10.10.0/24"
    ],
    "switch" => [
      "name"=>"Switch 2.5G",
      "meta"=>"Keeplink KP-9000-9XHML-X — mgmt 10.20.30.81",
      "detail"=>"Trunk → pfSense • Ports access par VLAN"
    ]
  ],
  "wan" => [
    ["provider"=>"Free","ip"=>"192.168.2.1","mask"=>"/24","type"=>"ADSL","notes"=>"IP Fixe:"]
  ],
  "pve" => [
    "label" => "PVE1 + PVE2",
    "hosts" => [
      ["name"=>"PVE1","ip"=>"10.10.10.9","vlan"=>"LAN (10.10.10.0/24)","notes"=>"RS2600 + 2 To NVMe 5 Gb/s","rowClass"=>"vl-lan"]
    ]
  ],
  "vlans" => [
    ["name"=>"1","cidr"=>"10.10.10.0/24","gw"=>"10.10.10.1","class"=>"lan"],
    ["name"=>"222 Users","cidr"=>"10.20.20.0/25","gw"=>"10.20.20.1","class"=>"v1222"],
    ["name"=>"333 Public","cidr"=>"10.30.30.0/25","gw"=>"10.30.30.1","class"=>"vl333"],
  ],
  "vlansNote" => "CIDR /27 et /25 pour maîtriser le DHCP",
  "vlansTable" => [
    ["vlan"=>"1","name"=>"LAN","subnet"=>"10.10.10.0/255.255.255.0","gw"=>"10.10.10.1","mask"=>"/24","role"=>"Description","rowClass"=>"vl-1"],
    ["vlan"=>"222","name"=>"SYNOHOMES","subnet"=>"10.20.20.0/255.255.255.128","gw"=>"10.20.20.1","mask"=>"/25 (126 hôtes)","role"=>"Description"=>"vl-222"],
    ["vlan"=>"333","name"=>"DOMYDESK","subnet"=>"10.30.30.0/255.255.255.128","gw"=>"10.30.30.1","mask"=>"/25 (126 hôtes)","role"=>"Description","rowClass"=>"vl-333"],
  ],
  "vms" => [
    // LAN
    ["name"=>"LAN","ip"=>"10.10.10.1","mask"=>"/24","vlan"=>"LAN","host"=>"PVE1","role"=>"Routeur / Firewall","rowClass"=>"vl-lan"],
    // VLAN
    ["name"=>"NAS","ip"=>"10.20.20.14","mask"=>"/25","vlan"=>"222","host"=>"PVE1","role"=>"Prod DmD","rowClass"=>"vl-222"],
    ["name"=>"RDS2","ip"=>"10.30.30.51","mask"=>"/25","vlan"=>"333","host"=>"PVE1","role"=>"RDS #2","rowClass"=>"vl-333"],
  ],
  "devices" => [
    ["name"=>"Téléphone","ip"=>"10.30.30.101","vlan"=>"333","rowClass"=>"vl-333"],
    ["name"=>"Imprimante","ip"=>"10.20.20.131","vlan"=>"222","rowClass"=>"vl-222"],
    ["name"=>"Raspberry 1","ip"=>"10.10.10.201","vlan"=>"1","rowClass"=>"vl-1"],
  ],
  "switchTitle" => "Switch 2.5 G — Keeplink KP-9000-9XHML-X",
  "switchMgmt"  => "Mgmt : 10.20.30.81",
  "switchUplink"=> "Uplink : 10.20.30.82 (SwitchRadius)",
  "switch" => [
    ["port"=>"1","mode"=>"Access","vlans"=>"1","desc"=>"LAN (10.10.10.0/24)","rowClass"=>"vl-lan"],
    ["port"=>"2","mode"=>"Access","vlans"=>"222","desc"=>"Medias To Switchs2","rowClass"=>"vl-1722"],
    ["port"=>"3","mode"=>"Access","vlans"=>"TRUNCK","desc"=>"LAN, 1721, 1722, 1010, 1012","rowClass"=>"vl-1722"],
    ["port"=>"4","mode"=>"SPF","vlans"=>"333","desc"=>"Médias borne 2,5Gb/s","rowClass"=>"vl-lan"],
  ]
];
