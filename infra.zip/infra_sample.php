<?php
// Retourne un tableau PHP ; il sera json_encode lors de l’écriture
return [
  "meta" => [
    "title" => "Infrastructure Maison",
    "subtitle" => "Doc statique – lisible & imprimable"
  ],
  "legend" => [
    ["label"=>"LAN serveurs","class"=>"vl-lan"],
    ["label"=>"VLAN1721 Users","class"=>"vl-1721"],
    ["label"=>"VLAN1722 Médias","class"=>"vl-1722"],
    ["label"=>"VLAN1010 SynoHomes","class"=>"vl-1010"],
    ["label"=>"VLAN1012 Public","class"=>"vl-1012"],
    ["label"=>"Starlink","class"=>"vl-star"],
    ["label"=>"Freebox","class"=>"vl-star"]
  ],
  "topology" => [
    "wan" => [
      ["name"=>"Free", "cidr"=>"192.168.2.1/24"],
      ["name"=>"Starlink", "cidr"=>"192.168.1.1/24"]
    ],
    "gw" => [
      "name"=>"pfSense",
      "meta"=>"GW VLANs, NAT, règles FW",
      "detail"=>"LAN: 10.20.30.1/28 • 1721: 172.100.100.1/27 • 1722: 172.200.200.1/25 • 1010: 172.10.10.1/25 • 1012: 172.12.12.1/27"
    ],
    "switch" => [
      "name"=>"Switch 2.5G",
      "meta"=>"Keeplink KP-9000-9XHML-X — mgmt 10.20.30.81",
      "detail"=>"Trunk → pfSense • Ports access par VLAN"
    ]
  ],
  "wan" => [
    ["provider"=>"Free","ip"=>"192.168.2.1","mask"=>"/24","type"=>"ADSL 7Megas","notes"=>"IP Fixe:"],
    ["provider"=>"Starlink","ip"=>"192.168.1.1","mask"=>"/24","type"=>"Satellite","notes"=>"NAT CGNAT probable"]
  ],
  "pve" => [
    "label" => "PVE1 + PVE2",
    "hosts" => [
      ["name"=>"PVE1","ip"=>"10.20.30.9","vlan"=>"LAN (10.20.30.0/28)","notes"=>"RS2600 + 2 To NVMe 5 Gb/s","rowClass"=>"vl-lan"],
      ["name"=>"PVE2","ip"=>"172.10.10.9","vlan"=>"1010 (172.10.10.0/25)","notes"=>"i5 • 16 Go • SSD 250 • 8 To USB-C RAID1","rowClass"=>"vl-1010"]
    ]
  ],
  "vlans" => [
    ["name"=>"LAN","cidr"=>"10.20.30.0/28","gw"=>"10.20.30.1","class"=>"lan"],
    ["name"=>"1721 Users","cidr"=>"172.100.100.0/27","gw"=>"172.100.100.1","class"=>"v1721"],
    ["name"=>"1012 Public","cidr"=>"172.12.12.0/27","gw"=>"172.12.12.1","class"=>"v1012"]
  ],
  "vlansNote" => "CIDR /27 et /25 pour maîtriser le DHCP",
  "vlansTable" => [
    ["vlan"=>"LAN","name"=>"LAN SERVEURS","subnet"=>"10.20.30.0/255.255.255.240","gw"=>"10.20.30.1","mask"=>"/28 (14 hôtes)","role"=>"Serveurs, caméras","rowClass"=>"vl-lan"],
    ["vlan"=>"1010","name"=>"SYNOHOMES","subnet"=>"172.10.10.0/255.255.255.128","gw"=>"172.10.10.1","mask"=>"/25 (126 hôtes)","role"=>"SynoHomes / DoMyDesk / Dev","rowClass"=>"vl-1010"],
    ["vlan"=>"1012","name"=>"PUBLIQUE","subnet"=>"172.12.12.0/255.255.255.128","gw"=>"172.12.12.1","mask"=>"/25 (126 hôtes)","role"=>"Invités / Jeux / Internet public","rowClass"=>"vl-1012"]
  ],
  "vms" => [
    // LAN
    ["name"=>"pfSense VLAN","ip"=>"10.20.30.1","mask"=>"/28","vlan"=>"LAN","host"=>"PVE1","role"=>"Routeur / Firewall","rowClass"=>"vl-lan"],
    ["name"=>"NAS-Dev","ip"=>"10.20.30.13","mask"=>"/28","vlan"=>"LAN","host"=>"PVE2","role"=>"NAS Dev","rowClass"=>"vl-lan"],
    ["name"=>"SVRAD-Slave","ip"=>"10.20.30.3","mask"=>"/28","vlan"=>"LAN","host"=>"PVE2","role"=>"AD / RADIUS secondaire","rowClass"=>"vl-lan"],
    // 1010
    ["name"=>"DoMyDesk","ip"=>"172.10.10.14","mask"=>"/25","vlan"=>"1010","host"=>"PVE1","role"=>"Prod DmD","rowClass"=>"vl-1010"],
    ["name"=>"RDS2","ip"=>"172.10.10.51","mask"=>"/25","vlan"=>"1010","host"=>"PVE1","role"=>"RDS #2","rowClass"=>"vl-1010"],
    ["name"=>"NAS-Backup","ip"=>"172.10.10.11","mask"=>"/25","vlan"=>"1010","host"=>"PVE2","role"=>"Backup","rowClass"=>"vl-1010"]
  ],
  "devices" => [
    ["name"=>"Véro — Téléphone","ip"=>"172.200.200.101","vlan"=>"1722","rowClass"=>"vl-1722"],
    ["name"=>"Imprimante Brother","ip"=>"172.200.200.131","vlan"=>"1722","rowClass"=>"vl-1722"],
    ["name"=>"Raspberry 1","ip"=>"172.200.200.201","vlan"=>"1722","rowClass"=>"vl-1722"],
    ["name"=>"Caméras","ip"=>"10.20.30.101 à 10.20.30.105","vlan"=>"1 - LAN","rowClass"=>"vl-lan"]
  ],
  "switchTitle" => "Switch 2.5 G — Keeplink KP-9000-9XHML-X",
  "switchMgmt"  => "Mgmt : 10.20.30.81",
  "switchUplink"=> "Uplink : 10.20.30.82 (SwitchRadius)",
  "switch" => [
    ["port"=>"1","mode"=>"Access","vlans"=>"1","desc"=>"LAN (10.20.30.0/27)","rowClass"=>"vl-lan"],
    ["port"=>"2","mode"=>"Access","vlans"=>"1722","desc"=>"Medias To Switchs2","rowClass"=>"vl-1722"],
    ["port"=>"3","mode"=>"Access","vlans"=>"TRUNCK","desc"=>"LAN, 1721, 1722, 1010, 1012","rowClass"=>"vl-1722"],
    ["port"=>"4","mode"=>"SPF","vlans"=>"LAN","desc"=>"Médias borne 2,5Gb/s","rowClass"=>"vl-lan"]
  ]
];
