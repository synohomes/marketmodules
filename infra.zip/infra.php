<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { echo "<div style='color:red;padding:10px'>⛔ Non connecté</div>"; return; }
$baseDir  = __DIR__ . "/../../users/profiles/$email/infra/";
$dataFile = $baseDir . "infra.json";
$docsFile = $baseDir . "infra_docs.json";
@mkdir($baseDir, 0775, true);
$docs = [];
if (file_exists($docsFile)) {
  $arr = json_decode(@file_get_contents($docsFile), true);
  if (is_array($arr)) {
    foreach ($arr as $d) {
      $id    = $d['id'] ?? null;
      $name  = $d['data']['header']['name']  ?? $id;   
      $title = $d['data']['header']['title'] ?? $name;    
      if ($id) {
        $docs[] = [
          'source'=>'multi',
          'id'=>$id,
          'name'=>$name,
          'title'=>$title
        ];
      }
    }
  }
}
$files = @glob($baseDir . '*.json') ?: [];
foreach ($files as $f) {
  if (realpath($f) === realpath($docsFile)) continue;
  $raw   = json_decode(@file_get_contents($f), true);
  $name  = $raw['header']['name']  ?? basename($f);     
  $title = $raw['header']['title'] ?? $name;             
  $docs[] = [
    'source'=>'file',
    'file'=>basename($f),
    'name'=>$name,
    'title'=>$title
  ];
}
if (empty($docs) && file_exists($dataFile)) {
  $raw   = json_decode(@file_get_contents($dataFile), true);
  $name  = $raw['header']['name']  ?? 'Infra';
  $title = $raw['header']['title'] ?? $name;
  $docs[] = ['source'=>'file','file'=>'infra.json','name'=>$name,'title'=>$title];
}
$baseRender = "modules/infra/infra_render.php?u=" . urlencode($email);
$cfgUrl     = "profile_edit.php?module=infra";
?>
<div style="padding:10px">
  <style>
    .infra-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}
    .infra-head .btn{padding:6px 10px;border-radius:8px;border:1px solid currentColor;background:transparent;color:inherit;text-decoration:none}
    .infra-grid{display:grid;gap:10px;grid-template-columns:repeat(auto-fill,minmax(220px,1fr))}
    .infra-card{border:1px solid currentColor;border-radius:12px;background:transparent;padding:12px;cursor:pointer;transition:.12s}
    .infra-card:hover{transform:translateY(-2px);box-shadow:0 6px 18px rgba(0,0,0,.35)}
    .infra-name{font-weight:600;margin-bottom:4px;font-size:14px}
    .infra-title{
	font-weight:600;
	font-size:14px;
  line-height:1.3;
		}
  </style>
  <?php if (empty($docs)): ?>
    <div style="color:#9aa;font-size:13px">Aucun document.</div>
  <?php else: ?>
    <div class="infra-grid">
      <?php foreach ($docs as $d):
        if ($d['source'] === 'multi') {
          $renderUrl = $baseRender . "&doc=" . urlencode($d['id']) . "&t=" . time();
        } else {
          $renderUrl = $baseRender . "&file=" . urlencode($d['file']) . "&t=" . time();
        }
      ?>
		<div class="infra-card" data-url="<?php echo htmlspecialchars($renderUrl); ?>">
		<div class="infra-title"><?php echo htmlspecialchars($d['title']); ?></div>
		</div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
  <script>
  (function(){
    function createPopup(url){
      const id='infra-pop-'+Math.random().toString(36).slice(2,8);
      const wrap=document.createElement('div');
      wrap.style.position='fixed';wrap.style.right='10px';wrap.style.bottom='10px';
      wrap.style.width='min(980px,95vw)';wrap.style.height='min(620px,80vh)';
      wrap.style.background='#0b0e14';wrap.style.border='1px solid rgba(255,255,255,.15)';
      wrap.style.borderRadius='12px';wrap.style.boxShadow='0 12px 40px rgba(0,0,0,.45)';
      wrap.style.overflow='hidden';wrap.style.zIndex='9999';
      wrap.innerHTML=`
        <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 12px;border-bottom:1px solid rgba(255,255,255,.15);background:#0f121a;cursor:move">
          <div style="font-weight:600">Aperçu — Infrastructure</div>
          <div style="display:flex;gap:6px">
            <button class="pop-toggle">Agrandir</button>
            <button class="pop-print">Imprimer</button>
            <button class="pop-close">✕</button>
          </div>
        </div>
        <iframe src="${url}" style="width:100%;height:calc(100% - 32px);border:0;background:#0f1115"></iframe>`;
      document.body.appendChild(wrap);
      const frame=wrap.querySelector('iframe');
      const toggle=wrap.querySelector('.pop-toggle');
      const close=wrap.querySelector('.pop-close');
      const printBt=wrap.querySelector('.pop-print');
      const bar=wrap.firstElementChild;
      function applySize(full){
        wrap.dataset.full=full?'1':'';
        if(full){
          wrap.style.inset='10px';wrap.style.width='auto';wrap.style.height='auto';
          toggle.textContent='Réduire';
        } else {
          wrap.style.inset='auto';wrap.style.right='10px';wrap.style.bottom='10px';
          wrap.style.width='min(980px,95vw)';wrap.style.height='min(620px,80vh)';
          toggle.textContent='Agrandir';
        }
      }
      applySize(false);
      toggle.onclick=()=>applySize(!(wrap.dataset.full==='1'));
      close.onclick=()=>wrap.remove();
      printBt.onclick=()=>{try{frame.contentWindow.print();}catch(_){}};
      let drag=false,sx=0,sy=0,ox=0,oy=0;
      bar.addEventListener('mousedown',e=>{
        if(wrap.dataset.full==='1')return;
        drag=true;sx=e.clientX;sy=e.clientY;
        const r=wrap.getBoundingClientRect();ox=r.left;oy=r.top;
        document.body.style.userSelect='none';
      });
      window.addEventListener('mousemove',e=>{
        if(!drag||wrap.dataset.full==='1')return;
        const nx=Math.min(window.innerWidth-60,Math.max(0,ox+(e.clientX-sx)));
        const ny=Math.min(window.innerHeight-60,Math.max(0,oy+(e.clientY-sy)));
        wrap.style.left=nx+'px';wrap.style.top=ny+'px';
        wrap.style.right='auto';wrap.style.bottom='auto';
      });
      window.addEventListener('mouseup',()=>{drag=false;document.body.style.userSelect='';});
    }
    document.querySelectorAll('.infra-card').forEach(card=>{
      card.addEventListener('click',()=>{
        const url=card.getAttribute('data-url');
        if(url) createPopup(url);
      });
    });
  })();
  </script>
</div>
