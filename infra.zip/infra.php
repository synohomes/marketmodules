<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { echo "<div style='color:red;padding:10px'>⛔ Non connecté</div>"; return; }

$baseDir  = __DIR__ . "/../../users/profiles/$email/infra/";
$dataFile = $baseDir . "infra.json";       // rétro-compat (ancien format unique)
$docsFile = $baseDir . "infra_docs.json";  // nouveau format multi-docs
@mkdir($baseDir, 0775, true);
/* Construit la liste des documents disponibles */
$docs = [];

/* 1) Multi-docs (infra_docs.json) — chaque entrée a un id et (optionnel) un title */
if (file_exists($docsFile)) {
  $arr = json_decode(@file_get_contents($docsFile), true);
  if (is_array($arr)) {
    foreach ($arr as $d) {
      $id    = $d['id']    ?? null;
      $title = $d['title'] ?? ($d['data']['header']['title'] ?? null); // on tente le titre réel
      if ($id) {
        $docs[] = ['source'=>'multi','id'=>$id,'title'=>$title ?: $id];
      }
    }
  }
}
/* 2) Fichiers JSON individuels (hors infra_docs.json) */
$files = @glob($baseDir . '*.json') ?: [];
foreach ($files as $f) {
  if (realpath($f) === realpath($docsFile)) continue;
  $title = null;
  $raw   = json_decode(@file_get_contents($f), true);
  if (is_array($raw)) $title = $raw['header']['title'] ?? $raw['moduleName'] ?? null;
  $docs[] = ['source'=>'file','file'=>basename($f),'title'=>$title ?: basename($f)];
}
/* 3) Rétro-compat stricte si seul infra.json existe */
if (empty($docs) && file_exists($dataFile)) {
  $raw   = json_decode(@file_get_contents($dataFile), true);
  $title = is_array($raw) ? ($raw['header']['title'] ?? $raw['moduleName'] ?? null) : null;
  $docs[] = ['source'=>'file','file'=>'infra.json','title'=>$title ?: 'Infra'];
}
/* URLs */
$baseRender = "modules/infra/infra_render.php?u=" . urlencode($email);
$cfgUrl     = "profile_edit.php?module=infra";
?>
<div style="padding:10px">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
    <div style="font-weight:600">Vos Infrastructures</div>
    <div style="display:flex;gap:8px">
      <a href="<?php echo $cfgUrl; ?>" class="btn" style="padding:6px 10px;border-radius:8px;border:1px solid #2b3445;background:#111;color:#e8ecf2;text-decoration:none">Configurer</a>
    </div>
  </div>
  <!-- Liste des documents en volets -->
  <div>
    <?php if (empty($docs)): ?>
      <div style="color:#9aa;font-size:13px">Aucun document trouvé.</div>
    <?php else: ?>
      <?php foreach ($docs as $d):
        if ($d['source'] === 'multi') {
          $renderUrl = $baseRender . "&doc=" . urlencode($d['id']) . "&t=" . time();
          $srcLabel  = "infra_docs.json → " . $d['id'];
        } else {
          $renderUrl = $baseRender . "&file=" . urlencode($d['file']) . "&t=" . time();
          $srcLabel  = $d['file'];
        }
      ?>
      <details class="infra-acc" style="border:1px solid #222;border-radius:10px;background:#0f1115;margin-bottom:10px;overflow:hidden">
        <summary style="list-style:none;padding:10px 12px;cursor:pointer;display:flex;align-items:center;gap:10px">
          <span class="caret" style="inline-size:10px;block-size:10px;border-right:2px solid #8ea2c8;border-bottom:2px solid #8ea2c8;transform:rotate(-45deg);margin-right:2px"></span>
          <span style="font-weight:300"><?php echo htmlspecialchars($d['title']); ?></span>
        </summary>
        <div style="padding:10px 12px;border-top:1px solid #1f2530;background:#0b0e14">
          <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
            <button class="btn infra-open"
                    data-url="<?php echo htmlspecialchars($renderUrl); ?>"
                    style="padding:6px 10px;border-radius:8px;border:1px solid #2b3445;background:#111;color:#e8ecf2;cursor:pointer">
              Aperçu
            </button>
            <button class="btn infra-max"
                    data-url="<?php echo htmlspecialchars($renderUrl); ?>"
                    style="padding:6px 10px;border-radius:8px;border:1px solid #2b3445;background:#111;color:#e8ecf2;cursor:pointer">
              Agrandir
            </button>
            <a href="<?php echo htmlspecialchars($renderUrl); ?>"
               target="_blank"
               class="btn"
               style="padding:6px 10px;border-radius:8px;border:1px solid #2b3445;background:#111;color:#e8ecf2;text-decoration:none">
              Nouvel onglet
            </a>
            <span style="font-size:12px;color:#9aa">Source : <code><?php echo htmlspecialchars($srcLabel); ?></code></span>
          </div>
        </div>
      </details>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <!-- Popup dans le dashboard -->
  <div id="infra-modal"
       style="display:none;position:absolute;right:10px;bottom:10px;width:min(250px,95vw);height:min(180px,80vh);background:#0b0e14;border:1px solid #222;border-radius:12px;box-shadow:0 12px 40px rgba(0,0,0,.45);overflow:hidden;z-index:50">
    <div id="infra-bar" style="display:flex;align-items:center;justify-content:space-between;background:#0f121a;border-bottom:1px solid #1f2530;padding:8px 12px;cursor:move">
      <div style="font-weight:600">Aperçu — Infrastructure</div>
      <div style="display:flex;gap:8px;align-items:center">
        <button id="infra-toggle" style="border:1px solid #2b3445;background:#1b2230;color:#e8ecf2;padding:4px 10px;border-radius:8px;cursor:pointer">Agrandir</button>
        <a id="infra-print" href="#" style="font-size:13px;text-decoration:none;padding:4px 8px;border:1px solid #2b3445;border-radius:8px;color:#e8ecf2">Imprimer</a>
        <button id="infra-close" style="border:0;background:#1b2230;color:#e8ecf2;padding:6px 10px;border-radius:8px;cursor:pointer">✕</button>
      </div>
    </div>
    <iframe id="infra-frame" src="about:blank" style="width:100%;height:calc(100% - 44px);border:0;background:#0f1115"></iframe>
  </div>
</div>

<script>
(function(){
  const modal    = document.getElementById('infra-modal');
  const frame    = document.getElementById('infra-frame');
  const printBtn = document.getElementById('infra-print');
  const closeBtn = document.getElementById('infra-close');
  const toggleBtn= document.getElementById('infra-toggle');
  const bar      = document.getElementById('infra-bar');

  function openModal(url, maximize=false){
    if (frame) frame.src = url;
    if (!modal) return;
    modal.style.display = 'block';
    if (maximize) {
      modal.dataset.full = '1';
      applySize();
    }
  }
  function closeModal(){ if (modal) modal.style.display = 'none'; }
  function applySize(){
    if (!modal) return;
    if (modal.dataset.full === '1') {
      modal.style.position = 'fixed';
      modal.style.inset = '10px';
      modal.style.width = 'auto';
      modal.style.height = 'auto';
      toggleBtn && (toggleBtn.textContent = 'Réduire');
    } else {
      modal.style.position = 'absolute';
      modal.style.right = '10px';
      modal.style.bottom = '10px';
      modal.style.width = 'min(980px,95vw)';
      modal.style.height = 'min(620px,80vh)';
      toggleBtn && (toggleBtn.textContent = 'Agrandir');
    }
  }

  // Ouvre petit aperçu
  document.querySelectorAll('.infra-open').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const url = btn.getAttribute('data-url');
      if (url) { modal.dataset.full = ''; applySize(); openModal(url,false); }
    });
  });

  // Ouvre directement en grand dans le dashboard (sans quitter la page)
  document.querySelectorAll('.infra-max').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const url = btn.getAttribute('data-url');
      if (url) { modal.dataset.full = '1'; applySize(); openModal(url,true); }
    });
  });

  // Drag du modal par la barre
  let dragging = false, sx=0, sy=0, ox=0, oy=0;
  bar && bar.addEventListener('mousedown', (e)=>{
    if (modal?.dataset.full === '1') return; // pas de drag en plein écran
    dragging = true; sx = e.clientX; sy = e.clientY;
    const rect = modal.getBoundingClientRect(); ox = rect.left; oy = rect.top;
    document.body.style.userSelect = 'none';
  });
  window.addEventListener('mousemove', (e)=>{
    if (!dragging || modal?.dataset.full === '1') return;
    const nx = ox + (e.clientX - sx);
    const ny = oy + (e.clientY - sy);
    modal.style.left = Math.max(0, nx) + 'px';
    modal.style.top  = Math.max(0, ny) + 'px';
    modal.style.right = 'auto'; modal.style.bottom = 'auto';
    modal.style.position = 'fixed';
  });
  window.addEventListener('mouseup', ()=>{ dragging=false; document.body.style.userSelect=''; });

  closeBtn && closeBtn.addEventListener('click', closeModal);
  toggleBtn && toggleBtn.addEventListener('click', ()=>{
    modal.dataset.full = modal.dataset.full === '1' ? '' : '1';
    applySize();
  });

  printBtn && printBtn.addEventListener('click', function(e){
    e.preventDefault();
    frame && frame.contentWindow && frame.contentWindow.focus();
    frame && frame.contentWindow && frame.contentWindow.print();
  });

  // Rotation caret
  document.querySelectorAll('details.infra-acc').forEach(d=>{
    const caret = d.querySelector('.caret');
    d.addEventListener('toggle', ()=>{ if (caret) caret.style.transform = d.open ? 'rotate(45deg)' : 'rotate(-45deg)'; });
  });
})();
</script>
