<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { echo "<div style='color:red;padding:10px'>⛔ Non connecté</div>"; return; }

$baseDir  = __DIR__ . "/../../users/profiles/$email/infra/";
$dataFile = $baseDir . "infra.json";       // rétro-compat (ancien format unique)
$docsFile = $baseDir . "infra_docs.json";  // nouveau format multi-docs
@mkdir($baseDir, 0775, true);
/* Construit la liste des documents disponibles */
$docs = [];

/* 1) Multi-docs (infra_docs.json) — chaque entrée a un id et (optionnel) un title */
if (file_exists($docsFile)) {
  $arr = json_decode(@file_get_contents($docsFile), true);
  if (is_array($arr)) {
    foreach ($arr as $d) {
      $id    = $d['id']    ?? null;
      $title = $d['title'] ?? ($d['data']['header']['title'] ?? null); // on tente le titre réel
      if ($id) {
        $docs[] = ['source'=>'multi','id'=>$id,'title'=>$title ?: $id];
      }
    }
  }
}
/* 2) Fichiers JSON individuels (hors infra_docs.json) */
$files = @glob($baseDir . '*.json') ?: [];
foreach ($files as $f) {
  if (realpath($f) === realpath($docsFile)) continue;
  $title = null;
  $raw   = json_decode(@file_get_contents($f), true);
  if (is_array($raw)) $title = $raw['header']['title'] ?? $raw['moduleName'] ?? null;
  $docs[] = ['source'=>'file','file'=>basename($f),'title'=>$title ?: basename($f)];
}
/* 3) Rétro-compat stricte si seul infra.json existe */
if (empty($docs) && file_exists($dataFile)) {
  $raw   = json_decode(@file_get_contents($dataFile), true);
  $title = is_array($raw) ? ($raw['header']['title'] ?? $raw['moduleName'] ?? null) : null;
  $docs[] = ['source'=>'file','file'=>'infra.json','title'=>$title ?: 'Infra'];
}
/* URLs */
$baseRender = "modules/infra/infra_render.php?u=" . urlencode($email);
$cfgUrl     = "profile_edit.php?module=infra";
?>
<div style="padding:10px">
  <!-- ====== AJOUT STYLES (override uniquement) ====== -->
  <style>
    /* Grille responsive sans changer le HTML :
       on met chaque <details.infra-acc> en "carte" inline-block avec des largeurs responsives */
    details.infra-acc{
      display:inline-block; vertical-align:top;
      width: calc(50% - 12px);               /* ≥2 colonnes par défaut */
      margin:6px;                            /* petit espacement */
      border:1px solid currentColor !important;
      border-radius:10px !important;
      background:transparent !important;     /* pas de bande noire */
      overflow:hidden;
    }
    @media (max-width:560px){
      details.infra-acc{ width:100%; }       /* 1 colonne sur mobile étroit */
    }
    @media (min-width:980px){
      details.infra-acc{ width: calc(33.333% - 12px); } /* 3 colonnes grands écrans */
    }

    /* En-tête du volet */
    details.infra-acc > summary{
      background:transparent !important;     /* supprime les fonds sombres */
      padding:10px 12px !important;
      list-style:none;
      display:flex; align-items:center; gap:10px; cursor:pointer;
      border-bottom:1px solid transparent;   /* ligne visible uniquement quand ouvert */
    }
    details.infra-acc[open] > summary{
      border-bottom-color: currentColor !important;
    }

    /* Corps du volet */
    details.infra-acc > div{
      background:transparent !important;     /* pas de bande noire */
      border-top:0 !important;
      padding:10px 12px !important;
    }

    /* Caret harmonisé avec le thème courant */
    .caret{
      inline-size:10px; block-size:10px;
      border-right:2px solid currentColor !important;
      border-bottom:2px solid currentColor !important;
      transform:rotate(-45deg);
      transition: transform .18s ease;
      margin-right:2px;
    }
    details.infra-acc[open] .caret{ transform:rotate(45deg); }

    /* Boutons : transparents, bordure et texte hérités du thème */
    .btn.infra-open,
    .btn.infra-max,
    a.btn[target="_blank"]{
      background:transparent !important;
      color:inherit !important;
      border:1px solid currentColor !important;
      border-radius:10px !important;
      padding:6px 10px !important;
    }
    .btn.infra-open:hover,
    .btn.infra-max:hover,
    a.btn[target="_blank"]:hover{ filter:brightness(1.08); }

    /* Lien "Configurer" => emoji uniquement, sans modifier le HTML */
    a.btn[href*="profile_edit.php?module=infra"]{
      position:relative;
      width:38px; height:38px;
      display:inline-flex; align-items:center; justify-content:center;
      border-radius:10px !important;
      background:transparent !important;
      border:1px solid currentColor !important;
      color:transparent !important;          /* cache le mot "Configurer" sans toucher au texte */
      padding:0 !important;
    }
    a.btn[href*="profile_edit.php?module=infra"]::before{
      content:"⚙️";                          /* emoji affiché à la place du texte */
      color:inherit; font-size:18px; line-height:1;
    }

    /* Texte source plus discret */
    code{ opacity:.8; }
  </style>

  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
    <div style="font-weight:600">Vos Infrastructures</div>
    <div style="display:flex;gap:8px">
      <a href="<?php echo $cfgUrl; ?>" class="btn" style="padding:6px 10px;border-radius:8px;border:1px solid #2b3445;background:#111;color:#e8ecf2;text-decoration:none">Configurer</a>
    </div>
  </div>
  <!-- Liste des documents en volets -->
  <div>
    <?php if (empty($docs)): ?>
      <div style="color:#9aa;font-size:13px">Aucun document trouvé.</div>
    <?php else: ?>
      <?php foreach ($docs as $d):
        if ($d['source'] === 'multi') {
          $renderUrl = $baseRender . "&doc=" . urlencode($d['id']) . "&t=" . time();
          $srcLabel  = "infra_docs.json → " . $d['id'];
        } else {
          $renderUrl = $baseRender . "&file=" . urlencode($d['file']) . "&t=" . time();
          $srcLabel  = $d['file'];
        }
      ?>
      <details class="infra-acc" style="border:1px solid #222;border-radius:10px;background:#0f1115;margin-bottom:10px;overflow:hidden">
        <summary style="list-style:none;padding:10px 12px;cursor:pointer;display:flex;align-items:center;gap:10px">
          <span class="caret" style="inline-size:10px;block-size:10px;border-right:2px solid #8ea2c8;border-bottom:2px solid #8ea2c8;transform:rotate(-45deg);margin-right:2px"></span>
          <span style="font-weight:300"><?php echo htmlspecialchars($d['title']); ?></span>
        </summary>
        <div style="padding:10px 12px;border-top:1px solid #1f2530;background:#0b0e14">
          <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
            <button class="btn infra-open"
                    data-url="<?php echo htmlspecialchars($renderUrl); ?>"
                    style="padding:6px 10px;border-radius:8px;border:1px solid #2b3445;background:#111;color:#e8ecf2;cursor:pointer">
              Aperçu
            </button>
            <button class="btn infra-max"
                    data-url="<?php echo htmlspecialchars($renderUrl); ?>"
                    style="padding:6px 10px;border-radius:8px;border:1px solid #2b3445;background:#111;color:#e8ecf2;cursor:pointer">
              Agrandir
            </button>
            <a href="<?php echo htmlspecialchars($renderUrl); ?>"
               target="_blank"
               class="btn"
               style="padding:6px 10px;border-radius:8px;border:1px solid #2b3445;background:#111;color:#e8ecf2;text-decoration:none">
              Nouvel onglet
            </a>
            <span style="font-size:12px;color:#9aa">Source : <code><?php echo htmlspecialchars($srcLabel); ?></code></span>
          </div>
        </div>
      </details>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <!-- Popup dans le dashboard -->

<script>
(function(){
  // ========= Fabrique de popup indépendante =========
  function createPopup(url, maximized){
    const id = 'infra-pop-' + Math.random().toString(36).slice(2,8);
    const wrap = document.createElement('div');
    wrap.id = id;
    wrap.className = 'infra-pop';
    // Toujours FIXED et attaché au <body> => indépendant du module
    wrap.style.position = 'fixed';
    wrap.style.right = '10px';
    wrap.style.bottom = '10px';
    wrap.style.width  = 'min(980px,95vw)';
    wrap.style.height = 'min(620px,80vh)';
    wrap.style.background = 'var(--infra-pop-bg, #0b0e14)';
    wrap.style.border = '1px solid rgba(255,255,255,.15)';
    wrap.style.borderRadius = '12px';
    wrap.style.boxShadow = '0 12px 40px rgba(0,0,0,.45)';
    wrap.style.overflow = 'hidden';
    wrap.style.zIndex = '9999';

    wrap.innerHTML = `
      <div class="infra-pop-bar" style="
          display:flex;align-items:center;justify-content:space-between;
          padding:8px 12px;border-bottom:1px solid rgba(255,255,255,.15);
          background:var(--infra-pop-bar,#0f121a);cursor:move"
      >
        <div style="font-weight:600">Aperçu — Infrastructure</div>
        <div style="display:flex;gap:8px;align-items:center">
          <button class="pop-toggle" style="border:1px solid rgba(255,255,255,.2);background:#1b2230;color:#e8ecf2;padding:4px 10px;border-radius:8px;cursor:pointer">Agrandir</button>
          <button class="pop-print"  style="border:1px solid rgba(255,255,255,.2);background:#1b2230;color:#e8ecf2;padding:4px 10px;border-radius:8px;cursor:pointer">Imprimer</button>
          <button class="pop-close"  style="border:0;background:#1b2230;color:#e8ecf2;padding:6px 10px;border-radius:8px;cursor:pointer">✕</button>
        </div>
      </div>
      <iframe class="infra-pop-frame" src="about:blank" style="width:100%;height:calc(100% - 44px);border:0;background:#0f1115"></iframe>
    `;
    document.body.appendChild(wrap);

    const frame   = wrap.querySelector('.infra-pop-frame');
    const toggle  = wrap.querySelector('.pop-toggle');
    const close   = wrap.querySelector('.pop-close');
    const printBt = wrap.querySelector('.pop-print');
    const bar     = wrap.querySelector('.infra-pop-bar');

    // charge l’URL
    if (frame) frame.src = url;

    // plein écran / réduit (toujours fixed, donc pas d’impact sur le module)
    function applySize(full){
      wrap.dataset.full = full ? '1' : '';
      if (full){
        wrap.style.inset = '10px';
        wrap.style.width = 'auto';
        wrap.style.height= 'auto';
        toggle.textContent = 'Réduire';
      } else {
        wrap.style.inset = 'auto';
        wrap.style.right = '10px';
        wrap.style.bottom= '10px';
        wrap.style.width  = 'min(980px,95vw)';
        wrap.style.height = 'min(620px,80vh)';
        toggle.textContent = 'Agrandir';
      }
    }
    applySize(!!maximized);

    toggle.addEventListener('click', ()=> applySize(!(wrap.dataset.full==='1')));
    close.addEventListener('click', ()=> wrap.remove());
    printBt.addEventListener('click', (e)=>{ e.preventDefault(); try{ frame.contentWindow.print(); }catch(_){} });

    // ===== Drag (dans le viewport) =====
    let drag=false, sx=0, sy=0, ox=0, oy=0;
    bar.addEventListener('mousedown', (e)=>{
      if (wrap.dataset.full==='1') return; // pas de drag en plein écran
      drag=true; sx=e.clientX; sy=e.clientY;
      const r = wrap.getBoundingClientRect(); ox=r.left; oy=r.top;
      document.body.style.userSelect='none';
    });
    window.addEventListener('mousemove', (e)=>{
      if (!drag || wrap.dataset.full==='1') return;
      const nx = Math.min(window.innerWidth - 60, Math.max(0, ox + (e.clientX - sx)));
      const ny = Math.min(window.innerHeight - 60, Math.max(0, oy + (e.clientY - sy)));
      wrap.style.left = nx + 'px';
      wrap.style.top  = ny + 'px';
      wrap.style.right = 'auto';
      wrap.style.bottom= 'auto';
    });
    window.addEventListener('mouseup', ()=>{ drag=false; document.body.style.userSelect=''; });

    return wrap;
  }

  // ========= Branche les boutons existants sur la fabrique =========
  document.querySelectorAll('.infra-open').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const url = btn.getAttribute('data-url');
      if (url) createPopup(url, false);
    });
  });
  document.querySelectorAll('.infra-max').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const url = btn.getAttribute('data-url');
      if (url) createPopup(url, true);
    });
  });

  // garde tes caret animés
  document.querySelectorAll('details.infra-acc').forEach(d=>{
    const caret = d.querySelector('.caret');
    d.addEventListener('toggle', ()=>{ if (caret) caret.style.transform = d.open ? 'rotate(45deg)' : 'rotate(-45deg)'; });
  });
})();
</script>
