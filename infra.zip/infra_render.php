<?php
if (session_status() === PHP_SESSION_NONE) session_start();

/* ------- Auth minimale ------- */
$viewer  = $_SESSION['user']['email'] ?? '';
$isAdmin = ($_SESSION['user']['role_system'] ?? '') === 'admin';
$u       = $_GET['u']   ?? '';
$docId   = $_GET['doc'] ?? '';
$file    = $_GET['file']?? '';

if (!$viewer) { http_response_code(403); echo "Non connecté"; exit; }
if ($u !== $viewer && !$isAdmin) { http_response_code(403); echo "Accès refusé"; exit; }

/* ------- Lecture des données (multi-docs d'abord) ------- */
$baseDir  = __DIR__ . "/../../users/profiles/$u/infra/";
$docsFile = $baseDir . "infra_docs.json";

$data = null;
if ($docId !== '' && is_file($docsFile)) {
  $all = json_decode(@file_get_contents($docsFile), true);
  if (is_array($all)) {
    foreach ($all as $d) {
      if (($d['id'] ?? '') === $docId) { $data = $d['data'] ?? null; break; }
    }
  }
}
/* Fallback sur fichier direct si demandé */
if (!$data && $file !== '') {
  $path = realpath($baseDir . basename($file));
  if ($path && is_file($path)) $data = json_decode(@file_get_contents($path), true);
}
/* Fallback ultime : 1er doc de infra_docs.json */
if (!$data && is_file($docsFile)) {
  $all = json_decode(@file_get_contents($docsFile), true);
  if (is_array($all) && !empty($all)) $data = $all[0]['data'] ?? null;
}

if (!$data) { http_response_code(404); echo "Aucune donnée trouvée."; exit; }
if (!is_array($data)) { http_response_code(500); echo "Données invalides."; exit; }

/* ------- Helpers ------- */
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function codeSpan($s){ return '<code>'.h($s).'</code>'; }
function infra_slug($s){
  $s = mb_strtolower(trim((string)$s), 'UTF-8');
  $s = preg_replace('~[^\pL\d]+~u', '-', $s);
  $s = preg_replace('~^-+|-+$~', '', $s);
  return $s ?: 'x';
}

/* ------- Mapping vers ton schéma ------- */
$header   = $data['header']   ?? [];
$legend   = $data['legend']   ?? [];
$style    = $data['style']    ?? [];
$topology = $data['topology'] ?? [];

$wan          = $data['wan']          ?? [];
$hypervisors  = $data['hypervisors']  ?? [];
$addressPlan  = $data['addressPlan']  ?? [];
$vms          = $data['vms']          ?? [];
$devices      = $data['devices']      ?? [];
$switchesList = $data['switches']     ?? [];

/* ------- En-tête / thème ------- */
$title    = $header['title'] ?? 'Infrastructure';
$subtitle = "Doc statique — lisible & imprimable";
$dateStr  = (($header['dateMode'] ?? 'auto') === 'fixed' && !empty($header['fixedDate']))
          ? $header['fixedDate']
          : (new DateTime())->format('d/m/Y');

$css = [
  'bg'     => $style['bg']     ?? '#0f1115',
  'panel'  => $style['panel']  ?? '#151a20',
  'text'   => $style['text']   ?? '#e8ecf2',
  'muted'  => $style['muted']  ?? '#97a3b6',
  'border' => $style['border'] ?? '#232a36',
  'accent' => $style['accent'] ?? '#f2c94c',
];

/* ------- Color maps depuis la légende ------- */
/* On supporte les DEUX: legend.class (ex: "vl-222") ET legend.label (ex: "VLAN1721 Users") */
$defaultColor = $css['accent'];
$labelMap = [];  // label -> ['slug','color']
$slugMap  = [];  // slug  -> color
$classMap = [];  // class -> color   (C'EST LA CLEF POUR vl-222 / vl-333)

foreach ($legend as $tag) {
  $label = is_array($tag) ? ($tag['label'] ?? $tag['text'] ?? '') : (string)$tag;
  $class = is_array($tag) ? trim((string)($tag['class'] ?? '')) : '';
  $color = is_array($tag) ? ($tag['color'] ?? $defaultColor) : $defaultColor;
  if ($label) {
    $slug = infra_slug($label);
    $labelMap[$label] = ['slug'=>$slug, 'color'=>$color];
    $slugMap[$slug]   = $color;
  }
  if ($class) {
    $classMap[$class] = $color;
    // bonus: si le class ressemble à vl-XXX → créer un alias slug "vlan-xxx"
    if (preg_match('~^vl-([a-z0-9\-]+)$~i',$class,$m)) {
      $slugMap['vlan-'.$m[1]] = $color;
    }
  }
}

/* ------- Couleur par ligne (robuste) ------- */
function parse_rgb($c, $fallback=[242,201,76]){
  $c = trim($c);
  if ($c === '') return $fallback;
  if ($c[0] === '#'){
    $hex = substr($c,1);
    if (strlen($hex)===3) $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    if (strlen($hex)===6) return [hexdec(substr($hex,0,2)),hexdec(substr($hex,2,2)),hexdec(substr($hex,4,2))];
  } elseif (stripos($c,'rgb')===0 && preg_match('~rgba?\(([^)]+)\)~',$c,$m)){
    $parts = array_map('trim', explode(',', $m[1]));
    $vals  = [];
    for($i=0;$i<3;$i++){
      $v=$parts[$i]??'0';
      $vals[] = (strpos($v,'%')!==false) ? (float)$v*2.55 : (int)$v;
    }
    return $vals;
  }
  return $fallback;
}
function color_for_row(array $row, array $labelMap, array $slugMap, array $classMap){
  // 1) rowClass: priorité au match EXACT sur legend.class (ex: "vl-222")
  if (!empty($row['rowClass'])){
    // supporte plusieurs classes séparées par espace
    $classes = preg_split('~\s+~', strtolower((string)$row['rowClass']));
    foreach ($classes as $c){
      if (isset($classMap[$c])) return $classMap[$c];               // <-- clé du problème résolu
      if (strpos($c,'row-')===0){ $slug = substr($c,4); if (isset($slugMap[$slug])) return $slugMap[$slug]; }
      if (strpos($c,'vl-')===0){  $slug = substr($c,3); if (isset($slugMap[$slug])) return $slugMap[$slug]; }
    }
  }
  // 2) colonne VLAN → si nombre N et on a "vl-N" dans la légende
  $v = '';
  if (!empty($row['vlan'])) $v=(string)$row['vlan']; elseif(!empty($row['VLAN'])) $v=(string)$row['VLAN'];
  if ($v !== '' && preg_match_all('~\d{2,4}~',$v,$m)){
    foreach ($m[0] as $num){
      if (isset($classMap['vl-'.$num])) return $classMap['vl-'.$num];
      if (isset($slugMap['vlan-'.$num])) return $slugMap['vlan-'.$num];
    }
  }
  // 3) recherche plein texte sur les labels
  $hay = strtolower(implode(' ', array_map('strval',$row)));
  foreach ($labelMap as $label=>$info){
    if (stripos($hay, strtolower($label))!==false) return $info['color'];
  }
  return null;
}
function tint_attrs(array $row, array $labelMap, array $slugMap, array $classMap, array $accentRgb){
  $c = color_for_row($row,$labelMap,$slugMap,$classMap);
  if (!$c) return ['',''];
  [$r,$g,$b] = parse_rgb($c,$accentRgb);
  $bg = "rgba($r,$g,$b,0.18)";
  $bd = "rgba($r,$g,$b,0.50)";
  return ['tint', "--row-bg:$bg;--row-bd:$bd;"];
}
$accentRgb = parse_rgb($css['accent']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title><?= h($title) ?></title>
<style>
  :root{
    --bg:<?= h($css['bg']) ?>; --panel:<?= h($css['panel']) ?>; --text:<?= h($css['text']) ?>;
    --muted:<?= h($css['muted']) ?>; --border:<?= h($css['border']) ?>; --accent:<?= h($css['accent']) ?>;
  }
  *{box-sizing:border-box}
  html,body{margin:0;background:var(--bg);color:var(--text);font-family:Inter,system-ui,Segoe UI,Roboto,Arial,sans-serif;line-height:1.45}
  .wrap{max-width:1100px;width:100%;margin:clamp(8px,2.5vw,24px) auto;padding:0 clamp(8px,3vw,18px)}
  .head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;margin-bottom:10px;flex-wrap:wrap}
  h1{margin:0 0 6px 0;font-size:clamp(18px,2.2vw,24px)}
  h2{margin:0;font-size:clamp(15px,1.8vw,18px)}
  .muted{color:var(--muted)}
  .card{background:var(--panel);border:1px solid var(--border);border-radius:14px;padding:clamp(10px,2vw,14px);margin-bottom:clamp(10px,2vw,16px);min-width:0}
  .grid2{display:grid;grid-template-columns:1fr;gap:clamp(8px,2vw,16px)}
  @media(min-width:900px){.grid2{grid-template-columns:1fr 1fr}}
  .legend{display:flex;flex-wrap:wrap;gap:8px}
  .tag{padding:4px 10px;border-radius:999px;border:1px solid var(--border);font-size:12px;white-space:nowrap;max-width:100%}
  code{background:#0f1320;border:1px solid var(--border);padding:1px 6px;border-radius:8px;white-space:nowrap}

  .topo{padding:clamp(10px,2vw,16px)}
  .topo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px 18px}
  .node{background:#0f1320;border:1px solid var(--border);border-radius:12px;padding:10px 12px}
  .node h3{margin:0 0 4px 0;font-size:14px}
  .node .meta{font-size:12px;color:var(--muted)}
  .wanchips{display:flex;gap:8px;flex-wrap:wrap}
  .chip{border:1px solid var(--border);border-radius:10px;padding:6px 8px;background:#121a2a;font-size:12px}
  .vlan-list{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px}
  .vlan-b{border:1px solid var(--border);border-radius:10px;padding:8px 10px;font-size:12px;background:#111725}

  .table-wrap{width:100%;overflow:auto;border-radius:10px}
  table{width:100%;border-collapse:collapse;table-layout:fixed}
  th,td{border:1px solid var(--border);padding:8px 10px;text-align:left;vertical-align:top;word-wrap:break-word}
  th{background:#1b2030}
  @media(max-width:250px){
    table thead{display:none}
    table, tbody, tr, td{display:block;width:100%}
    tr{border:1px solid var(--border);border-radius:10px;margin-bottom:8px;background:#0f1320}
    td{border:none;border-bottom:1px solid var(--border);padding:8px 10px}
    td:last-child{border-bottom:none}
    td::before{content:attr(data-label);display:block;font-size:11px;color:var(--muted);margin-bottom:4px}
  }

  /* Teinte appliquée par style inline (variables CSS) */
  tr.tint td { background: var(--row-bg); border-color: var(--row-bd); }

  body.embed .wrap{max-width:100%;padding:0 8px}
  body.embed .card{padding:10px}
</style>

<?php
/* Colore aussi les tags légende via CSS (optionnel) */
echo "<style>";
foreach ($labelMap as $label=>$info){
  $slug  = $info['slug'];
  $color = $info['color'];
  echo ".tag-$slug { background: {$color}22; border-color: {$color}66; }";
}
echo "</style>";
?>
</head>
<body>
<div class="wrap">
  <div class="head">
    <div>
      <h1><?= h($title) ?></h1>
      <div class="muted"><?= h($subtitle) ?> — Mise à jour : <?= h($dateStr) ?></div>
    </div>
    <div class="legend">
      <?php foreach ($legend as $tag):
        $label = is_array($tag) ? ($tag['label'] ?? $tag['text'] ?? '') : (string)$tag;
        if (!$label) continue;
        $color = is_array($tag) ? ($tag['color'] ?? $defaultColor) : $defaultColor;
        $slug  = infra_slug($label);
      ?>
        <span class="tag tag-<?= h($slug) ?>" style="background:<?= h($color) ?>22;border-color:<?= h($color) ?>66">
          <?= h($label) ?>
        </span>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Topologie -->
  <section class="card topo">
    <div class="topo-grid">
      <div class="node">
        <h3><?= h($topology['company']['name'] ?? 'DoMyCompany') ?></h3>
        <div class="wanchips">
          <?php foreach (($topology['company']['wan'] ?? []) as $w): ?>
            <div class="chip"><?= h($w['label'] ?? '') ?><?php if (!empty($w['cidr'])): ?> <span class="muted">(<?= h($w['cidr']) ?>)</span><?php endif; ?></div>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="node">
        <h3><?= h($topology['pfsense']['name'] ?? 'pfSense') ?></h3>
        <div class="meta"><?= h($topology['pfsense']['ips'] ?? '') ?></div>
      </div>
      <div class="node">
        <h3><?= h(($topology['switchesTop'][0]['label'] ?? 'Switch')) ?></h3>
        <div class="meta">
          <?php foreach (($topology['switchesTop'][0]['meta'] ?? []) as $ln): ?>
            <?= h($ln) ?><br>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="node" style="grid-column:1/-1">
        <h3>VLANs & sous-réseaux</h3>
        <div class="vlan-list">
          <?php foreach (($topology['vlansRow'] ?? []) as $v): ?>
            <div class="vlan-b">
              <b><?= h($v['name'] ?? '') ?></b><br>
              <span class="muted"><?= h($v['cidr'] ?? '') ?><br>GW <?= h($v['gw'] ?? '') ?></span>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </section>

  <div class="grid2">
    <!-- WAN -->
    <section class="card">
      <h2>Accès WAN</h2>
      <div class="table-wrap">
        <table>
          <thead><tr><th>FAI</th><th>Masque/Plage</th><th>IP Publique</th><th>Type</th></tr></thead>
          <tbody>
            <?php foreach ($wan as $w):
              [$tclass,$tstyle] = tint_attrs($w,$labelMap,$slugMap,$classMap,$accentRgb);
            ?>
              <tr class="<?= h($tclass) ?>" style="<?= h($tstyle) ?>">
                <td data-label="FAI"><?= h($w['provider'] ?? '') ?></td>
                <td data-label="Masque/Plage"><?= codeSpan($w['mask'] ?? '') ?></td>
                <td data-label="IP Publique"><?= h($w['publicIp'] ?? '') ?></td>
                <td data-label="Type"><?= h($w['type'] ?? '') ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </section>

    <!-- Hyperviseurs -->
    <section class="card">
      <h2>Hyperviseurs Proxmox</h2>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Hôte</th><th>Adresse</th><th>VLAN</th><th>Notes</th></tr></thead>
          <tbody>
            <?php foreach ($hypervisors as $hrow):
              [$tclass,$tstyle] = tint_attrs($hrow,$labelMap,$slugMap,$classMap,$accentRgb);
            ?>
              <tr class="<?= h($tclass) ?>" style="<?= h($tstyle) ?>">
                <td data-label="Hôte"><?= h($hrow['host'] ?? '') ?></td>
                <td data-label="Adresse"><?= codeSpan($hrow['addr'] ?? '') ?></td>
                <td data-label="VLAN"><?= h($hrow['vlan'] ?? '') ?></td>
                <td data-label="Notes"><?= h($hrow['notes'] ?? '') ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </section>
  </div>

  <!-- Plan d’adressage -->
  <section class="card">
    <h2>Plan d’adressage / VLAN</h2>
    <div class="table-wrap">
      <table>
        <thead><tr><th>VLAN</th><th>Nom</th><th>Sous-réseau</th><th>Passerelle</th><th>Masque</th><th>Rôle</th></tr></thead>
        <tbody>
          <?php foreach ($addressPlan as $r):
            [$tclass,$tstyle] = tint_attrs($r,$labelMap,$slugMap,$classMap,$accentRgb);
          ?>
            <tr class="<?= h($tclass) ?>" style="<?= h($tstyle) ?>">
              <td data-label="VLAN"><b><?= h($r['vlan'] ?? '') ?></b></td>
              <td data-label="Nom"><?= h($r['name'] ?? '') ?></td>
              <td data-label="Sous-réseau"><?= codeSpan($r['subnet'] ?? '') ?></td>
              <td data-label="Passerelle"><?= codeSpan($r['gw'] ?? '') ?></td>
              <td data-label="Masque"><?= h($r['mask'] ?? '') ?></td>
              <td data-label="Rôle"><?= h($r['role'] ?? '') ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </section>

  <!-- VMs -->
  <section class="card">
    <h2>Machines virtuelles</h2>
    <div class="table-wrap">
      <table>
        <thead><tr><th>VM</th><th>Adresse</th><th>Masque</th><th>VLAN</th><th>Hôte</th><th>Rôle</th></tr></thead>
        <tbody>
          <?php foreach ($vms as $vm):
            [$tclass,$tstyle] = tint_attrs($vm,$labelMap,$slugMap,$classMap,$accentRgb);
          ?>
            <tr class="<?= h($tclass) ?>" style="<?= h($tstyle) ?>">
              <td data-label="VM"><?= h($vm['vm'] ?? '') ?></td>
              <td data-label="Adresse"><?= codeSpan($vm['addr'] ?? '') ?></td>
              <td data-label="Masque"><?= h($vm['mask'] ?? '') ?></td>
              <td data-label="VLAN"><?= h($vm['vlan'] ?? '') ?></td>
              <td data-label="Hôte"><?= h($vm['host'] ?? '') ?></td>
              <td data-label="Rôle"><?= h($vm['role'] ?? '') ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </section>

  <!-- Périphériques -->
  <section class="card">
    <h2>Périphériques Maison</h2>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Nom</th><th>Adresse</th><th>VLAN</th></tr></thead>
        <tbody>
          <?php foreach ($devices as $d):
            [$tclass,$tstyle] = tint_attrs($d,$labelMap,$slugMap,$classMap,$accentRgb);
          ?>
            <tr class="<?= h($tclass) ?>" style="<?= h($tstyle) ?>">
              <td data-label="Nom"><?= h($d['name'] ?? '') ?></td>
              <td data-label="Adresse"><?= codeSpan($d['addr'] ?? '') ?></td>
              <td data-label="VLAN"><?= h($d['vlan'] ?? '') ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </section>

  <!-- Switches -->
  <?php foreach ($switchesList as $sw): ?>
    <section class="card">
      <h2><?= h($sw['title'] ?? 'Switch') ?></h2>
      <div class="table-wrap">
        <table>
          <thead><tr><th>rowClass</th><th>Port</th><th>Mode</th><th>VLAN(s)</th><th>Description</th></tr></thead>
          <tbody>
            <?php foreach (($sw['ports'] ?? []) as $p):
              [$tclass,$tstyle] = tint_attrs($p,$labelMap,$slugMap,$classMap,$accentRgb);
            ?>
              <tr class="<?= h($tclass) ?>" style="<?= h($tstyle) ?>">
                <td data-label="rowClass"><?= h($p['rowClass'] ?? '') ?></td>
                <td data-label="Port"><?= h($p['port'] ?? '') ?></td>
                <td data-label="Mode"><?= h($p['mode'] ?? '') ?></td>
                <td data-label="VLAN(s)"><?= h($p['vlans'] ?? '') ?></td>
                <td data-label="Description"><?= h($p['desc'] ?? '') ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </section>
  <?php endforeach; ?>

</div>

<script>
  try{ if (window.self !== window.top) document.body.classList.add('embed'); }catch(_){}
</script>
</body>
</html>
