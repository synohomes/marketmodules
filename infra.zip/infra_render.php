<?php
if (session_status() === PHP_SESSION_NONE) session_start();

/* ------- Auth minimale ------- */
$viewer  = $_SESSION['user']['email'] ?? '';
$isAdmin = ($_SESSION['user']['role_system'] ?? '') === 'admin';
$u       = $_GET['u']   ?? '';
$docId   = $_GET['doc'] ?? '';
$file    = $_GET['file']?? '';

if (!$viewer) { http_response_code(403); echo "Non connecté"; exit; }
if ($u !== $viewer && !$isAdmin) { http_response_code(403); echo "Accès refusé"; exit; }

/* ------- Lecture des données (multi-docs d'abord) ------- */
$baseDir  = __DIR__ . "/../../users/profiles/$u/infra/";
$docsFile = $baseDir . "infra_docs.json";

$data = null;
$sourceLabel = '';

if ($docId !== '' && is_file($docsFile)) {
  $all = json_decode(@file_get_contents($docsFile), true);
  if (is_array($all)) {
    foreach ($all as $d) {
      if (($d['id'] ?? '') === $docId) { $data = $d['data'] ?? null; break; }
    }
  }
  $sourceLabel = "infra_docs.json → $docId";
}

/* Fallback sur fichier direct si demandé */
if (!$data && $file !== '') {
  $path = realpath($baseDir . basename($file));
  if ($path && is_file($path)) {
    $data = json_decode(@file_get_contents($path), true);
    $sourceLabel = basename($path);
  }
}

/* Fallback ultime : 1er doc de infra_docs.json */
if (!$data && is_file($docsFile)) {
  $all = json_decode(@file_get_contents($docsFile), true);
  if (is_array($all) && !empty($all)) {
    $data = $all[0]['data'] ?? null;
    $sourceLabel = "infra_docs.json → " . ($all[0]['id'] ?? '');
  }
}

if (!$data) { http_response_code(404); echo "Aucune donnée trouvée."; exit; }
if (!is_array($data)) { http_response_code(500); echo "Données invalides."; exit; }

/* ------- Helpers ------- */
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function codeSpan($s){ return '<code>'.h($s).'</code>'; }

/* ------- Mapping vers ton schéma ------- */
$header   = $data['header']   ?? [];
$legend   = $data['legend']   ?? [];
$style    = $data['style']    ?? [];
$topology = $data['topology'] ?? [];

$wan          = $data['wan']          ?? [];
$hypervisors  = $data['hypervisors']  ?? [];
$addressPlan  = $data['addressPlan']  ?? [];
$vms          = $data['vms']          ?? [];
$devices      = $data['devices']      ?? [];
$switchesList = $data['switches']     ?? [];

$title    = $header['title'] ?? 'Infrastructure';
$subtitle = "Doc statique — lisible & imprimable";
$dateStr  = (($header['dateMode'] ?? 'auto') === 'fixed' && !empty($header['fixedDate']))
          ? $header['fixedDate']
          : (new DateTime())->format('d/m/Y');

$css = [
  'bg'     => $style['bg']     ?? '#0f1115',
  'panel'  => $style['panel']  ?? '#151a20',
  'text'   => $style['text']   ?? '#e8ecf2',
  'muted'  => $style['muted']  ?? '#97a3b6',
  'border' => $style['border'] ?? '#232a36',
  'accent' => $style['accent'] ?? '#f2c94c',
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title><?= h($title) ?></title>
<style>
  :root{
    --bg:<?= h($css['bg']) ?>; --panel:<?= h($css['panel']) ?>; --text:<?= h($css['text']) ?>;
    --muted:<?= h($css['muted']) ?>; --border:<?= h($css['border']) ?>; --accent:<?= h($css['accent']) ?>;
  }
  *{box-sizing:border-box}
  html,body{margin:0;background:var(--bg);color:var(--text);font-family:Inter,system-ui,Segoe UI,Roboto,Arial,sans-serif;line-height:1.45;overscroll-behavior:contain}
  .wrap{max-width:1100px;width:100%;margin:clamp(8px,2.5vw,24px) auto;padding:0 clamp(8px,3vw,18px)}
  .head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;margin-bottom:10px;flex-wrap:wrap}
  h1{margin:0 0 6px 0;font-size:clamp(18px,2.2vw,24px)}
  h2{margin:0;font-size:clamp(15px,1.8vw,18px)}
  .muted{color:var(--muted)}
  .card{background:var(--panel);border:1px solid var(--border);border-radius:14px;padding:clamp(10px,2vw,14px);margin-bottom:clamp(10px,2vw,16px);min-width:0}
  .grid2{display:grid;grid-template-columns:1fr;gap:clamp(8px,2vw,16px)}
  @media(min-width:900px){.grid2{grid-template-columns:1fr 1fr}}
  .legend{display:flex;flex-wrap:wrap;gap:8px}
  .tag{padding:4px 10px;border-radius:999px;border:1px solid var(--border);font-size:12px;white-space:nowrap;max-width:100%}
  code{background:#0f1320;border:1px solid var(--border);padding:1px 6px;border-radius:8px;white-space:nowrap}

  /* Topologie */
  .topo{padding:clamp(10px,2vw,16px)}
  .topo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px 18px}
  .node{background:#0f1320;border:1px solid var(--border);border-radius:12px;padding:10px 12px;min-width:0}
  .node h3{margin:0 0 4px 0;font-size:14px}
  .node .meta{font-size:12px;color:var(--muted);word-wrap:break-word}
  .wanchips{display:flex;gap:8px;flex-wrap:wrap}
  .chip{border:1px solid var(--border);border-radius:10px;padding:6px 8px;background:#121a2a;font-size:12px}
  .vlan-list{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px}
  .vlan-b{border:1px solid var(--border);border-radius:10px;padding:8px 10px;font-size:12px;background:#111725}

  /* Tables responsives (empilement mobile) */
  .table-wrap{width:100%;overflow:auto;border-radius:10px}
  table{width:100%;border-collapse:collapse;table-layout:fixed}
  th,td{border:1px solid var(--border);padding:8px 10px;text-align:left;vertical-align:top;word-wrap:break-word}
  th{background:#1b2030}
  @media(max-width:250px){
    table thead{display:none}
    table, tbody, tr, td{display:block;width:100%}
    tr{border:1px solid var(--border);border-radius:10px;margin-bottom:8px;background:#0f1320}
    td{border:none;border-bottom:1px solid var(--border);padding:8px 10px}
    td:last-child{border-bottom:none}
    td::before{content:attr(data-label);display:block;font-size:11px;color:var(--muted);margin-bottom:4px}
  }

  /* Mode iframe : compact */
  body.embed .wrap{max-width:100%;padding:0 8px}
  body.embed .card{padding:10px}
</style>
</head>
<body>
<div class="wrap">
  <div class="head">
    <div>
      <h1><?= h($title) ?></h1>
      <div class="muted"><?= h($subtitle) ?> — Mise à jour : <?= h($dateStr) ?></div>
    </div>
    <div class="legend">
      <?php foreach ($legend as $tag): ?>
        <span class="tag" style="<?= isset($tag['color']) ? 'background:'.$tag['color'].'20;border-color:'.$tag['color'].'40' : '' ?>">
          <?= h($tag['label'] ?? '') ?>
        </span>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Topologie -->
  <section class="card topo">
    <div class="topo-grid">
      <div class="node">
        <h3>WAN</h3>
        <div class="wanchips">
          <?php foreach (($topology['company']['wan'] ?? []) as $w): ?>
            <div class="chip"><?= h($w['label'] ?? '') ?><?php if (!empty($w['cidr'])): ?> <span class="muted">(<?= h($w['cidr']) ?>)</span><?php endif; ?></div>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="node">
        <h3><?= h($topology['pfsense']['name'] ?? 'pfSense') ?></h3>
        <div class="meta"><?= h($topology['pfsense']['ips'] ?? '') ?></div>
      </div>
      <div class="node">
        <h3><?= h(($topology['switchesTop'][0]['label'] ?? 'Switch')) ?></h3>
        <div class="meta">
          <?php foreach (($topology['switchesTop'][0]['meta'] ?? []) as $ln): ?>
            <?= h($ln) ?><br>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="node" style="grid-column:1/-1">
        <h3>VLANs & sous-réseaux</h3>
        <div class="vlan-list">
          <?php foreach (($topology['vlansRow'] ?? []) as $v): ?>
            <div class="vlan-b">
              <b><?= h($v['name'] ?? '') ?></b><br>
              <span class="muted"><?= h($v['cidr'] ?? '') ?><br>GW <?= h($v['gw'] ?? '') ?></span>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </section>

  <div class="grid2">
    <!-- WAN -->
    <section class="card">
      <h2>Accès WAN</h2>
      <div class="table-wrap">
        <table>
          <thead><tr><th>FAI</th><th>Masque/Plage</th><th>IP Publique</th><th>Type</th></tr></thead>
          <tbody>
            <?php foreach ($wan as $w): ?>
              <tr>
                <td data-label="FAI"><?= h($w['provider'] ?? '') ?></td>
                <td data-label="Masque/Plage"><?= codeSpan($w['mask'] ?? '') ?></td>
                <td data-label="IP Publique"><?= h($w['publicIp'] ?? '') ?></td>
                <td data-label="Type"><?= h($w['type'] ?? '') ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </section>

    <!-- Hyperviseurs -->
    <section class="card">
      <h2>Hyperviseurs Proxmox</h2>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Hôte</th><th>Adresse</th><th>VLAN</th><th>Notes</th></tr></thead>
          <tbody>
            <?php foreach ($hypervisors as $hrow): ?>
              <tr class="<?= h($hrow['rowClass'] ?? '') ?>">
                <td data-label="Hôte"><?= h($hrow['host'] ?? '') ?></td>
                <td data-label="Adresse"><?= codeSpan($hrow['addr'] ?? '') ?></td>
                <td data-label="VLAN"><?= h($hrow['vlan'] ?? '') ?></td>
                <td data-label="Notes"><?= h($hrow['notes'] ?? '') ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </section>
  </div>

  <!-- Plan d’adressage -->
  <section class="card">
    <h2>Plan d’adressage / VLAN</h2>
    <div class="table-wrap">
      <table>
        <thead><tr><th>VLAN</th><th>Nom</th><th>Sous-réseau</th><th>Passerelle</th><th>Masque</th><th>Rôle</th></tr></thead>
        <tbody>
          <?php foreach ($addressPlan as $r): ?>
            <tr class="<?= h($r['rowClass'] ?? '') ?>">
              <td data-label="VLAN"><b><?= h($r['vlan'] ?? '') ?></b></td>
              <td data-label="Nom"><?= h($r['name'] ?? '') ?></td>
              <td data-label="Sous-réseau"><?= codeSpan($r['subnet'] ?? '') ?></td>
              <td data-label="Passerelle"><?= codeSpan($r['gw'] ?? '') ?></td>
              <td data-label="Masque"><?= h($r['mask'] ?? '') ?></td>
              <td data-label="Rôle"><?= h($r['role'] ?? '') ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </section>

  <!-- VMs -->
  <section class="card">
    <h2>Machines virtuelles</h2>
    <div class="table-wrap">
      <table>
        <thead><tr><th>VM</th><th>Adresse</th><th>Masque</th><th>VLAN</th><th>Hôte</th><th>Rôle</th></tr></thead>
        <tbody>
          <?php foreach ($vms as $vm): ?>
            <tr class="<?= h($vm['rowClass'] ?? '') ?>">
              <td data-label="VM"><?= h($vm['vm'] ?? '') ?></td>
              <td data-label="Adresse"><?= codeSpan($vm['addr'] ?? '') ?></td>
              <td data-label="Masque"><?= h($vm['mask'] ?? '') ?></td>
              <td data-label="VLAN"><?= h($vm['vlan'] ?? '') ?></td>
              <td data-label="Hôte"><?= h($vm['host'] ?? '') ?></td>
              <td data-label="Rôle"><?= h($vm['role'] ?? '') ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </section>

  <!-- Périphériques -->
  <section class="card">
    <h2>Périphériques Maison</h2>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Nom</th><th>Adresse</th><th>VLAN</th></tr></thead>
        <tbody>
          <?php foreach ($devices as $d): ?>
            <tr class="<?= h($d['rowClass'] ?? '') ?>">
              <td data-label="Nom"><?= h($d['name'] ?? '') ?></td>
              <td data-label="Adresse"><?= codeSpan($d['addr'] ?? '') ?></td>
              <td data-label="VLAN"><?= h($d['vlan'] ?? '') ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </section>

  <!-- Switches -->
  <?php foreach ($switchesList as $sw): ?>
    <section class="card">
      <h2><?= h($sw['title'] ?? 'Switch') ?></h2>
      <div class="table-wrap">
        <table>
          <thead><tr><th>rowClass</th><th>Port</th><th>Mode</th><th>VLAN(s)</th><th>Description</th></tr></thead>
          <tbody>
            <?php foreach (($sw['ports'] ?? []) as $p): ?>
              <tr class="<?= h($p['rowClass'] ?? '') ?>">
                <td data-label="rowClass"><?= h($p['rowClass'] ?? '') ?></td>
                <td data-label="Port"><?= h($p['port'] ?? '') ?></td>
                <td data-label="Mode"><?= h($p['mode'] ?? '') ?></td>
                <td data-label="VLAN(s)"><?= h($p['vlans'] ?? '') ?></td>
                <td data-label="Description"><?= h($p['desc'] ?? '') ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </section>
  <?php endforeach; ?>

  
</div>

<script>
  // Mode compact si affiché en iframe (aperçu dans le dashboard)
  try{ if (window.self !== window.top) document.body.classList.add('embed'); }catch(_){}
</script>
</body>
</html>
