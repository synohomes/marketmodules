<?php
/* -----------------------------------------------------------
   infracfg.php — Config Infra (multi-docs par utilisateur)
   - NE TOUCHE PAS la session / thème
   - CSS SCOPÉ sous .infra-scope pour ne pas écraser style.css
------------------------------------------------------------ */
if (session_status() === PHP_SESSION_NONE) session_start();

/* ====== CONTEXTE UTILISATEUR ====== */
$email = $_GET['dev_email'] ?? ($_SESSION['user']['email'] ?? '');
if (!$email) { echo "<div style='color:red;padding:10px'>⛔ Non connecté</div>"; return; }

/* ====== FICHIERS ====== */
$baseDir  = dirname(__DIR__, 2) . "/users/profiles/$email/infra/";
@mkdir($baseDir, 0775, true);
$docsFile = $baseDir . "infra_docs.json";
if (!file_exists($docsFile)) @file_put_contents($docsFile, "[]");
$docs = json_decode(@file_get_contents($docsFile), true);
if (!is_array($docs)) $docs = [];

/* ====== URLS FIABLES ====== */
$docRoot  = rtrim(str_replace('\\','/', realpath($_SERVER['DOCUMENT_ROOT'])), '/');
$selfAbs  = str_replace('\\','/', __FILE__);
$selfRel  = '/'.ltrim(str_replace($docRoot, '', $selfAbs), '/');

$actionUrl    = $selfRel . '?dev_email=' . rawurlencode($email);
$afterSaveUrl = dirname($selfRel, 3) . "/profile_edit.php?module=infra&dev_email=" . rawurlencode($email);

/* ====== VALEURS PAR DÉFAUT ====== */
$defaults = [
  "moduleName" => "Infra",
  "header" => ["title" => "Infrastructure Maison","dateMode" => "auto"],
  "legend" => [
    ["class"=>"vl-star","label"=>"Starlink","color"=>"#A613F0"],
    ["class"=>"vl-free","label"=>"Freebox","color"=>"#FFAA00"],
    ["class"=>"vl-lan","label"=>"LAN serveurs","color"=>"#F54927"],
    ["class"=>"vl-1721","label"=>"VLAN1721 Users","color"=>"#F2F527"],
    ["class"=>"vl-1212","label"=>"VLAN1012 Public","color"=>"#1373F0"]
  ],
  "style" => ["bg"=>"#0f1115","panel"=>"#151a20","text"=>"#e8ecf2","muted"=>"#97a3b6","border"=>"#232a36","accent"=>"#f2c94c"],
  "wan" => [],
  "hypervisors" => [],
  "addressPlan" => [],
  "vms" => [],
  "devices" => [],
  "switches" => []
];

/* ====== MERGE ====== */
function is_list_array($a){ if (!is_array($a)) return false; if ($a === []) return true; return array_keys($a) === range(0, count($a)-1); }
function merge_preferring_data($defaults, $data){
  if (!is_array($defaults)) return ($data !== null ? $data : $defaults);
  if (!is_array($data))     return $defaults;
  if (is_list_array($defaults) || is_list_array($data)) {
    return ($data === [] || $data === null) ? $defaults : $data;
  }
  $out = $defaults;
  foreach ($data as $k=>$v){ $out[$k] = merge_preferring_data($defaults[$k] ?? null, $v); }
  return $out;
}

/* ====== ROUTAGE DOC COURANT ====== */
$docId = $_GET['doc'] ?? null;
$currentIndex = -1;
foreach ($docs as $i=>$d) if (($d['id'] ?? '') === $docId) { $currentIndex = $i; break; }
if ($currentIndex < 0 && !empty($docs)) { $currentIndex = 0; $docId = $docs[0]['id']; }
$currentTitle = $docs[$currentIndex]['title'] ?? 'Nouveau document';
$currentData  = $docs[$currentIndex]['data']  ?? $defaults;

/* ====== ENDPOINTS JSON ====== */
if (isset($_GET['_delete_doc']) && $_GET['_delete_doc']=='1') {
  while (ob_get_level() > 0) ob_end_clean();
  @ini_set('display_errors', 0); @ini_set('html_errors', 0);
  $delId = $_GET['doc'] ?? '';
  $docs  = json_decode(@file_get_contents($docsFile), true); if (!is_array($docs)) $docs = [];
  $docs  = array_values(array_filter($docs, fn($d)=>($d['id'] ?? '') !== $delId));
  @file_put_contents($docsFile, json_encode($docs, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
  http_response_code(204); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['payload'])) {
  while (ob_get_level() > 0) ob_end_clean();
  @ini_set('display_errors', 0); @ini_set('html_errors', 0);
  header('Content-Type: application/json; charset=utf-8');

  $payload = json_decode($_POST['payload'], true);
  if (json_last_error() !== JSON_ERROR_NONE || !is_array($payload)) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'msg'=>'JSON invalide: '.json_last_error_msg()], JSON_UNESCAPED_UNICODE);
    exit;
  }

  $postedId    = trim($_POST['doc_id']   ?? '');
  $postedTitle = trim($_POST['doc_title']?? '');
  if ($postedTitle === '') $postedTitle = trim($payload['header']['title'] ?? '') ?: 'Infra';

  $docs = json_decode(@file_get_contents($docsFile), true); if (!is_array($docs)) $docs = [];
  $ix = -1; foreach ($docs as $i=>$d) if (($d['id'] ?? '') === $postedId) { $ix = $i; break; }

  if ($ix < 0) {
    $postedId = $postedId ?: uniqid('infra_');
    $docs[] = ['id'=>$postedId,'title'=>$postedTitle,'updatedAt'=>date('c'),'data'=>$payload];
  } else {
    $docs[$ix]['title']     = $postedTitle;
    $docs[$ix]['data']      = $payload;
    $docs[$ix]['updatedAt'] = date('c');
  }

  $json = json_encode($docs, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
  $tmp  = $docsFile . '.tmp';
  $bytes = @file_put_contents($tmp, $json, LOCK_EX);
  if ($bytes === false || !@rename($tmp, $docsFile)) {
    @unlink($tmp);
    $err = error_get_last()['message'] ?? 'écriture impossible';
    http_response_code(500);
    echo json_encode(['ok'=>false,'msg'=>"Échec d’enregistrement : $err"]);
    exit;
  }
  @chmod($docsFile, 0664);
  echo json_encode(['ok'=>true,'msg'=>'Enregistré','doc_id'=>$postedId]); exit;
}

if (isset($_GET['_get_doc']) && $_GET['_get_doc'] === '1') {
  while (ob_get_level() > 0) ob_end_clean();
  @ini_set('display_errors', 0); @ini_set('html_errors', 0);
  header('Content-Type: application/json; charset=utf-8');

  $wantId = $_GET['doc'] ?? '';
  $docs   = json_decode(@file_get_contents($docsFile), true); if (!is_array($docs)) $docs = [];
  $found  = null; foreach ($docs as $d) { if (($d['id'] ?? '') === $wantId) { $found = $d; break; } }
  if (!$found) { echo json_encode(['ok'=>false,'msg'=>'Doc introuvable']); exit; }

  echo json_encode([
    'ok'    => true,
    'id'    => $found['id'],
    'title' => $found['title'] ?? '',
    'data'  => ($found['data'] ?? [])
  ], JSON_UNESCAPED_UNICODE);
  exit;
}

/* ====== CHARGEMENT INITIAL — BRUT ====== */
$data = $currentData;

/* ====== DEBUG ====== */
if (isset($_GET['debug'])) {
  while (ob_get_level() > 0) ob_end_clean();
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode([
    'email'=>$email,
    'docsFile'=>$docsFile,
    'count'=>count($docs),
    'currentId'=>$docId,
    'titles'=>array_map(fn($d)=>[$d['id'],$d['title'] ?? ''], $docs),
    'selfRel'=>$selfRel,
    'actionUrl'=>$actionUrl
  ], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE); exit;
}
?>

<!-- ==================== UI MODULE (INCLUABLE) ==================== -->
<div class="infra-scope">
  <style>
    .infra-scope{ color: inherit; }
    .infra-scope .wrap{max-width:1200px;margin:24px auto;padding:0 16px}
    .infra-scope .card{ padding:14px; margin:14px 0; border:1px solid currentColor; border-radius:12px; background:transparent; }
    .infra-scope .actions{ display:flex; gap:8px; flex-wrap:wrap; margin-top:8px; }
    .infra-scope .grid2{ display:grid; grid-template-columns:1fr 1fr; gap:12px; }
    .infra-scope .grid3{ display:grid; grid-template-columns:repeat(3,1fr); gap:12px; }
    .infra-scope .tagRow{ display:grid; grid-template-columns:140px 1fr 1fr auto; gap:8px; align-items:center; }
    .infra-scope label{ display:block; font-size:12px; margin:6px 0 4px; }
    .infra-scope input[type="text"], .infra-scope input[type="url"], .infra-scope textarea, .infra-scope select{
      width:100%; padding:10px; border:1px solid currentColor; border-radius:10px; background:transparent; color:inherit; box-sizing:border-box;
    }
    .infra-scope .btn{ padding:8px 12px; border:1px solid currentColor; border-radius:10px; background:transparent; color:inherit; cursor:pointer; }
    .infra-scope .btn:hover{ filter:brightness(1.08); }
    .infra-scope .btn-danger{ border-style:dashed; }
    .infra-scope .pill{ display:inline-block; padding:4px 8px; border:1px solid currentColor; border-radius:999px; font-size:12px; background:transparent; }
    .infra-scope table{ width:100%; border-collapse:collapse; }
    .infra-scope th, .infra-scope td{ padding:8px 10px; vertical-align:top; border:1px solid currentColor; }
    @media (max-width:450px){ .infra-scope .grid2, .infra-scope .grid3{ grid-template-columns:1fr; } .infra-scope .tagRow{ grid-template-columns:1fr; } }

    /* === Bouton couleur + panel de 20 couleurs (popover) === */
    .infra-scope .chip-wrap{ position:relative; display:inline-flex; align-items:center; }
    .infra-scope .chip{
      width:30px; height:30px; border-radius:8px; border:1px solid currentColor; cursor:pointer;
      box-shadow:0 1px 0 rgba(0,0,0,.2) inset;
    }
    .infra-scope .pop{
      position:absolute; top:36px; left:0; z-index:9999;
      background:rgba(0,0,0,.35); backdrop-filter:saturate(130%) blur(6px);
      border:1px solid currentColor; border-radius:12px; padding:8px; display:none;
      box-shadow:0 8px 20px rgba(0,0,0,.35);
    }
    .infra-scope .pop-grid{ display:grid; grid-template-columns:repeat(10, 22px); gap:6px; }
    .infra-scope .pop-swatch{ width:22px; height:22px; border-radius:6px; border:1px solid currentColor; cursor:pointer; }
    .infra-scope .field-inline{ display:flex; gap:8px; align-items:center; }
  </style>

  <div class="wrap">
    <div class="section" style="margin:16px 0">
      <h2 id="infraTitle" style="cursor:pointer">⚙️ Configuration Infrastructure</h2>
      <details id="infraAcc"><summary style="display:none"></summary><div class="inner">

        <div class="card">
          <div class="actions">
            <span class="pill">🗂️Nom du document</span>
            <select id="doc_select">
              <?php foreach ($docs as $d): ?>
                <option value="<?= htmlspecialchars($d['id']) ?>" <?= ($d['id']===$docId?'selected':'') ?>>
                  <?= htmlspecialchars($d['title'] ?? $d['id']) ?>
                </option>
              <?php endforeach; ?>
              <?php if (empty($docs)): ?><option value="">(Nouveau)</option><?php endif; ?>
            </select>
            <input type="text" id="doc_title" placeholder="Nom du document" value="<?= htmlspecialchars($currentTitle) ?>" style="min-width:220px">
            <button class="btn" type="button" id="doc_new_btn">+ Nouveau</button>
            <button class="btn btn-danger" type="button" id="doc_del_btn" <?= $docId?'':'disabled' ?>>Supprimer</button>
          </div>
        </div>

        <form action="<?= htmlspecialchars($actionUrl) ?>" method="post" onsubmit="return collectAndSubmit();">
          <input type="hidden" id="doc_id" name="doc_id" value="<?= htmlspecialchars($docId ?? '') ?>">
          <input type="hidden" id="payload" name="payload">
          <input type="hidden" id="doc_title_hidden" name="doc_title">

          <div class="card">
            <span class="pill">📃 Infos sur le document</span>
            <div class="grid2">
              <div>
                <label>Titre</label>
                <input type="text" id="h_title" value="<?= htmlspecialchars($data['header']['title'] ?? '') ?>">
              </div>
              <div>
                <label>Date (auto ou fixe)</label>
                <div class="grid2">
                  <select id="h_dateMode">
                    <option value="auto" <?= ($data['header']['dateMode']??'auto')==='auto'?'selected':''; ?>>Automatique (date du jour)</option>
                    <option value="fixed" <?= ($data['header']['dateMode']??'auto')==='fixed'?'selected':''; ?>>Fixe</option>
                  </select>
                  <input type="text" id="h_dateFixed" placeholder="JJ/MM/AAAA (si fixe)" value="<?= htmlspecialchars($data['header']['fixedDate'] ?? '') ?>">
                </div>
              </div>
            </div>
            <div class="grid3" style="margin-top:8px">
              <div>
                <label>Couleur accent</label>
                <div class="field-inline">
                  <input type="text" id="s_accent" value="<?= htmlspecialchars($data['style']['accent'] ?? '') ?>" placeholder="#RRGGBB">
                  <span class="chip-wrap"><i class="chip" id="chip_accent"></i><div class="pop" id="pop_accent"></div></span>
                </div>
              </div>
              <div>
                <label>Fond</label>
                <div class="field-inline">
                  <input type="text" id="s_bg" value="<?= htmlspecialchars($data['style']['bg'] ?? '') ?>" placeholder="#RRGGBB">
                  <span class="chip-wrap"><i class="chip" id="chip_bg"></i><div class="pop" id="pop_bg"></div></span>
                </div>
              </div>
              <div>
                <label>Panel</label>
                <div class="field-inline">
                  <input type="text" id="s_panel" value="<?= htmlspecialchars($data['style']['panel'] ?? '') ?>" placeholder="#RRGGBB">
                  <span class="chip-wrap"><i class="chip" id="chip_panel"></i><div class="pop" id="pop_panel"></div></span>
                </div>
              </div>
            </div>
          </div>

          <div class="card">
            <span class="pill">📥 Légende VLANs / Tags de couleur</span>
            <div class="actions"><button type="button" class="btn" onclick="addLegend()">+ Ajouter</button></div>
            <div id="legendWrap"></div>
            <div class="pill" style="opacity:.7">class = nom de classe (ex: vl-1722) • color = couleur (#RRGGBB)</div>
          </div>

          <div class="card"><div class="pill">📡 Table — Accès WAN</div><div id="wanTable"></div><div class="actions"><button type="button" class="btn" onclick="addWan()">+ Ligne</button></div></div>
          <div class="card"><div class="pill">📀 Table — Hyperviseurs Proxmox</div><div id="hyperTable"></div><div class="actions"><button type="button" class="btn" onclick="addHyper()">+ Ligne</button></div></div>
          <div class="card"><div class="pill">⛓️ Table — Plan d’adressage / VLAN</div><div id="addrTable"></div><div class="actions"><button type="button" class="btn" onclick="addAddr()">+ Ligne</button></div></div>
          <div class="card"><div class="pill">💻 Table — Machines virtuelles</div><div id="vmsTable"></div><div class="actions"><button type="button" class="btn" onclick="addVm()">+ Ligne</button></div></div>
          <div class="card"><div class="pill">🏘️ Table — Périphériques Maison</div><div id="devTable"></div><div class="actions"><button type="button" class="btn" onclick="addDev()">+ Ligne</button></div></div>

          <!-- ======== SWITCHES ========= -->
          <div class="card">
            <div class="actions" style="justify-content:space-between">
              <span class="pill">🔌 Switches</span>
              <button type="button" class="btn" onclick="addSwitch()">+ Switch</button>
            </div>
            <div id="switchesWrap" style="margin-top:8px"></div>
          </div>
          <!-- =========================== -->

          <div class="actions" style="justify-content:center">
            <button class="btn" type="button" onclick="saveInfra()">💾 Enregistrer</button>
          </div>
        </form>

      </div></details>
    </div>
  </div>
</div>

<script>
/* ====== JS ====== */
const AFTER_SAVE = <?= json_encode($afterSaveUrl) ?>;
const ACTION_URL = <?= json_encode($actionUrl) ?>;
const data       = <?= json_encode($data, JSON_UNESCAPED_UNICODE) ?>;
const DEFAULTS   = <?= json_encode($defaults, JSON_UNESCAPED_UNICODE) ?>;
if (!data.moduleName) data.moduleName = "Infra";

/* Palette 20 couleurs */
const DMD_PALETTE = [
  "#0f1115","#151a20","#232a36","#3f4c6b","#556987",
  "#97a3b6","#ecf0f1","#f2c94c","#FFAA00","#F54927",
  "#A613F0","#1373F0","#2ecc71","#1abc9c","#9b59b6",
  "#e74c3c","#f1c40f","#34495e","#2c3e50","#ffffff"
];

const $  = (s, r=document)=>r.querySelector(s);
function el(tag, attrs={}, children=[]){ const e=document.createElement(tag);
  for(const [k,v] of Object.entries(attrs)){ if(k==='class') e.className=v; else if(k==='text') e.textContent=v; else e.setAttribute(k,v);}
  (Array.isArray(children)?children:[children]).forEach(c=>c!=null&&e.appendChild(c)); return e; }
function mkInput(value='', ph='', onChange=()=>{}, type='text'){ const i=el('input',{type, value:value??'', placeholder:ph}); i.addEventListener('input', ()=> onChange(i.value)); return i; }
function btn(label, onClick, cls='btn'){ const b=el('button',{type:'button',class:cls,text:label}); b.onclick=onClick; return b; }
function delBtn(onClick){ return btn('🗑', onClick, 'btn btn-danger'); }

/* Normalise #RGB/#RRGGBB */
function normHex(v){
  if (!v) return '';
  v = String(v).trim();
  if (/^#([0-9a-f]{3})$/i.test(v)) { const m=v.slice(1); return '#'+m.split('').map(x=>x+x).join(''); }
  if (/^#([0-9a-f]{6})$/i.test(v)) return v.toUpperCase();
  return v;
}

/* ====== CHIP + POPOVER ====== */
let openPop = null;
document.addEventListener('click', (e)=>{ if(openPop && !openPop.contains(e.target)) { openPop.style.display='none'; openPop=null; } });

function mountChip(input, chipEl, popEl, setter){
  if(!input || !chipEl || !popEl) return;
  // Color sync
  const sync = ()=>{ const v=normHex(input.value||''); chipEl.style.background = v || 'transparent'; setter(v); };
  input.addEventListener('input', sync); sync();

  // Build palette once
  popEl.innerHTML='';
  const grid = el('div',{class:'pop-grid'});
  DMD_PALETTE.forEach(c=>{
    const sw = el('div',{class:'pop-swatch'}); sw.style.background=c; sw.title=c;
    sw.addEventListener('click', ()=>{ input.value = normHex(c); sync(); if(openPop){openPop.style.display='none'; openPop=null;} });
    grid.appendChild(sw);
  });
  popEl.appendChild(grid);

  chipEl.addEventListener('click', (e)=>{
    e.stopPropagation();
    if(openPop && openPop!==popEl) openPop.style.display='none';
    popEl.style.display = (popEl.style.display==='block')?'none':'block';
    openPop = (popEl.style.display==='block') ? popEl : null;
  });
}

/* Toggle volet (inchangé) */
(function(){const t=$('#infraTitle'),acc=$('#infraAcc'); if(t&&acc){t.addEventListener('click',()=>{acc.open=!acc.open; if(acc.open) acc.scrollIntoView({behavior:'smooth',block:'start'});});}})();

/* Bind header/style */
(function initHeader(){
  $('#h_title')?.addEventListener('input', e=> data.header.title = e.target.value);
  $('#h_dateMode')?.addEventListener('change', e=> data.header.dateMode = e.target.value);
  $('#h_dateFixed')?.addEventListener('input', e=>{ if (data.header.dateMode==='fixed') data.header.fixedDate = e.target.value.trim(); });

  const acc = $('#s_accent'), bg = $('#s_bg'), panel = $('#s_panel');
  if (acc) mountChip(acc, $('#chip_accent'), $('#pop_accent'), v=> data.style.accent = v);
  if (bg)  mountChip(bg,  $('#chip_bg'),     $('#pop_bg'),     v=> data.style.bg     = v);
  if (panel) mountChip(panel,$('#chip_panel'),$('#pop_panel'), v=> data.style.panel  = v);
})();

/* ------- LÉGENDE ------- */
function renderLegend(){
  const wrap = $('#legendWrap'); if (!wrap) return; wrap.innerHTML='';
  if (!Array.isArray(data.legend)) data.legend=[];
  data.legend.forEach((it,i)=>{
    const colorInput = mkInput(it.color,'#RRGGBB', v=>{ it.color = normHex(v); }, 'text');

    // chip + popover
    const chip = el('i',{class:'chip'});
    const pop  = el('div',{class:'pop'});
    const chipWrap = el('span',{class:'chip-wrap'},[chip,pop]);
    // Palette
    const grid = el('div',{class:'pop-grid'});
    DMD_PALETTE.forEach(c=>{
      const sw=el('div',{class:'pop-swatch'}); sw.style.background=c; sw.title=c;
      sw.addEventListener('click', ()=>{ const v=normHex(c); colorInput.value=v; it.color=v; chip.style.background=v; if(openPop){openPop.style.display='none'; openPop=null;} });
      grid.appendChild(sw);
    });
    pop.appendChild(grid);
    chip.addEventListener('click',(e)=>{
      e.stopPropagation();
      if(openPop && openPop!==pop) openPop.style.display='none';
      pop.style.display = (pop.style.display==='block')?'none':'block';
      openPop = (pop.style.display==='block') ? pop : null;
    });
    // sync initial
    chip.style.background = normHex(it.color||'') || 'transparent';
    colorInput.addEventListener('input', ()=>{ const v=normHex(colorInput.value||''); it.color=v; chip.style.background=v; });

    const row = el('div',{class:'tagRow'},[
      mkInput(it.class,'class (vl-xxxx)', v=>it.class=v),
      mkInput(it.label,'label', v=>it.label=v),
      el('div',{}, [colorInput]),
      el('div',{}, [chipWrap]),
      delBtn(()=>{ data.legend.splice(i,1); renderLegend(); })
    ]);
    wrap.appendChild(row);
  });
}
function addLegend(){ (data.legend ||= []).push({class:'',label:'',color:'#cccccc'}); renderLegend(); }

/* ------- TABLES GÉNÉRIQUES ------- */
function renderTable(containerSel, arrGetter, columns){
  const host = $(containerSel); if (!host) return; host.innerHTML='';
  const table = el('table'); host.appendChild(table);
  const thead = el('tr'); columns.forEach(c=> thead.appendChild(el('th',{text:c.label}))); thead.appendChild(el('th',{text:' '})); table.appendChild(thead);
  const rows = arrGetter(); if (!Array.isArray(rows)) return;
  rows.forEach((row, idx)=>{
    const tr = el('tr');
    columns.forEach(c=>{
      const td = el('td');
      td.appendChild(mkInput(row[c.key] ?? '', c.label, v=> row[c.key]=v));
      tr.appendChild(td);
    });
    tr.appendChild(el('td',{}, delBtn(()=>{ rows.splice(idx,1); renderTable(containerSel, arrGetter, columns); })));
    table.appendChild(tr);
  });
}
function addRow(arrGetter, tpl, rerender){ const arr = arrGetter(); if (!Array.isArray(arr)) return; arr.push({...tpl}); rerender(); }

/* ------- WAN / HYPER / PLAN / VMS / DEV ------- */
function renderWan(){ if(!Array.isArray(data.wan)) data.wan=[]; renderTable('#wanTable', ()=>data.wan, [
  {key:'rowClass',label:'rowClass'},{key:'provider',label:'FAI'},{key:'mask',label:'Masque/Plage'},{key:'publicIp',label:'IP Publique'},{key:'type',label:'Type'}
]);}
function addWan(){ addRow(()=>data.wan, {rowClass:'',provider:'',mask:'',publicIp:'',type:''}, renderWan); }

function renderHyper(){ if(!Array.isArray(data.hypervisors)) data.hypervisors=[]; renderTable('#hyperTable', ()=>data.hypervisors, [
  {key:'rowClass',label:'rowClass'},{key:'host',label:'Hôte'},{key:'addr',label:'Adresse'},{key:'vlan',label:'VLAN'},{key:'notes',label:'Notes'}
]);}
function addHyper(){ addRow(()=>data.hypervisors, {rowClass:'',host:'',addr:'',vlan:'',notes:''}, renderHyper); }

function renderAddr(){ if(!Array.isArray(data.addressPlan)) data.addressPlan=[]; renderTable('#addrTable', ()=>data.addressPlan, [
  {key:'rowClass',label:'rowClass'},{key:'vlan',label:'VLAN'},{key:'name',label:'Nom'},{key:'subnet',label:'Sous-réseau'},{key:'gw',label:'Gateway'},{key:'mask',label:'Masque'},{key:'role',label:'Rôle'}
]);}
function addAddr(){ addRow(()=>data.addressPlan, {rowClass:'',vlan:'',name:'',subnet:'',gw:'',mask:'',role:''}, renderAddr); }

function renderVms(){ if(!Array.isArray(data.vms)) data.vms=[]; renderTable('#vmsTable', ()=>data.vms, [
  {key:'rowClass',label:'rowClass'},{key:'vm',label:'VM'},{key:'addr',label:'Adresse'},{key:'mask',label:'Masque'},{key:'vlan',label:'VLAN'},{key:'host',label:'Hôte'},{key:'role',label:'Rôle'}
]);}
function addVm(){ addRow(()=>data.vms, {rowClass:'',vm:'',addr:'',mask:'',vlan:'',host:'',role:''}, renderVms); }

function renderDev(){ if(!Array.isArray(data.devices)) data.devices=[]; renderTable('#devTable', ()=>data.devices, [
  {key:'rowClass',label:'rowClass'},{key:'name',label:'Nom'},{key:'addr',label:'Adresse'},{key:'vlan',label:'VLAN'}
]);}
function addDev(){ addRow(()=>data.devices, {rowClass:'',name:'',addr:'',vlan:''}, renderDev); }

/* ------- SWITCHES ------- */
function renderSwitches(){
  const wrap = $('#switchesWrap'); if(!wrap) return; wrap.innerHTML='';
  if (!Array.isArray(data.switches)) data.switches = [];
  data.switches.forEach((sw, sidx)=>{
    const card = el('div',{class:'card'});
    const header = el('div',{class:'actions'},[
      el('span',{class:'pill',text:'🔌 Switch #' + (sidx+1)}),
      el('div',{},[
        btn('+ Port', () => addPort(sidx)),
        delBtn(()=>{ data.switches.splice(sidx,1); renderSwitches(); })
      ])
    ]);
    const titleRow = el('div',{class:'actions'},[
      el('span',{class:'pill',text:'Titre'}),
      mkInput(sw.title || '', 'Nom du switch', v=> sw.title = v)
    ]);
    const table = el('table');
    const headTr = el('tr');
    ['rowClass','Port','Mode','VLAN(s)','Description',' '].forEach(h=> headTr.appendChild(el('th',{text:h})));
    table.appendChild(headTr);
    (sw.ports ||= []).forEach((p, pidx)=>{
      const tr = el('tr');
      const cells = [
        mkInput(p.rowClass || '','vl-xxxx', v=> p.rowClass=v),
        mkInput(p.port || '','1',        v=> p.port=v),
        mkInput(p.mode || '','Access',   v=> p.mode=v),
        mkInput(p.vlans || '','1,1722',  v=> p.vlans=v),
        mkInput(p.desc || '','Description', v=> p.desc=v)
      ];
      cells.forEach(c=> tr.appendChild(el('td',{},c)));
      tr.appendChild(el('td',{}, delBtn(()=>{ sw.ports.splice(pidx,1); renderSwitches(); })));
      table.appendChild(tr);
    });
    card.append(header, titleRow, table);
    wrap.appendChild(card);
  });
}
function addSwitch(){ (data.switches ||= []).push({title:'',ports:[]}); renderSwitches(); }
function addPort(sidx){ (data.switches[sidx].ports ||= []).push({rowClass:'',port:'',mode:'',vlans:'',desc:''}); renderSwitches(); }

/* Rendu initial */
function rerenderAll(){
  renderLegend(); renderWan(); renderHyper(); renderAddr(); renderVms(); renderDev(); renderSwitches();
}

/* Doc select / CRUD */
function setUrlDocParam(id){
  const u = new URL(window.location.href);
  if (id) u.searchParams.set('doc', id); else u.searchParams.delete('doc');
  history.replaceState(null, '', u.toString());
}
async function loadDocInPlace(id){
  if (!id){
    Object.keys(data).forEach(k=> delete data[k]);
    Object.assign(data, JSON.parse(JSON.stringify(DEFAULTS)));
    document.getElementById('doc_id').value = '';
    rerenderAll(); setUrlDocParam('');
    // re-monter les chips style
    mountChip($('#s_accent'), $('#chip_accent'), $('#pop_accent'), v=> data.style.accent = v);
    mountChip($('#s_bg'),     $('#chip_bg'),     $('#pop_bg'),     v=> data.style.bg     = v);
    mountChip($('#s_panel'),  $('#chip_panel'),  $('#pop_panel'),  v=> data.style.panel  = v);
    return;
  }
  try{
    const url = ACTION_URL + '&_get_doc=1&doc=' + encodeURIComponent(id) + '&ts=' + Date.now();
    const res  = await fetch(url, { credentials:'same-origin', cache:'no-store', headers:{'Accept':'application/json'} });
    const text = await res.text();
    let json; try { json = JSON.parse(text); }
    catch(parseErr){ alert('Erreur lecture doc: ' + parseErr.message + '\n\nRéponse:\n' + text.slice(0,300)); return; }
    if (!json.ok) { alert(json.msg || 'Doc introuvable'); return; }

    Object.keys(data).forEach(k=> delete data[k]);
    Object.assign(data, json.data || {});
    document.getElementById('doc_id').value = json.id || id;
    const t = document.getElementById('doc_title');
    if (t) t.value = json.title || json.data?.header?.title || 'Infra';
    rerenderAll();
    setUrlDocParam(json.id || id);

    // sync champs + chips
    $('#s_accent').value = data.style?.accent || '';
    $('#s_bg').value     = data.style?.bg     || '';
    $('#s_panel').value  = data.style?.panel  || '';
    mountChip($('#s_accent'), $('#chip_accent'), $('#pop_accent'), v=> data.style.accent = v);
    mountChip($('#s_bg'),     $('#chip_bg'),     $('#pop_bg'),     v=> data.style.bg     = v);
    mountChip($('#s_panel'),  $('#chip_panel'),  $('#pop_panel'),  v=> data.style.panel  = v);

  }catch(e){
    alert('Erreur réseau: ' + e.message);
  }
}
(function(){
  const sel = document.getElementById('doc_select');
  if (sel) sel.addEventListener('change', ()=>{ const v = sel.value || ''; const hid = document.getElementById('doc_id'); if (hid) hid.value = v; loadDocInPlace(v); });

  document.getElementById('doc_new_btn')?.addEventListener('click', ()=>{
    document.getElementById('doc_id').value = '';
    const t = document.getElementById('doc_title'); if (!t.value.trim()) t.value = 'Nouveau document';
    loadDocInPlace('');
  });

  const delBtnEl = document.getElementById('doc_del_btn');
  if (delBtnEl) delBtnEl.addEventListener('click', async ()=>{
    const id = document.getElementById('doc_id').value;
    if (!id) return alert('Pas de document sélectionné.');
    if (!confirm('Supprimer ce document ?')) return;
    try{
      const res = await fetch(ACTION_URL + '&_delete_doc=1&doc=' + encodeURIComponent(id), {credentials:'same-origin'});
      if (!res.ok){ alert('Suppression échouée ('+res.status+')'); return; }
      if (sel) { [...sel.options].forEach(o=>{ if (o.value===id) o.remove(); }); sel.value = ''; }
      loadDocInPlace('');
    }catch(e){ alert('Erreur réseau: '+e.message); }
  });
})();

/* Save */
function collectAndSubmit() {
  const t = document.getElementById('doc_title');
  document.getElementById('doc_title_hidden').value = (t?.value || '').trim() || 'Infra';
  document.getElementById('payload').value = JSON.stringify(data);
  return true;
}
async function saveInfra(){
  collectAndSubmit();
  const body = new URLSearchParams();
  body.set('payload',   document.getElementById('payload').value);
  body.set('doc_id',    document.getElementById('doc_id').value);
  body.set('doc_title', document.getElementById('doc_title_hidden').value);
  try{
    const res  = await fetch(ACTION_URL, {
      method:'POST',
      headers:{ 'Content-Type':'application/x-www-form-urlencoded', 'X-Requested-With':'XMLHttpRequest', 'Accept':'application/json' },
      body, credentials:'same-origin', cache:'no-store'
    });
    const text = await res.text();
    let resp; try { resp = JSON.parse(text); }
    catch(e){ alert('Réponse non JSON ('+res.status+'):\n'+text.slice(0,300)); return; }

    if (resp.ok){
      const id = resp.doc_id || document.getElementById('doc_id').value || '';
      const hid = document.getElementById('doc_id'); if (hid) hid.value = id;
      const title = document.getElementById('doc_title_hidden')?.value || 'Infra';
      const sel = document.getElementById('doc_select');
      if (sel && ![...sel.options].some(o => o.value === id)) { sel.add(new Option(title, id, true, true)); }
      else if (sel) { sel.value = id; const opt = [...sel.options].find(o=>o.value===id); if (opt) opt.textContent = title; }
      alert('✅ Enregistré.'); setUrlDocParam(id);
    } else {
      alert('❌ '+(resp.msg || 'Erreur inconnue'));
    }
  } catch(e){
    alert('❌ Erreur réseau: '+e.message);
  }
}

/* Init */
window.addEventListener('DOMContentLoaded', () => {
  const currentId = (document.getElementById('doc_id')?.value || '').trim() || (document.getElementById('doc_select')?.value || '').trim();
  if (currentId) loadDocInPlace(currentId); else {
    rerenderAll();
    mountChip($('#s_accent'), $('#chip_accent'), $('#pop_accent'), v=> data.style.accent=v);
    mountChip($('#s_bg'),     $('#chip_bg'),     $('#pop_bg'),     v=> data.style.bg=v);
    mountChip($('#s_panel'),  $('#chip_panel'),  $('#pop_panel'),  v=> data.style.panel=v);
  }
});
</script>
