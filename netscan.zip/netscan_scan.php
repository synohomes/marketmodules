<?php
if (session_status()===PHP_SESSION_NONE) session_start();
header('Content-Type: application/json; charset=utf-8');
$email = $_SESSION['user']['email'] ?? '';
if (!$email){ echo json_encode(['ok'=>false,'error'=>'Non connecté']); exit; }
$uDir = __DIR__ . "/../../users/profiles/$email/";
@mkdir($uDir, 0775, true);
$cfgFile   = $uDir . "netscan.json";
$stateFile = $uDir . "netscan_state.json";
$lockFile  = $uDir . "netscan.lock";
$histDir   = $uDir . "netscan_history/";
@mkdir($histDir, 0775, true);
function readJsonSafe($f){ if(!file_exists($f)) return []; $js=json_decode(@file_get_contents($f),true); return is_array($js)?$js:[]; }
function writeJsonAtomic($f,$arr){ $t=$f.".tmp"; file_put_contents($t,json_encode($arr,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)); @rename($t,$f); }
function withLock($lockFile,$fn){ $h=@fopen($lockFile,'c+'); if(!$h) return $fn(); try{ @flock($h,LOCK_EX); $r=$fn(); @flock($h,LOCK_UN); } finally{ @fclose($h);} return $r; }
function now(){ return date('Y-m-d H:i:s'); }
function cidrToList($cidr, $limit=4096){
  $cidr=trim($cidr); if(!preg_match('~^(\d{1,3}(?:\.\d{1,3}){3})/(\d{1,2})$~',$cidr,$m)) return [];
  $ip=$m[1]; $mask=(int)$m[2]; if($mask<1||$mask>32) return [];
  $iplong=ip2long($ip); if($iplong===false) return [];
  $netmask = -1 << (32-$mask); $network = $iplong & $netmask; $broadcast = $network + ~ $netmask;
  $start=$network+1; $end=$broadcast-1; if($end<$start) return [];
  $res=[]; $cap=min($limit,65536);
  for($i=$start;$i<=$end;$i++){ $res[]=long2ip($i); if(count($res)>=$cap) break; }
  return $res;
}
function pingTTL($ip){
  $ttl=null;$alive=false; $os=PHP_OS_FAMILY;
  $cmd = ($os==='Windows') ? "ping -n 1 -w 500 ".escapeshellarg($ip) : "ping -c 1 -W 1 ".escapeshellarg($ip)." 2>&1";
  if(function_exists('exec')){ @exec($cmd,$out,$ret); $txt=implode("\n",$out);
    if (preg_match('~ttl[=\s](\d+)~i',$txt,$m)) $ttl=(int)$m[1];
    if (preg_match('~(1 received|bytes from)~i',$txt) && !preg_match('~Unreachable|100% packet loss~i',$txt)) $alive=true;
    if ($os==='Windows' && stripos($txt,'TTL=')!==false) $alive=true;
  }
  return [$alive,$ttl];
}
function tcpBanner($ip,$port,$timeout=0.6){
  $errno=0;$err=''; $ctx=stream_context_create(['socket'=>['tcp_nodelay'=>true]]);
  $fp=@stream_socket_client("tcp://$ip:$port",$errno,$err,$timeout,STREAM_CLIENT_CONNECT,$ctx);
  if(!$fp) return [false,''];
  @stream_set_timeout($fp, (int)ceil($timeout));
  $ban='';
  if ($port==22){ $ban=@fgets($fp,1024)?:''; }
  elseif (in_array($port,[80,8080,8000,8443,443],true)) {
    @fwrite($fp,"HEAD / HTTP/1.0\r\nHost: $ip\r\nConnection: close\r\n\r\n");
    $read=@stream_get_contents($fp);
    if (is_string($read)){
      if (preg_match('~^Server:\s*(.+)$~mi',$read,$m)) $ban=trim($m[1]); else $ban=substr(trim($read),0,96);
    }
  } else {
    stream_set_blocking($fp,false); $t=@fgets($fp,256); if($t) $ban=trim($t);
  }
  @fclose($fp); return [true,$ban];
}
function guessOS($ttl,$banners){
  if ($ttl!==null){
    if ($ttl>=120 && $ttl<=130) return 'Windows (TTL~128)';
    if ($ttl>=60 && $ttl<=70)   return 'Linux/Unix (TTL~64)';
    if ($ttl>=240 && $ttl<=255) return 'Network/Cisco (TTL~255)';
  }
  $b = strtolower(implode(' | ',$banners));
  if (str_contains($b,'microsoft-iis')||str_contains($b,'rdp')||str_contains($b,'smb')) return 'Windows (bannières)';
  if (str_contains($b,'openssh')||str_contains($b,'ubuntu')||str_contains($b,'debian')||str_contains($b,'nginx')||str_contains($b,'apache')) return 'Linux/Unix (bannières)';
  if (str_contains($b,'synology')||str_contains($b,'qts')||str_contains($b,'openwrt')) return 'NAS/Appliance';
  if (str_contains($b,'routeros')||str_contains($b,'edgeos')||str_contains($b,'fortinet')) return 'Network/Appliance';
  return $ttl!==null?("Inconnu (TTL=$ttl)"):"Inconnu";
}
function reverseHost($ip){ $h=@gethostbyaddr($ip); return ($h && $h!==$ip)?$h:''; }
function udp53Probe($ip,$timeout=0.7){
  $sock=@stream_socket_client("udp://$ip:53",$errno,$errstr,$timeout);
  if(!$sock) return [false,''];
  stream_set_timeout($sock,(int)ceil($timeout));
  $id=random_int(0,65535);
  $qname = "\x07example\x03com\x00"; $qtype="\x00\x01"; $qclass="\x00\x01";
  $hdr = pack("nnnnnn",$id,0x0100,1,0,0,0); $pkt = $hdr.$qname.$qtype.$qclass;
  @fwrite($sock,$pkt); $resp=@fread($sock,512); @fclose($sock);
  if(!$resp) return [false,''];
  $rid = (ord($resp[0])<<8) + ord($resp[1]);
  $qr = (ord($resp[2])>>7)&1;
  if ($rid===$id && $qr===1) return [true,'DNS/UDP'];
  return [false,''];
}

/* ARP lecture */
function readARP(){
  $entries=[];
  // /proc/net/arp (Linux)
  if (@is_readable('/proc/net/arp')){
    $lines=file('/proc/net/arp', FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES);
    array_shift($lines);
    foreach($lines as $ln){
      $parts=preg_split('/\s+/', trim($ln));
      if(count($parts)>=6){ $entries[]=['ip'=>$parts[0],'mac'=>strtolower($parts[3])]; }
    }
  } else {
    // arp -an
    if(function_exists('exec')){
      @exec('arp -an 2>&1',$out,$ret);
      foreach($out as $ln){
        if(preg_match('~\((\d+\.\d+\.\d+\.\d+)\)\s+at\s+([0-9a-f:]{11,})~i',$ln,$m)){
          $entries[]=['ip'=>$m[1],'mac'=>strtolower($m[2])];
        }
      }
    }
  }
  // uniq par IP
  $seen=[]; $res=[];
  foreach($entries as $e){ if(isset($seen[$e['ip']])) continue; $seen[$e['ip']]=1; $res[]=$e; }
  return $res;
}

/* -------------- Actions -------------- */
$in = json_decode(file_get_contents('php://input')?:'[]', true) ?: [];
$action = $in['action'] ?? '';
$BATCH = 32;

if ($action==='save'){
  $cidrs = array_values(array_filter(array_map('trim', explode(',', $in['cidrs'] ?? ''))));
  $ports = array_values(array_filter(array_map('intval', explode(',', $in['ports'] ?? ''))));
  $cfg = readJsonSafe($cfgFile);
  $cfg['cidrs']= $cidrs ?: ["192.168.0.0/24"];
  $cfg['ports']= $ports ?: [22,80,443];
  $cfg['resolve']= !empty($in['resolve']);
  $cfg['deep']= !empty($in['deep']);
  $cfg['max_hosts']= max(16,min(65536,(int)($in['max_hosts']??4096)));
  writeJsonAtomic($cfgFile,$cfg);
  echo json_encode(['ok'=>true]); exit;
}

if ($action==='get_jobs'){
  $cfg=readJsonSafe($cfgFile);
  echo json_encode(['ok'=>true,'jobs'=>$cfg['jobs']??[]]); exit;
}

if ($action==='save_jobs'){
  $cfg=readJsonSafe($cfgFile);
  $jobs = $in['jobs'] ?? [];
  // Ajout d'ID si absent
  foreach($jobs as &$j){ if(empty($j['id'])) $j['id']=bin2hex(random_bytes(5)); $j['last_run']=$j['last_run'] ?? null; }
  $cfg['jobs']=$jobs;
  writeJsonAtomic($cfgFile,$cfg);
  echo json_encode(['ok'=>true]); exit;
}

if ($action==='run_jobs'){
  // simple déclenchement async: on marque un flag et netscan_cron.php s'en occupe
  $flag = $uDir . "netscan_run.flag";
  @file_put_contents($flag, time());
  echo json_encode(['ok'=>true,'count'=>count((readJsonSafe($cfgFile)['jobs']??[]))]); exit;
}

if ($action==='init'){
  $cfg=readJsonSafe($cfgFile);
  $cidrsRaw=trim($in['cidrs']??''); $portsRaw=trim($in['ports']??'');
  $resolve=!empty($in['resolve']); $deep=!empty($in['deep']);
  $maxHosts=max(16,min(65536,(int)($in['max_hosts']??($cfg['max_hosts']??4096))));
  $cidrs=$cidrsRaw? array_values(array_filter(array_map('trim', explode(',', $cidrsRaw)))) : ($cfg['cidrs']??["192.168.0.0/24"]);
  $ports=$portsRaw? array_values(array_filter(array_map('intval', explode(',', $portsRaw)))) : ($cfg['ports']??[22,80,443]);
  if($deep){ foreach([53,135,139,445,3389,8000,8080,8443] as $p) if(!in_array($p,$ports,true)) $ports[]=$p; }

  $targets=[]; foreach($cidrs as $c) $targets=array_merge($targets, cidrToList($c,$maxHosts));
  $targets=array_values(array_unique($targets)); if(!$targets){ echo json_encode(['ok'=>false,'error'=>'Aucune IP']); exit; }
  if(count($targets)>$maxHosts) $targets=array_slice($targets,0,$maxHosts);

  $state=['id'=>bin2hex(random_bytes(6)),'targets'=>$targets,'idx'=>0,'ports'=>$ports,'resolve'=>$resolve,'deep'=>$deep,'results'=>[],'stop'=>false,'started_at'=>time()];
  writeJsonAtomic($stateFile,$state);
  echo json_encode(['ok'=>true,'state_id'=>$state['id'],'total'=>count($targets)]); exit;
}

if ($action==='stop'){
  withLock($lockFile,function()use($stateFile){ $st=readJsonSafe($stateFile); if(!$st)return; $st['stop']=true; writeJsonAtomic($stateFile,$st); });
  echo json_encode(['ok'=>true]); exit;
}

if ($action==='status'){
  $st=readJsonSafe($stateFile);
  if(!$st){ $cfg=readJsonSafe($cfgFile); echo json_encode(['ok'=>true,'results'=>$cfg['last_results']??[],'done'=>0,'total'=>0,'found'=>count($cfg['last_results']??[]),'finished'=>true]); exit; }
  echo json_encode(['ok'=>true,'id'=>$st['id']??'','done'=>$st['idx']??0,'total'=>count($st['targets']??[]),'found'=>count($st['results']??[]),'results'=>$st['results']??[],'finished'=>(!empty($st['stop'])||(($st['idx']??0)>=count($st['targets']??[])))]); exit;
}

if ($action==='step'){
  $append=[]; $progress=0; $msg='';
  $out = withLock($lockFile,function()use($stateFile,&$append,&$progress,&$msg,$cfgFile,$histDir){
    $st=readJsonSafe($stateFile); if(!$st) return ['ok'=>false,'error'=>'État introuvable'];
    if(!empty($st['stop'])) return ['ok'=>true,'finished'=>true,'done'=>$st['idx'],'total'=>count($st['targets']),'found'=>count($st['results']),'append'=>[],'progress'=>100,'msg'=>'Arrêté'];

    $targets=$st['targets']; $idx=(int)$st['idx']; $ports=(array)$st['ports']; $resolve=!empty($st['resolve']);
    $total=count($targets); $BATCH=32; $max=min($total,$idx+$BATCH);

    for($i=$idx;$i<$max;$i++){
      $ip=$targets[$i];
      [$alive,$ttl]=pingTTL($ip);
      if(!$alive){ foreach([80,22,443] as $p){ [$ok,] = tcpBanner($ip,$p,0.25); if($ok){ $alive=true; break; } } }
      if($alive){
        $host=$resolve? reverseHost($ip):'';
        $services=[]; $details=[]; $banners=[];
        foreach($ports as $p){
          if($p===53){ [$ok,$ban]=udp53Probe($ip,0.6); if($ok){ $services[]='53/udp'; if($ban) $details['53u']=$ban; continue; } }
          [$ok,$ban]=tcpBanner($ip,$p, ($p===443||$p===3389)?0.8:0.5);
          if($ok){ $services[]="$p/tcp"; if($ban){ $details[(string)$p]=$ban; $banners[]=$ban; } }
        }
        $os=guessOS($ttl,$banners);
        $row=['ip'=>$ip,'host'=>$host,'os_guess'=>$os,'services'=>$services,'details'=>$details];
        $st['results'][]=$row; $append[]=$row;
      }
    }
    $st['idx']=$max; $progress=$total?round(($st['idx']/$total)*100,1):100; $msg="{$st['idx']}/{$total} traités, ".count($st['results'])." hôte(s)";
    writeJsonAtomic($stateFile,$st);

    $finished=($st['idx']>=$total);
    if($finished){
      $cfg=readJsonSafe($cfgFile);
      $cfg['last_results']=$st['results'];
      writeJsonAtomic($cfgFile,$cfg);
      // Historique
      $fname=$histDir."scan_".date('Ymd_His').".json";
      writeJsonAtomic($fname, ['date'=>now(),'results'=>$st['results']]);
    }
    return ['ok'=>true,'finished'=>$finished,'done'=>$st['idx'],'total'=>$total,'found'=>count($st['results']),'append'=>$append,'progress'=>$progress,'msg'=>$msg];
  });
  echo json_encode($out); exit;
}

if ($action==='arp'){
  $e=readARP(); echo json_encode(['ok'=>true,'entries'=>$e]); exit;
}

if ($action==='push_infra'){
  $cfg=readJsonSafe($cfgFile);
  $rows=$cfg['last_results']??[];
  if(!$rows){ echo json_encode(['ok'=>false,'error'=>'Pas de résultats']); exit; }
  $payload=['source'=>'netscan','when'=>date('c'),'data'=>$rows];
  $mode=$cfg['infra']['mode']??'none';

  if($mode==='filedrop'){
    $path=$cfg['infra']['filedrop_path']??'';
    if(!$path){ echo json_encode(['ok'=>false,'error'=>'filedrop sans chemin']); exit; }
    if(!is_dir($path)) @mkdir($path,0775,true);
    $fname = rtrim($path,'/')."/netscan_".date('Ymd_His').".json";
    $ok=@file_put_contents($fname, json_encode($payload,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
    echo json_encode(['ok'=> (bool)$ok,'mode'=>'filedrop','file'=>$fname]); exit;
  }
  if($mode==='webhook'){
    $url=$cfg['infra']['webhook_url']??''; $tok=$cfg['infra']['webhook_token']??'';
    if(!$url){ echo json_encode(['ok'=>false,'error'=>'webhook sans URL']); exit; }
    // POST via stream_context (pas d’ext. curl requise)
    $opts=['http'=>['method'=>'POST','header'=>"Content-Type: application/json\r\n".($tok?"Authorization: Bearer $tok\r\n":""),'content'=>json_encode($payload),'timeout'=>5]];
    $ctx=stream_context_create($opts);
    $resp=@file_get_contents($url,false,$ctx);
    $ok = $resp!==false;
    echo json_encode(['ok'=>$ok,'mode'=>'webhook']); exit;
  }
  echo json_encode(['ok'=>false,'error'=>'Mode Infra: none']); exit;
}

echo json_encode(['ok'=>false,'error'=>'Action inconnue']);
