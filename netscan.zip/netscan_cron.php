<?php
if (session_status()===PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email && isset($_GET['u'])) $email = $_GET['u'];
if (!$email){ http_response_code(403); exit('Non connecté'); }
$uDir=__DIR__."/../../users/profiles/$email/"; @mkdir($uDir,0775,true);
$cfgFile=$uDir."netscan.json"; $stateFile=$uDir."netscan_state.json"; $histDir=$uDir."netscan_history/";
@mkdir($histDir,0775,true);
function readJsonSafe($f){ if(!file_exists($f)) return []; $js=json_decode(@file_get_contents($f),true); return is_array($js)?$js:[]; }
function writeJsonAtomic($f,$a){ $t=$f.".tmp"; file_put_contents($t,json_encode($a,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)); @rename($t,$f); }
function now(){ return date('Y-m-d H:i:s'); }
$cfg=readJsonSafe($cfgFile);
$jobs=$cfg['jobs']??[]; $ran=0;
foreach($jobs as &$j){
  if(empty($j['enabled'])) continue;
  $last=strtotime($j['last_run']??'1970-01-01 00:00:00');
  $intH= max(1, (int)($j['interval_h']??24));
  if (time() >= ($last + $intH*3600)){
    $cidrs=$j['cidrs']??[]; $ports=$j['ports']??[22,80,443]; $resolve=!empty($j['resolve']); $deep=!empty($j['deep']);
    if($deep){ foreach([53,135,139,445,3389,8000,8080,8443] as $p) if(!in_array($p,$ports,true)) $ports[]=$p; }
    $maxHosts= max(16, min(65536, (int)($j['max_hosts']??4096)));
    $targets=[]; foreach($cidrs as $c){ $targets=array_merge($targets, (function($cidr,$limit){ $cidr=trim($cidr);
      if(!preg_match('~^(\d{1,3}(?:\.\d{1,3}){3})/(\d{1,2})$~',$cidr,$m)) return [];
      $ip=$m[1]; $mask=(int)$m[2]; if($mask<1||$mask>32) return [];
      $iplong=ip2long($ip); if($iplong===false) return [];
      $netmask = -1 << (32-$mask); $network=$iplong & $netmask; $broadcast=$network + ~ $netmask;
      $start=$network+1; $end=$broadcast-1; if($end<$start) return [];
      $res=[]; $cap=min($limit,65536); for($i=$start;$i<=$end;$i++){ $res[]=long2ip($i); if(count($res)>=$cap) break; } return $res;
    })($c,$maxHosts)); }
    $targets=array_values(array_unique($targets));
    if(count($targets)>$maxHosts) $targets=array_slice($targets,0,$maxHosts);
    $rows=[]; foreach($targets as $ip){
      $alive=false; foreach([80,22,443] as $p){ $fp=@fsockopen($ip,$p,$e,$s,0.25); if($fp){ fclose($fp); $alive=true; break; } }
      if(!$alive) continue;
      $host = $resolve? (@gethostbyaddr($ip)?:''):'';
      $services=[]; $details=[];
      foreach($ports as $p){
        $ok=false; $ban='';
        if($p==53){ $sock=@stream_socket_client("udp://$ip:53",$ee,$es,0.5); if($sock){ $ok=true; fclose($sock); } }
        else { $fp=@fsockopen($ip,$p,$e,$s,0.4); if($fp){ $ok=true; fclose($fp);} }
        if($ok){ $services[]=$p.($p==53?'/udp':'/tcp'); }
      }
      $rows[]=['ip'=>$ip,'host'=>$host,'os_guess'=>'','services'=>$services,'details'=>$details];
    }
    $cfg['last_results']=$rows;
    $fname=$histDir."job_".($j['id']??'unknown')."_".date('Ymd_His').".json";
    writeJsonAtomic($fname,['job'=>$j['name']??'','date'=>now(),'results'=>$rows]);
    $j['last_run']=now(); $ran++;
  }
}
$cfg['jobs']=$jobs; writeJsonAtomic($cfgFile,$cfg);
header('Content-Type: application/json'); echo json_encode(['ok'=>true,'ran'=>$ran]);
