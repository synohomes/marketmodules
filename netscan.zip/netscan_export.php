<?php
if (session_status()===PHP_SESSION_NONE) session_start();
$email=$_SESSION['user']['email']??''; if(!$email){ http_response_code(403); exit('Non connecté'); }
$uDir=__DIR__."/../../users/profiles/$email/"; $cfgFile=$uDir."netscan.json";
$fmt=strtolower($_GET['fmt']??'csv');
$cfg=file_exists($cfgFile)?(json_decode(file_get_contents($cfgFile),true)?:[]):[];
$rows=$cfg['last_results']??[];
if($fmt==='json'){
  header('Content-Type: application/json; charset=utf-8');
  header('Content-Disposition: attachment; filename="netscan_results.json"');
  echo json_encode($rows,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE); exit;
}
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="netscan_results.csv"');
$out=fopen('php://output','w'); fputcsv($out,['ip','host','os','services','details']);
foreach($rows as $r){
  $svc=implode(' ',$r['services']??[]);
  $det=json_encode($r['details']??[],JSON_UNESCAPED_UNICODE);
  fputcsv($out,[$r['ip']??'',$r['host']??'',$r['os_guess']??'',$svc,$det]);
}
fclose($out);
