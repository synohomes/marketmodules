<?php
if (session_status()===PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email){ echo "<div style='color:#f66;padding:10px'>⛔ Non connecté</div>"; return; }
$uDir = __DIR__ . "/../../users/profiles/$email/";
@mkdir($uDir,0775,true);
$cfgFile = $uDir . "netscan.json";
function readSafe($f){ if(!file_exists($f)) return []; $js=json_decode(@file_get_contents($f),true); return is_array($js)?$js:[]; }
function writeAtomic($f,$a){ $t=$f.".tmp"; file_put_contents($t,json_encode($a,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)); @rename($t,$f); }
$cfg = readSafe($cfgFile);
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_GET['module']??'')==='netscan'){
  $cidrs = array_values(array_filter(array_map('trim', explode(',', $_POST['cidrs'] ?? ''))));
  $ports = array_values(array_filter(array_map('intval', explode(',', $_POST['ports'] ?? ''))));
  $cfg['cidrs']   = $cidrs ?: ["192.168.0.0/24"];
  $cfg['ports']   = $ports ?: [22,80,443];
  $cfg['resolve'] = isset($_POST['resolve']);
  $cfg['deep']    = isset($_POST['deep']);
  $cfg['max_hosts'] = max(16,min(65536,(int)($_POST['max_hosts'] ?? 4096)));
  $cfg['infra']['mode'] = $_POST['infra_mode'] ?? 'none'; // none|filedrop|webhook
  $cfg['infra']['filedrop_path'] = trim($_POST['infra_filedrop'] ?? '');
  $cfg['infra']['webhook_url']   = trim($_POST['infra_url'] ?? '');
  $cfg['infra']['webhook_token'] = trim($_POST['infra_token'] ?? '');
  writeAtomic($cfgFile,$cfg);
  echo "<div style='color:#8f8;padding:10px'>✅ Enregistré.</div>";
}
$cidrsDef = implode(', ', $cfg['cidrs'] ?? ["192.168.0.0/24"]);
$portsDef = implode(',', $cfg['ports'] ?? [22,80,443]);
$resolve  = !isset($cfg['resolve']) || $cfg['resolve'];
$deep     = isset($cfg['deep']) ? (bool)$cfg['deep'] : true;
$maxHosts = $cfg['max_hosts'] ?? 4096;
$infra    = $cfg['infra'] ?? ['mode'=>'none'];
?>
<div class="section">
  <h2>Netscan – Configuration</h2>
  <form method="post" action="?module=netscan">
    <label>Sous-réseaux par défaut (CIDR, virgules)</label>
    <input type="text" name="cidrs" value="<?=htmlspecialchars($cidrsDef,ENT_QUOTES)?>" style="width:100%;padding:10px;margin:6px 0">
    <label>Ports par défaut (ex: 22,80,443)</label>
    <input type="text" name="ports" value="<?=htmlspecialchars($portsDef,ENT_QUOTES)?>" style="width:100%;padding:10px;margin:6px 0">
    <div style="display:flex;gap:14px;align-items:center;margin:8px 0">
      <label><input type="checkbox" name="resolve" <?=$resolve?'checked':'';?>> Résolution DNS</label>
      <label><input type="checkbox" name="deep" <?=$deep?'checked':'';?>> Scan approfondi</label>
    </div>
    <label>Limite d'hôtes</label>
    <input type="number" name="max_hosts" min="16" max="65536" value="<?=intval($maxHosts)?>" style="width:160px;padding:8px;margin:6px 0">
    <h3>Intégration “Infra”</h3>
    <p style="opacity:.8">Sans toucher au code d’Infra. Choisis le mode d’envoi :</p>
    <label>Mode</label>
    <select name="infra_mode" style="padding:8px">
      <?php foreach (['none'=>'Aucun','filedrop'=>'Dépôt de fichier','webhook'=>'Webhook HTTP(S)'] as $k=>$v): ?>
        <option value="<?=$k?>" <?=($infra['mode']??'none')===$k?'selected':'';?>><?=$v?></option>
      <?php endforeach; ?>
    </select>
    <div style="margin-top:8px">
      <label>Chemin dépôt (filedrop)</label>
      <input type="text" name="infra_filedrop" value="<?=htmlspecialchars($infra['filedrop_path']??'',ENT_QUOTES)?>" style="width:100%;padding:8px">
    </div>
    <div style="margin-top:8px">
      <label>URL Webhook (Infra)</label>
      <input type="text" name="infra_url" value="<?=htmlspecialchars($infra['webhook_url']??'',ENT_QUOTES)?>" style="width:100%;padding:8px">
      <label>Token Bearer</label>
      <input type="text" name="infra_token" value="<?=htmlspecialchars($infra['webhook_token']??'',ENT_QUOTES)?>" style="width:100%;padding:8px">
    </div>
    <div style="margin-top:10px"><button type="submit">Enregistrer</button></div>
  </form>
</div>
