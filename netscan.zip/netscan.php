<?php
if (session_status()===PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { echo "<div style='color:#f66;padding:10px'>⛔ Non connecté</div>"; return; }
$uDir = __DIR__ . "/../../users/profiles/$email/";
@mkdir($uDir, 0775, true);
$cfgFile = $uDir . "netscan.json";
function readJsonSafe($f){ if(!file_exists($f)) return []; $js=json_decode(@file_get_contents($f),true); return is_array($js)?$js:[]; }
$cfg = readJsonSafe($cfgFile);
$cidrsDef   = $cfg['cidrs'] ?? ["192.168.0.0/24"];
$portsDef   = $cfg['ports'] ?? [22,80,443];
$resolveDef = isset($cfg['resolve']) ? (bool)$cfg['resolve'] : true;
$deepDef    = isset($cfg['deep']) ? (bool)$cfg['deep'] : true; // V3: par défaut ON
$limitDef   = isset($cfg['max_hosts']) ? (int)$cfg['max_hosts'] : 4096;
$lastResults= $cfg['last_results'] ?? [];
$infraMode  = $cfg['infra']['mode'] ?? 'none'; // none|filedrop|webhook
$infraPath  = $cfg['infra']['filedrop_path'] ?? '';
$infraURL   = $cfg['infra']['webhook_url'] ?? '';
$infraTok   = $cfg['infra']['webhook_token'] ?? '';
$jobs = $cfg['jobs'] ?? []; // [{id,name,cidrs,ports,resolve,deep,max_hosts,interval_h,last_run,enabled}]
function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
?>
<style>
.netscan { color:#ddd; font-family:system-ui,Segoe UI,Roboto,Arial,sans-serif; }
.netscan .row { display:flex; gap:10px; flex-wrap:wrap; margin:8px 0; }
.netscan .row>*{ flex:1 1 auto; min-width:180px; }
.netscan input[type=text], .netscan input[type=number] { background:#111; border:1px solid #333; color:#ddd; border-radius:8px; padding:10px; }
.netscan .chk { display:flex; align-items:center; gap:8px; }
.netscan button { border:0; border-radius:10px; padding:10px 14px; cursor:pointer; background:var(--primary-dark,#2a4861); color:#fff; font-weight:600; }
.netscan .ghost { background:#1c1c1c; border:1px solid #333; color:#aaa; }
.netscan .bar { height:10px; background:#1b1b1b; border:1px solid #333; border-radius:999px; overflow:hidden; }
.netscan .bar>span { display:block; height:100%; width:0%; background:var(--primary-color,#4B0082); }
.netscan table { width:100%; border-collapse:collapse; margin-top:10px; }
.netscan th, .netscan td { border-bottom:1px solid #333; padding:8px 10px; text-align:left; font-size:14px; }
.netscan .badge { display:inline-block; border:1px solid #444; border-radius:999px; padding:2px 8px; margin:2px 4px 0 0; font-size:12px; }
.netscan .pill { display:inline-block; background:#171717; border:1px solid #333; border-radius:8px; padding:4px 8px; margin:2px 6px 0 0; font-size:12px; }
.netscan .card { border:1px solid #2a2a2a; background:#121212; border-radius:12px; padding:12px; }
.netscan .title { font-weight:700; opacity:.9; }
.netscan .right { display:flex; gap:8px; align-items:center; justify-content:flex-end; flex:1 1 auto; }
.netscan .search { max-width:280px; }
</style>
<div class="netscan">
  <div class="row card">
    <div class="title">Scan manuel</div>
    <input id="cidrs" type="text" placeholder="CIDR: 192.168.0.0/24, 192.168.1.0/24" value="<?=e(implode(', ',(array)$cidrsDef))?>">
    <input id="ports" type="text" placeholder="Ports (ex: 22,80,443)" value="<?=e(implode(',',(array)$portsDef))?>">
    <input id="limit" type="number" min="16" max="65536" value="<?=e($limitDef)?>" title="Limite d'hôtes">
    <label class="chk"><input id="resolve" type="checkbox" <?=$resolveDef?'checked':''?>> Reverse DNS</label>
    <label class="chk"><input id="deep" type="checkbox" <?=$deepDef?'checked':''?>> Scan approfondi</label>
    <div class="right">
      <button id="save">Enregistrer par défaut</button>
      <button id="start">Scanner</button>
      <button id="stop" class="ghost">Stop</button>
      <button id="arp" class="ghost" title="Lecture ARP locale">ARP</button>
      <button id="exportCsv" class="ghost">CSV</button>
      <button id="exportJson" class="ghost">JSON</button>
      <button id="exportPdf" class="ghost">PDF</button>
      <button id="pushInfra" class="ghost" title="Envoyer à Infra">Envoyer à Infra</button>
    </div>
  </div>
  <div class="row">
    <div class="bar" style="flex:3"><span id="prog"></span></div>
    <div id="st" style="flex:2; font-size:12px; opacity:.85">Prêt.</div>
    <input class="search" id="filter" type="text" placeholder="Filtrer (IP, nom, service)">
  </div>
  <div id="results">
    <?php if ($lastResults): ?>
      <table>
        <thead><tr><th>IP</th><th>Nom</th><th>OS</th><th>Services</th><th>Détails</th></tr></thead>
        <tbody>
          <?php foreach ($lastResults as $r): ?>
            <tr data-row="1">
              <td><?=e($r['ip']??'')?></td>
              <td><?=e($r['host']??'')?></td>
              <td><?=e($r['os_guess']??'')?></td>
              <td><?php foreach(($r['services']??[]) as $s) echo '<span class="badge">'.e($s).'</span>'; ?></td>
              <td><?php foreach(($r['details']??[]) as $k=>$v){ if($v==='') continue; echo '<span class="pill"><b>'.e($k).':</b> '.e(is_string($v)?$v:json_encode($v,JSON_UNESCAPED_UNICODE)).'</span>'; } ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php else: ?>
      <div class="card">Aucun résultat encore. Lance un scan.</div>
    <?php endif; ?>
  </div>
  <div class="row card">
    <div class="title">Planification (jobs)</div>
    <div style="font-size:12px;opacity:.8">Utilise aussi <code>modules/netscan/netscan_cron.php</code> (URL cron) pour exécuter automatiquement les jobs.</div>
    <div class="row" id="jobs"></div>
    <div class="row">
      <button id="addJob">+ Nouveau job</button>
      <button id="saveJobs" class="ghost">Enregistrer les jobs</button>
      <button id="runJobs" class="ghost" title="Exécution immédiate via cron local">Exécuter maintenant</button>
    </div>
  </div>
  <div class="row card">
    <div class="title">Infra (intégration)</div>
    <div>Mode: <b><?=e($infraMode)?></b>
      <?php if($infraMode==='filedrop'): ?> — Dossier: <code><?=e($infraPath)?></code><?php endif; ?>
      <?php if($infraMode==='webhook'): ?> — URL: <code><?=e($infraURL)?></code><?php endif; ?>
    </div>
  </div>
</div>
<script>
(()=> {
  const api='modules/netscan/netscan_scan.php';
  const st=document.getElementById('st'), prog=document.getElementById('prog'), res=document.getElementById('results');
  const fCid=document.getElementById('cidrs'), fPor=document.getElementById('ports'), fRes=document.getElementById('resolve'), fDeep=document.getElementById('deep'), fLim=document.getElementById('limit');
  const btnS=document.getElementById('start'), btnP=document.getElementById('stop'), btnV=document.getElementById('save');
  const btnCsv=document.getElementById('exportCsv'), btnJson=document.getElementById('exportJson'), btnPdf=document.getElementById('exportPdf'), btnInfra=document.getElementById('pushInfra');
  const btnArp=document.getElementById('arp');
  const fFilter=document.getElementById('filter');

  const jobsWrap=document.getElementById('jobs');
  const btnAddJob=document.getElementById('addJob'), btnSaveJobs=document.getElementById('saveJobs'), btnRunJobs=document.getElementById('runJobs');

  let running=false, stateId=null;
  function setProgress(p){ prog.style.width=Math.max(0,Math.min(100,p))+'%'; }
  function setStatus(t){ st.textContent=t; }
  function escapeHtml(s){ return (s??'').toString().replace(/[&<>"]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }
  function renderTable(rows){
    let html = `<table><thead><tr><th>IP</th><th>Nom</th><th>OS</th><th>Services</th><th>Détails</th></tr></thead><tbody>`;
    for (const r of rows){
      const svc=(r.services||[]).map(s=>`<span class="badge">${escapeHtml(s)}</span>`).join('');
      const det=Object.entries(r.details||{}).filter(([k,v])=>v!=='').map(([k,v])=>`<span class="pill"><b>${escapeHtml(k)}:</b> ${escapeHtml(typeof v==='string'?v:JSON.stringify(v))}</span>`).join('');
      html+=`<tr data-row="1"><td>${escapeHtml(r.ip||'')}</td><td>${escapeHtml(r.host||'')}</td><td>${escapeHtml(r.os_guess||'')}</td><td>${svc}</td><td>${det}</td></tr>`;
    }
    html+=`</tbody></table>`; res.innerHTML=html; applyFilter();
  }

  async function call(action, body={}) {
    const r=await fetch(api,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,...body})});
    return r.json();
  }

  btnV.addEventListener('click', async ()=>{
    const js = await call('save',{cidrs:fCid.value,ports:fPor.value,resolve:fRes.checked,deep:fDeep.checked,max_hosts:+fLim.value});
    setStatus(js.ok?'Paramètres enregistrés.':('Erreur: '+(js.error||'')));
  });

  btnS.addEventListener('click', async ()=>{
    if(running) return;
    setProgress(0); setStatus('Préparation…');
    const init=await call('init',{cidrs:fCid.value,ports:fPor.value,resolve:fRes.checked,deep:fDeep.checked,max_hosts:+fLim.value});
    if(!init.ok){ setStatus('Erreur: '+(init.error||'')); return; }
    stateId=init.state_id; running=true; btnS.disabled=true;
    (async function loop(){
      while(running){
        const step=await call('step',{state_id:stateId});
        if(!step.ok){ setStatus('Erreur: '+(step.error||'')); running=false; break; }
        setProgress(step.progress||0);
        setStatus(step.msg||(`${step.done}/${step.total} traités, ${step.found} hôte(s)`));
        if(step.append && step.append.length){
          const full=await call('status',{state_id:stateId});
          if(full.ok) renderTable(full.results||[]);
        }
        if(step.finished){ running=false; break; }
      }
      btnS.disabled=false;
      const fin=await call('status',{state_id:stateId});
      if(fin.ok){ renderTable(fin.results||[]); setProgress(100); setStatus(`Terminé: ${fin.results?.length||0} hôte(s)`); }
    })();
  });

  btnP.addEventListener('click', async ()=>{ if(!stateId) return; await call('stop',{state_id:stateId}); running=false; setStatus('Arrêt demandé.'); });

  btnCsv.addEventListener('click', ()=> window.open('modules/netscan/netscan_export.php?fmt=csv','_blank'));
  btnJson.addEventListener('click',()=> window.open('modules/netscan/netscan_export.php?fmt=json','_blank'));
  btnPdf.addEventListener('click', ()=> window.open('modules/netscan/netscan_export_pdf.php','_blank'));
  btnInfra.addEventListener('click', async ()=>{
    const js = await call('push_infra', {});
    setStatus(js.ok ? ('Envoyé à Infra: '+(js.mode||'?')) : ('Erreur Infra: '+(js.error||'')));
  });

  btnArp.addEventListener('click', async ()=>{
    const js = await call('arp', {});
    if(js.ok && Array.isArray(js.entries)){
      // on remplit un petit tableau rapide
      const rows = (js.entries||[]).map(a=>({ip:a.ip,host:'',os_guess:'',services:[],details:{mac:a.mac||''}}));
      renderTable(rows);
      setStatus(`ARP: ${rows.length} entrée(s) trouvée(s)`);
    } else setStatus('ARP indisponible.');
  });

  // --- Jobs UI ---
  function jobRow(j,i){
    return `
      <div class="row" data-i="${i}">
        <input class="jname"  type="text" placeholder="Nom du job" value="${escapeHtml(j.name||'Job '+(i+1))}">
        <input class="jcidrs" type="text" placeholder="CIDR(s)" value="${escapeHtml((j.cidrs||[]).join(', '))}">
        <input class="jports" type="text" placeholder="Ports" value="${escapeHtml((j.ports||[]).join(','))}">
        <input class="jlim"   type="number" min="16" max="65536" value="${escapeHtml(j.max_hosts||4096)}" style="max-width:120px">
        <input class="jint"   type="number" min="1"  max="168" value="${escapeHtml(j.interval_h||24)}" title="Intervalle (heures)" style="max-width:120px">
        <label class="chk"><input class="jres" type="checkbox" ${j.resolve?'checked':''}>DNS</label>
        <label class="chk"><input class="jdeep"type="checkbox" ${j.deep?'checked':''}>Deep</label>
        <label class="chk"><input class="jen"  type="checkbox" ${j.enabled?'checked':''}>Actif</label>
        <button class="ghost jdel" type="button">Suppr</button>
      </div>`;
  }
  function loadJobs(){
    call('get_jobs',{}).then(js=>{
      jobsWrap.innerHTML='';
      const arr = js.jobs||[];
      arr.forEach((j,i)=> jobsWrap.insertAdjacentHTML('beforeend', jobRow(j,i)));
      jobsWrap.querySelectorAll('.jdel').forEach((b,idx)=> b.addEventListener('click',()=>{ b.parentElement.remove(); }));
    });
  }
  loadJobs();

  btnAddJob.addEventListener('click', ()=> {
    const i = jobsWrap.querySelectorAll('.row').length;
    jobsWrap.insertAdjacentHTML('beforeend', jobRow({name:'Job '+(i+1),cidrs:[],ports:[22,80,443],resolve:true,deep:true,max_hosts:4096,interval_h:24,enabled:true}, i));
  });

  btnSaveJobs.addEventListener('click', async ()=>{
    const rows = [...jobsWrap.querySelectorAll('.row')];
    const jobs = rows.map(r=>({
      name:r.querySelector('.jname').value.trim(),
      cidrs:r.querySelector('.jcidrs').value.split(',').map(s=>s.trim()).filter(Boolean),
      ports:r.querySelector('.jports').value.split(',').map(s=>parseInt(s.trim(),10)).filter(n=>!isNaN(n)),
      max_hosts:parseInt(r.querySelector('.jlim').value,10)||4096,
      interval_h:parseInt(r.querySelector('.jint').value,10)||24,
      resolve:r.querySelector('.jres').checked,
      deep:r.querySelector('.jdeep').checked,
      enabled:r.querySelector('.jen').checked
    }));
    const js = await call('save_jobs',{jobs});
    setStatus(js.ok?'Jobs enregistrés.':('Erreur: '+(js.error||'')));
  });

  btnRunJobs.addEventListener('click', async ()=>{
    const js = await call('run_jobs',{});
    setStatus(js.ok?('Jobs déclenchés: '+(js.count||0)):('Erreur: '+(js.error||'')));
  });

  // Filtre
  fFilter.addEventListener('input', applyFilter);
  function applyFilter(){
    const q=fFilter.value.trim().toLowerCase();
    const rows=res.querySelectorAll('tbody tr[data-row]');
    rows.forEach(tr=> tr.style.display = (!q || tr.textContent.toLowerCase().includes(q)) ? '' : 'none');
  }
})();
</script>
