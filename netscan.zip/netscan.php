<?php
if (session_status()===PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { echo "<div class='netscan-error'>⛔ Non connecté</div>"; return; }
$uDir = __DIR__ . "/../../users/profiles/$email/";
@mkdir($uDir, 0775, true);
$cfgFile = $uDir . "netscan.json";
function readJsonSafe($f){ if(!file_exists($f)) return []; $js=json_decode(@file_get_contents($f),true); return is_array($js)?$js:[]; }
$cfg = readJsonSafe($cfgFile);
$cidrsDef   = $cfg['cidrs'] ?? ["192.168.0.0/24"];
$portsDef   = $cfg['ports'] ?? [22,80,443];
$resolveDef = isset($cfg['resolve']) ? (bool)$cfg['resolve'] : true;
$deepDef    = isset($cfg['deep']) ? (bool)$cfg['deep'] : true;
$limitDef   = isset($cfg['max_hosts']) ? (int)$cfg['max_hosts'] : 4096;
$lastResults= $cfg['last_results'] ?? [];
$infraMode  = $cfg['infra']['mode'] ?? 'none';
$infraPath  = $cfg['infra']['filedrop_path'] ?? '';
$infraURL   = $cfg['infra']['webhook_url'] ?? '';
$jobs = $cfg['jobs'] ?? [];
function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
$cssVersion = @filemtime(__DIR__ . '/netscan.css') ?: time();
?>
<link rel="stylesheet" href="modules/netscan/netscan.css?v=<?=e($cssVersion)?>">

<div class="netscan" data-netscan-root>
  <div class="netscan__head">
    <div class="netscan__brand">
      <span class="netscan__tag">Netscan</span>
      <h3 class="netscan__title">Scanner réseau</h3>
    </div>
    <button type="button" class="netscan__count" id="nsOpenCount" title="Afficher les résultats">
      <strong id="nsCount"><?=count($lastResults)?></strong>
      <span>hôtes</span>
    </button>
  </div>

  <div class="netscan__panel">
    <div class="netscan__form">
      <div class="netscan__field">
        <label for="cidrs">CIDR</label>
        <input id="cidrs" type="text" placeholder="192.168.0.0/24, 192.168.1.0/24" value="<?=e(implode(', ',(array)$cidrsDef))?>">
      </div>
      <div class="netscan__field">
        <label for="ports">Ports</label>
        <input id="ports" type="text" placeholder="22,80,443" value="<?=e(implode(',',(array)$portsDef))?>">
      </div>
      <div class="netscan__field">
        <label for="limit">Limite hôtes</label>
        <input id="limit" type="number" min="16" max="65536" value="<?=e($limitDef)?>">
      </div>
      <div class="netscan__checks">
        <label class="netscan__check"><input id="resolve" type="checkbox" <?=$resolveDef?'checked':''?>><span>Reverse DNS</span></label>
        <label class="netscan__check"><input id="deep" type="checkbox" <?=$deepDef?'checked':''?>><span>Scan approfondi</span></label>
      </div>
      <div class="netscan__actions">
        <div class="netscan__actions-left">
          <button id="save" type="button">Enregistrer</button>
          <button id="start" type="button" class="netscan__primary">Scanner</button>
          <button id="stop" type="button">Stop</button>
          <button id="arp" type="button" title="Lecture ARP locale">ARP</button>
        </div>
        <div class="netscan__actions-right">
          <button id="exportCsv" type="button">CSV</button>
          <button id="exportJson" type="button">JSON</button>
          <button id="exportPdf" type="button">PDF</button>
          <button id="pushInfra" type="button" title="Envoyer à Infra">Infra</button>
        </div>
      </div>
    </div>
  </div>

  <div class="netscan__status">
    <div class="netscan__bar"><span id="prog"></span></div>
    <div id="st" class="netscan__message">Prêt.</div>
    <input id="filter" type="text" placeholder="Filtrer les résultats">
  </div>

  <div id="results" class="netscan__results" role="button" tabindex="0" title="Ouvrir les résultats dans une fenêtre">
    <div class="netscan__results-top">
      <div class="netscan__results-title">
        <strong>Résultats détectés</strong>
        <span id="nsResultHint">Clique pour afficher IP, ports, OS et détails.</span>
      </div>
      <span class="netscan__open">Ouvrir</span>
    </div>
    <div class="netscan__chips" id="nsPreview">
      <?php if ($lastResults): ?>
        <?php foreach (array_slice($lastResults, 0, 12) as $r): ?>
          <span class="netscan__chip"><?=e($r['ip'] ?? '')?></span>
        <?php endforeach; ?>
        <?php if (count($lastResults) > 12): ?><span class="netscan__chip">+<?=count($lastResults)-12?></span><?php endif; ?>
      <?php else: ?>
        <span class="netscan__empty">Aucun résultat. Lance un scan.</span>
      <?php endif; ?>
    </div>
  </div>

  <div class="netscan__bottom">
    <details>
      <summary><span>Planification</span><span class="netscan__summary-note">jobs automatiques</span></summary>
      <div class="netscan__details-body">
        <div>Utilise <code>modules/netscan/netscan_cron.php</code> pour l'exécution automatique.</div>
        <div class="netscan__jobs" id="jobs"></div>
        <div class="netscan__actions-left">
          <button id="addJob" type="button">+ Nouveau job</button>
          <button id="saveJobs" type="button">Enregistrer les jobs</button>
          <button id="runJobs" type="button">Exécuter maintenant</button>
        </div>
      </div>
    </details>
    <details>
      <summary><span>Infra</span><span class="netscan__summary-note">mode : <?=e($infraMode)?></span></summary>
      <div class="netscan__details-body">
        <?php if($infraMode==='filedrop'): ?>Dossier : <code><?=e($infraPath)?></code><?php elseif($infraMode==='webhook'): ?>URL : <code><?=e($infraURL)?></code><?php else: ?>Aucune intégration active.<?php endif; ?>
      </div>
    </details>
  </div>
</div>

<script>
(()=> {
  const root = document.currentScript.previousElementSibling;
  const api='modules/netscan/netscan_scan.php';
  const st=document.getElementById('st'), prog=document.getElementById('prog');
  const fCid=document.getElementById('cidrs'), fPor=document.getElementById('ports'), fRes=document.getElementById('resolve'), fDeep=document.getElementById('deep'), fLim=document.getElementById('limit');
  const btnS=document.getElementById('start'), btnP=document.getElementById('stop'), btnV=document.getElementById('save');
  const btnCsv=document.getElementById('exportCsv'), btnJson=document.getElementById('exportJson'), btnPdf=document.getElementById('exportPdf'), btnInfra=document.getElementById('pushInfra');
  const btnArp=document.getElementById('arp');
  const fFilter=document.getElementById('filter');
  const nsCount=document.getElementById('nsCount');
  const nsOpenCount=document.getElementById('nsOpenCount');
  const results=document.getElementById('results');
  const nsPreview=document.getElementById('nsPreview');
  const jobsWrap=document.getElementById('jobs');
  const btnAddJob=document.getElementById('addJob'), btnSaveJobs=document.getElementById('saveJobs'), btnRunJobs=document.getElementById('runJobs');

  let running=false, stateId=null, zIndex=100000;
  let currentRows = <?=json_encode(array_values($lastResults), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)?>;

  function setProgress(p){ prog.style.width=Math.max(0,Math.min(100,p))+'%'; }
  function setStatus(t){ st.textContent=t; }
  function escapeHtml(s){ return (s??'').toString().replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }
  function detailsUptime(r){
    const d = r.details || {};
    return d.uptime || d.Uptime || d['temps de fonctionnement'] || d['uptime_seconds'] || r.uptime || 'Non disponible';
  }
  function detailsHtml(details){
    const entries = Object.entries(details || {}).filter(([k,v]) => v !== '' && v !== null && typeof v !== 'undefined');
    if(!entries.length) return '<span class="netscan__pill">Aucun détail</span>';
    return entries.map(([k,v])=>`<span class="netscan__pill"><b>${escapeHtml(k)}:</b> ${escapeHtml(typeof v === 'string' ? v : JSON.stringify(v))}</span>`).join('');
  }
  function servicesHtml(services){
    const arr = services || [];
    if(!arr.length) return '<span class="netscan__badge">Aucun</span>';
    return arr.map(s=>`<span class="netscan__badge">${escapeHtml(s)}</span>`).join('');
  }
  function renderPreview(rows){
    const shown = Array.isArray(rows) ? rows : [];
    nsCount.textContent = currentRows.length;
    if(!shown.length){
      nsPreview.innerHTML = currentRows.length ? '<span class="netscan__empty">Aucun résultat pour ce filtre.</span>' : '<span class="netscan__empty">Aucun résultat. Lance un scan.</span>';
      return;
    }
    const chips = shown.slice(0, 12).map(r => `<span class="netscan__chip">${escapeHtml(r.ip || '')}</span>`).join('');
    const more = shown.length > 12 ? `<span class="netscan__chip">+${shown.length - 12}</span>` : '';
    nsPreview.innerHTML = chips + more;
  }
  function updatePreview(rows){
    currentRows = Array.isArray(rows) ? rows : [];
    renderPreview(filteredRows());
  }
  function filteredRows(){
    const q = (fFilter.value || '').trim().toLowerCase();
    if(!q) return currentRows;
    return currentRows.filter(r => JSON.stringify(r).toLowerCase().includes(q));
  }
  function renderRowsTable(rows){
    if(!rows.length) return '<div class="netscan__empty">Aucun résultat à afficher.</div>';
    return `<table class="netscan__table">
      <thead><tr><th>IP</th><th>Nom</th><th>OS</th><th>Uptime</th><th>Ports / services</th><th>Détails</th></tr></thead>
      <tbody>${rows.map(r=>`<tr>
        <td>${escapeHtml(r.ip || '')}</td>
        <td>${escapeHtml(r.host || '')}</td>
        <td>${escapeHtml(r.os_guess || 'Inconnu')}</td>
        <td>${escapeHtml(detailsUptime(r))}</td>
        <td>${servicesHtml(r.services)}</td>
        <td>${detailsHtml(r.details)}</td>
      </tr>`).join('')}</tbody>
    </table>`;
  }
  function bringToFront(win){ win.style.zIndex = ++zIndex; }
  function makeDraggable(win){
    const head = win.querySelector('.netscan__modal-head');
    let active=false, sx=0, sy=0, sl=0, stp=0;
    head.addEventListener('pointerdown', e=>{
      if(e.target.closest('button')) return;
      active=true; bringToFront(win); sx=e.clientX; sy=e.clientY; sl=win.offsetLeft; stp=win.offsetTop;
      head.setPointerCapture(e.pointerId);
    });
    head.addEventListener('pointermove', e=>{
      if(!active) return;
      const nx = Math.max(0, Math.min(window.innerWidth - 60, sl + e.clientX - sx));
      const ny = Math.max(0, Math.min(window.innerHeight - 42, stp + e.clientY - sy));
      win.style.left = nx + 'px'; win.style.top = ny + 'px';
    });
    head.addEventListener('pointerup', e=>{ active=false; try{head.releasePointerCapture(e.pointerId);}catch(_){} });
  }
  function openResultsWindow(){
    const rows = filteredRows();
    const win = document.createElement('div');
    win.className = 'netscan__modal';
    const offset = (document.querySelectorAll('.netscan__modal').length % 5) * 22;
    win.style.left = `calc(50vw - 490px + ${offset}px)`;
    win.style.top = `calc(50vh - 310px + ${offset}px)`;
    win.innerHTML = `
      <div class="netscan__modal-head">
        <div class="netscan__modal-title">Netscan — ${rows.length} hôte(s)</div>
        <div class="netscan__modal-tools">
          <button type="button" data-min>−</button>
          <button type="button" data-close>×</button>
        </div>
      </div>
      <div class="netscan__modal-body">
        <div class="netscan__modal-filters">
          <input type="text" placeholder="Filtrer dans cette fenêtre" data-filter>
          <button type="button" data-refresh>Actualiser</button>
        </div>
        <div data-table>${renderRowsTable(rows)}</div>
      </div>`;
    document.body.appendChild(win);
    bringToFront(win);
    makeDraggable(win);
    win.addEventListener('pointerdown', ()=>bringToFront(win));
    win.querySelector('[data-close]').addEventListener('click', ()=>win.remove());
    win.querySelector('[data-min]').addEventListener('click', ()=>win.classList.toggle('is-minimized'));
    const localFilter = win.querySelector('[data-filter]');
    const table = win.querySelector('[data-table]');
    function redraw(){
      const q = localFilter.value.trim().toLowerCase();
      const base = filteredRows();
      const shown = q ? base.filter(r=>JSON.stringify(r).toLowerCase().includes(q)) : base;
      win.querySelector('.netscan__modal-title').textContent = `Netscan — ${shown.length} hôte(s)`;
      table.innerHTML = renderRowsTable(shown);
    }
    localFilter.addEventListener('input', redraw);
    win.querySelector('[data-refresh]').addEventListener('click', redraw);
  }
  async function call(action, body={}) {
    const r=await fetch(api,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,...body})});
    return r.json();
  }

  btnV.addEventListener('click', async ()=>{
    const js = await call('save',{cidrs:fCid.value,ports:fPor.value,resolve:fRes.checked,deep:fDeep.checked,max_hosts:+fLim.value});
    setStatus(js.ok?'Paramètres enregistrés.':('Erreur: '+(js.error||'')));
  });

  btnS.addEventListener('click', async ()=>{
    if(running) return;
    setProgress(0); setStatus('Préparation…');
    const init=await call('init',{cidrs:fCid.value,ports:fPor.value,resolve:fRes.checked,deep:fDeep.checked,max_hosts:+fLim.value});
    if(!init.ok){ setStatus('Erreur: '+(init.error||'')); return; }
    stateId=init.state_id; running=true; btnS.disabled=true;
    (async function loop(){
      while(running){
        const step=await call('step',{state_id:stateId});
        if(!step.ok){ setStatus('Erreur: '+(step.error||'')); running=false; break; }
        setProgress(step.progress||0);
        setStatus(step.msg||(`${step.done}/${step.total} traités, ${step.found} hôte(s)`));
        if(step.append && step.append.length){
          const full=await call('status',{state_id:stateId});
          if(full.ok) updatePreview(full.results||[]);
        }
        if(step.finished){ running=false; break; }
      }
      btnS.disabled=false;
      const fin=await call('status',{state_id:stateId});
      if(fin.ok){ updatePreview(fin.results||[]); setProgress(100); setStatus(`Terminé : ${fin.results?.length||0} hôte(s)`); }
    })();
  });

  btnP.addEventListener('click', async ()=>{ if(!stateId) return; await call('stop',{state_id:stateId}); running=false; setStatus('Arrêt demandé.'); });
  btnCsv.addEventListener('click', ()=> window.open('modules/netscan/netscan_export.php?fmt=csv','_blank'));
  btnJson.addEventListener('click',()=> window.open('modules/netscan/netscan_export.php?fmt=json','_blank'));
  btnPdf.addEventListener('click', ()=> window.open('modules/netscan/netscan_export_pdf.php','_blank'));
  btnInfra.addEventListener('click', async ()=>{
    const js = await call('push_infra', {});
    setStatus(js.ok ? ('Envoyé à Infra : '+(js.mode||'?')) : ('Erreur Infra : '+(js.error||'')));
  });
  btnArp.addEventListener('click', async ()=>{
    const js = await call('arp', {});
    if(js.ok && Array.isArray(js.entries)){
      const rows = (js.entries||[]).map(a=>({ip:a.ip,host:'',os_guess:'',services:[],details:{mac:a.mac||''}}));
      updatePreview(rows);
      setStatus(`ARP : ${rows.length} entrée(s) trouvée(s)`);
    } else setStatus('ARP indisponible.');
  });

  results.addEventListener('click', openResultsWindow);
  results.addEventListener('keydown', e=>{ if(e.key === 'Enter' || e.key === ' ') openResultsWindow(); });
  nsOpenCount.addEventListener('click', openResultsWindow);
  fFilter.addEventListener('input', ()=>renderPreview(filteredRows()));

  function jobRow(j,i){
    return `<div class="netscan__job" data-i="${i}">
      <div><label>Nom</label><input class="jname" type="text" value="${escapeHtml(j.name||'Job '+(i+1))}"></div>
      <div><label>CIDR</label><input class="jcidrs" type="text" value="${escapeHtml((j.cidrs||[]).join(', '))}"></div>
      <div><label>Ports</label><input class="jports" type="text" value="${escapeHtml((j.ports||[]).join(','))}"></div>
      <div><label>Limite</label><input class="jlim" type="number" min="16" max="65536" value="${escapeHtml(j.max_hosts||4096)}"></div>
      <div><label>Heures</label><input class="jint" type="number" min="1" max="168" value="${escapeHtml(j.interval_h||24)}"></div>
      <label class="netscan__check"><input class="jres" type="checkbox" ${j.resolve?'checked':''}><span>DNS</span></label>
      <label class="netscan__check"><input class="jdeep" type="checkbox" ${j.deep?'checked':''}><span>Deep</span></label>
      <label class="netscan__check"><input class="jen" type="checkbox" ${j.enabled?'checked':''}><span>Actif</span></label>
      <button class="jdel" type="button">Suppr</button>
    </div>`;
  }
  function bindJobDeletes(){ jobsWrap.querySelectorAll('.jdel').forEach(b=> b.onclick = ()=>b.closest('.netscan__job').remove()); }
  function loadJobs(){
    call('get_jobs',{}).then(js=>{
      jobsWrap.innerHTML='';
      (js.jobs||[]).forEach((j,i)=> jobsWrap.insertAdjacentHTML('beforeend', jobRow(j,i)));
      bindJobDeletes();
    });
  }
  loadJobs();
  btnAddJob.addEventListener('click', ()=> {
    const i = jobsWrap.querySelectorAll('.netscan__job').length;
    jobsWrap.insertAdjacentHTML('beforeend', jobRow({name:'Job '+(i+1),cidrs:[],ports:[22,80,443],resolve:true,deep:true,max_hosts:4096,interval_h:24,enabled:true}, i));
    bindJobDeletes();
  });
  btnSaveJobs.addEventListener('click', async ()=>{
    const rows = [...jobsWrap.querySelectorAll('.netscan__job')];
    const jobs = rows.map(r=>({
      name:r.querySelector('.jname').value.trim(),
      cidrs:r.querySelector('.jcidrs').value.split(',').map(s=>s.trim()).filter(Boolean),
      ports:r.querySelector('.jports').value.split(',').map(s=>parseInt(s.trim(),10)).filter(n=>!isNaN(n)),
      max_hosts:parseInt(r.querySelector('.jlim').value,10)||4096,
      interval_h:parseInt(r.querySelector('.jint').value,10)||24,
      resolve:r.querySelector('.jres').checked,
      deep:r.querySelector('.jdeep').checked,
      enabled:r.querySelector('.jen').checked
    }));
    const js = await call('save_jobs',{jobs});
    setStatus(js.ok?'Jobs enregistrés.':('Erreur: '+(js.error||'')));
  });
  btnRunJobs.addEventListener('click', async ()=>{
    const js = await call('run_jobs',{});
    setStatus(js.ok?('Jobs déclenchés : '+(js.count||0)):('Erreur: '+(js.error||'')));
  });

  document.addEventListener('keydown', e=>{
    if(e.key !== 'Escape') return;
    const wins = [...document.querySelectorAll('.netscan__modal')];
    if(!wins.length) return;
    wins.sort((a,b)=>(parseInt(a.style.zIndex||0)-parseInt(b.style.zIndex||0))).pop().remove();
  });
})();
</script>
