<?php
if (session_status()===PHP_SESSION_NONE) session_start();
$email=$_SESSION['user']['email']??''; if(!$email){ http_response_code(403); exit('Non connecté'); }
$uDir=__DIR__."/../../users/profiles/$email/"; $cfgFile=$uDir."netscan.json";
$cfg=file_exists($cfgFile)?(json_decode(file_get_contents($cfgFile),true)?:[]):[];
$rows=$cfg['last_results']??[];
function pdf_escape($s){ return str_replace(['\\','(',')'],['\\\\','\\(','\\)'], $s); }
$W=595; $H=842; // A4 pt
$margin=36; $line=14; $y=$H-$margin-40;
$buf = [];
$buf[]="%PDF-1.4";
$objs=[]; $o=1;
$fontObj=$o++; $pageObj=$o++; $contentsObj=$o++; $pagesObj=$o++; $catalogObj=$o++;
$header = "BT /F1 10 Tf 36 ".($H-$margin)." Td (DoMyDesk - netscan V3 - ".date('Y-m-d H:i').") Tj ET";
$lines=[];
$lines[] = "BT /F1 12 Tf 36 $y Td (IP | Host | OS | Services) Tj ET"; $y -= ($line+6);
foreach($rows as $r){
  $ip=$r['ip']??''; $h=$r['host']??''; $os=$r['os_guess']??'';
  $svc=implode(',', $r['services']??[]);
  $txt = pdf_escape("$ip | $h | $os | $svc");
  if($y < 60){ 
    $lines[] = "BT /F1 10 Tf 36 $y Td (… suite tronquée …) Tj ET";
    break;
  }
  $lines[] = "BT /F1 10 Tf 36 $y Td ($txt) Tj ET"; $y -= $line;
}
$stream = $header."\n".implode("\n",$lines);
$contents = "<< /Length ".strlen($stream)." >>\nstream\n".$stream."\nendstream";
$objs[$fontObj] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>";
$objs[$contentsObj] = $contents;
$objs[$pageObj] = "<< /Type /Page /Parent ".($pagesObj)." 0 R /MediaBox [0 0 $W $H] /Contents ".($contentsObj)." 0 R /Resources << /Font << /F1 ".($fontObj)." 0 R >> >> >>";
$objs[$pagesObj] = "<< /Type /Pages /Kids [".($pageObj)." 0 R] /Count 1 >>";
$objs[$catalogObj] = "<< /Type /Catalog /Pages ".($pagesObj)." 0 R >>";
$xrefPos = 0;
$out = [];
$offsets = [];
$pos = 0;
foreach($objs as $id=>$body){
  $s = "$id 0 obj\n$body\nendobj\n";
  $offsets[$id] = $pos + strlen(implode("\n",$buf)) + strlen(implode("",$out));
  $out[] = $s;
}
$xrefPos = strlen(implode("\n",$buf)) + strlen(implode("",$out));
$buf[] = implode("",$out);
$buf[] = "xref\n0 ".($catalogObj+1)."\n0000000000 65535 f \n";
for($i=1;$i<=$catalogObj;$i++){
  $off = $offsets[$i] ?? 0;
  $buf[] = sprintf("%010d 00000 n \n", $off);
}
$buf[] = "trailer << /Size ".($catalogObj+1)." /Root ".($catalogObj)." 0 R >>\nstartxref\n".$xrefPos."\n%%EOF";
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="netscan_results.pdf"');
echo implode("",$buf);
