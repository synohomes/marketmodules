<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$me = $_SESSION['user']['email'] ?? '';
if (!$me) {
    echo "<div class='section'>⛔ Connecte-toi pour jouer à GamePacMan.</div>";
    return;
}
$themeFile = __DIR__ . "/../../users/profiles/$me/theme.json";
$theme = "default";
if (is_file($themeFile)) {
    $t = json_decode(file_get_contents($themeFile), true);
    if (!empty($t['theme'])) $theme = $t['theme'];
}
?>
<div class="gamepacman-container">
    <div class="gamepacman-header">
        <div class="gamepacman-title">
            🟡 GamePacMan
        </div>
        <div class="gamepacman-controls">
            <label for="gp-map-select">Carte :</label>
            <select id="gp-map-select">
                <option value="0">Neon Blue Maze</option>
                <option value="1">Dark Storm Maze</option>
                <option value="2">DoMyDesk Violet Grid</option>
                <option value="3">Pixel Green Tech</option>
                <option value="4">Cyber Pink Warp</option>
                <option value="5">Blue Spiral</option>
                <option value="6">Green Cross</option>
                <option value="7">Violet Lab</option>
                <option value="8">Tech Circuit</option>
                <option value="9">Pink Chaos</option>
            </select>
            <label for="gp-diff-select">Difficulté :</label>
            <select id="gp-diff-select">
                <option value="easy">Facile</option>
                <option value="normal" selected>Normal</option>
                <option value="hard">Difficile</option>
            </select>
            <button id="gp-start-btn">▶ Lancer la partie</button>
            <button id="gp-reset-scores" type="button">🗑️ Reset scores</button>
            <button id="gp-export-btn" type="button">📄 Scores PDF</button>
        </div>
    </div>
    <div class="gamepacman-info">
        <span>Score : <span id="gp-score">0</span></span>
        <span>Meilleur : <span id="gp-best">0</span></span>
        <span>Carte actuelle : <span id="gp-map-name">Neon Blue Maze</span></span>
    </div>
    <div class="gamepacman-canvas-wrapper">
        <canvas id="gp-canvas" width="448" height="496"></canvas>
        <div id="gp-message" class="gamepacman-message"></div>
    </div>
    <div class="gamepacman-footer">
        <small>Utilise les flèches du clavier pour déplacer PacMan.</small>
    </div>
</div>
<link rel="stylesheet" href="modules/GamePacMan/style.css?v=3">
<script src="modules/GamePacMan/maps.js?v=3"></script>
<script src="modules/GamePacMan/game.js?v=3"></script>
<script>
(function() {
    function tryInit() {
        if (window.GamePacMan && typeof window.GamePacMan.init === 'function') {
            window.GamePacMan.init({
                canvasId: 'gp-canvas',
                scoreSpanId: 'gp-score',
                bestSpanId: 'gp-best',
                mapSelectId: 'gp-map-select',
                mapNameId: 'gp-map-name',
                startButtonId: 'gp-start-btn',
                messageId: 'gp-message',
                exportButtonId: 'gp-export-btn',
                difficultySelectId: 'gp-diff-select',
                resetButtonId: 'gp-reset-scores',
                scoreEndpoint: 'modules/GamePacMan/score.php',
                exportEndpoint: 'modules/GamePacMan/export.php'
            });
        } else {
            setTimeout(tryInit, 50);
        }
    }
    tryInit();
})();
</script>
