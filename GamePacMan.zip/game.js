(function () {
    const TILE = 16;
    const SCALE = 2;
    const BASE_SPEED_PAC = 8;
    const BASE_SPEED_GHOST = 7;
    const POWER_DURATION = 7000; // ms
    const HARD_EXTRA_PELLETS_DELAY = 10000;
    const HARD_EXTRA_PELLETS_COUNT = 2;
    function createAudio(src) {
        const a = new Audio(src);
        a.volume = 0.3;
        return a;
    }
    const sounds = {
        start: createAudio('modules/GamePacMan/sounds/start.wav'),
        eat: createAudio('modules/GamePacMan/sounds/eat.wav'),
        power: createAudio('modules/GamePacMan/sounds/power.wav'),
        death: createAudio('modules/GamePacMan/sounds/death.wav')
    };
    function dirVector(dir) {
        if (dir === 'left') return { x: -1, y: 0 };
        if (dir === 'right') return { x: 1, y: 0 };
        if (dir === 'up') return { x: 0, y: -1 };
        if (dir === 'down') return { x: 0, y: 1 };
        return { x: 0, y: 0 };
    }
    function cellCenter(col, row) {
        return {
            x: (col + 0.5) * TILE * SCALE,
            y: (row + 0.5) * TILE * SCALE
        };
    }
    function getCell(pos) {
        const c = Math.floor(pos.x / (TILE * SCALE));
        const r = Math.floor(pos.y / (TILE * SCALE));
        return { c, r };
    }
    function withinBounds(grid, c, r) {
        return r >= 0 && r < grid.length && c >= 0 && c < grid[0].length;
    }
    function isWall(grid, c, r) {
        if (!withinBounds(grid, c, r)) return true;
        return grid[r][c] === 1;
    }
    function distance2(a, b) {
        const dx = a.x - b.x;
        const dy = a.y - b.y;
        return dx * dx + dy * dy;
    }
    const GamePacMan = {
        cfg: null,
        canvas: null,
        ctx: null,
        map: null,
        pacman: null,
        ghosts: [],
        pelletsLeft: 0,
        score: 0,
        bestScore: 0,
        running: false,
        lastTime: 0,
        powerMode: false,
        powerEndTime: 0,
        messageEl: null,
        scoreSpan: null,
        bestSpan: null,
        mapNameEl: null,
        startBtn: null,
        mapSelect: null,
        exportBtn: null,
        diffSelect: null,
        resetBtn: null,
        scoreEndpoint: '',
        exportEndpoint: '',
        animFrame: null,
        difficulty: 'normal',
        speedPac: BASE_SPEED_PAC,
        speedGhost: BASE_SPEED_GHOST,
        lastExtraPellets: 0,
        init(options) {
            this.cfg = options;
            this.canvas = document.getElementById(options.canvasId);
            if (!this.canvas) return;
            this.ctx = this.canvas.getContext('2d');
            this.messageEl = document.getElementById(options.messageId);
            this.scoreSpan = document.getElementById(options.scoreSpanId);
            this.bestSpan = document.getElementById(options.bestSpanId);
            this.mapNameEl = document.getElementById(options.mapNameId);
            this.startBtn = document.getElementById(options.startButtonId);
            this.mapSelect = document.getElementById(options.mapSelectId);
            this.exportBtn = document.getElementById(options.exportButtonId);
            this.diffSelect = document.getElementById(options.difficultySelectId);
            this.resetBtn = document.getElementById(options.resetButtonId);
            this.scoreEndpoint = options.scoreEndpoint;
            this.exportEndpoint = options.exportEndpoint;

            if (!window.GamePacManMaps || !window.GamePacManMaps.length) {
                console.error('GamePacManMaps manquant.');
                return;
            }
            this.startBtn.addEventListener('click', () => this.startGame());
            this.mapSelect.addEventListener('change', () => this.changeMap());
            if (this.exportBtn) {
                this.exportBtn.addEventListener('click', () => this.openExportPopup());
            }
            if (this.diffSelect) {
                this.diffSelect.addEventListener('change', () => {
                    this.difficulty = this.diffSelect.value || 'normal';
                    this.updateDifficultyParams();
                });
            }
            if (this.resetBtn) {
                this.resetBtn.addEventListener('click', () => this.resetScores());
            }
            window.addEventListener('keydown', (e) => this.keyDown(e));
            this.difficulty = (this.diffSelect && this.diffSelect.value) || 'normal';
            this.updateDifficultyParams();
            this.loadBestScore();
            this.changeMap(true);
        },
        updateDifficultyParams() {
            if (this.difficulty === 'easy') {
                this.speedPac = BASE_SPEED_PAC * 0.8;
                this.speedGhost = BASE_SPEED_GHOST * 0.7;
            } else if (this.difficulty === 'hard') {
                this.speedPac = BASE_SPEED_PAC * 1.05;
                this.speedGhost = BASE_SPEED_GHOST * 1.3;
            } else {
                this.speedPac = BASE_SPEED_PAC;
                this.speedGhost = BASE_SPEED_GHOST;
            }
        },
        changeMap(skipResetButtonText) {
            const mIndex = parseInt(this.mapSelect.value, 10) || 0;
            this.map = JSON.parse(JSON.stringify(window.GamePacManMaps[mIndex]));
            if (this.mapNameEl) this.mapNameEl.textContent = this.map.name;
            const rows = this.map.grid.length;
            const cols = this.map.grid[0].length;
            this.canvas.width = cols * TILE * SCALE;
            this.canvas.height = rows * TILE * SCALE;
            if (!skipResetButtonText && this.startBtn) {
                this.startBtn.textContent = '▶ Lancer la partie';
            }
            this.running = false;
            this.drawStatic();
        },
        keyDown(e) {
            if (!this.pacman || !this.running) return;
            const key = e.key;
            if (key === 'ArrowLeft') this.pacman.nextDir = 'left';
            if (key === 'ArrowRight') this.pacman.nextDir = 'right';
            if (key === 'ArrowUp') this.pacman.nextDir = 'up';
            if (key === 'ArrowDown') this.pacman.nextDir = 'down';
        },
        startGame() {
            if (!this.map) return;
            this.resetGame();
            this.running = true;
            this.lastTime = performance.now();
            if (this.startBtn) this.startBtn.textContent = '⏸ Rejouer';
            this.hideMessage();
            try { sounds.start.currentTime = 0; sounds.start.play(); } catch(e) {}
            const loop = (t) => {
                this.animFrame = requestAnimationFrame(loop);
                this.update(t);
                this.render();
            };
            if (this.animFrame) cancelAnimationFrame(this.animFrame);
            this.animFrame = requestAnimationFrame(loop);
        },
        resetGame() {
            const g = this.map.grid;
            this.pelletsLeft = 0;
            for (let r = 0; r < g.length; r++) {
                for (let c = 0; c < g[0].length; c++) {
                    if (g[r][c] === 2 || g[r][c] === 3) this.pelletsLeft++;
                }
            }
            const startRow = g.length - 3;
            const startCol = Math.floor(g[0].length / 2);
            const startPos = cellCenter(startCol, startRow);
            this.pacman = {
                pos: { x: startPos.x, y: startPos.y },
                dir: 'left',
                nextDir: 'left',
                radius: (TILE * SCALE) / 2 - 2,
                mouthAngle: 0,
                mouthDir: 1
            };
            this.ghosts = [];
            for (let r = 0; r < g.length; r++) {
                for (let c = 0; c < g[0].length; c++) {
                    if (g[r][c] === 4) {
                        const p = cellCenter(c, r);
                        this.ghosts.push({
                            pos: { x: p.x, y: p.y },
                            dir: 'up',
                            color: '#ff5555',
                            scatter: false,
                            frightened: false
                        });
                    }
                }
            }
            if (!this.ghosts.length) {
                const centerRow = Math.floor(g.length / 2);
                const centerCol = Math.floor(g[0].length / 2);
                const p = cellCenter(centerCol, centerRow);
                for (let i = 0; i < 3; i++) {
                    this.ghosts.push({
                        pos: { x: p.x + (i - 1) * TILE * SCALE, y: p.y },
                        dir: 'up',
                        color: ['#ff5555','#55ffff','#ffb8ff'][i],
                        scatter: false,
                        frightened: false
                    });
                }
            }
            if (this.difficulty === 'easy') {
                this.ghosts = this.ghosts.slice(0, 2);
            } else if (this.difficulty === 'hard') {
                while (this.ghosts.length < 4) {
                    const g0 = this.ghosts[this.ghosts.length - 1] || this.ghosts[0];
                    this.ghosts.push({
                        pos: { x: g0.pos.x, y: g0.pos.y },
                        dir: g0.dir,
                        color: '#ffaa00',
                        scatter: false,
                        frightened: false
                    });
                }
            }
            this.score = 0;
            this.updateScoreUI();
            this.powerMode = false;
            this.powerEndTime = 0;
            this.lastExtraPellets = performance.now();
        },
        update(timestamp) {
            if (!this.running) {
                this.lastTime = timestamp;
                return;
            }
            const dtMs = timestamp - this.lastTime;
            this.lastTime = timestamp;
            const dtSec = dtMs / 1000;
            const deltaPac = dtSec * this.speedPac;
            const deltaGhost = dtSec * this.speedGhost;
            this.updatePacman(deltaPac);
            this.updateGhosts(deltaGhost);
            this.checkCollisions();
            if (this.powerMode && timestamp > this.powerEndTime) {
                this.powerMode = false;
                this.ghosts.forEach(g => g.frightened = false);
            }
            if (this.difficulty === 'hard') {
                if (timestamp - this.lastExtraPellets > HARD_EXTRA_PELLETS_DELAY) {
                    this.lastExtraPellets = timestamp;
                    this.spawnExtraPellets(HARD_EXTRA_PELLETS_COUNT);
                }
            }
            if (this.pelletsLeft <= 0) {
                this.victory();
            }
        },
        spawnExtraPellets(count) {
            const g = this.map.grid;
            const rows = g.length;
            const cols = g[0].length;
            let added = 0;
            for (let tries = 0; tries < 200 && added < count; tries++) {
                const r = 1 + Math.floor(Math.random() * (rows - 2));
                const c = 1 + Math.floor(Math.random() * (cols - 2));
                if (g[r][c] === 0) {
                    g[r][c] = 2;
                    this.pelletsLeft++;
                    added++;
                }
            }
        },
        updatePacman(delta) {
            if (!this.pacman) return;
            const g = this.map.grid;
            const vecNext = dirVector(this.pacman.nextDir);
            const cell = getCell(this.pacman.pos);
            const center = cellCenter(cell.c, cell.r);
            const distToCenter2 = distance2(this.pacman.pos, center);
            if (distToCenter2 < (4 * 4) && this.pacman.nextDir !== this.pacman.dir) {
                const nc = cell.c + vecNext.x;
                const nr = cell.r + vecNext.y;
                if (!isWall(g, nc, nr)) {
                    this.pacman.dir = this.pacman.nextDir;
                    this.pacman.pos.x = center.x;
                    this.pacman.pos.y = center.y;
                }
            }
            const vec = dirVector(this.pacman.dir);
            const step = delta * TILE * SCALE;
            const maxStep = 2;
            let remaining = step;
            while (remaining > 0.0001) {
                const s = Math.min(remaining, maxStep);
                let newX = this.pacman.pos.x + vec.x * s;
                let newY = this.pacman.pos.y + vec.y * s;
                let nc = Math.floor(newX / (TILE * SCALE));
                let nr = Math.floor(newY / (TILE * SCALE));
                if (!isWall(g, nc, nr)) {
                    this.pacman.pos.x = newX;
                    this.pacman.pos.y = newY;
                    remaining -= s;
                } else {
                    const c2 = getCell(this.pacman.pos);
                    const center2 = cellCenter(c2.c, c2.r);
                    this.pacman.pos.x = center2.x;
                    this.pacman.pos.y = center2.y;
                    remaining = 0;
                }
            }
            const c = getCell(this.pacman.pos);
            if (withinBounds(g, c.c, c.r)) {
                if (g[c.r][c.c] === 2) {
                    g[c.r][c.c] = 0;
                    this.score += 10;
                    this.pelletsLeft--;
                    this.updateScoreUI();
                    try { sounds.eat.currentTime = 0; sounds.eat.play(); } catch(e) {}
                } else if (g[c.r][c.c] === 3) {
                    g[c.r][c.c] = 0;
                    this.score += 50;
                    this.pelletsLeft--;
                    this.updateScoreUI();
                    this.powerMode = true;
                    this.powerEndTime = performance.now() + POWER_DURATION;
                    this.ghosts.forEach(g => g.frightened = true);
                    try { sounds.power.currentTime = 0; sounds.power.play(); } catch(e) {}
                }
            }
            this.pacman.mouthAngle += 0.15 * this.pacman.mouthDir;
            if (this.pacman.mouthAngle > 0.5) this.pacman.mouthDir = -1;
            if (this.pacman.mouthAngle < 0.1) this.pacman.mouthDir = 1;
        },
        updateGhosts(delta) {
            const g = this.map.grid;
            const pacPos = this.pacman ? this.pacman.pos : { x: 0, y: 0 };
            const cols = g[0].length;
            this.ghosts.forEach(ghost => {
                const vec = dirVector(ghost.dir);
                const step = delta * TILE * SCALE;
                const maxStep = 2;
                let remaining = step;
                while (remaining > 0.0001) {
                    const s = Math.min(remaining, maxStep);
                    let newX = ghost.pos.x + vec.x * s;
                    let newY = ghost.pos.y + vec.y * s;
                    let nc = Math.floor(newX / (TILE * SCALE));
                    let nr = Math.floor(newY / (TILE * SCALE));
                    if (this.difficulty === 'hard' && (nc < 0 || nc >= cols)) {
                        if (nc < 0) {
                            newX = (cols - 0.5) * TILE * SCALE;
                        } else {
                            newX = 0.5 * TILE * SCALE;
                        }
                        nc = Math.floor(newX / (TILE * SCALE));
                    }
                    if (isWall(g, nc, nr)) {
                        const cell = getCell(ghost.pos);
                        ghost.pos = cellCenter(cell.c, cell.r);
                        const dirs = ['left','right','up','down'];
                        const candidates = [];
                        for (const d of dirs) {
                            if ((d === 'left' && ghost.dir === 'right') ||
                                (d === 'right' && ghost.dir === 'left') ||
                                (d === 'up' && ghost.dir === 'down') ||
                                (d === 'down' && ghost.dir === 'up')) {
                                continue;
                            }
                            const v = dirVector(d);
                            const cc = cell.c + v.x;
                            const rr = cell.r + v.y;
                            if (!isWall(g, cc, rr)) {
                                candidates.push(d);
                            }
                        }
                        if (!candidates.length) {
                            const reverse = {
                                left: 'right',
                                right: 'left',
                                up: 'down',
                                down: 'up'
                            };
                            ghost.dir = reverse[ghost.dir] || ghost.dir;
                        } else {
                            if (this.powerMode) {
                                let best = null;
                                let bestDist = -1;
                                candidates.forEach(d => {
                                    const v = dirVector(d);
                                    const cc = cell.c + v.x;
                                    const rr = cell.r + v.y;
                                    const pos = cellCenter(cc, rr);
                                    const dist = distance2(pos, pacPos);
                                    if (dist > bestDist) {
                                        bestDist = dist;
                                        best = d;
                                    }
                                });
                                ghost.dir = best || candidates[0];
                            } else {
                                let best = null;
                                let bestDist = Infinity;
                                candidates.forEach(d => {
                                    const v = dirVector(d);
                                    const cc = cell.c + v.x;
                                    const rr = cell.r + v.y;
                                    const pos = cellCenter(cc, rr);
                                    const dist = distance2(pos, pacPos);
                                    if (dist < bestDist) {
                                        bestDist = dist;
                                        best = d;
                                    }
                                });
                                ghost.dir = best || candidates[0];
                            }
                        }
                        remaining = 0;
                    } else {
                        ghost.pos.x = newX;
                        ghost.pos.y = newY;
                        remaining -= s;
                    }
                }
            });
        },
        checkCollisions() {
            if (!this.pacman) return;
            const pacPos = this.pacman.pos;
            const threshold2 = Math.pow((TILE * SCALE) / 2, 2);
            for (const ghost of this.ghosts) {
                const d2 = distance2(pacPos, ghost.pos);
                if (d2 < threshold2) {
                    if (this.powerMode && ghost.frightened) {
                        this.score += 200;
                        this.updateScoreUI();
                        const g = this.map.grid;
                        let spawnFound = false;
                        for (let r = 0; r < g.length && !spawnFound; r++) {
                            for (let c = 0; c < g[0].length && !spawnFound; c++) {
                                if (g[r][c] === 4) {
                                    ghost.pos = cellCenter(c, r);
                                    ghost.dir = 'up';
                                    ghost.frightened = false;
                                    spawnFound = true;
                                }
                            }
                        }
                    } else {
                        this.gameOver();
                        return;
                    }
                }
            }
        },
        gameOver() {
            this.running = false;
            if (this.animFrame) cancelAnimationFrame(this.animFrame);
            try { sounds.death.currentTime = 0; sounds.death.play(); } catch(e) {}
            const html =
                "💀 Game Over<br>Score : " + this.score +
                "<br><br>" +
                "<button type='button' onclick='window.GamePacMan.onRestart()'>Rejouer</button>" +
                "<button type='button' onclick='window.GamePacMan.onExport()'>Exporter mes scores</button>";
            this.showMessage(html);
            this.saveScore();
        },
        victory() {
            this.running = false;
            if (this.animFrame) cancelAnimationFrame(this.animFrame);
            this.saveScore();

            const html =
                "🏆 Niveau terminé !<br>Score : " + this.score +
                "<br><br>" +
                "<button type='button' onclick='window.GamePacMan.onNextMap()'>Carte suivante</button>" +
                "<button type='button' onclick='window.GamePacMan.onExport()'>Exporter mes scores</button>";
            this.showMessage(html);
        },
        onNextMap() {
            if (!this.mapSelect || !window.GamePacManMaps) return;
            let idx = parseInt(this.mapSelect.value, 10) || 0;
            idx = (idx + 1) % window.GamePacManMaps.length;
            this.mapSelect.value = String(idx);
            this.hideMessage();
            this.changeMap();
            this.startGame();
        },
        onRestart() {
            this.hideMessage();
            this.startGame();
        },
        onExport() {
            this.hideMessage();
            this.openExportPopup();
        },
        showMessage(msg) {
            if (!this.messageEl) return;
            this.messageEl.innerHTML = msg;
            this.messageEl.classList.add('visible');
        },
        hideMessage() {
            if (!this.messageEl) return;
            this.messageEl.classList.remove('visible');
        },
        updateScoreUI() {
            if (this.scoreSpan) this.scoreSpan.textContent = this.score;
            if (this.score > this.bestScore) {
                this.bestScore = this.score;
                this.saveBestScoreLocal();
            }
            if (this.bestSpan) this.bestSpan.textContent = this.bestScore;
        },
        saveBestScoreLocal() {
            try {
                localStorage.setItem('GamePacMan_bestScore', String(this.bestScore));
            } catch(e) {}
        },
        loadBestScore() {
            try {
                const v = localStorage.getItem('GamePacMan_bestScore');
                if (v) {
                    this.bestScore = parseInt(v, 10) || 0;
                    if (this.bestSpan) this.bestSpan.textContent = this.bestScore;
                }
            } catch(e) {}
        },
        saveScore() {
            if (!this.scoreEndpoint) return;
            const form = new FormData();
            form.append('action', 'add');
            form.append('score', String(this.score));
            fetch(this.scoreEndpoint, {
                method: 'POST',
                body: form,
                credentials: 'same-origin'
            }).then(r => r.json())
              .then(data => {
                  if (data && typeof data.best !== 'undefined') {
                      this.bestScore = data.best;
                      if (this.bestSpan) this.bestSpan.textContent = this.bestScore;
                  }
              }).catch(() => {});
        },
        resetScores() {
            if (!this.scoreEndpoint) return;
            if (!confirm("Supprimer tous tes scores PacMan ?")) return;
            const form = new FormData();
            form.append('action', 'reset');
            fetch(this.scoreEndpoint, {
                method: 'POST',
                body: form,
                credentials: 'same-origin'
            }).then(r => r.json())
              .then(data => {
                  if (data && data.ok) {
                      this.bestScore = 0;
                      if (this.bestSpan) this.bestSpan.textContent = '0';
                  }
              }).catch(() => {});
        },
        openExportPopup() {
            if (!this.exportEndpoint) return;
            const container = this.canvas.closest('.gamepacman-container');
            if (!container) {
                window.open(this.exportEndpoint, '_blank');
                return;
            }
            let overlay = container.querySelector('.gamepacman-pdf-overlay');
            if (!overlay) {
                overlay = document.createElement('div');
                overlay.className = 'gamepacman-pdf-overlay';
                overlay.innerHTML = `
                    <div class="gamepacman-pdf-box">
                        <button type="button" class="gamepacman-pdf-close">✖</button>
                        <iframe class="gamepacman-pdf-frame" src=""></iframe>
                    </div>
                `;
                container.appendChild(overlay);
                overlay.querySelector('.gamepacman-pdf-close').addEventListener('click', () => {
                    overlay.style.display = 'none';
                });
            }
            const frame = overlay.querySelector('.gamepacman-pdf-frame');
            frame.src = this.exportEndpoint + '?t=' + Date.now();
            overlay.style.display = 'flex';
        },
        drawStatic() {
            if (!this.ctx || !this.map) return;
            this.render();
        },
        render() {
            if (!this.ctx || !this.map) return;
            const ctx = this.ctx;
            const g = this.map.grid;
            const rows = g.length;
            const cols = g[0].length;
            ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
            for (let r = 0; r < rows; r++) {
                for (let c = 0; c < cols; c++) {
                    const val = g[r][c];
                    const x = c * TILE * SCALE;
                    const y = r * TILE * SCALE;
                    if (val === 1) {
                        const wallColor = this.map.wallColor || '#2222aa';
                        ctx.fillStyle = wallColor;
                        ctx.fillRect(x, y, TILE * SCALE, TILE * SCALE);
                    } else {
                        ctx.fillStyle = '#000000';
                        ctx.fillRect(x, y, TILE * SCALE, TILE * SCALE);
                        if (val === 2) {
                            const pelletColor = this.map.pelletColor || '#ffff99';
                            ctx.fillStyle = pelletColor;
                            ctx.beginPath();
                            ctx.arc(x + TILE * SCALE / 2, y + TILE * SCALE / 2, 2, 0, Math.PI * 2);
                            ctx.fill();
                        }
                        if (val === 3) {
                            const powerColor = this.map.powerColor || '#ff99ff';
                            ctx.fillStyle = powerColor;
                            ctx.beginPath();
                            ctx.arc(x + TILE * SCALE / 2, y + TILE * SCALE / 2, 4, 0, Math.PI * 2);
                            ctx.fill();
                        }
                    }
                }
            }
            if (this.pacman) {
                const p = this.pacman.pos;
                const radius = this.pacman.radius;
                ctx.fillStyle = '#ffff00';
                const dir = this.pacman.dir;
                let startA = 0, endA = 0;
                const open = this.pacman.mouthAngle;

                if (dir === 'right') {
                    startA = open;
                    endA = 2 * Math.PI - open;
                } else if (dir === 'left') {
                    startA = Math.PI + open;
                    endA = Math.PI - open;
                } else if (dir === 'up') {
                    startA = -Math.PI / 2 + open;
                    endA = 1.5 * Math.PI - open;
                } else if (dir === 'down') {
                    startA = Math.PI / 2 + open;
                    endA = 0.5 * Math.PI - open;
                } else {
                    startA = 0;
                    endA = 2 * Math.PI;
                }
                ctx.beginPath();
                ctx.moveTo(p.x, p.y);
                ctx.arc(p.x, p.y, radius, startA, endA, false);
                ctx.closePath();
                ctx.fill();
            }
            this.ghosts.forEach(ghost => {
                const p = ghost.pos;
                ctx.fillStyle = this.powerMode && ghost.frightened ? '#3333ff' : ghost.color || '#ff5555';
                const w = TILE * SCALE - 2;
                const h = TILE * SCALE - 2;
                const x = p.x - w / 2;
                const y = p.y - h / 2;
                ctx.beginPath();
                ctx.arc(x + w / 2, y + h / 2, w/2, Math.PI, 0);
                ctx.lineTo(x + w, y + h);
                ctx.lineTo(x + (3*w/4), y + h - 4);
                ctx.lineTo(x + (2*w/4), y + h);
                ctx.lineTo(x + (1*w/4), y + h - 4);
                ctx.lineTo(x, y + h);
                ctx.closePath();
                ctx.fill();
                ctx.fillStyle = '#ffffff';
                ctx.beginPath();
                ctx.arc(x + w/3, y + h/2 - 2, 3, 0, 2*Math.PI);
                ctx.arc(x + 2*w/3, y + h/2 - 2, 3, 0, 2*Math.PI);
                ctx.fill();
                ctx.fillStyle = '#000000';
                ctx.beginPath();
                ctx.arc(x + w/3, y + h/2 - 2, 1.5, 0, 2*Math.PI);
                ctx.arc(x + 2*w/3, y + h/2 - 2, 1.5, 0, 2*Math.PI);
                ctx.fill();
            });
        }
    };
    window.GamePacMan = GamePacMan;
})();
