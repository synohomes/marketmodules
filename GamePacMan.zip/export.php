<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$me = $_SESSION['user']['email'] ?? '';
if (!$me) {
    echo "<html><body><p>⛔ Connecte-toi pour voir tes scores.</p></body></html>";
    exit;
}
$baseDir = __DIR__ . "/../../users/profiles/$me/GamePacMan/";
$file = $baseDir . 'scores.json';
$scores = [];
if (is_file($file)) {
    $json = file_get_contents($file);
    $scores = json_decode($json, true);
    if (!is_array($scores)) $scores = [];
}
usort($scores, function($a, $b) {
    return $b['score'] <=> $a['score'];
});
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>GamePacMan - Scores de <?php echo htmlspecialchars($me, ENT_QUOTES, 'UTF-8'); ?></title>
<style>
body {
    font-family: Arial, sans-serif;
    background: #ffffff;
    color: #000000;
    margin: 20px;
}
h1, h2 {
    margin-bottom: 5px;
}
table {
    border-collapse: collapse;
    width: 100%;
    margin-top: 15px;
}
th, td {
    border: 1px solid #333;
    padding: 4px 6px;
    font-size: 0.85rem;
}
th {
    background: #eeeeee;
}
tfoot td {
    font-weight: bold;
}
.small {
    font-size: 0.8rem;
    color: #555;
}
</style>
</head>
<body>
    <h1>GamePacMan</h1>
    <h2>Tableau des scores</h2>
    <p class="small">
        Utilisateur : <strong><?php echo htmlspecialchars($me, ENT_QUOTES, 'UTF-8'); ?></strong><br>
        Généré le : <?php echo date('Y-m-d H:i:s'); ?><br>
        Astuce : utilise <strong>Imprimer &rarr; Enregistrer en PDF</strong> pour obtenir ton PDF.
    </p>
    <?php if (!$scores): ?>
        <p>Aucun score enregistré pour le moment.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Score</th>
                    <th>Date</th>
                    <th>Utilisateur</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($scores as $i => $row): ?>
                <tr>
                    <td><?php echo $i+1; ?></td>
                    <td><?php echo (int)($row['score'] ?? 0); ?></td>
                    <td><?php echo htmlspecialchars($row['date'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                    <td><?php echo htmlspecialchars($row['user'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="4">
                        Total scores : <?php echo count($scores); ?> &mdash;
                        Meilleur score : <?php echo (int)$scores[0]['score']; ?>
                    </td>
                </tr>
            </tfoot>
        </table>
    <?php endif; ?>
</body>
</html>
