<?php
if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json; charset=utf-8');
$me = $_SESSION['user']['email'] ?? '';
if (!$me) {
    echo json_encode(['error' => 'not_logged']);
    exit;
}
$baseDir = __DIR__ . "/../../users/profiles/$me/GamePacMan/";
@mkdir($baseDir, 0775, true);
$file = $baseDir . 'scores.json';
$scores = [];
if (is_file($file)) {
    $json = file_get_contents($file);
    $scores = json_decode($json, true);
    if (!is_array($scores)) $scores = [];
}
$action = $_POST['action'] ?? $_GET['action'] ?? '';
if ($action === 'add' && isset($_POST['score'])) {
    $score = (int)$_POST['score'];
    if ($score < 0) $score = 0;
    $scores[] = [
        'score' => $score,
        'date'  => date('Y-m-d H:i:s'),
        'user'  => $me
    ];
    usort($scores, function($a, $b) {
        return $b['score'] <=> $a['score'];
    });
    if (count($scores) > 100) {
        $scores = array_slice($scores, 0, 100);
    }
    file_put_contents($file, json_encode($scores, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    $best = $scores[0]['score'] ?? $score;
    echo json_encode([
        'ok' => true,
        'best' => $best,
        'count' => count($scores)
    ]);
    exit;
}
if ($action === 'reset') {
    $scores = [];
    file_put_contents($file, json_encode($scores, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    echo json_encode(['ok' => true, 'reset' => true]);
    exit;
}
if ($action === 'list' || $action === '') {
    echo json_encode([
        'ok' => true,
        'scores' => $scores
    ]);
    exit;
}
echo json_encode(['error' => 'unknown_action']);
