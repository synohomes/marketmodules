<?php
error_reporting(0);
$cfgDir   = __DIR__ . "/cfg";
$jsonFile = $cfgDir . "/proxv1.json";
$cacheDir = __DIR__ . "/cache";
if (!is_dir($cacheDir)) @mkdir($cacheDir, 0775, true);
header('Content-Type: application/json; charset=utf-8');
if (!file_exists($jsonFile)) {
  http_response_code(404);
  echo json_encode(['ok'=>false,'err'=>'cfg_missing']);
  exit;
}
$servers = json_decode(@file_get_contents($jsonFile), true);
if (!is_array($servers)) $servers = [];
function api_call($url, $token, $secret) {
  $opts = [
    'http' => [
      'method'  => 'GET',
      'timeout' => 6,
      'header'  => "Authorization: PVEAPIToken=$token=$secret\r\n"
    ],
    'ssl' => ['verify_peer'=>false,'verify_peer_name'=>false]
  ];
  $ctx = stream_context_create($opts);
  $res = @file_get_contents($url, false, $ctx);
  $code = 0;
  if (isset($http_response_header[0]) &&
      preg_match('#\s(\d{3})\s#', $http_response_header[0], $m)) {
    $code = (int)$m[1];
  }
  return [
    'ok'   => $res !== false && $code>=200 && $code<300,
    'code' => $code ?: ($res===false ? 0 : 200),
    'data' => $res ? json_decode($res,true) : null
  ];
}
$updated = [];
foreach ($servers as $srv) {
  $safe = preg_replace('/[^a-zA-Z0-9_-]/', '_', $srv['name'] ?? 'srv');
  $file = "$cacheDir/{$safe}.json";
  $base  = "https://{$srv['ip']}:{$srv['port']}/api2/json";
  $nodes  = api_call("$base/nodes", $srv['token_id'], $srv['secret']);
  if (!$nodes['ok'] || empty($nodes['data']['data'][0]['node'])) {
    $payload = [
      'ts'     => time(),
      'server' => ['name'=>$srv['name'],'ip'=>$srv['ip'],'port'=>$srv['port']],
      'error'  => ['where'=>'nodes','code'=>$nodes['code']]
    ];
    @file_put_contents($file, json_encode($payload, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE), LOCK_EX);
    @chmod($file, 0664);
    continue;
  }
  $node   = $nodes['data']['data'][0]['node'];
  $status = api_call("$base/nodes/$node/status", $srv['token_id'], $srv['secret']);
  $vms    = api_call("$base/nodes/$node/qemu",   $srv['token_id'], $srv['secret']);
  $payload = [
    'ts'     => time(),
    'server' => ['name'=>$srv['name'],'ip'=>$srv['ip'],'port'=>$srv['port']],
    'node'   => $node,
    'status' => $status['ok'] ? ($status['data']['data'] ?? null) : null,
    'vms'    => $vms['ok'] ? ($vms['data']['data'] ?? []) : [],
  ];
  if (!$status['ok'] || !$vms['ok']) {
    $payload['error'] = [
      'where' => !$status['ok'] ? 'status' : 'qemu',
      'code'  => !$status['ok'] ? $status['code'] : $vms['code']
    ];
  }

  @file_put_contents($file, json_encode($payload, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE), LOCK_EX);
  @chmod($file, 0664);
  $updated[] = $safe;
}
echo json_encode(['ok'=>true,'updated'=>$updated], JSON_UNESCAPED_UNICODE);
