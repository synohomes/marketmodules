<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

/* ------------------------------------------------------------------ */
/*  OPTIONS RAPIDES                                                   */
/* ------------------------------------------------------------------ */
$ENABLE_CONSOLE   = true;   // boutons Console + popup noVNC
$SHOW_CREATE_FORM = true;   // affiche le volet "Créer une VM (V3)"
$CACHE_TTL        = 300;    // 5 minutes

/* ------------------------------------------------------------------ */
/*  FICHIERS & DOSSIERS                                               */
/* ------------------------------------------------------------------ */
$cfgFile  = __DIR__ . "/cfg/proxv1.json";  // liste des serveurs
$cacheDir = __DIR__ . "/cache";
if (!is_dir($cacheDir)) @mkdir($cacheDir, 0775, true);

if (!file_exists($cfgFile)) { echo "<div style='color:#ccc'>Aucun serveur Proxmox configuré.</div>"; return; }
$servers = json_decode(@file_get_contents($cfgFile), true);
if (!is_array($servers) || !count($servers)) { echo "<div style='color:#ccc'>Aucun serveur Proxmox défini.</div>"; return; }

/* ------------------------------------------------------------------ */
/*  OUTILS                                                            */
/* ------------------------------------------------------------------ */
function read_cache($cacheDir, $name) {
  $safe = preg_replace('/[^a-zA-Z0-9_-]/', '_', $name);
  $f = "$cacheDir/{$safe}.json";
  if (!file_exists($f)) return null;
  $data = json_decode(@file_get_contents($f), true);
  return is_array($data) ? $data : null;
}
function ago($ts){
  $d = time() - (int)$ts;
  if ($d < 60)   return $d.'s';
  if ($d < 3600) return floor($d/60).'m';
  return floor($d/3600).'h';
}
?>
<style>
/* Cartes & grille VM */
.proxcard{background:#1a1a1a;border:1px solid #444;border-radius:8px;margin:10px 0;padding:10px;color:#ccc;position:relative}
.proxtitle{font-weight:bold;color:#fff;font-size:14px;margin-bottom:8px;cursor:pointer;user-select:none;position:relative}
.proxtitle::after{content:'▼';position:absolute;right:10px;transition:transform .2s ease}
.proxtitle.collapsed::after{transform:rotate(-90deg)}
.proxinfo{margin-left:10px;margin-bottom:6px}
.vmgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:8px;margin-top:6px}
.vmitem{background:#222;padding:8px;border-radius:6px;display:flex;flex-direction:column;align-items:flex-start;justify-content:flex-start;height:130px;box-sizing:border-box;position:relative}
.vmname{font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%;width:100%;display:flex;align-items:center}
.vmstatus{width:10px;height:10px;border-radius:50%;margin-right:6px;display:inline-block;flex-shrink:0}
.vmctrl{margin-top:auto;display:flex;gap:4px;flex-wrap:wrap}
.vmctrl button{background:#333;color:#777;border:none;font-size:11px;padding:4px 6px;cursor:not-allowed;border-radius:4px;flex:0 0 auto}
.vmctrl button.active{background:#2b2;color:#fff;cursor:pointer}
.badge{font-size:11px;color:#aaa;margin-left:8px}
.badge.stale{color:#f90}
.hidden{display:none}
.skel{background:repeating-linear-gradient(90deg,#2a2a2a,#2a2a2a 8px,#333 8px,#333 16px);height:90px;border-radius:6px}

/* Popup console confinée au module */
.pv1-modal{
  position:absolute; inset:5% 5% auto 5%;
  width:90%; height:90%;
  background:#111; border:1px solid #333; border-radius:10px;
  box-shadow:0 20px 60px rgba(0,0,0,.6);
  z-index:999; display:none; flex-direction:column;
}
.pv1-modal-header{
  display:flex;align-items:center;justify-content:space-between;
  padding:10px 14px;border-bottom:1px solid #222;color:#ddd;font-weight:600
}
.pv1-modal-body{flex:1;min-height:0}
.pv1-modal iframe{
  width:100%;height:100%;border:0;border-bottom-left-radius:10px;border-bottom-right-radius:10px
}
.pv1-close{
  background:#222;color:#ddd;border:1px solid #444;border-radius:8px;padding:6px 10px;cursor:pointer
}

/* ---- Volet déroulant "Créer une VM (V3)" ---- */
.pv1-drawer-toggle{
  /* AVANT: margin:8px 10px 0 10px;  -> On ajoute un espace sous le bouton */
  margin:8px 10px 10px 10px;
  display:flex; align-items:center; gap:8px;
  background:#181818; border:1px solid #333; color:#ddd; padding:8px 10px;
  border-radius:8px; cursor:pointer; user-select:none;
}
.pv1-drawer-toggle .chev{margin-left:auto; transition:transform .2s ease; opacity:.8}
.pv1-drawer.open + .pv1-drawer-toggle .chev{transform:rotate(180deg)}

.pv1-drawer{
  margin:8px 10px; border:1px dashed #3a3a3a; border-radius:10px; overflow:hidden;
  max-height:0; transition:max-height .25s ease;
}
.pv1-drawer.open{max-height:900px} /* assez grand pour le contenu */

/* Contenu formulaire vitrine */
.pv1-form{background:#151515; padding:12px;}
.pv1-form h4{margin:0 0 10px 0;color:#ddd;font-size:14px;display:flex;align-items:center;gap:8px}
.pv1-grid{display:grid;gap:10px;grid-template-columns: repeat(auto-fit,minmax(180px,1fr));}
.pv1-field{display:flex;flex-direction:column;gap:6px}
.pv1-field label{font-size:12px;color:#bbb}
.pv1-field input,.pv1-field select{
  background:#202020;border:1px solid #3a3a3a;border-radius:6px;color:#ddd;padding:6px 8px;font-size:13px
}
.pv1-actions{margin-top:10px;display:flex;gap:8px;align-items:center}
.pv1-btn{background:#2b2;border:none;color:#fff;border-radius:8px;padding:8px 12px;cursor:not-allowed;opacity:.7}
.pv1-chip{font-size:12px;color:#ccc;background:#222;border:1px solid #333;border-radius:999px;padding:4px 8px}
.pv1-note{color:#f0c040;font-size:12px}

/* mini toaster */
.pv1-toast{
  position:absolute; right:16px; bottom:16px; background:#111; color:#eee;
  border:1px solid #333; padding:10px 12px; border-radius:10px; box-shadow:0 10px 30px rgba(0,0,0,.4);
  font-size:13px; display:none; z-index:1000;
}
</style>
<script>
function toggleVMs(el){
  const g = el.nextElementSibling;
  if (g && g.classList.contains('vmbox')) {
    g.classList.toggle('hidden');
    el.classList.toggle('collapsed');
  }
}
</script>
<?php
/* ------------------------------------------------------------------ */
/*  RENDU depuis le CACHE                                             */
/* ------------------------------------------------------------------ */
$needUpdate = false;

foreach ($servers as $srv) {
  $srvName = $srv['name'] ?? ($srv['ip'] ?? 'pve');
  $cache   = read_cache($cacheDir, $srvName);
  $stale   = true;
  if ($cache && isset($cache['ts'])) $stale = (time() - $cache['ts'] > $CACHE_TTL);
  if (!$cache || $stale) $needUpdate = true;

  echo "<div class='proxcard'>";
  echo "<div class='proxtitle' onclick='toggleVMs(this)'>🖥️ "
     . htmlspecialchars($srvName)
     . " (" . htmlspecialchars($srv['ip'] ?? '-') . ")";

  if ($cache && isset($cache['ts'])) {
    $cls = $stale ? "badge stale" : "badge";
    echo "<span class='$cls'>cache " . ago($cache['ts']) . "</span>";
  } else {
    echo "<span class='badge stale'>initialisation…</span>";
  }
  echo "</div>";
  echo "<div class='vmbox hidden'>";

  // Erreur API éventuelle
  if (!empty($cache['error'])) {
    $w = htmlspecialchars($cache['error']['where'] ?? '?');
    $c = htmlspecialchars((string)($cache['error']['code'] ?? '?'));
    echo "<div class='proxinfo' style='color:#f90'>⚠️ Erreur API ($w) — code $c. Affichage basé sur le dernier cache disponible.</div>";
  }

  // Pas de cache -> squelette
  if (!$cache) {
    echo "<div class='proxinfo'>Chargement des données…</div>";
    echo "<div class='vmgrid'><div class='skel'></div><div class='skel'></div><div class='skel'></div></div>";
    echo "</div></div>";
    continue;
  }

  /* -------------------------------------------------------------- */
  /*  VOLET DÉROULANT "CRÉER UNE VM" (Vitrine V3)                   */
  /* -------------------------------------------------------------- */
  if ($SHOW_CREATE_FORM) {
    $nodeDefault = $cache['node'] ?? $srvName;

    // Drawer (fermé par défaut)
    echo "<div class='pv1-drawer' id='drawer-".htmlspecialchars($srvName,ENT_QUOTES)."'>
            <form class='pv1-form' onsubmit='return false' aria-disabled='true'>
              <h4 class='pv1-lock'>🔒 Créer une VM (démo)</h4>
              <div class='pv1-grid'>
                <div class='pv1-field'>
                  <label>Node</label>
                  <input type='text' value='".htmlspecialchars($nodeDefault,ENT_QUOTES)."' disabled>
                </div>
                <div class='pv1-field'>
                  <label>Nom de la VM</label>
                  <input type='text' placeholder='ex: debian-prod' disabled>
                </div>
                <div class='pv1-field'>
                  <label>VMID</label>
                  <input type='number' min='100' step='1' placeholder='ex: 110' disabled>
                </div>
                <div class='pv1-field'>
                  <label>vCPU</label>
                  <input type='number' min='1' step='1' value='2' disabled>
                </div>
                <div class='pv1-field'>
                  <label>RAM (Mo)</label>
                  <input type='number' min='256' step='256' value='2048' disabled>
                </div>
                <div class='pv1-field'>
                  <label>Disque (Go)</label>
                  <input type='number' min='8' step='1' value='20' disabled>
                </div>
                <div class='pv1-field'>
                  <label>Bridge réseau</label>
                  <input type='text' placeholder='ex: vmbr0' disabled>
                </div>
                <div class='pv1-field'>
                  <label>ISO / Modèle</label>
                  <input type='text' placeholder='ex: local:iso/debian-12.iso' disabled>
                </div>
              </div>
              <div class='pv1-actions'>
                <button class='pv1-btn' type='button' data-demo-create>Créer la VM</button>
                <span class='pv1-chip'>Fonction premium</span>
                <span class='pv1-note'>Disponible en <strong>V3</strong> (création directe depuis le dashboard). La <strong>V2</strong> apporte le contrôle des VM.</span>
              </div>
            </form>
          </div>
          <div class='pv1-drawer-toggle' data-drawer-toggle='drawer-".htmlspecialchars($srvName,ENT_QUOTES)."'>
            ➕ Créer une VM
            <span class='chev'>▾</span>
          </div>";
  }

  // ---- RESSOURCES DU NŒUD ----
  $status = $cache['status'] ?? null;
  if ($status) {
    $cpuUsage = isset($status['cpu']) ? round($status['cpu'] * 100, 1) : 0;
    $memUsed  = isset($status['memory']['used'])  ? round($status['memory']['used']  / (1024*1024*1024), 1) : 0;
    $memTotal = isset($status['memory']['total']) ? round($status['memory']['total'] / (1024*1024*1024), 1) : 0;
    echo "<div class='proxinfo'>🧠 RAM utilisée : {$memUsed} / {$memTotal} Go</div>";
    echo "<div class='proxinfo'>⚙️ CPU utilisé : {$cpuUsage}%</div>";
  }

  // ---- VMs ----
  $vmsArr = $cache['vms'] ?? [];
  if ($vmsArr) {
    echo "<div class='proxinfo'>💾 Machines virtuelles :</div><div class='vmgrid'>";

    usort($vmsArr, function($a,$b){
      if (($a['status']??'') !== ($b['status']??'')) return (($a['status']??'')==='running')?-1:1;
      return ($a['vmid']??0) <=> ($b['vmid']??0);
    });

    foreach ($vmsArr as $vm) {
      $name    = $vm['name'] ?? ("VM-".($vm['vmid']??'?'));
      $short   = (strlen($name)>12) ? (substr($name,0,12).'...') : $name;
      $vmid    = (int)($vm['vmid'] ?? 0);
      $running = (($vm['status']??'')==='running');
      $color   = $running ? "#0f0" : "#f00";

      $cpu = isset($vm['cpu']) ? round($vm['cpu']*100,1) : 0;
      $ramUsed = isset($vm['mem']) ? round($vm['mem']/(1024*1024),1) : 0;
      $ramMax  = (isset($vm['maxmem']) && $vm['maxmem']>0) ? round($vm['maxmem']/(1024*1024),1) : 0;
      $ramStr  = $ramMax ? "$ramUsed / $ramMax Mo" : "$ramUsed Mo";
      $ramColor = ($ramMax>0 && ($ramUsed/$ramMax)>0.8) ? "#f80" : "#ccc";
      $cpuColor = ($cpu>80) ? "#f80" : "#ccc";

      $nodeForVm = $vm['node'] ?? ($cache['node'] ?? $srvName);

      // IDs uniques par VM: node+vmid
      $idBase  = preg_replace('/[^a-zA-Z0-9_-]/','_', $nodeForVm . '_' . $vmid);
      $modalId = "pv1_modal_"  . $idBase;

      echo "<div class='vmitem'>";
      echo "  <div class='vmname' title='".htmlspecialchars($name,ENT_QUOTES)."'>
                <span class='vmstatus' style='background:$color'></span>
                <span style='flex:1;'>".htmlspecialchars($short,ENT_QUOTES)."</span>
                <span style='color:$color;font-size:12px;margin-left:4px;'>(".htmlspecialchars((string)$vmid,ENT_QUOTES).")</span>
              </div>";
      echo "  <div style='height:3px;'></div>";
      echo "  <div style='font-size:11px;line-height:1.3;color:$ramColor;'>🧠 RAM : $ramStr</div>";
      echo "  <div style='font-size:11px;color:$cpuColor;'>⚙️ CPU : $cpu%</div>";

      echo "  <div class='vmctrl'>";
      if ($ENABLE_CONSOLE) {
        $btnClass = $running ? "pv1-console-btn active" : "pv1-console-btn";
        $disabled = $running ? "" : "disabled";
        echo "    <button class='$btnClass'
                          data-node='".htmlspecialchars($nodeForVm,ENT_QUOTES)."'
                          data-vmid='".(int)$vmid."'
                          data-modal='$modalId' $disabled>🖥️ Console</button>";
      }
      echo "    <button title='Pause : version premium'>⏸</button>";
      echo "    <button title='Stop : version premium'>⏹</button>";
      echo "  </div>";
      echo "</div>";

      if ($ENABLE_CONSOLE) {
        echo "<div class='pv1-modal' id='$modalId'>
                <div class='pv1-modal-header'>
                  <div>Console VM #".(int)$vmid." (".htmlspecialchars($nodeForVm,ENT_QUOTES).")</div>
                  <button class='pv1-close' data-target='$modalId'>✖</button>
                </div>
                <div class='pv1-modal-body'>
                  <iframe src='' allow='clipboard-read; clipboard-write'></iframe>
                </div>
              </div>";
      }
    }
    echo "</div>";
  }

  echo "<div class='pv1-toast' data-toast>✨ Fonction disponible en V3 (création directe de VM depuis le dashboard). La V2 apportera le contrôle de vos VM.</div>";

  echo "</div></div>";
}
?>

<script>
(function(){
  const root = document.currentScript.closest('.module, .module-container, body');

  // Toggle volets "Créer une VM"
  root.addEventListener('click', (e)=>{
    const tog = e.target.closest('[data-drawer-toggle]');
    if (!tog) return;
    const id = tog.getAttribute('data-drawer-toggle');
    const drawer = root.querySelector('#'+CSS.escape(id));
    if (!drawer) return;
    drawer.classList.toggle('open');
    // inverse la flèche
    const chev = tog.querySelector('.chev');
    if (chev) chev.style.transform = drawer.classList.contains('open') ? 'rotate(180deg)' : 'none';
  });

  // Ouvrir/Fermer console
  root.addEventListener('click', (e)=>{
    const btn = e.target.closest('.pv1-console-btn');
    if (btn) {
      const node = btn.dataset.node;
      const vmid = btn.dataset.vmid;
      const modalId = btn.dataset.modal;
      const modal = root.querySelector('#'+modalId);
      const iframe = modal ? modal.querySelector('iframe') : null;
      if (modal && iframe) {
        iframe.src = `modules/proxv1/console.php?node=${encodeURIComponent(node)}&vmid=${encodeURIComponent(vmid)}`;
        modal.style.display = 'flex';
      }
      return;
    }
    const close = e.target.closest('.pv1-close');
    if (close) {
      const id = close.getAttribute('data-target');
      const modal = root.querySelector('#'+id);
      if (modal) {
        const iframe = modal.querySelector('iframe');
        if (iframe) iframe.src = 'about:blank';
        modal.style.display = 'none';
      }
    }
  });

  // Clique sur "Créer la VM" (vitrine V3)
  root.addEventListener('click', (e)=>{
    const demoBtn = e.target.closest('[data-demo-create]');
    if (!demoBtn) return;
    const card = demoBtn.closest('.vmbox') || root;
    const toast = card.querySelector('[data-toast]') || root.querySelector('[data-toast]');
    if (toast){
      toast.style.display='block';
      clearTimeout(window.__pv1_toast_t);
      window.__pv1_toast_t = setTimeout(()=>{ toast.style.display='none'; }, 3000);
    }
  });

  // Rafraîchissement contrôlé du cache (si besoin)
  const NEED = <?php echo $needUpdate ? 'true' : 'false'; ?>;
  if (!NEED) return;

  const KEY='proxv1_last_bg_refresh';
  const NOW=Date.now();
  const TTL=15000; // 15 s
  const last = parseInt(sessionStorage.getItem(KEY)||'0',10);

  if (NOW - last >= TTL) {
    sessionStorage.setItem(KEY, String(NOW));
    fetch('modules/proxv1/proxv1_fetch.php', {cache:'no-store'})
      .then(r=>r.json())
      .then(_=> setTimeout(()=>location.reload(), 700))
      .catch(()=>{ /* on reste sur le cache */ });
  }
})();
</script>
