<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
$node = isset($_GET['node']) ? preg_replace('~[^A-Za-z0-9._-]~','', $_GET['node']) : '';
$vmid = isset($_GET['vmid']) ? (int)$_GET['vmid'] : 0;
$type = isset($_GET['type']) ? strtolower($_GET['type']) : 'qemu'; // 'qemu' ou 'lxc'
if ($type !== 'lxc') $type = 'qemu';
if (!$node || !$vmid) { http_response_code(400); echo "Paramètres invalides."; exit; }
$cfgFile = __DIR__ . "/cfg/proxv1.json";
if (!file_exists($cfgFile)) { http_response_code(500); echo "Config Proxmox (module) manquante."; exit; }
$servers = json_decode(file_get_contents($cfgFile), true);
if (!is_array($servers) || !count($servers)) { http_response_code(500); echo "Config Proxmox (module) invalide."; exit; }
$node_lc = strtolower($node);
$server = null;
foreach ($servers as $s) {
  $sname = strtolower(trim($s['name'] ?? ''));
  $sip   = trim($s['ip'] ?? '');
  if ($sname && $sname === $node_lc) { $server = $s; break; }
  if ($sip   && $sip   === $node)    { $server = $s; break; }
}
if (!$server) $server = $servers[0];
$host = rtrim($server['host'] ?? '', '/');
$ip   = trim($server['ip'] ?? '');
$port = (string)($server['port'] ?? '8006');
if (!$host) {
  if (!$ip) { http_response_code(500); echo "Config serveur incomplète : host/ip manquant."; exit; }
  $host = 'https://' . $ip . ':' . $port;
}
$verify = isset($server['verify_ssl']) ? (bool)$server['verify_ssl'] : false;
$token_id     = $server['token_id']     ?? '';
$token_secret = $server['token_secret'] ?? ($server['secret'] ?? '');
if (!$token_id || !$token_secret) { http_response_code(500); echo "Config serveur incomplète : token_id/token_secret manquant."; exit; }
$endpoint = $host . "/api2/json/nodes/{$node}/{$type}/{$vmid}/vncproxy";
$ch = curl_init($endpoint);
curl_setopt_array($ch, [
  CURLOPT_POST            => true,
  CURLOPT_HTTPHEADER      => ["Authorization: PVEAPIToken={$token_id}={$token_secret}"],
  CURLOPT_POSTFIELDS      => http_build_query(['websocket'=>1]),
  CURLOPT_RETURNTRANSFER  => true,
  CURLOPT_SSL_VERIFYPEER  => $verify,
  CURLOPT_SSL_VERIFYHOST  => $verify ? 2 : 0,
  CURLOPT_TIMEOUT         => 12,
]);
$resp = curl_exec($ch);
$err  = curl_error($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
if ($code !== 200 || !$resp) { http_response_code(502); echo "Échec vncproxy ($code): " . htmlspecialchars($err ?: $resp); exit; }
$j = json_decode($resp, true);
$data = $j['data'] ?? null;
if (!$data || empty($data['port']) || empty($data['ticket'])) { http_response_code(502); echo "Réponse vncproxy invalide."; exit; }
$port_ws = $data['port'];
$ticket  = $data['ticket'];
$secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
setcookie("PVEAuthCookie", $ticket, 0, "/", "", $secure, true);
$wsBase = preg_replace('~^http~','ws', $host);
$wsUrl  = $wsBase . "/api2/json/nodes/{$node}/{$type}/{$vmid}/vncwebsocket?port=" . urlencode($port_ws) . "&vncticket=" . urlencode($ticket);
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Console VM #<?php echo (int)$vmid; ?> (<?php echo htmlspecialchars($node,ENT_QUOTES); ?>)</title>
<style>
  html,body{height:100%;margin:0;background:#000;overflow:hidden}
  #screen{width:100%;height:100%;display:block}
  #topbar{position:absolute;left:10px;top:10px;z-index:2;background:rgba(0,0,0,.5);color:#ddd;padding:6px 10px;border-radius:8px;font:14px/1.2 system-ui,Segoe UI,Roboto,Arial}
  #status{margin-left:8px;opacity:.8}
</style>
</head>
<body>
  <div id="topbar">noVNC <span id="status">…</span></div>
  <canvas id="screen"></canvas>
  <script type="module">
    import { RFB } from "./novnc/rfb.js";
    const wsUrl = <?php echo json_encode($wsUrl); ?>;
    const setStatus = (t) => {
      let s = document.getElementById('status');
      if (!s) { s = document.createElement('span'); s.id='status'; document.body.appendChild(s); }
      s.textContent = t;
    };
    const canvas = document.getElementById('screen');
    const fit = () => {
      canvas.width  = document.documentElement.clientWidth;
      canvas.height = document.documentElement.clientHeight;
    };
    new ResizeObserver(fit).observe(document.documentElement);
    window.addEventListener('resize', fit);
    fit();
    try {
      const rfb = new RFB(canvas, wsUrl, { credentials: { password: "" } });
      rfb.viewOnly = false;
      rfb.scaleViewport = true;
      rfb.background = '#000000';
      rfb.addEventListener('connect',   () => setStatus('connecté'));
      rfb.addEventListener('disconnect',() => setStatus('déconnecté'));
      rfb.addEventListener('credentialsrequired', () => setStatus('auth requise'));
      rfb.addEventListener('securityfailure',     () => setStatus('échec sécurité'));
    } catch (e) {
      console.error(e);
      setStatus('erreur: ' + e.message);
    }
  </script>
</body>
</html>
