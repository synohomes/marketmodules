<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['user']['email']) || $_SESSION['user']['role_system'] !== 'admin') {
    echo "<div style='color:red;padding:10px'>⛔ Accès réservé à l'administrateur</div>";
    return;
}

$cfgFile = __DIR__ . "/cfg/proxv1.json";
$keyDir  = "/var/lib/domydesk_keys";
$keyFile = $keyDir . "/proxv1.key";

if (!is_dir(dirname($cfgFile))) @mkdir(dirname($cfgFile), 0775, true);

// Charger configuration existante
$config = file_exists($cfgFile) ? json_decode(file_get_contents($cfgFile), true) : [];

// Traitement formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $servers = [];
    $useCrypto = isset($_POST['encrypt_api']);

    if ($useCrypto && !extension_loaded('sodium')) {
        echo "<div style='color:red'>❌ Libsodium non disponible sur ce serveur, chiffrement impossible.</div>";
        $useCrypto = false;
    }

    if ($useCrypto && !is_dir($keyDir)) {
        @mkdir($keyDir, 0700, true);
    }

    if ($useCrypto && !file_exists($keyFile)) {
        $key = sodium_crypto_secretbox_keygen();
        file_put_contents($keyFile, $key);
        chmod($keyFile, 0600);
    } elseif ($useCrypto) {
        $key = file_get_contents($keyFile);
    }

    if (!empty($_POST['name'])) {
        foreach ($_POST['name'] as $i => $name) {
            if (trim($name) === '') continue;
            $srv = [
                "name"     => trim($name),
                "ip"       => trim($_POST['ip'][$i]),
                "port"     => trim($_POST['port'][$i]),
                "token_id" => trim($_POST['token_id'][$i]),
                "secret"   => trim($_POST['secret'][$i]),
                "encrypted"=> $useCrypto
            ];

            if ($useCrypto && !empty($srv['secret'])) {
                $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
                $cipher = sodium_crypto_secretbox($srv['secret'], $nonce, $key);
                $srv['secret'] = base64_encode($nonce . $cipher);
            }

            $servers[] = $srv;
        }
    }
    file_put_contents($cfgFile, json_encode($servers, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
    echo "<div style='color:lime;padding:10px'>✅ Configuration sauvegardée";
    if ($useCrypto) {
        echo "<br>🔑 Clé de chiffrement stockée dans : <code>$keyFile</code>";
    }
    echo "</div>";
    $config = $servers;
}
?>
<style>
.proxv1-form {
    margin-left: 50px; /* décale le formulaire vers la droite */
    max-width: 600px;  /* évite que ça s’étale trop large */
}
.proxv1-container {
    display: flex;
    gap: 20px;
}
.proxv1-form {
    flex: 1;
    max-width: 500px;
}
.proxv1-apercu {
    flex: 1;
    background: rgba(0,0,0,0.2);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 10px;
    padding: 10px;
    color: #ffae7a;
    cursor: pointer;
    overflow-y: auto;
    max-height: 450px;
    font-size: 14px;
}
.proxv1-apercu:hover {
    background: rgba(255,255,255,0.05);
}

/* Popup */
#prox_help {
    display: none;
    position: fixed;
    inset: 0;
    z-index: 9999;
    background: rgba(0,0,0,.6);
}
#prox_help .box {
    position: relative;
    margin: 50px auto;
    max-width: 900px;
    background: #111;
    border: 1px solid #555;
    border-radius: 10px;
    padding: 18px;
    color: #ddd;
}
#prox_help .close {
    position: absolute;
    top: 8px;
    right: 12px;
    background: none;
    border: none;
    color: #ccc;
    font-size: 20px;
    cursor: pointer;
}
#prox_help h1 { color: #ffae7a; }
#prox_help h2 { color: #ffa257; }
#prox_help code {
    background: #1c1c1c;
    border: 1px solid #333;
    padding: 2px 6px;
    border-radius: 6px;
    color: #c9f;
}
</style>

<div class="proxv1-container">
    <!-- Formulaire -->
    <form class="proxv1-form" method="post" action="modules/proxv1/proxv1save.php">
        <label>Nom :</label>
        <input type="text" name="name" required>

        <label>IP :</label>
        <input type="text" name="ip" required>

        <label>Port :</label>
        <input type="number" name="port" required>

        <label>Token ID (ex: root@pam!mon_token) :</label>
        <input type="text" name="token_id" required>

        <label>Clé secrète (secret) :</label>
        <input type="text" name="secret" required>

        <label style="display:flex;align-items:center;gap:6px;margin-top:8px;">
            <input type="checkbox" name="encrypt_api" value="1">
            🔒 Chiffrer la clé API (libsodium)
        </label>
        <div style="font-size:12px;color:#aaa;margin:4px 0 10px;">
            La clé de chiffrement sera stockée dans <code>/var/lib/domydesk_keys/proxv1.key</code>.
        </div>

        <button type="submit">💾 Enregistrer les modifications</button>
    </form>

    <!-- Aperçu procédure -->
    <div class="proxv1-apercu" onclick="document.getElementById('prox_help').style.display='block'">
        <h3>🔐 Procédure API Proxmox</h3>
        <p>1️⃣ Créer un utilisateur dédié dans <b>Datacenter &gt; Permissions &gt; Users</b></p>
        <p>2️⃣ Lui donner le rôle <b>Administrator</b> sur <code>/</code> avec Propagate.</p>
        <p>3️⃣ Créer un <b>API Token</b> pour cet utilisateur.</p>
        <p>4️⃣ Copier le <b>Token ID</b> et le <b>Secret</b> ici.</p>
        <p style="color:#ccc;font-size:12px;">💡 Cliquez pour voir la procédure détaillée.</p>
    </div>
</div>

<!-- Popup -->
<div id="prox_help">
    <div class="box">
        <button class="close" onclick="document.getElementById('prox_help').style.display='none'">×</button>
        <h1>Procédure complète API Proxmox</h1>

        <h2>1. Créer un utilisateur</h2>
        <ul>
            <li>Menu : <b>Datacenter &gt; Permissions &gt; Users</b></li>
            <li>User : <code>DMDadminProx</code>, Realm : <code>pve</code></li>
            <li>Mot de passe fort</li>
            <li>Ajouter</li>
        </ul>

        <h2>2. Donner les permissions</h2>
        <ul>
            <li>Menu : <b>Datacenter &gt; Permissions</b></li>
            <li>Path : <code>/</code></li>
            <li>User : <code>DMDadminProx@pve</code></li>
            <li>Role : <code>Administrator</code></li>
            <li>Propagate : ✅</li>
        </ul>

        <h2>3. Créer un API Token</h2>
        <ul>
            <li>Menu : <b>Datacenter &gt; Permissions &gt; API Tokens</b></li>
            <li>User : <code>DMDadminProx@pve</code></li>
            <li>Token ID : <code>ProxV1</code></li>
            <li>Privilege Separation : ✅</li>
        </ul>

        <h2>4. Utilisation</h2>
        <p><b>Token ID :</b> <code>DMDadminProx@pve!ProxV1</code></p>
        <p><b>Secret :</b> (affiché une seule fois)</p>
        <p><b>Test :</b></p>
        <pre><code>curl -k -H "Authorization: PVEAPIToken=DMDadminProx@pve!ProxV1=SECRET" \
https://IP_PROXMOX:8006/api2/json/nodes</code></pre>
    </div>
</div>

