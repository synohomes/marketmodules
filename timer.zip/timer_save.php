<?php
session_start();
$email = $_SESSION['user']['email'] ?? '';
$userDir = __DIR__ . '/../../users/profiles/' . $email . '/timer';

if (!is_dir($userDir)) mkdir($userDir, 0777, true);

$data = json_decode(file_get_contents("php://input"), true);
file_put_contents("$userDir/timers.json", json_encode($data, JSON_PRETTY_PRINT));
