<?php
session_start();

$email   = $_SESSION['user']['email'] ?? '';
$userDir = __DIR__ . '/../../users/profiles/' . $email;

/* === AJOUT : récupérer le thème courant et lier son style.css === */
$theme      = 'default';
$themeJson  = $userDir . '/theme.json';
if (is_file($themeJson)) {
    $tdata = json_decode(file_get_contents($themeJson), true);
    if (!empty($tdata['theme']) && is_file(__DIR__ . '/../../theme/' . $tdata['theme'] . '/style.css')) {
        $theme = basename($tdata['theme']);
    }
}
$themeFile = __DIR__ . "/../../theme/$theme/style.css";
$baseUrl   = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\'); // ex: /domydesk/modules/timer -> /domydesk/modules/timer
// remonter proprement à la racine web avant /theme :
$baseRoot  = rtrim(dirname($baseUrl . '/..' . '/..'), '/\\'); // equivalent de ../../ en URL
$themeHref = $baseRoot . "/theme/" . rawurlencode($theme) . "/style.css";
if (is_file($themeFile)) {
    $themeHref .= '?v=' . filemtime($themeFile); // cache-busting
}
/* === /AJOUT === */

$dataFile = "$userDir/timer/timers.json";
if (!is_dir(dirname($dataFile))) mkdir(dirname($dataFile), 0777, true);
if (!file_exists($dataFile)) file_put_contents($dataFile, '[]');
$timers = json_decode(file_get_contents($dataFile), true) ?: [];
?>
<!-- lien du thème -->
<link rel="stylesheet" href="<?= htmlspecialchars($themeHref) ?>">

<div id="timer-wrapper"></div>
<button id="add-timer-btn" class="timer-add-btn">➕ Ajouter</button>

<link rel="stylesheet" href="modules/timer/style.css" />
<script>
(() => {
const timers = <?= json_encode($timers) ?>;
const wrapper = document.getElementById('timer-wrapper');
const btnAdd = document.getElementById('add-timer-btn');

function saveTimers() {
  fetch("modules/timer/timer_save.php", {
    method: "POST",
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(timers)
  });
}

function format(sec) {
  const h = String(Math.floor(sec / 3600)).padStart(2,'0');
  const m = String(Math.floor((sec % 3600) / 60)).padStart(2,'0');
  const s = String(sec % 60).padStart(2,'0');
  return `${h}:${m}:${s}`;
}

function createBox(t, index) {
  const box = document.createElement('div');
  box.className = 'timer-box';

  const del = document.createElement('button');
  del.className = 'timer-delete';
  del.textContent = '×';
  del.onclick = () => {
    timers.splice(index, 1);
    wrapper.removeChild(box);
    saveTimers();
  };
  box.appendChild(del);

  const display = document.createElement('div');
  display.className = 'timer-display';
  box.appendChild(display);

  const inputs = document.createElement('div');
  inputs.className = 'timer-inputs';

  const hh = document.createElement('input');
  const mm = document.createElement('input');
  const ss = document.createElement('input');
  [hh, mm, ss].forEach(i => {
    i.type = 'number'; i.min = 0; i.max = 99;
    i.value = '00';
    inputs.appendChild(i);
  });

  box.appendChild(inputs);

  const controls = document.createElement('div');
  controls.className = 'timer-controls';

  const btnSet = document.createElement('button');
  btnSet.textContent = '⏎';
  btnSet.onclick = () => {
    const h = parseInt(hh.value)||0, m = parseInt(mm.value)||0, s = parseInt(ss.value)||0;
    t.total = h*3600 + m*60 + s;
    t.start = null;
    update();
    saveTimers();
  };

  const btnPlay = document.createElement('button');
  btnPlay.textContent = '▶️';
  btnPlay.onclick = () => {
    if (!t.start && t.total > 0) {
      t.start = Date.now();
      saveTimers();
    }
  };

  const btnPause = document.createElement('button');
  btnPause.textContent = '⏸️';
  btnPause.onclick = () => {
    if (t.start) {
      const elapsed = Math.floor((Date.now() - t.start)/1000);
      t.total = Math.max(0, t.total - elapsed);
      t.start = null;
      update();
      saveTimers();
    }
  };

  const btnReset = document.createElement('button');
  btnReset.textContent = '🔁';
  btnReset.onclick = () => {
    t.start = null;
    t.total = 0;
    update();
    saveTimers();
  };

  controls.append(btnSet, btnPlay, btnPause, btnReset);
  box.appendChild(controls);

  function update() {
    let sec = t.total;
    if (t.start) sec = Math.max(0, t.total - Math.floor((Date.now() - t.start)/1000));
    display.textContent = format(sec);
  }

  setInterval(update, 1000);
  update();
  wrapper.appendChild(box);
}

btnAdd.onclick = () => {
  const newTimer = { total: 0, start: null };
  timers.push(newTimer);
  createBox(newTimer, timers.length - 1);
  saveTimers();
};

timers.forEach((t, i) => createBox(t, i));
})();
</script>
