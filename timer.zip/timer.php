<?php
session_start();
$email   = $_SESSION['user']['email'] ?? '';
$userDir = __DIR__ . '/../../users/profiles/' . $email;
$theme      = 'default';
$themeJson  = $userDir . '/theme.json';
if (is_file($themeJson)) {
    $tdata = json_decode(file_get_contents($themeJson), true);
    if (!empty($tdata['theme']) && is_file(__DIR__ . '/../../theme/' . $tdata['theme'] . '/style.css')) {
        $theme = basename($tdata['theme']);
    }
}
$themeFile = __DIR__ . "/../../theme/$theme/style.css";
$baseUrl   = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$baseRoot  = rtrim(dirname($baseUrl . '/..' . '/..'), '/\\');
$themeHref = $baseRoot . "/theme/" . rawurlencode($theme) . "/style.css";
if (is_file($themeFile)) $themeHref .= '?v=' . filemtime($themeFile);
$dataFile = "$userDir/timer/timers.json";
if (!is_dir(dirname($dataFile))) mkdir(dirname($dataFile), 0777, true);
if (!file_exists($dataFile)) file_put_contents($dataFile, '[]');
$timers = json_decode(file_get_contents($dataFile), true) ?: [];
?>
<link rel="stylesheet" href="<?= htmlspecialchars($themeHref) ?>">
<div id="timer-wrapper"></div>
<div style="margin-top:10px">
  <button id="add-timer-btn" title="Ajouter un bloc">➕ Ajouter</button>
</div>
<script>
const timerSound = new Audio("modules/timer/sound/bip.wav");
timerSound.preload = "auto";
let audioUnlocked = false;
function unlockAudioOnce(){
  if (audioUnlocked) return;
  timerSound.play().then(()=>{
    timerSound.pause();
    timerSound.currentTime = 0;
    audioUnlocked = true;
  }).catch(()=>{});
}
function playTimerSound(){
  try {
    timerSound.currentTime = 0;
    timerSound.play();
  } catch(e){ console.warn("Son non joué:", e); }
}

(() => {
  const timers  = <?= json_encode($timers, JSON_UNESCAPED_UNICODE) ?>;
  const wrapper = document.getElementById('timer-wrapper');
  const btnAdd  = document.getElementById('add-timer-btn');

  function debounce(fn, wait=300){
    let t; return (...args)=>{ clearTimeout(t); t=setTimeout(()=>fn(...args), wait); };
  }
  function saveTimers() {
    fetch("modules/timer/timer_save.php", {
      method: "POST",
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(timers)
    }).catch(()=>{});
  }
  const saveTimersDebounced = debounce(saveTimers, 400);

  function fmt(sec){
    sec = Math.max(0, Math.floor(sec||0));
    const h = String(Math.floor(sec/3600)).padStart(2,'0');
    const m = String(Math.floor((sec%3600)/60)).padStart(2,'0');
    const s = String(sec%60).padStart(2,'0');
    return `${h}:${m}:${s}`;
  }

  function createBox(t, index){
    if (!t.mode) t.mode = 'timer';
    if (t.mode === 'timer') { t.total  = typeof t.total  === 'number' ? t.total  : 0; }
    else                   { t.elapsed = typeof t.elapsed === 'number' ? t.elapsed : 0; }
    if (typeof t.label !== 'string') t.label = '';
    t._lastSec = undefined;
    t._beeped  = false;
    const box = document.createElement('div');
    box.style.borderTop  = '1px solid var(--primary-dark, rgba(255,255,255,0.2))';
    box.style.marginTop  = '12px';
    box.style.paddingTop = '10px';
    const head = document.createElement('div');
    head.style.display = 'flex';
    head.style.alignItems = 'center';
    head.style.gap = '8px';
    const modeBtn = document.createElement('button');
    modeBtn.title = t.mode === 'timer' ? 'Mode: Timer (cliquer pour Chronomètre)' : 'Mode: Chronomètre (cliquer pour Timer)';
    modeBtn.textContent = (t.mode === 'timer') ? '⏳' : '⏱️';
    const nameWrap = document.createElement('div');
    nameWrap.style.display = 'flex';
    nameWrap.style.alignItems = 'center';
    nameWrap.style.gap = '6px';
    const nameInput = document.createElement('input');
    nameInput.type = 'text';
    nameInput.value = t.label || '';
    nameInput.placeholder = (t.mode === 'timer') ? 'Nom du timer' : 'Nom du chrono';
    nameInput.title = 'Renommer (double-clic pour éditer, Entrée/blur pour valider)';
    nameInput.readOnly = true;
    nameInput.style.fontSize = '0.9em';
    nameInput.style.padding  = '2px 6px';
    nameInput.style.minWidth = '10ch';
    nameInput.style.maxWidth = '24ch';
    const editBtn = document.createElement('button');
    editBtn.title = 'Renommer';
    editBtn.textContent = '✎';
    function enableEdit(){ nameInput.readOnly = false; nameInput.focus(); nameInput.select(); }
    function confirmEdit(){
      if (nameInput.readOnly) return;
      nameInput.readOnly = true;
      t.label = nameInput.value.trim();
      saveTimersDebounced();
    }
    editBtn.onclick = enableEdit;
    nameInput.ondblclick = enableEdit;
    nameInput.addEventListener('keydown', (e)=>{
      if (e.key === 'Enter') { e.preventDefault(); confirmEdit(); }
      if (e.key === 'Escape') { e.preventDefault(); nameInput.value = t.label||''; nameInput.readOnly = true; }
    });
    nameInput.addEventListener('blur', confirmEdit);
    nameWrap.append(nameInput, editBtn);
    const display = document.createElement('div');
    display.style.fontWeight = '700';
    const del = document.createElement('button');
    del.title = 'Supprimer';
    del.textContent = '×';
    del.style.marginLeft = 'auto';
    del.onclick = () => {
      timers.splice(index, 1);
      wrapper.removeChild(box);
      saveTimers();
    };
    [modeBtn, del, editBtn].forEach(btn => {
      btn.style.padding   = '2px 6px';
      btn.style.fontSize  = '0.85em';
      btn.style.lineHeight= '1.2';
      btn.style.minWidth  = 'auto';
    });
    head.append(modeBtn, nameWrap, display, del);
    box.appendChild(head);
    const area = document.createElement('div');
    area.style.display = 'flex';
    area.style.flexDirection = 'column';
    area.style.gap = '6px';
    area.style.marginTop = '8px';
    const inputsWrap = document.createElement('div');
    inputsWrap.style.display = 'flex';
    inputsWrap.style.gap = '6px';
    inputsWrap.style.alignItems = 'center';
    const hh = document.createElement('input');
    const mm = document.createElement('input');
    const ss = document.createElement('input');
    [hh, mm, ss].forEach(i => {
      i.type='number'; i.min=0; i.max=99; i.value='00';
      i.inputMode='numeric';
      i.style.width='3.6em';
      i.style.textAlign='center';
      i.style.fontSize = '0.9em';
      i.style.padding = '2px';
    });
    inputsWrap.append(hh, mm, ss);
    const controls = document.createElement('div');
    controls.style.display = 'flex';
    controls.style.gap = '6px';
    controls.style.justifyContent = 'center';
    const bSet   = document.createElement('button'); bSet.title='Définir (Timer)'; bSet.textContent='⏎';
    const bPlay  = document.createElement('button'); bPlay.title='Démarrer';       bPlay.textContent='▶️';
    const bPause = document.createElement('button'); bPause.title='Pause';          bPause.textContent='⏸️';
    const bReset = document.createElement('button'); bReset.title='Réinitialiser';  bReset.textContent='🔁';
    [bSet, bPlay, bPause, bReset].forEach(btn => {
      btn.style.padding = '2px 8px';
      btn.style.fontSize = '0.9em';
      btn.style.lineHeight = '1.2';
      btn.style.minWidth = 'auto';
    });
    controls.append(bSet, bPlay, bPause, bReset);
    area.append(inputsWrap, controls);
    box.appendChild(area);
    function vis(){
      const isTimer = (t.mode === 'timer');
      inputsWrap.style.display = isTimer ? '' : 'none';
      bSet.style.display       = isTimer ? '' : 'none';
      nameInput.placeholder    = isTimer ? 'Nom du timer' : 'Nom du chrono';
    }
    function update(){
      let sec;
      if (t.mode === 'timer') {
        sec = t.total||0;
        if (t.start) {
          sec = Math.max(0, (t.total||0) - Math.floor((Date.now()-t.start)/1000));
          if (sec <= 0) {
            t.total = 0;
            t.start = null;
          }
        }
      } else {
        sec = t.elapsed||0;
        if (t.start) sec = (t.elapsed||0) + Math.floor((Date.now()-t.start)/1000);
      }
      if (t.mode === 'timer') {
        if (t._lastSec === undefined) t._lastSec = sec;
        if (t._lastSec > 0 && sec === 0 && !t._beeped) {
          playTimerSound();
          t._beeped = true; 
        }
        if (sec > 0) t._beeped = false; 
        t._lastSec = sec;
      } else {
        t._lastSec = sec;
      }
      display.textContent = fmt(sec);
    }
    modeBtn.onclick = () => {
      const cur = t.mode === 'timer'
        ? (t.start ? Math.max(0, (t.total||0) - Math.floor((Date.now()-t.start)/1000)) : (t.total||0))
        : (t.start ? (t.elapsed||0) + Math.floor((Date.now()-t.start)/1000) : (t.elapsed||0));
      if (t.mode === 'timer') {
        t.mode='chrono'; t.start=null; t.elapsed=cur; delete t.total;
        modeBtn.textContent='⏱️';
        modeBtn.title='Mode: Chronomètre (cliquer pour Timer)';
      } else {
        t.mode='timer'; t.start=null; t.total=cur; delete t.elapsed;
        modeBtn.textContent='⏳';
        modeBtn.title='Mode: Timer (cliquer pour Chronomètre)';
      }
      t._beeped = false; // reset
      vis(); update(); saveTimers();
    };
    bSet.onclick = () => {
      if (t.mode !== 'timer') return;
      const H = parseInt(hh.value)||0, M = parseInt(mm.value)||0, S = parseInt(ss.value)||0;
      t.total = H*3600 + M*60 + S;
      t.start = null;
      t._beeped = false;
      update(); saveTimers();
    };
    bPlay.onclick = () => {
      unlockAudioOnce(); 
      if (t.start) return;
      if (t.mode === 'timer') {
        if ((t.total||0) > 0) { t.start = Date.now(); saveTimers(); }
      } else {
        t.start = Date.now(); saveTimers();
      }
    };
    bPause.onclick = () => {
      if (!t.start) return;
      const elapsed = Math.floor((Date.now()-t.start)/1000);
      if (t.mode === 'timer') { t.total = Math.max(0, (t.total||0) - elapsed); }
      else { t.elapsed = (t.elapsed||0) + elapsed; }
      t.start = null; update(); saveTimers();
    };
    bReset.onclick = () => {
      t.start = null;
      if (t.mode === 'timer') t.total = 0; else t.elapsed = 0;
      t._beeped = false;
      update(); saveTimers();
    };
    vis(); update();
    if (t.mode === 'timer' && (t.total||0) > 0) {
      const cur = t.total||0;
      hh.value = String(Math.floor(cur/3600)).padStart(2,'0');
      mm.value = String(Math.floor((cur%3600)/60)).padStart(2,'0');
      ss.value = String(cur%60).padStart(2,'0');
    }
    wrapper.appendChild(box);
    const iv = setInterval(update, 1000);
    box.addEventListener('DOMNodeRemoved', () => clearInterval(iv));
  }
  btnAdd.onclick = () => {
    const item = { mode:'timer', total:0, start:null, label:'Timer' };
    timers.push(item);
    createBox(item, timers.length-1);
    saveTimers();
  };
  timers.forEach((t,i)=>createBox(t,i));
})();
</script>
