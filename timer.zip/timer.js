let timers = [];
let container = null;

function createTimer(data, index) {
  const box = document.createElement('div');
  box.className = 'timer-box';

  const display = document.createElement('div');
  display.className = 'timer-display';
  box.appendChild(display);

  const inputH = document.createElement('input');
  inputH.type = 'number';
  inputH.min = 0;
  inputH.max = 99;
  inputH.placeholder = 'HH';
  inputH.value = Math.floor(data.total / 3600);

  const inputM = document.createElement('input');
  inputM.type = 'number';
  inputM.min = 0;
  inputM.max = 59;
  inputM.placeholder = 'MM';
  inputM.value = Math.floor((data.total % 3600) / 60);

  const inputS = document.createElement('input');
  inputS.type = 'number';
  inputS.min = 0;
  inputS.max = 59;
  inputS.placeholder = 'SS';
  inputS.value = data.total % 60;

  const inputZone = document.createElement('div');
  inputZone.append(inputH, document.createTextNode(" : "), inputM, document.createTextNode(" : "), inputS);
  box.appendChild(inputZone);

  const btnSet = document.createElement('button');
  btnSet.textContent = '⏎';
  btnSet.onclick = () => {
    const h = parseInt(inputH.value) || 0;
    const m = parseInt(inputM.value) || 0;
    const s = parseInt(inputS.value) || 0;
    data.total = data.remaining = h * 3600 + m * 60 + s;
    updateDisplay();
    saveTimers();
  };

  const btnStart = document.createElement('button');
  btnStart.textContent = '▶️';
  btnStart.onclick = () => {
    if (data.interval || data.remaining <= 0) return;
    data.interval = setInterval(() => {
      data.remaining--;
      updateDisplay();
      if (data.remaining <= 0) {
        clearInterval(data.interval);
        data.interval = null;
        try { new Audio('/assets/beep.mp3').play(); } catch (e) {}
      }
      saveTimers();
    }, 1000);
  };

  const btnPause = document.createElement('button');
  btnPause.textContent = '⏸️';
  btnPause.onclick = () => {
    clearInterval(data.interval);
    data.interval = null;
    saveTimers();
  };

  const btnReset = document.createElement('button');
  btnReset.textContent = '🔁';
  btnReset.onclick = () => {
    data.remaining = data.total;
    updateDisplay();
    saveTimers();
  };

  const controls = document.createElement('div');
  controls.className = 'timer-controls';
  controls.append(btnSet, btnStart, btnPause, btnReset);
  box.appendChild(controls);

  function updateDisplay() {
    const h = String(Math.floor(data.remaining / 3600)).padStart(2, '0');
    const m = String(Math.floor((data.remaining % 3600) / 60)).padStart(2, '0');
    const s = String(data.remaining % 60).padStart(2, '0');
    display.textContent = `${h}:${m}:${s}`;
  }

  updateDisplay();
  container.appendChild(box);
}

function saveTimers() {
  const toSave = timers.map(t => ({
    total: t.total,
    remaining: t.remaining
  }));
  fetch('modules/timer/timer_data.php', {
    method: 'POST',
    body: JSON.stringify(toSave)
  });
}

function loadTimers() {
  fetch('modules/timer/timer_data.php')
    .then(res => res.json())
    .then(data => {
      container.innerHTML = '';
      timers = [];
      data.forEach((t, i) => {
        t.interval = null;
        timers.push(t);
        createTimer(t, i);
      });
    });
}

document.addEventListener('DOMContentLoaded', () => {
  container = document.getElementById('timer-container');
  document.getElementById('add-timer-btn').onclick = () => {
    const t = { total: 0, remaining: 0, interval: null };
    timers.push(t);
    createTimer(t, timers.length - 1);
    saveTimers();
  };
  loadTimers();
});
