<?php
session_start();
header('Content-Type: application/json');
$email = $_SESSION['user']['email'] ?? '';
if (!$email) exit(json_encode(['error' => 'non connecté']));
$userPath = __DIR__ . "/../../users/profiles/$email";
$dataFile = "$userPath/timer.json";
if (!file_exists($userPath)) mkdir($userPath, 0777, true);
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    echo file_exists($dataFile) ? file_get_contents($dataFile) : json_encode([]);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = file_get_contents("php://input");
    file_put_contents($dataFile, $input);
    echo json_encode(['status' => 'ok']);
    exit;
}
