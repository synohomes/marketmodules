<?php
if (session_status() === PHP_SESSION_NONE) session_start();
error_reporting(E_ALL); ini_set('display_errors', 1);
header('Content-Type: application/json; charset=utf-8');
function jdie($msg, $extra = []) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>$msg]+$extra);
  exit;
}
function jok($data = []) {
  echo json_encode(['ok'=>true]+$data);
  exit;
}
$email = $_SESSION['user']['email'] ?? '';
if (!$email) jdie('AUTH');
$dir       = __DIR__ . "/../../users/profiles/$email/contact/";
$avatarDir = $dir . "avatars/";
$dataFile  = $dir . "contacts.json";
if (!is_dir($dir) && !@mkdir($dir, 0775, true)) jdie('MKDIR_DIR', ['dir'=>$dir]);
if (!is_dir($avatarDir) && !@mkdir($avatarDir, 0775, true)) jdie('MKDIR_AVATARS', ['avatars'=>$avatarDir]);
if (!file_exists($dataFile) && @file_put_contents($dataFile, "[]", LOCK_EX) === false) jdie('CREATE_JSON', ['file'=>$dataFile]);
if (!is_writable($dataFile)) @chmod($dataFile, 0666);
if (!is_writable($dataFile)) jdie('JSON_NOT_WRITABLE', ['file'=>$dataFile]);
$contacts = [];
$raw = @file_get_contents($dataFile);
if ($raw !== false && trim($raw) !== '') {
  $tmp = json_decode($raw, true);
  if (is_array($tmp)) $contacts = $tmp;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') jdie('METHOD');
if (isset($_POST['delete_contact_id'])) {
  $idDel = trim($_POST['delete_contact_id']);
  $changed = false;
  foreach ($contacts as $i=>$c) {
    if (($c['id'] ?? '') === $idDel) {
      if (!empty($c['avatar']) && file_exists($avatarDir.$c['avatar'])) @unlink($avatarDir.$c['avatar']);
      unset($contacts[$i]); $changed = true; break;
    }
  }
  if ($changed) {
    $json = json_encode(array_values($contacts), JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);
    if ($json === false) jdie('ENCODE_DELETE');
    $tmpFile = $dataFile.'.tmp';
    if (@file_put_contents($tmpFile, $json, LOCK_EX) === false || !@rename($tmpFile, $dataFile)) jdie('WRITE_DELETE');
  }
  jok(['deleted'=>$changed]);
}
if (($_POST['form_contactcfg'] ?? '') === '1' || isset($_POST['prenom'])) {

  $id         = ($_POST['id'] ?? '') ?: uniqid('c_', true);
  $prenom     = trim($_POST['prenom'] ?? '');
  $nom        = trim($_POST['nom'] ?? '');
  $mail       = trim($_POST['mail'] ?? '');
  $entreprise = trim($_POST['entreprise'] ?? '');
  $tel        = trim($_POST['tel'] ?? '');
  $avatar     = '';
  if (isset($_FILES['avatar']) && is_array($_FILES['avatar']) && ($_FILES['avatar']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
    if (($_FILES['avatar']['error'] ?? 0) !== UPLOAD_ERR_OK) {
      jdie('UPLOAD_ERR', ['code'=>$_FILES['avatar']['error']]);
    }
    if (!is_uploaded_file($_FILES['avatar']['tmp_name'])) jdie('UPLOAD_TMP');
    $ext = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
    if (!preg_match('/^(png|jpe?g|gif|webp)$/', $ext)) $ext = 'png';
    $avatarName = uniqid('av_', true).'.'.$ext;
    if (!@move_uploaded_file($_FILES['avatar']['tmp_name'], $avatarDir.$avatarName)) {
      jdie('MOVE_UPLOAD_FAIL', ['to'=>$avatarDir.$avatarName]);
    }
    $avatar = $avatarName;
  }
  $found = false;
  foreach ($contacts as &$c) {
    if (($c['id'] ?? '') === $id) {
      $c['prenom']     = $prenom;
      $c['nom']        = $nom;
      $c['mail']       = $mail;
      $c['entreprise'] = $entreprise;
      $c['tel']        = $tel;
      if ($avatar) $c['avatar'] = $avatar;
      $found = true; break;
    }
  }
  unset($c);
  if (!$found) {
    $contacts[] = [
      'id'=>$id,'prenom'=>$prenom,'nom'=>$nom,'mail'=>$mail,
      'entreprise'=>$entreprise,'tel'=>$tel,'avatar'=>$avatar
    ];
  }
  $json = json_encode(array_values($contacts), JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);
  if ($json === false) jdie('ENCODE_SAVE', ['json_last_error'=>json_last_error_msg()]);
  $tmpFile = $dataFile.'.tmp';
  if (@file_put_contents($tmpFile, $json, LOCK_EX) === false) jdie('WRITE_TMP');
  if (!@rename($tmpFile, $dataFile)) {
    $fp = @fopen($dataFile, 'wb');
    if (!$fp) jdie('OPEN_FINAL');
    @flock($fp, LOCK_EX);
    $ok = @fwrite($fp, $json) !== false;
    @fflush($fp); @flock($fp, LOCK_UN); @fclose($fp);
    if (!$ok) jdie('WRITE_FINAL');
  }
  @chmod($dataFile, 0666);
  jok(['id'=>$id]);
}
jdie('NO_ROUTE');
