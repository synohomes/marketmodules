<?php
/* Configuration du module Contact.
   On réutilise l'interface complète du module pour éviter deux logiques différentes. */
require __DIR__ . '/contact.php';
