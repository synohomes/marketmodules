<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { http_response_code(403); exit('Accès refusé'); }

$base = realpath(__DIR__ . '/../..');
if ($base === false) exit('Base introuvable');
$file = $base . "/users/profiles/$email/contact/contacts.json";
if (!file_exists($file)) exit('Aucun contact à exporter.');
$contacts = json_decode((string)@file_get_contents($file), true);
if (!is_array($contacts)) $contacts = [];

$id = trim((string)($_GET['id'] ?? ''));
if ($id !== '') {
    $contacts = array_values(array_filter($contacts, fn($c) => is_array($c) && (($c['id'] ?? '') === $id)));
}

$cols = [
    'id' => 'ID',
    'civilite' => 'Civilité',
    'prenom' => 'Prénom',
    'nom' => 'Nom',
    'surnom' => 'Surnom',
    'is_private' => 'Privé',
    'is_pro' => 'Pro',
    'relation_private' => 'Type privé',
    'relation_pro' => 'Type pro',
    'entreprise' => 'Entreprise',
    'poste' => 'Poste',
    'service' => 'Service',
    'siret' => 'SIRET',
    'mail' => 'Email principal',
    'mail2' => 'Email secondaire',
    'tel' => 'Téléphone',
    'tel2' => 'Téléphone 2',
    'adresse' => 'Adresse',
    'code_postal' => 'Code postal',
    'ville' => 'Ville',
    'pays' => 'Pays',
    'date_naissance' => 'Date de naissance',
    'statut_familial' => 'Situation familiale',
    'site_web' => 'Site web',
    'linkedin' => 'LinkedIn',
    'tags' => 'Tags',
    'notes' => 'Notes',
    'created_at' => 'Créé le',
    'updated_at' => 'Modifié le',
];

$filename = $id !== '' ? 'contact_' . preg_replace('/[^a-zA-Z0-9_-]/', '_', $id) . '.csv' : 'contacts.csv';
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
$out = fopen('php://output', 'w');
fwrite($out, "\xEF\xBB\xBF");
fputcsv($out, array_values($cols), ';');
foreach ($contacts as $c) {
    if (!is_array($c)) continue;
    $row = [];
    foreach ($cols as $key => $label) {
        $value = $c[$key] ?? '';
        if (is_bool($value)) $value = $value ? 'Oui' : 'Non';
        if ($key === 'is_private' || $key === 'is_pro') $value = !empty($value) ? 'Oui' : 'Non';
        $row[] = $value;
    }
    fputcsv($out, $row, ';');
}
fclose($out);
exit;
