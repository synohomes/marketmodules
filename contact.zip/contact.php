<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { echo "<div class='error'>⛔ Non connecté</div>"; return; }

$base = realpath(__DIR__ . '/../..');
if ($base === false) { echo "<div class='error'>⛔ Base introuvable</div>"; return; }

$dir       = $base . "/users/profiles/$email/contact";
$avatarDir = $dir . "/avatars";
$dataFile  = $dir . "/contacts.json";

if (!is_dir($dir)) @mkdir($dir, 0775, true);
if (!is_dir($avatarDir)) @mkdir($avatarDir, 0775, true);
if (!file_exists($dataFile)) @file_put_contents($dataFile, "[]", LOCK_EX);

$raw = @file_get_contents($dataFile);
$contacts = $raw ? json_decode($raw, true) : [];
if (!is_array($contacts)) $contacts = [];

function contact_h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function contact_initials(array $c): string {
    $p = trim((string)($c['prenom'] ?? ''));
    $n = trim((string)($c['nom'] ?? ''));
    $a = mb_substr($p, 0, 1, 'UTF-8') . mb_substr($n, 0, 1, 'UTF-8');
    if ($a === '') $a = mb_substr((string)($c['entreprise'] ?? '?'), 0, 2, 'UTF-8');
    return mb_strtoupper($a ?: '?', 'UTF-8');
}
function contact_sort_key(array $c): string {
    return trim((string)($c['nom'] ?? '') . ' ' . (string)($c['prenom'] ?? '') . ' ' . (string)($c['entreprise'] ?? ''));
}
function contact_letter(array $c): string {
    $key = contact_sort_key($c);
    $first = mb_strtoupper(mb_substr($key, 0, 1, 'UTF-8'), 'UTF-8');
    return preg_match('/^[A-ZÀÂÄÇÉÈÊËÎÏÔÖÙÛÜŸ]$/u', $first) ? $first : '#';
}
function contact_full_name(array $c): string {
    $name = trim((string)($c['prenom'] ?? '') . ' ' . (string)($c['nom'] ?? ''));
    return $name !== '' ? $name : ((string)($c['entreprise'] ?? '') ?: '(Sans nom)');
}
function contact_avatar_url(array $c, string $email, string $avatarDir): string {
    if (!empty($c['avatar']) && is_file($avatarDir . '/' . $c['avatar'])) {
        return 'users/profiles/' . rawurlencode($email) . '/contact/avatars/' . rawurlencode((string)$c['avatar']);
    }
    return '';
}
function contact_norm_record(array $c, string $email, string $avatarDir): array {
    $c['id'] = (string)($c['id'] ?? uniqid('c_', true));
    $c['civilite'] = (string)($c['civilite'] ?? '');
    $c['prenom'] = (string)($c['prenom'] ?? '');
    $c['nom'] = (string)($c['nom'] ?? '');
    $c['surnom'] = (string)($c['surnom'] ?? '');
    $c['is_private'] = array_key_exists('is_private', $c) ? (bool)$c['is_private'] : true;
    $c['is_pro'] = array_key_exists('is_pro', $c) ? (bool)$c['is_pro'] : ((string)($c['entreprise'] ?? '') !== '');
    $c['relation_private'] = (string)($c['relation_private'] ?? '');
    $c['relation_pro'] = (string)($c['relation_pro'] ?? '');
    $c['entreprise'] = (string)($c['entreprise'] ?? '');
    $c['poste'] = (string)($c['poste'] ?? '');
    $c['service'] = (string)($c['service'] ?? '');
    $c['siret'] = (string)($c['siret'] ?? '');
    $c['mail'] = (string)($c['mail'] ?? '');
    $c['mail2'] = (string)($c['mail2'] ?? '');
    $c['tel'] = (string)($c['tel'] ?? '');
    $c['tel2'] = (string)($c['tel2'] ?? '');
    $c['adresse'] = (string)($c['adresse'] ?? '');
    $c['code_postal'] = (string)($c['code_postal'] ?? '');
    $c['ville'] = (string)($c['ville'] ?? '');
    $c['pays'] = (string)($c['pays'] ?? '');
    $c['date_naissance'] = (string)($c['date_naissance'] ?? '');
    $c['statut_familial'] = (string)($c['statut_familial'] ?? '');
    $c['site_web'] = (string)($c['site_web'] ?? '');
    $c['linkedin'] = (string)($c['linkedin'] ?? '');
    $c['tags'] = (string)($c['tags'] ?? '');
    $c['notes'] = (string)($c['notes'] ?? '');
    $c['avatar_url'] = contact_avatar_url($c, $email, $avatarDir);
    $c['initials'] = contact_initials($c);
    $c['display_name'] = contact_full_name($c);
    $c['letter'] = contact_letter($c);
    return $c;
}

$contacts = array_map(fn($c) => is_array($c) ? contact_norm_record($c, $email, $avatarDir) : [], $contacts);
$contacts = array_values(array_filter($contacts));
usort($contacts, function ($a, $b) {
    return strcoll(mb_strtolower(contact_sort_key($a), 'UTF-8'), mb_strtolower(contact_sort_key($b), 'UTF-8'));
});

$cssFile = __DIR__ . '/contact.css';
$cssHref = 'modules/contact/contact.css' . (is_file($cssFile) ? '?v=' . filemtime($cssFile) : '');
$letters = ['Tous','#','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
$contactJson = json_encode($contacts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
?>
<link rel="stylesheet" href="<?= contact_h($cssHref) ?>">

<div class="contact-app" id="contactApp">
  <div class="contact-toolbar">
    <input class="contact-search" id="contactSearch" type="search" placeholder="Rechercher nom, société, email, téléphone, ville...">
    <select class="contact-filter" id="contactScopeFilter" aria-label="Filtrer les contacts">
      <option value="all">Tous</option>
      <option value="private">Privé</option>
      <option value="pro">Pro</option>
      <option value="client">Clients</option>
      <option value="fournisseur">Fournisseurs</option>
      <option value="prospect">Prospects</option>
    </select>
    <a class="contact-btn ghost" href="modules/contact/contact_exportcsv.php">Export CSV</a>
    <button type="button" class="contact-btn primary" id="contactNewBtn">+ Nouveau contact</button>
  </div>

  <div class="contact-layout">
    <nav class="contact-az" aria-label="Index alphabétique">
      <?php foreach ($letters as $i => $letter): ?>
        <button type="button" class="<?= $i === 0 ? 'active' : '' ?>" data-letter="<?= contact_h($letter) ?>"><?= contact_h($letter) ?></button>
      <?php endforeach; ?>
    </nav>

    <div class="contact-directory">
      <div class="contact-directory-head" aria-hidden="true">
        <span></span><span>Nom / prénom</span><span>Société</span><span>Email</span><span>Téléphone</span><span></span>
      </div>
      <div class="contact-list" id="contactList">
        <?php
        $currentLetter = null;
        foreach ($contacts as $c):
          $letter = $c['letter'];
          if ($letter !== $currentLetter):
            $currentLetter = $letter;
        ?>
          <div class="contact-letter" data-letter-title="<?= contact_h($letter) ?>"><?= contact_h($letter) ?></div>
        <?php endif; ?>
          <button type="button"
                  class="contact-row"
                  data-contact-id="<?= contact_h($c['id']) ?>"
                  data-letter="<?= contact_h($letter) ?>"
                  data-search="<?= contact_h(mb_strtolower(json_encode($c, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE), 'UTF-8')) ?>">
            <span>
              <?php if ($c['avatar_url']): ?>
                <img class="contact-avatar" src="<?= contact_h($c['avatar_url']) ?>" alt="">
              <?php else: ?>
                <span class="contact-initials"><?= contact_h($c['initials']) ?></span>
              <?php endif; ?>
            </span>
            <span>
              <span class="contact-main-name"><?= contact_h($c['display_name']) ?></span>
              <span class="contact-main-sub"><?= contact_h($c['poste'] ?: $c['relation_private'] ?: $c['relation_pro'] ?: $c['surnom']) ?></span>
            </span>
            <span class="contact-company contact-muted"><?= contact_h($c['entreprise'] ?: '—') ?></span>
            <span class="contact-muted"><?= contact_h($c['mail'] ?: $c['mail2'] ?: '—') ?></span>
            <span class="contact-phone contact-muted"><?= contact_h($c['tel'] ?: $c['tel2'] ?: '—') ?></span>
            <span class="contact-actions" onclick="event.stopPropagation()">
              <button class="contact-iconbtn contact-edit" type="button" title="Modifier" data-contact-id="<?= contact_h($c['id']) ?>">✎</button>
              <button class="contact-iconbtn contact-delete" type="button" title="Supprimer" data-contact-id="<?= contact_h($c['id']) ?>">×</button>
            </span>
          </button>
        <?php endforeach; ?>
        <?php if (empty($contacts)): ?>
          <div class="contact-empty">Aucun contact pour l’instant.</div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<script>
window.DMD_CONTACTS = <?= $contactJson ?: '[]' ?>;
(()=>{
  const contacts = Array.isArray(window.DMD_CONTACTS) ? window.DMD_CONTACTS : [];
  const byId = new Map(contacts.map(c => [String(c.id), c]));
  const list = document.getElementById('contactList');
  const search = document.getElementById('contactSearch');
  const scopeFilter = document.getElementById('contactScopeFilter');
  const az = document.querySelector('.contact-az');
  const newBtn = document.getElementById('contactNewBtn');
  let activeLetter = 'Tous';
  let zTop = 4000;

  const esc = (v)=>String(v ?? '').replace(/[&<>'"]/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[s]));
  const fullName = (c)=>String(c.display_name || [c.prenom,c.nom].filter(Boolean).join(' ') || c.entreprise || '(Sans nom)');
  const telHref = (v)=>String(v || '').replace(/[^0-9+]/g,'');
  const normalize = (v)=>String(v || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');

  function field(c, key){ return c && c[key] ? String(c[key]) : ''; }
  function info(label, value, wide=false){
    return `<div class="contact-info ${wide?'wide':''}"><label>${esc(label)}</label><div>${value ? esc(value) : '—'}</div></div>`;
  }
  function linkInfo(label, value, hrefPrefix='', wide=false){
    const v = String(value || '');
    const href = hrefPrefix === 'tel:' ? hrefPrefix + telHref(v) : hrefPrefix + v;
    return `<div class="contact-info ${wide?'wide':''}"><label>${esc(label)}</label><div>${v ? `<a href="${esc(href)}">${esc(v)}</a>` : '—'}</div></div>`;
  }
  function avatarHtml(c, big=false){
    if(c.avatar_url) return `<img class="contact-avatar" src="${esc(c.avatar_url)}" alt="">`;
    return `<span class="contact-initials">${esc(c.initials || '?')}</span>`;
  }
  function badges(c){
    const out = [];
    if(c.is_private) out.push('<span class="contact-badge">Privé</span>');
    if(c.is_pro) out.push('<span class="contact-badge">Pro</span>');
    if(c.relation_pro) out.push(`<span class="contact-badge">${esc(c.relation_pro)}</span>`);
    if(c.relation_private) out.push(`<span class="contact-badge">${esc(c.relation_private)}</span>`);
    return out.join('');
  }

  function bring(win){ win.style.zIndex = ++zTop; }
  function updatePageScrollBounds(){
    let maxRight = window.innerWidth;
    let maxBottom = window.innerHeight;
    document.querySelectorAll('.contact-window').forEach(w=>{
      const left = parseFloat(w.style.left || '0');
      const top = parseFloat(w.style.top || '0');
      maxRight = Math.max(maxRight, left + w.offsetWidth + 36);
      maxBottom = Math.max(maxBottom, top + w.offsetHeight + 36);
    });
    let spacer = document.getElementById('contactBrowserScrollSpacer');
    if(!spacer){
      spacer = document.createElement('div');
      spacer.id = 'contactBrowserScrollSpacer';
      spacer.style.position = 'absolute';
      spacer.style.left = '0';
      spacer.style.top = '0';
      spacer.style.width = '1px';
      spacer.style.height = '1px';
      spacer.style.pointerEvents = 'none';
      spacer.style.opacity = '0';
      document.body.appendChild(spacer);
    }
    spacer.style.left = maxRight + 'px';
    spacer.style.top = maxBottom + 'px';
  }
  function clampWindow(win){
    const left = Math.max(6, parseFloat(win.style.left || '0'));
    const top = Math.max(6, parseFloat(win.style.top || '0'));
    win.style.left = left + 'px';
    win.style.top = top + 'px';
    updatePageScrollBounds();
  }
  function makeMovable(win, handle){
    let dragging = false, dx = 0, dy = 0;
    const down = (e)=>{
      if(e.target.closest('button,a,input,select,textarea,label')) return;
      dragging = true; bring(win);
      const p = e.touches ? e.touches[0] : e;
      const r = win.getBoundingClientRect();
      dx = p.clientX - r.left; dy = p.clientY - r.top;
      document.addEventListener('mousemove', move);
      document.addEventListener('mouseup', up);
      document.addEventListener('touchmove', move, {passive:false});
      document.addEventListener('touchend', up);
    };
    const move = (e)=>{
      if(!dragging) return;
      const p = e.touches ? e.touches[0] : e;
      if(e.cancelable) e.preventDefault();
      win.style.left = (window.scrollX + p.clientX - dx) + 'px';
      win.style.top = (window.scrollY + p.clientY - dy) + 'px';
      clampWindow(win);
    };
    const up = ()=>{
      dragging = false;
      document.removeEventListener('mousemove', move);
      document.removeEventListener('mouseup', up);
      document.removeEventListener('touchmove', move);
      document.removeEventListener('touchend', up);
    };
    handle.addEventListener('mousedown', down);
    handle.addEventListener('touchstart', down, {passive:false});
    win.addEventListener('mousedown', ()=>bring(win));
  }
  function makeResizable(win, handle){
    let resizing=false, startX=0, startY=0, startW=0, startH=0;
    const down=(e)=>{
      resizing=true; bring(win);
      const p=e.touches ? e.touches[0] : e;
      startX=p.clientX; startY=p.clientY; startW=win.offsetWidth; startH=win.offsetHeight;
      document.addEventListener('mousemove', move);
      document.addEventListener('mouseup', up);
      document.addEventListener('touchmove', move, {passive:false});
      document.addEventListener('touchend', up);
      if(e.cancelable) e.preventDefault();
      e.stopPropagation();
    };
    const move=(e)=>{
      if(!resizing) return;
      const p=e.touches ? e.touches[0] : e;
      if(e.cancelable) e.preventDefault();
      win.style.width = Math.max(330, startW + (p.clientX - startX)) + 'px';
      win.style.minHeight = Math.max(250, startH + (p.clientY - startY)) + 'px';
      updatePageScrollBounds();
    };
    const up=()=>{
      resizing=false;
      document.removeEventListener('mousemove', move);
      document.removeEventListener('mouseup', up);
      document.removeEventListener('touchmove', move);
      document.removeEventListener('touchend', up);
    };
    handle.addEventListener('mousedown', down);
    handle.addEventListener('touchstart', down, {passive:false});
  }

  function windowBase(title, subtitle, left=90, top=80){
    const win = document.createElement('div');
    win.className = 'contact-window';
    win.style.left = (window.scrollX + Math.max(8, left)) + 'px';
    win.style.top = (window.scrollY + Math.max(8, top)) + 'px';
    win.style.zIndex = ++zTop;
    win.innerHTML = `<div class="contact-window-head">
      <div class="contact-window-title"><strong>${esc(title)}</strong><span class="contact-main-sub">${esc(subtitle || '')}</span></div>
      <div class="contact-window-tools"></div>
      <button type="button" class="contact-window-close" title="Fermer">×</button>
    </div><div class="contact-window-body"></div><span class="contact-window-resize" title="Redimensionner"></span>`;
    document.body.appendChild(win);
    win.querySelector('.contact-window-close').addEventListener('click',()=>{ win.remove(); updatePageScrollBounds(); });
    makeMovable(win, win.querySelector('.contact-window-head'));
    makeResizable(win, win.querySelector('.contact-window-resize'));
    updatePageScrollBounds();
    return win;
  }

  function openDetail(c, anchor){
    const r = anchor ? anchor.getBoundingClientRect() : {left:90, bottom:80};
    const win = windowBase(fullName(c), c.entreprise || c.mail || '', r.left + 18, r.bottom + 8);
    const tools = win.querySelector('.contact-window-tools');
    tools.innerHTML = `<a class="contact-btn ghost" href="modules/contact/contact_exportpdf.php?id=${encodeURIComponent(c.id)}">PDF</a>
                       <a class="contact-btn ghost" href="modules/contact/contact_exportcsv.php?id=${encodeURIComponent(c.id)}">CSV</a>
                       <button type="button" class="contact-btn ghost">Modifier</button>`;
    tools.querySelector('button').addEventListener('click',()=>openForm(c, r.left + 44, r.bottom + 34));
    win.querySelector('.contact-window-body').innerHTML = `
      <div class="contact-profile-top">
        <div>${avatarHtml(c,true)}</div>
        <div>
          <h3 style="margin:0 0 6px">${esc(fullName(c))}</h3>
          <div class="contact-badgebar">${badges(c)}</div>
          <div class="contact-main-sub">${esc([c.poste,c.service,c.entreprise].filter(Boolean).join(' • '))}</div>
        </div>
      </div>
      <div class="contact-info-grid">
        ${info('Civilité', c.civilite)}
        ${info('Surnom', c.surnom)}
        ${linkInfo('Email principal', c.mail, 'mailto:')}
        ${linkInfo('Email secondaire', c.mail2, 'mailto:')}
        ${linkInfo('Téléphone', c.tel, 'tel:')}
        ${linkInfo('Téléphone 2', c.tel2, 'tel:')}
        ${info('Entreprise', c.entreprise)}
        ${info('Poste / fonction', c.poste)}
        ${info('Service', c.service)}
        ${info('SIRET', c.siret)}
        ${info('Adresse', [c.adresse,c.code_postal,c.ville,c.pays].filter(Boolean).join(' '), true)}
        ${info('Date de naissance', c.date_naissance)}
        ${info('Situation familiale', c.statut_familial)}
        ${linkInfo('Site web', c.site_web, '')}
        ${linkInfo('LinkedIn', c.linkedin, '')}
        ${info('Tags', c.tags, true)}
        ${info('Notes', c.notes, true)}
      </div>`;
  }

  function formTemplate(c){
    const checked = (v)=>v ? 'checked' : '';
    const sel = (a,b)=>String(a||'')===String(b||'')?'selected':'';
    return `<form id="contactForm" class="contact-form-grid" enctype="multipart/form-data">
      <input type="hidden" name="action" value="save"><input type="hidden" name="id" value="${esc(c.id||'')}">
      <div class="contact-field"><label>Civilité</label><select class="contact-select" name="civilite"><option value=""></option><option ${sel(c.civilite,'Madame')}>Madame</option><option ${sel(c.civilite,'Monsieur')}>Monsieur</option><option ${sel(c.civilite,'Autre')}>Autre</option></select></div>
      <div class="contact-field"><label>Photo / avatar</label><input class="contact-input" type="file" name="avatar" accept="image/*"></div>
      <div class="contact-field"><label>Prénom</label><input class="contact-input" name="prenom" value="${esc(c.prenom||'')}"></div>
      <div class="contact-field"><label>Nom</label><input class="contact-input" name="nom" value="${esc(c.nom||'')}"></div>
      <div class="contact-field"><label>Surnom</label><input class="contact-input" name="surnom" value="${esc(c.surnom||'')}"></div>
      <div class="contact-field"><label>Catégorie</label><div class="contact-checks"><label><input type="checkbox" name="is_private" value="1" ${checked(c.is_private)}> Privé</label><label><input type="checkbox" name="is_pro" value="1" ${checked(c.is_pro)}> Pro</label></div></div>
      <div class="contact-field contact-private-only"><label>Type privé</label><select class="contact-select" name="relation_private"><option value=""></option><option ${sel(c.relation_private,'Famille')}>Famille</option><option ${sel(c.relation_private,'Ami')}>Ami</option><option ${sel(c.relation_private,'Connaissance')}>Connaissance</option><option ${sel(c.relation_private,'Urgence')}>Urgence</option><option ${sel(c.relation_private,'Autre')}>Autre</option></select></div>
      <div class="contact-field contact-pro-only"><label>Type pro</label><select class="contact-select" name="relation_pro"><option value=""></option><option ${sel(c.relation_pro,'Client')}>Client</option><option ${sel(c.relation_pro,'Fournisseur')}>Fournisseur</option><option ${sel(c.relation_pro,'Prospect')}>Prospect</option><option ${sel(c.relation_pro,'Partenaire')}>Partenaire</option><option ${sel(c.relation_pro,'Prestataire')}>Prestataire</option><option ${sel(c.relation_pro,'Administration')}>Administration</option><option ${sel(c.relation_pro,'Autre')}>Autre</option></select></div>
      <div class="contact-field contact-pro-only"><label>Entreprise</label><input class="contact-input" name="entreprise" value="${esc(c.entreprise||'')}"></div>
      <div class="contact-field contact-pro-only"><label>Poste / fonction</label><input class="contact-input" name="poste" value="${esc(c.poste||'')}"></div>
      <div class="contact-field contact-pro-only"><label>Service</label><input class="contact-input" name="service" value="${esc(c.service||'')}"></div>
      <div class="contact-field contact-pro-only"><label>SIRET</label><input class="contact-input" name="siret" value="${esc(c.siret||'')}"></div>
      <div class="contact-field"><label>Email principal</label><input class="contact-input" type="email" name="mail" value="${esc(c.mail||'')}"></div>
      <div class="contact-field"><label>Email secondaire</label><input class="contact-input" type="email" name="mail2" value="${esc(c.mail2||'')}"></div>
      <div class="contact-field"><label>Téléphone</label><input class="contact-input" name="tel" value="${esc(c.tel||'')}"></div>
      <div class="contact-field"><label>Téléphone 2</label><input class="contact-input" name="tel2" value="${esc(c.tel2||'')}"></div>
      <div class="contact-field wide"><label>Adresse postale</label><input class="contact-input" name="adresse" value="${esc(c.adresse||'')}"></div>
      <div class="contact-field"><label>Code postal</label><input class="contact-input" name="code_postal" value="${esc(c.code_postal||'')}"></div>
      <div class="contact-field"><label>Ville</label><input class="contact-input" name="ville" value="${esc(c.ville||'')}"></div>
      <div class="contact-field"><label>Pays</label><input class="contact-input" name="pays" value="${esc(c.pays||'')}"></div>
      <div class="contact-field"><label>Date de naissance</label><input class="contact-input" type="date" name="date_naissance" value="${esc(c.date_naissance||'')}"></div>
      <div class="contact-field"><label>Situation familiale</label><select class="contact-select" name="statut_familial"><option value=""></option><option ${sel(c.statut_familial,'Célibataire')}>Célibataire</option><option ${sel(c.statut_familial,'Marié(e)')}>Marié(e)</option><option ${sel(c.statut_familial,'Pacsé(e)')}>Pacsé(e)</option><option ${sel(c.statut_familial,'Divorcé(e)')}>Divorcé(e)</option><option ${sel(c.statut_familial,'Veuf/Veuve')}>Veuf/Veuve</option><option ${sel(c.statut_familial,'Autre')}>Autre</option></select></div>
      <div class="contact-field"><label>Site web</label><input class="contact-input" name="site_web" value="${esc(c.site_web||'')}"></div>
      <div class="contact-field"><label>LinkedIn</label><input class="contact-input" name="linkedin" value="${esc(c.linkedin||'')}"></div>
      <div class="contact-field wide"><label>Tags</label><input class="contact-input" name="tags" placeholder="VIP, relance, compta..." value="${esc(c.tags||'')}"></div>
      <div class="contact-field wide"><label>Notes</label><textarea class="contact-textarea" name="notes">${esc(c.notes||'')}</textarea></div>
      <div class="contact-field wide"><div class="contact-msg" id="contactFormMsg"></div><div class="contact-form-actions"><button type="button" class="contact-btn ghost" data-close>Annuler</button><button type="submit" class="contact-btn primary">Enregistrer</button></div></div>
    </form>`;
  }

  function refreshVisibility(form){
    const isPro = form.querySelector('[name="is_pro"]').checked;
    const isPrivate = form.querySelector('[name="is_private"]').checked;
    form.querySelectorAll('.contact-pro-only').forEach(el=>el.classList.toggle('is-hidden', !isPro));
    form.querySelectorAll('.contact-private-only').forEach(el=>el.classList.toggle('is-hidden', !isPrivate));
  }
  function openForm(c={}, left=100, top=80){
    const win = windowBase(c.id ? 'Modifier le contact' : 'Nouveau contact', c.id ? fullName(c) : 'Fiche complète', left, top);
    win.querySelector('.contact-window-body').innerHTML = formTemplate(c);
    const form = win.querySelector('#contactForm');
    const msg = win.querySelector('#contactFormMsg');
    form.querySelector('[data-close]').addEventListener('click',()=>win.remove());
    form.querySelectorAll('[name="is_private"],[name="is_pro"]').forEach(i=>i.addEventListener('change',()=>refreshVisibility(form)));
    refreshVisibility(form);
    form.addEventListener('submit', async (e)=>{
      e.preventDefault();
      msg.textContent = 'Enregistrement...';
      const fd = new FormData(form);
      try{
        const r = await fetch('modules/contact/contact_process.php', {method:'POST', body:fd, credentials:'same-origin'});
        const j = await r.json().catch(()=>({ok:false,error:'Réponse JSON invalide'}));
        if(!r.ok || !j.ok) throw new Error(j.error || ('HTTP '+r.status));
        location.reload();
      }catch(err){ msg.textContent = 'Erreur : ' + err.message; }
    });
  }

  function applyFilters(){
    const q = normalize(search.value);
    const filter = scopeFilter.value;
    const rows = Array.from(document.querySelectorAll('.contact-row'));
    let visibleLetters = new Set();
    rows.forEach(row=>{
      const id = row.dataset.contactId;
      const c = byId.get(id) || {};
      const letterOk = activeLetter === 'Tous' || row.dataset.letter === activeLetter;
      const textOk = !q || normalize(row.dataset.search).includes(q);
      let typeOk = true;
      if(filter === 'private') typeOk = !!c.is_private;
      if(filter === 'pro') typeOk = !!c.is_pro;
      if(filter === 'client') typeOk = normalize(c.relation_pro) === 'client';
      if(filter === 'fournisseur') typeOk = normalize(c.relation_pro) === 'fournisseur';
      if(filter === 'prospect') typeOk = normalize(c.relation_pro) === 'prospect';
      const ok = letterOk && textOk && typeOk;
      row.style.display = ok ? '' : 'none';
      if(ok) visibleLetters.add(row.dataset.letter);
    });
    document.querySelectorAll('.contact-letter').forEach(h=>{
      const nextRows = [];
      let n = h.nextElementSibling;
      while(n && !n.classList.contains('contact-letter')){ if(n.classList.contains('contact-row')) nextRows.push(n); n = n.nextElementSibling; }
      h.style.display = nextRows.some(r=>r.style.display !== 'none') ? '' : 'none';
    });
  }

  list.addEventListener('click', (e)=>{
    const edit = e.target.closest('.contact-edit');
    const del = e.target.closest('.contact-delete');
    const row = e.target.closest('.contact-row');
    if(edit){ openForm(byId.get(edit.dataset.contactId) || {}, e.clientX || 120, e.clientY || 80); return; }
    if(del){
      const c = byId.get(del.dataset.contactId) || {};
      if(!confirm('Supprimer '+fullName(c)+' ?')) return;
      const fd = new FormData(); fd.append('action','delete'); fd.append('id', del.dataset.contactId);
      fetch('modules/contact/contact_process.php', {method:'POST', body:fd, credentials:'same-origin'}).then(()=>location.reload());
      return;
    }
    if(row) openDetail(byId.get(row.dataset.contactId) || {}, row);
  });
  newBtn.addEventListener('click',()=>openForm({is_private:true,is_pro:false}, 110, 85));
  search.addEventListener('input', applyFilters);
  scopeFilter.addEventListener('change', applyFilters);
  az.addEventListener('click', (e)=>{
    const b = e.target.closest('button[data-letter]');
    if(!b) return;
    activeLetter = b.dataset.letter;
    az.querySelectorAll('button').forEach(x=>x.classList.toggle('active', x === b));
    applyFilters();
  });
})();
</script>
