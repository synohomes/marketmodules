(function initCountdown() {
  const start = () => {
    const events = document.querySelectorAll(".countdown-event");
    if (events.length === 0) return;

    events.forEach(ev => {
      let dateStr = ev.dataset.date?.trim() || "";
      const id = ev.dataset.id;
      const timer = document.getElementById("timer_" + id);
      if (!timer) return;

      if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(dateStr)) dateStr += ":00";
      const date = new Date(dateStr);
      if (isNaN(date.getTime())) {
        timer.textContent = "❌ Date invalide";
        return;
      }

      const tick = () => {
        const now = new Date();
        const diff = date - now;
        if (diff <= 0) {
          ev.classList.add("event-finished");
          timer.textContent = "🎉 C'est le moment !";
          return;
        }
        const d = Math.floor(diff / (1000 * 60 * 60 * 24));
        const h = Math.floor((diff / (1000 * 60 * 60)) % 24);
        const m = Math.floor((diff / (1000 * 60)) % 60);
        const s = Math.floor((diff / 1000) % 60);
        timer.textContent = `${d}j ${h}h ${m}m ${s}s`;
      };

      tick();
      setInterval(tick, 1000);
    });
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else setTimeout(start, 300);
})();
