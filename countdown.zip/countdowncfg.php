<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$user = $_SESSION['user']['email'] ?? '';
if (!$user) { echo "<div class='section'>Connecte-toi d'abord.</div>"; exit; }

$cfgDir = __DIR__ . "/data/$user";
@mkdir($cfgDir, 0775, true);
$file = "$cfgDir/countdowns.json";
if (!file_exists($file)) file_put_contents($file, '[]');

$themesFile = __DIR__ . "/data/themes.json";
if (!file_exists($themesFile)) file_put_contents($themesFile, '[]');

$events = json_decode(file_get_contents($file), true) ?? [];
$themes = json_decode(file_get_contents($themesFile), true) ?? [];

// ajout/suppression événement
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['titre'])) {
  $id = $_POST['id'] ?: uniqid('evt_');
  $titre = trim($_POST['titre']);
  $date = $_POST['date'];
  $themeId = $_POST['theme'];
  $theme = array_values(array_filter($themes, fn($t) => $t['id'] === $themeId))[0] ?? null;
  $image = $theme['image'] ?? "modules/countdown/img/default.png";

  $found = false;
  foreach ($events as &$ev) {
    if ($ev['id'] === $id) {
      $ev = compact('id', 'titre', 'date', 'themeId', 'image');
      $found = true;
      break;
    }
  }
  if (!$found) $events[] = compact('id', 'titre', 'date', 'themeId', 'image');

  file_put_contents($file, json_encode($events, JSON_PRETTY_PRINT));
  echo "<div class='section'>✅ Événement enregistré.</div>";
}

if (isset($_GET['del'])) {
  $events = array_filter($events, fn($e) => $e['id'] !== $_GET['del']);
  file_put_contents($file, json_encode(array_values($events), JSON_PRETTY_PRINT));
  echo "<div class='section'>🗑️ Supprimé.</div>";
}

// ajout d'un thème
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_theme_id'])) {
  $newTheme = [
    'id' => trim($_POST['new_theme_id']),
    'nom' => trim($_POST['new_theme_nom']),
    'image' => trim($_POST['new_theme_img']),
    'effet' => trim($_POST['new_theme_effet']),
  ];
  $themes[] = $newTheme;
  file_put_contents($themesFile, json_encode($themes, JSON_PRETTY_PRINT));
  echo "<div class='section'>🎨 Thème ajouté.</div>";
}

if (isset($_GET['del_theme'])) {
  $themes = array_filter($themes, fn($t) => $t['id'] !== $_GET['del_theme']);
  file_put_contents($themesFile, json_encode(array_values($themes), JSON_PRETTY_PRINT));
  echo "<div class='section'>🗑️ Thème supprimé.</div>";
}
?>

<div class="section">
  <h2>🎯 Mes comptes à rebours</h2>
  <ul>
    <?php foreach ($events as $ev): ?>
      <li>
        <b><?= htmlspecialchars($ev['titre']) ?></b> (<?= htmlspecialchars($ev['date']) ?>)
        <a href="?module=countdown&del=<?= urlencode($ev['id']) ?>" onclick="return confirm('Supprimer ?')">🗑️</a>
      </li>
    <?php endforeach; ?>
  </ul>
</div>

<div class="section">
  <h3>➕ Ajouter / Modifier un événement</h3>
  <form method="post" action="?module=countdown">
    <input type="hidden" name="id" value="">
    <label>Titre :</label>
    <input type="text" name="titre" required>
    <label>Date et heure :</label>
    <input type="datetime-local" name="date" required>
    <label>Thème :</label>
    <select name="theme" id="themeSelect" onchange="updatePreview()">
      <?php foreach ($themes as $t): ?>
        <option value="<?= htmlspecialchars($t['id']) ?>" data-img="<?= htmlspecialchars($t['image']) ?>">
          <?= htmlspecialchars($t['nom']) ?>
        </option>
      <?php endforeach; ?>
    </select>
    <div id="themePreview" style="margin:10px 0;"></div>
    <br>
    <button type="submit">💾 Sauvegarder</button>
  </form>
</div>

<div class="section">
  <h3>🎨 Gestion des thèmes</h3>
  <ul>
    <?php foreach ($themes as $t): ?>
      <li>
        <img src="<?= htmlspecialchars($t['image']) ?>" width="30" style="vertical-align:middle;">
        <?= htmlspecialchars($t['nom']) ?> (<?= htmlspecialchars($t['effet']) ?>)
        <a href="?module=countdown&del_theme=<?= urlencode($t['id']) ?>" onclick="return confirm('Supprimer ce thème ?')">🗑️</a>
      </li>
    <?php endforeach; ?>
  </ul>

  <form method="post" action="?module=countdown">
    <h4>➕ Ajouter un nouveau thème</h4>
    <label>ID :</label><input type="text" name="new_theme_id" required>
    <label>Nom :</label><input type="text" name="new_theme_nom" required>
    <label>Image :</label><input type="text" name="new_theme_img" placeholder="modules/countdown/img/monimage.png" required>
    <label>Effet :</label>
    <select name="new_theme_effet">
      <option value="neige">❄️ Neige</option>
      <option value="confettis">🎊 Confettis</option>
      <option value="pétales">🌸 Pétales</option>
      <option value="feu_artifice">🎆 Feu d’artifice</option>
    </select>
    <button type="submit">💾 Ajouter</button>
  </form>
</div>

<script>
function updatePreview(){
  const select = document.getElementById('themeSelect');
  const img = select.options[select.selectedIndex].getAttribute('data-img');
  document.getElementById('themePreview').innerHTML = `<img src="${img}" width="60" style="border-radius:8px;">`;
}
window.addEventListener('DOMContentLoaded', updatePreview);
</script>

<style>
ul { list-style: none; padding: 0; }
li { margin: 8px 0; }
form input, form select { width: 100%; margin-bottom: 10px; padding: 6px; border-radius: 5px; }
button { background: var(--primary-color, #00aced); color: #fff; border: none; padding: 8px 15px; border-radius: 6px; cursor: pointer; }
button:hover { opacity: 0.9; }
</style>
