<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$user = $_SESSION['user']['email'] ?? '';
if (!$user) { echo "<div class='section'>Connecte-toi d'abord.</div>"; exit; }

$cfgDir = __DIR__ . "/data/$user";
@mkdir($cfgDir, 0775, true);
$file = "$cfgDir/countdowns.json";
if (!file_exists($file)) file_put_contents($file, '[]');

$events = json_decode(file_get_contents($file), true) ?? [];

$themePath = "../../users/profiles/$user/theme.json";
$theme = "default";
if (file_exists($themePath)) {
  $t = json_decode(file_get_contents($themePath), true);
  if (!empty($t['theme'])) $theme = $t['theme'];
}
echo "<link rel='stylesheet' href='../../theme/$theme/style.css'>";
?>

<div class="countdown-container">
  <?php if (empty($events)): ?>
    <div class="section">Aucun événement configuré. Double-clique pour en ajouter un 🎉</div>
  <?php else: ?>
    <?php foreach ($events as $event): ?>
      <div class="countdown-event" data-date="<?= htmlspecialchars($event['date']) ?>" data-id="<?= htmlspecialchars($event['id']) ?>">
        <div class="event-logo">
          <img src="<?= htmlspecialchars($event['image'] ?? 'modules/countdown/img/default.png') ?>" alt="<?= htmlspecialchars($event['titre']) ?>">
        </div>
        <div class="event-title"><?= htmlspecialchars($event['titre']) ?></div>
        <div class="event-timer" id="timer_<?= htmlspecialchars($event['id']) ?>">Chargement...</div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<script src="modules/countdown/countdown.js?v=2"></script>

<style>
.countdown-container {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: center;
}
.countdown-event {
  width: 150px;
  height: 150px;
  border-radius: 50%;
  background: var(--dms-card, #333);
  color: var(--dms-text, #fff);
  text-align: center;
  box-shadow: 0 0 10px rgba(255,255,255,0.1);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  position: relative;
  transition: transform 0.2s ease;
}
.countdown-event:hover { transform: scale(1.05); }
.event-logo img {
  width: 50px;
  height: 50px;
  border-radius: 50%;
}
.event-title {
  font-size: 14px;
  margin-top: 5px;
  color: #fff;
}
.event-timer {
  font-weight: bold;
  font-size: 13px;
  color: var(--primary-color, #00aced);
  margin-top: 5px;
}
.event-finished {
  background: linear-gradient(135deg, #ff4444, #ffcc00);
  animation: pulse 1s infinite alternate;
}
@keyframes pulse {
  from { transform: scale(1); box-shadow: 0 0 5px #ffcc00; }
  to { transform: scale(1.05); box-shadow: 0 0 15px #ff4444; }
}
</style>
