<?php
if (session_status() === PHP_SESSION_NONE) session_start();

$email = $_SESSION['user']['email'] ?? '';
if (!$email) {
    echo "<div class='meteov2-pro'><div class='mv2-empty'>⛔ Non connecté</div></div>";
    return;
}

function mv2_profile_dir(string $email): string {
    $base = realpath(__DIR__ . '/../../users/profiles');
    if ($base === false) $base = __DIR__ . '/../../users/profiles';
    $safe = str_replace(["\0", '/', '\\'], '', $email);
    return rtrim($base, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $safe;
}

function mv2_load_config(string $file): array {
    $def = [
        'locations' => [
            ['name' => 'Paris, France', 'lat' => 48.8566, 'lon' => 2.3522, 'tz' => 'Europe/Paris']
        ],
        'days' => 7,
        'unit' => 'metric',
        'default_view' => 'dashboard',
        'show_location_switch' => true,
        'show_view_switch' => true,
        'show_hourly' => true,
        'show_daily' => true,
        'show_details' => true,
        'refresh_minutes' => 20
    ];

    if (!file_exists($file)) {
        @mkdir(dirname($file), 0775, true);
        @file_put_contents($file, json_encode($def, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
        return $def;
    }

    $cfg = json_decode((string)@file_get_contents($file), true);
    if (!is_array($cfg)) return $def;
    $cfg = array_replace_recursive($def, $cfg);
    $cfg['locations'] = array_values(array_filter($cfg['locations'] ?? [], static function ($l) {
        return is_array($l) && isset($l['lat'], $l['lon']) && is_numeric($l['lat']) && is_numeric($l['lon']);
    }));
    if (!$cfg['locations']) $cfg['locations'] = $def['locations'];
    $cfg['days'] = max(1, min(16, (int)($cfg['days'] ?? 7)));
    $cfg['unit'] = (($cfg['unit'] ?? 'metric') === 'imperial') ? 'imperial' : 'metric';
    $allowedViews = ['dashboard', 'daily', 'hourly', 'table'];
    $cfg['default_view'] = in_array(($cfg['default_view'] ?? 'dashboard'), $allowedViews, true) ? $cfg['default_view'] : 'dashboard';
    $cfg['refresh_minutes'] = max(5, min(180, (int)($cfg['refresh_minutes'] ?? 20)));
    return $cfg;
}

$cfgFile = mv2_profile_dir($email) . DIRECTORY_SEPARATOR . 'meteov2.json';
$cfg = mv2_load_config($cfgFile);
$uid = 'meteov2_' . substr(hash('sha256', $email . microtime(true)), 0, 10);
$isDirectModule = strpos($_SERVER['SCRIPT_NAME'] ?? '', '/modules/meteov2/') !== false;
$cssHref = $isDirectModule ? 'meteov2.css' : 'modules/meteov2/meteov2.css';
$cssFile = __DIR__ . '/meteov2.css';
$cssVersion = file_exists($cssFile) ? filemtime($cssFile) : time();
$cssInline = is_file($cssFile) ? (string)file_get_contents($cssFile) : '';
?>
<link rel="stylesheet" href="<?= htmlspecialchars($cssHref, ENT_QUOTES, 'UTF-8') ?>?v=<?= (int)$cssVersion ?>">
<?php if (is_file($cssFile)): ?>
<style id="meteov2-inline-style-<?= (int)$cssVersion ?>">
<?= $cssInline ?>
</style>
<?php endif; ?>
<div id="<?= htmlspecialchars($uid, ENT_QUOTES, 'UTF-8') ?>" class="meteov2-pro" data-config='<?= htmlspecialchars(json_encode($cfg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), ENT_QUOTES, 'UTF-8') ?>'>
  <div class="mv2-shell">
    <div class="mv2-toolbar">
      <div class="mv2-kicker">🌦️ Météo Live</div>
      <div class="mv2-controls">
        <?php if (!empty($cfg['show_location_switch']) && count($cfg['locations']) > 1): ?>
          <select class="mv2-select" data-mv2-location aria-label="Lieu météo">
            <?php foreach ($cfg['locations'] as $i => $loc): ?>
              <option value="<?= (int)$i ?>"><?= htmlspecialchars($loc['name'] ?? ('Lieu ' . ($i + 1)), ENT_QUOTES, 'UTF-8') ?></option>
            <?php endforeach; ?>
          </select>
        <?php endif; ?>
        <?php if (!empty($cfg['show_view_switch'])): ?>
          <div class="mv2-tabs" role="tablist" aria-label="Affichage météo">
            <button type="button" class="mv2-tab" data-mv2-view="dashboard">Vue</button>
            <button type="button" class="mv2-tab" data-mv2-view="daily">Jours</button>
            <button type="button" class="mv2-tab" data-mv2-view="hourly">Heures</button>
            <button type="button" class="mv2-tab" data-mv2-view="table">Table</button>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <div class="mv2-status mv2-loader">Chargement de la météo…</div>

    <section class="mv2-hero mv2-hidden" data-mv2-hero>
      <div class="mv2-titlebox">
        <div class="mv2-kicker" data-mv2-condition>Prévision</div>
        <div class="mv2-location" data-mv2-location-title>—</div>
        <div class="mv2-desc" data-mv2-summary>Analyse météo en cours…</div>
        <div class="mv2-updated" data-mv2-updated>—</div>
      </div>
      <div class="mv2-current-main">
        <div class="mv2-icon-big" data-mv2-icon>🌡️</div>
        <div>
          <div class="mv2-temp-big" data-mv2-temp>--°</div>
          <div class="mv2-feels" data-mv2-feels>Ressenti —</div>
        </div>
      </div>
    </section>

    <section class="mv2-grid-stats mv2-hidden" data-mv2-stats></section>

    <section class="mv2-panel mv2-hidden" data-mv2-hourly-panel>
      <div class="mv2-panel-head">
        <div>
          <div class="mv2-panel-title">Prochaines heures</div>
          <div class="mv2-panel-sub">Température, pluie, vent et UV heure par heure</div>
        </div>
      </div>
      <div class="mv2-hours" data-mv2-hourly></div>
    </section>

    <section class="mv2-panel mv2-hidden" data-mv2-daily-panel>
      <div class="mv2-panel-head">
        <div>
          <div class="mv2-panel-title">Prévisions sur <?= (int)$cfg['days'] ?> jour<?= ((int)$cfg['days'] > 1) ? 's' : '' ?></div>
          <div class="mv2-panel-sub">Tendance, amplitudes et risque de pluie</div>
        </div>
      </div>
      <div class="mv2-days" data-mv2-daily></div>
    </section>

    <section class="mv2-panel mv2-hidden" data-mv2-table-panel>
      <div class="mv2-panel-head">
        <div>
          <div class="mv2-panel-title">Vue numérique</div>
          <div class="mv2-panel-sub">Lecture compacte pour exploitation rapide</div>
        </div>
      </div>
      <div class="mv2-table-wrap" data-mv2-table></div>
    </section>
  </div>
</div>
<script>
(function(){
  const root = document.getElementById(<?= json_encode($uid) ?>);
  if (!root) return;

  // Fallback volontaire : le dashboard DoMyDesk peut ignorer les <link> dans les modules injectés.
  // On pousse donc le CSS du module dans le <head> pour éviter l'affichage HTML brut.
  try {
    const cssId = 'meteov2-style-' + <?= json_encode((string)$cssVersion) ?>;
    if (!document.getElementById(cssId)) {
      const st = document.createElement('style');
      st.id = cssId;
      st.textContent = <?= json_encode($cssInline, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
      document.head.appendChild(st);
    }
  } catch(e) {}

  const cfg = JSON.parse(root.dataset.config || '{}');
  const locations = Array.isArray(cfg.locations) ? cfg.locations : [];
  const unit = cfg.unit === 'imperial' ? 'imperial' : 'metric';
  const days = Math.max(1, Math.min(16, parseInt(cfg.days || 7, 10)));
  const refreshMs = Math.max(5, Math.min(180, parseInt(cfg.refresh_minutes || 20, 10))) * 60000;
  const defaultView = ['dashboard','daily','hourly','table'].includes(cfg.default_view) ? cfg.default_view : 'dashboard';

  const el = {
    status: root.querySelector('.mv2-status'),
    selectLocation: root.querySelector('[data-mv2-location]'),
    tabs: Array.from(root.querySelectorAll('[data-mv2-view]')),
    hero: root.querySelector('[data-mv2-hero]'),
    condition: root.querySelector('[data-mv2-condition]'),
    title: root.querySelector('[data-mv2-location-title]'),
    summary: root.querySelector('[data-mv2-summary]'),
    updated: root.querySelector('[data-mv2-updated]'),
    icon: root.querySelector('[data-mv2-icon]'),
    temp: root.querySelector('[data-mv2-temp]'),
    feels: root.querySelector('[data-mv2-feels]'),
    stats: root.querySelector('[data-mv2-stats]'),
    hourlyPanel: root.querySelector('[data-mv2-hourly-panel]'),
    hourly: root.querySelector('[data-mv2-hourly]'),
    dailyPanel: root.querySelector('[data-mv2-daily-panel]'),
    daily: root.querySelector('[data-mv2-daily]'),
    tablePanel: root.querySelector('[data-mv2-table-panel]'),
    table: root.querySelector('[data-mv2-table]')
  };

  let currentView = defaultView;
  let currentData = null;
  let timer = null;

  const WMO = {
    0:['☀️','Ciel dégagé'],1:['🌤️','Principalement dégagé'],2:['⛅','Partiellement nuageux'],3:['☁️','Couvert'],
    45:['🌫️','Brouillard'],48:['🌫️','Brouillard givrant'],51:['🌦️','Bruine faible'],53:['🌦️','Bruine'],55:['🌧️','Bruine forte'],
    56:['🌧️','Bruine verglaçante'],57:['🌧️','Bruine verglaçante forte'],61:['🌧️','Pluie faible'],63:['🌧️','Pluie'],65:['🌧️','Pluie forte'],
    66:['🌧️','Pluie verglaçante'],67:['🌧️','Pluie verglaçante forte'],71:['🌨️','Neige faible'],73:['🌨️','Neige'],75:['❄️','Neige forte'],77:['❄️','Grains de neige'],
    80:['🌦️','Averses faibles'],81:['🌧️','Averses'],82:['⛈️','Averses fortes'],85:['🌨️','Averses de neige'],86:['❄️','Averses de neige fortes'],
    95:['⛈️','Orage'],96:['⛈️','Orage avec grêle'],99:['⛈️','Orage violent avec grêle']
  };

  function esc(s){ return String(s ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c])); }
  function weather(code){ return WMO[Number(code)] || ['🌡️','Météo variable']; }
  function temp(v){ return Number.isFinite(Number(v)) ? Math.round(Number(v)) + '°' : '—'; }
  function one(v, suffix){ return Number.isFinite(Number(v)) ? Number(v).toFixed(1).replace('.0','') + suffix : '—'; }
  function int(v, suffix){ return Number.isFinite(Number(v)) ? Math.round(Number(v)) + suffix : '—'; }
  function windUnit(){ return unit === 'imperial' ? ' mph' : ' km/h'; }
  function distanceUnit(){ return unit === 'imperial' ? ' mi' : ' km'; }
  function hourFmt(t, tz){ try { return new Intl.DateTimeFormat('fr-FR',{hour:'2-digit',minute:'2-digit',timeZone:tz || 'auto'}).format(new Date(t)); } catch(e){ return String(t).slice(11,16); } }
  function dayFmt(t, tz){ try { return new Intl.DateTimeFormat('fr-FR',{weekday:'short',day:'2-digit',month:'short',timeZone:tz || 'auto'}).format(new Date(t)); } catch(e){ return t; } }
  function fullDateFmt(t, tz){ try { return new Intl.DateTimeFormat('fr-FR',{dateStyle:'medium',timeStyle:'short',timeZone:tz || 'auto'}).format(new Date(t)); } catch(e){ return t; } }

  function selectedLocation(){
    const i = el.selectLocation ? parseInt(el.selectLocation.value || '0', 10) : 0;
    return locations[i] || locations[0] || {name:'Paris, France', lat:48.8566, lon:2.3522, tz:'Europe/Paris'};
  }

  function buildUrl(loc){
    const url = new URL('https://api.open-meteo.com/v1/forecast');
    url.searchParams.set('latitude', loc.lat);
    url.searchParams.set('longitude', loc.lon);
    url.searchParams.set('timezone', loc.tz || 'auto');
    url.searchParams.set('forecast_days', days);
    url.searchParams.set('current', 'temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m,pressure_msl,precipitation,cloud_cover');
    url.searchParams.set('hourly', 'temperature_2m,apparent_temperature,relative_humidity_2m,precipitation_probability,precipitation,weather_code,wind_speed_10m,wind_direction_10m,uv_index,visibility');
    url.searchParams.set('daily', 'weather_code,temperature_2m_max,temperature_2m_min,apparent_temperature_max,apparent_temperature_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max,wind_gusts_10m_max,uv_index_max,sunrise,sunset');
    if (unit === 'imperial') {
      url.searchParams.set('temperature_unit', 'fahrenheit');
      url.searchParams.set('wind_speed_unit', 'mph');
      url.searchParams.set('precipitation_unit', 'inch');
    } else {
      url.searchParams.set('temperature_unit', 'celsius');
      url.searchParams.set('wind_speed_unit', 'kmh');
      url.searchParams.set('precipitation_unit', 'mm');
    }
    return url.toString();
  }

  function showLoading(){
    el.status.className = 'mv2-status mv2-loader';
    el.status.textContent = 'Chargement de la météo…';
    el.status.classList.remove('mv2-hidden');
  }
  function showError(message){
    el.status.className = 'mv2-status mv2-error';
    el.status.textContent = message;
    el.status.classList.remove('mv2-hidden');
    [el.hero, el.stats, el.hourlyPanel, el.dailyPanel, el.tablePanel].forEach(x => x && x.classList.add('mv2-hidden'));
  }
  function hideStatus(){ el.status.classList.add('mv2-hidden'); }

  async function load(){
    const loc = selectedLocation();
    showLoading();
    try {
      const response = await fetch(buildUrl(loc), {cache:'no-store'});
      if (!response.ok) throw new Error('HTTP ' + response.status);
      const data = await response.json();
      currentData = {loc, data, loadedAt: new Date()};
      renderAll();
      scheduleRefresh();
    } catch (e) {
      showError('❌ Impossible de récupérer la météo pour le moment.');
    }
  }

  function scheduleRefresh(){
    if (timer) clearTimeout(timer);
    timer = setTimeout(load, refreshMs);
  }

  function hourlyRows(){
    if (!currentData || !currentData.data.hourly) return [];
    const h = currentData.data.hourly;
    const now = Date.now() - 3600000;
    const rows = (h.time || []).map((t, i) => ({
      time: t,
      temp: h.temperature_2m?.[i],
      feels: h.apparent_temperature?.[i],
      humidity: h.relative_humidity_2m?.[i],
      pop: h.precipitation_probability?.[i],
      rain: h.precipitation?.[i],
      code: h.weather_code?.[i],
      wind: h.wind_speed_10m?.[i],
      windDir: h.wind_direction_10m?.[i],
      uv: h.uv_index?.[i],
      visibility: h.visibility?.[i]
    })).filter(r => new Date(r.time).getTime() >= now);
    return rows.slice(0, 24);
  }

  function dailyRows(){
    if (!currentData || !currentData.data.daily) return [];
    const d = currentData.data.daily;
    return (d.time || []).map((t, i) => ({
      time: t,
      code: d.weather_code?.[i],
      tmax: d.temperature_2m_max?.[i],
      tmin: d.temperature_2m_min?.[i],
      feelsMax: d.apparent_temperature_max?.[i],
      feelsMin: d.apparent_temperature_min?.[i],
      rain: d.precipitation_sum?.[i],
      pop: d.precipitation_probability_max?.[i],
      wind: d.wind_speed_10m_max?.[i],
      gust: d.wind_gusts_10m_max?.[i],
      uv: d.uv_index_max?.[i],
      sunrise: d.sunrise?.[i],
      sunset: d.sunset?.[i]
    }));
  }

  function renderHero(){
    const c = currentData.data.current || {};
    const loc = currentData.loc;
    const [ico, label] = weather(c.weather_code);
    const h = hourlyRows()[0] || {};
    const rainRisk = Number.isFinite(Number(h.pop)) ? `Risque de pluie ${Math.round(h.pop)}%` : 'Risque de pluie non disponible';
    const wind = int(c.wind_speed_10m, windUnit());
    el.condition.textContent = label;
    el.title.textContent = loc.name || 'Lieu météo';
    el.summary.textContent = `${rainRisk} • vent ${wind} • humidité ${int(c.relative_humidity_2m, '%')}`;
    el.updated.textContent = `Mis à jour ${fullDateFmt(c.time || currentData.loadedAt.toISOString(), loc.tz)} • actualisation auto ${cfg.refresh_minutes || 20} min`;
    el.icon.textContent = ico;
    el.temp.textContent = temp(c.temperature_2m);
    el.feels.textContent = `Ressenti ${temp(c.apparent_temperature)} · ${c.is_day ? 'journée' : 'nuit'}`;
    el.hero.classList.remove('mv2-hidden');
  }

  function renderStats(){
    const c = currentData.data.current || {};
    const h = hourlyRows()[0] || {};
    const visibilityKm = Number.isFinite(Number(h.visibility)) ? (unit === 'imperial' ? one(Number(h.visibility) / 1609.34, distanceUnit()) : one(Number(h.visibility) / 1000, distanceUnit())) : '—';
    const stats = [
      ['💧', 'Humidité', int(c.relative_humidity_2m, '%'), 'Air ambiant'],
      ['🌬️', 'Vent', int(c.wind_speed_10m, windUnit()), `Rafales ${int(c.wind_gusts_10m, windUnit())}`],
      ['🧭', 'Pression', int(c.pressure_msl, ' hPa'), 'Niveau mer'],
      ['☔', 'Pluie', one(c.precipitation, unit === 'imperial' ? ' in' : ' mm'), `Probabilité ${int(h.pop, '%')}`],
      ['☁️', 'Nuages', int(c.cloud_cover, '%'), 'Couverture'],
      ['🔆', 'UV', one(h.uv, ''), 'Indice actuel'],
      ['👁️', 'Visibilité', visibilityKm, 'Estimation'],
      ['🧭', 'Direction', int(c.wind_direction_10m, '°'), 'Vent dominant']
    ];
    el.stats.innerHTML = stats.map(s => `<article class="mv2-card"><div class="mv2-card-label">${esc(s[0])} ${esc(s[1])}</div><div class="mv2-card-value">${esc(s[2])}</div><div class="mv2-card-extra">${esc(s[3])}</div></article>`).join('');
    el.stats.classList.remove('mv2-hidden');
  }

  function renderHourly(){
    const loc = currentData.loc;
    const rows = hourlyRows();
    el.hourly.innerHTML = rows.map(r => {
      const [ico, label] = weather(r.code);
      return `<article class="mv2-hour">
        <div class="mv2-hour-time">${esc(hourFmt(r.time, loc.tz))}</div>
        <div class="mv2-hour-icon" title="${esc(label)}">${esc(ico)}</div>
        <div class="mv2-hour-temp">${esc(temp(r.temp))}</div>
        <div class="mv2-hour-meta">☔ ${esc(int(r.pop, '%'))}</div>
        <div class="mv2-hour-meta">🌬️ ${esc(int(r.wind, windUnit()))}</div>
      </article>`;
    }).join('') || '<div class="mv2-empty">Aucune donnée horaire disponible.</div>';
    if (cfg.show_hourly !== false) el.hourlyPanel.classList.remove('mv2-hidden');
  }

  function renderDaily(){
    const loc = currentData.loc;
    const rows = dailyRows();
    el.daily.innerHTML = rows.map(r => {
      const [ico, label] = weather(r.code);
      return `<article class="mv2-day">
        <div class="mv2-day-top"><div><div class="mv2-day-name">${esc(dayFmt(r.time, loc.tz))}</div><div class="mv2-card-extra">${esc(label)}</div></div><div class="mv2-day-icon">${esc(ico)}</div></div>
        <div class="mv2-day-temp"><span class="mv2-day-max">${esc(temp(r.tmax))}</span><span class="mv2-day-min">/ ${esc(temp(r.tmin))}</span></div>
        <div class="mv2-day-meta">
          <div class="mv2-minirow"><span>☔ Pluie</span><strong>${esc(one(r.rain, unit === 'imperial' ? ' in' : ' mm'))}</strong></div>
          <div class="mv2-minirow"><span>Risque</span><strong>${esc(int(r.pop, '%'))}</strong></div>
          <div class="mv2-minirow"><span>🌬️ Vent</span><strong>${esc(int(r.wind, windUnit()))}</strong></div>
          <div class="mv2-minirow"><span>🔆 UV</span><strong>${esc(one(r.uv, ''))}</strong></div>
        </div>
      </article>`;
    }).join('') || '<div class="mv2-empty">Aucune prévision disponible.</div>';
    if (cfg.show_daily !== false) el.dailyPanel.classList.remove('mv2-hidden');
  }

  function renderTable(){
    const loc = currentData.loc;
    const rows = dailyRows();
    el.table.innerHTML = `<table class="mv2-table">
      <thead><tr><th>Jour</th><th>Condition</th><th>Temp.</th><th>Ressenti</th><th>Pluie</th><th>Vent</th><th>Rafales</th><th>UV</th><th>Soleil</th></tr></thead>
      <tbody>${rows.map(r => {
        const [ico, label] = weather(r.code);
        return `<tr><td>${esc(dayFmt(r.time, loc.tz))}</td><td>${esc(ico)} ${esc(label)}</td><td>${esc(temp(r.tmax))} / ${esc(temp(r.tmin))}</td><td>${esc(temp(r.feelsMax))} / ${esc(temp(r.feelsMin))}</td><td>${esc(one(r.rain, unit === 'imperial' ? ' in' : ' mm'))} · ${esc(int(r.pop, '%'))}</td><td>${esc(int(r.wind, windUnit()))}</td><td>${esc(int(r.gust, windUnit()))}</td><td>${esc(one(r.uv, ''))}</td><td>${esc(hourFmt(r.sunrise, loc.tz))} / ${esc(hourFmt(r.sunset, loc.tz))}</td></tr>`;
      }).join('')}</tbody></table>`;
    el.tablePanel.classList.remove('mv2-hidden');
  }

  function applyView(){
    el.tabs.forEach(t => t.classList.toggle('is-active', t.dataset.mv2View === currentView));
    const dashboard = currentView === 'dashboard';
    el.stats.classList.toggle('mv2-hidden', !dashboard);
    el.hourlyPanel.classList.toggle('mv2-hidden', !(dashboard || currentView === 'hourly') || cfg.show_hourly === false);
    el.dailyPanel.classList.toggle('mv2-hidden', !(dashboard || currentView === 'daily') || cfg.show_daily === false);
    el.tablePanel.classList.toggle('mv2-hidden', currentView !== 'table');
  }

  function renderAll(){
    if (!currentData || !currentData.data) return;
    hideStatus();
    renderHero();
    renderStats();
    renderHourly();
    renderDaily();
    renderTable();
    applyView();
  }

  el.tabs.forEach(t => t.addEventListener('click', () => { currentView = t.dataset.mv2View || 'dashboard'; applyView(); }));
  if (el.selectLocation) el.selectLocation.addEventListener('change', load);

  load();
})();
</script>
