<?php

if (session_status()===PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { echo "<div style='color:#f66;padding:10px'>⛔ Non connecté</div>"; return; }
$cfgFile = __DIR__ . "/../../users/profiles/$email/meteov2.json";
if (!file_exists($cfgFile)) {
    @mkdir(dirname($cfgFile), 0775, true);
    $def = [
        "locations" => [
            ["name"=>"Paris, FR","lat"=>48.8566,"lon"=>2.3522,"tz"=>"Europe/Paris"]
        ],
        "days" => 3,
        "unit" => "metric",
        "default_mode" => "digital",
        "show_mode_switch" => true,
        "show_location_switch" => true
    ];
    file_put_contents($cfgFile, json_encode($def, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
}
$cfg = json_decode(file_get_contents($cfgFile), true) ?: [];
$locations = $cfg['locations'] ?? [];
$days      = max(1, min(7, intval($cfg['days'] ?? 3)));
$unit      = strtolower($cfg['unit'] ?? 'metric');
$modeDef   = ($cfg['default_mode'] ?? 'digital') === 'numerique' ? 'numerique' : 'digital';
$showMode  = !empty($cfg['show_mode_switch']);
$showLoc   = !empty($cfg['show_location_switch']);
if (empty($locations)) {
    echo "<div class='meteov2-empty' style='padding:12px'>ℹ️ Aucun lieu configuré. Ouvre <code>meteov2cfg.php</code> pour en ajouter.</div>";
    return;
}
$uid = 'meteov2_' . substr(md5($email . microtime(true)),0,8);
?>
<style>
/* ——— Styles sobres, héritent du thème global ——— */
#<?= $uid ?> .mv2-wrap{display:flex;flex-direction:column;gap:8px;font-size:14px;}
#<?= $uid ?> .mv2-topbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
#<?= $uid ?> .mv2-topbar select{
  background: var(--panel-bg, #151515);
  color: inherit; border:1px solid var(--primary-color, #888);
  border-radius:8px; padding:6px 8px; outline:none;
}
#<?= $uid ?> .mv2-head{display:flex;align-items:baseline;gap:12px}
#<?= $uid ?> .mv2-title{font-weight:600;font-size:15px}
#<?= $uid ?> .mv2-sub{opacity:.8}

#<?= $uid ?> .mv2-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}
#<?= $uid ?> .mv2-card{
  background: var(--panel-bg, #151515);
  border:1px solid var(--primary-color, #666);
  border-radius:12px; padding:10px; display:flex;flex-direction:column;gap:6px
}
#<?= $uid ?> .mv2-date{font-weight:600}
#<?= $uid ?> .mv2-temp{font-size:24px; font-weight:700}
#<?= $uid ?> .mv2-row{display:flex;justify-content:space-between;opacity:.9}
#<?= $uid ?> .mv2-ico{font-size:20px}

#<?= $uid ?> table.mv2-table{width:100%; border-collapse:collapse; font-size:14px}
#<?= $uid ?> table.mv2-table th, 
#<?= $uid ?> table.mv2-table td{
  border-bottom:1px solid rgba(255,255,255,.08);
  padding:8px 6px; text-align:left;
}
#<?= $uid ?> table.mv2-table th{opacity:.8; font-weight:600}
@media (max-width: 600px){
  #<?= $uid ?> .mv2-cards{grid-template-columns:1fr}
}
</style>
<div id="<?= $uid ?>" class="mv2-wrap" data-unit="<?= htmlspecialchars($unit) ?>" data-days="<?= $days ?>" data-mode="<?= $modeDef ?>">
  <div class="mv2-topbar">
    <?php if($showLoc): ?>
    <select class="mv2-select-loc" aria-label="Lieu">
      <?php foreach ($locations as $i=>$L):
        $lbl = htmlspecialchars($L['name'] ?? ("Lieu ".($i+1)));
      ?>
      <option value="<?= $i ?>"><?= $lbl ?></option>
      <?php endforeach; ?>
    </select>
    <?php endif; ?>
    <?php if($showMode): ?>
    <select class="mv2-select-mode" aria-label="Mode d'affichage">
      <option value="digital"   <?= $modeDef==='digital'?'selected':'' ?>>Digital</option>
      <option value="numerique" <?= $modeDef==='numerique'?'selected':'' ?>>Numérique</option>
    </select>
    <?php endif; ?>
  </div>
  <div class="mv2-head">
    <div class="mv2-title">Prévisions</div>
    <div class="mv2-sub mv2-breadcrumb"></div>
  </div>
  <div class="mv2-view mv2-digital" style="display:none"></div>
  <div class="mv2-view mv2-numerique" style="display:none"></div>
</div>
<script>
(function(){
  const root  = document.getElementById("<?= $uid ?>");
  const unit  = root.dataset.unit || 'metric';
  const days  = Math.max(1, Math.min(7, parseInt(root.dataset.days||3)));
  const initMode = root.dataset.mode || 'digital';
  const selLoc  = root.querySelector('.mv2-select-loc');
  const selMode = root.querySelector('.mv2-select-mode');
  const breadcrumb = root.querySelector('.mv2-breadcrumb');
  const vDigital  = root.querySelector('.mv2-digital');
  const vTable    = root.querySelector('.mv2-numerique');
  const LOCATIONS = <?php echo json_encode($locations, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); ?>;
  function fmtDate(d, tz){
    try {
      return new Intl.DateTimeFormat('fr-FR', {weekday:'short', day:'2-digit', month:'short', timeZone: tz}).format(new Date(d));
    } catch(e){
      return d;
    }
  }
  function weatherEmoji(code){
    const group = [
      {set:[0], ico:"☀️"},
      {set:[1,2], ico:"🌤️"},
      {set:[3], ico:"☁️"},
      {set:[45,48], ico:"🌫️"},
      {set:[51,53,55,56,57], ico:"🌦️"},
      {set:[61,63,65], ico:"🌧️"},
      {set:[66,67], ico:"🌧️❄️"},
      {set:[71,73,75,77,85,86], ico:"🌨️"},
      {set:[80,81,82], ico:"🌦️"},
      {set:[95,96,99], ico:"⛈️"}
    ];
    code = Number(code)||0;
    for (const g of group) if (g.set.includes(code)) return g.ico;
    return "🌡️";
  }
  function currentSelection(){
    const idx = selLoc ? parseInt(selLoc.value) : 0;
    const L   = LOCATIONS[idx] || LOCATIONS[0];
    const mode= selMode ? selMode.value : initMode;
    return { idx, L, mode };
  }
  function buildUrl(L){
    const u = new URL("https://api.open-meteo.com/v1/forecast");
    u.searchParams.set("latitude",  L.lat);
    u.searchParams.set("longitude", L.lon);
    u.searchParams.set("timezone",  L.tz || "auto");
    u.searchParams.set("daily", "weathercode,temperature_2m_max,temperature_2m_min,precipitation_sum,windspeed_10m_max");
    u.searchParams.set("forecast_days", days);
    if (unit === 'imperial'){
      u.searchParams.set("temperature_unit", "fahrenheit");
      u.searchParams.set("wind_speed_unit", "mph");
    } else {
      u.searchParams.set("temperature_unit", "celsius");
      u.searchParams.set("wind_speed_unit", "kmh");
    }
    return u.toString();
  }
  async function load(){
    const {L, mode} = currentSelection();
    breadcrumb.textContent = `${L.name || 'Lieu'} • ${days} jour${days>1?'s':''} • ${L.tz || 'TZ: auto'}`;
    const url = buildUrl(L);
    vDigital.style.display = 'none';
    vTable.style.display   = 'none';
    vDigital.innerHTML     = 'Chargement…';
    vTable.innerHTML       = 'Chargement…';
    try{
      const r = await fetch(url, {cache:'no-store'});
      if(!r.ok) throw new Error('HTTP '+r.status);
      const data = await r.json();
      render(data, L, mode);
    }catch(e){
      vDigital.innerHTML = `<div style="padding:8px;opacity:.85">❌ Impossible de récupérer la météo.</div>`;
      vTable.innerHTML   = vDigital.innerHTML;
      vDigital.style.display = (mode==='digital')?'block':'none';
      vTable.style.display   = (mode==='numerique')?'block':'none';
    }
  }
  function render(data, L, mode){
    const d = (data && data.daily) ? data.daily : null;
    if(!d){ vDigital.textContent='Données indisponibles'; vTable.textContent='Données indisponibles'; return; }
    const rows = d.time.map((t, i)=>({
      date: fmtDate(t, L.tz || 'UTC'),
      wmo: d.weathercode[i],
      tmax: d.temperature_2m_max[i],
      tmin: d.temperature_2m_min[i],
      rain: d.precipitation_sum[i],
      wind: d.windspeed_10m_max[i]
    }));
    vDigital.innerHTML = `
      <div class="mv2-cards">
        ${rows.map(r => `
          <div class="mv2-card">
            <div class="mv2-row"><span class="mv2-date">${r.date}</span><span class="mv2-ico">${weatherEmoji(r.wmo)}</span></div>
            <div class="mv2-temp">${Math.round(r.tmax)}° / ${Math.round(r.tmin)}°</div>
            <div class="mv2-row"><span>Pluie</span><span>${(r.rain||0).toFixed(1)} mm</span></div>
            <div class="mv2-row"><span>Vent max</span><span>${Math.round(r.wind)} ${unit==='imperial'?'mph':'km/h'}</span></div>
          </div>
        `).join('')}
      </div>
    `;
    vTable.innerHTML = `
      <table class="mv2-table">
        <thead>
          <tr>
            <th>Jour</th>
            <th>Cond.</th>
            <th>Max</th>
            <th>Min</th>
            <th>Pluie</th>
            <th>Vent max</th>
          </tr>
        </thead>
        <tbody>
          ${rows.map(r=>`
            <tr>
              <td>${r.date}</td>
              <td>${weatherEmoji(r.wmo)}</td>
              <td>${Math.round(r.tmax)}°</td>
              <td>${Math.round(r.tmin)}°</td>
              <td>${(r.rain||0).toFixed(1)} mm</td>
              <td>${Math.round(r.wind)} ${unit==='imperial'?'mph':'km/h'}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
    vDigital.style.display = (mode==='digital')?'block':'none';
    vTable.style.display   = (mode==='numerique')?'block':'none';
  }
  if (selLoc)  selLoc.addEventListener('change', load);
  if (selMode) selMode.addEventListener('change', load);
  if (selMode) selMode.value = initMode;
  load();
})();
</script>
