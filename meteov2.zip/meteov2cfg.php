<?php
if (session_status()===PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { echo "<div style='color:#f66;padding:10px'>⛔ Non connecté</div>"; return; }
$cfgFile = __DIR__ . "/../../users/profiles/$email/meteov2.json";
@mkdir(dirname($cfgFile), 0775, true);
$cfg = file_exists($cfgFile) ? json_decode(file_get_contents($cfgFile), true) : [];
if (!$cfg) {
  $cfg = [
    "locations" => [["name"=>"Paris, FR","lat"=>48.8566,"lon"=>2.3522,"tz"=>"Europe/Paris"]],
    "days" => 3, "unit"=>"metric", "default_mode"=>"digital",
    "show_mode_switch"=>true, "show_location_switch"=>true
  ];
}
$msg = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (!empty($_POST['remove_idx'])) {
        $rm = array_map('intval', (array)$_POST['remove_idx']);
        $locs = $cfg['locations'] ?? [];
        $new  = [];
        foreach ($locs as $i=>$L) if (!in_array($i, $rm, true)) $new[] = $L;
        $cfg['locations'] = $new;
    }
    if (!empty($_POST['add_locations_json'])) {
        $toAdd = json_decode($_POST['add_locations_json'], true);
        if (is_array($toAdd)) {
            $cfg['locations'] = array_values(array_merge($cfg['locations']??[], $toAdd));
        }
    }
    $days = intval($_POST['days'] ?? 3);
    $cfg['days'] = max(1, min(7, $days));
    $unit = ($_POST['unit'] ?? 'metric');
    $cfg['unit'] = ($unit === 'imperial') ? 'imperial' : 'metric';
    $mode = ($_POST['default_mode'] ?? 'digital');
    $cfg['default_mode'] = ($mode === 'numerique') ? 'numerique' : 'digital';
    $cfg['show_mode_switch'] = !empty($_POST['show_mode_switch']);
    $cfg['show_location_switch'] = !empty($_POST['show_location_switch']);
    file_put_contents($cfgFile, json_encode($cfg, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
    $msg = '✅ Configuration enregistrée';
}
$isIncluded = (strpos($_SERVER['SCRIPT_NAME'], '/modules/meteov2/') === false);
$formAction = $isIncluded ? '?module=meteov2' : '';
?>
<style>
.mv2cfg{display:flex;flex-direction:column;gap:14px}
.mv2cfg .sect{
  background: var(--panel-bg, #151515);
  border:1px solid var(--primary-color, #666);
  border-radius:14px; padding:12px
}
.mv2cfg h3{margin:0 0 8px 0; font-size:16px}
.mv2cfg label{display:block; margin:6px 0 2px}
.mv2cfg input[type="text"], .mv2cfg select{
  width:100%; background:var(--panel-bg, #151515); color:inherit;
  border:1px solid var(--primary-color, #666); border-radius:8px; padding:8px
}
.mv2cfg .row{display:flex; gap:10px; flex-wrap:wrap}
.mv2cfg .row > div{flex:1 1 220px}
.mv2cfg .pill{
  border:1px dashed var(--primary-color, #666); border-radius:10px; padding:8px; margin:6px 0;
  display:flex; align-items:center; justify-content:space-between; gap:8px
}
.mv2cfg .btn{
  background:transparent; color:inherit; border:1px solid var(--primary-color, #666);
  border-radius:10px; padding:8px 10px; cursor:pointer
}
.mv2cfg .btn.primary{background:var(--primary-color, #666); color:#000; border-color:var(--primary-color, #666)}
.mv2cfg .muted{opacity:.8}
</style>
<div class="mv2cfg">
  <?php if($msg): ?><div class="sect" style="border-color:limegreen"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
  <form method="post" action="<?= $formAction ?>">
    <input type="hidden" name="add_locations_json" id="mv2-add-json" value="">
    <div class="sect">
      <h3>🎯 Lieux configurés</h3>
      <?php if(empty($cfg['locations'])): ?>
        <div class="muted">Aucun lieu pour l’instant.</div>
      <?php endif; ?>
      <?php foreach(($cfg['locations']??[]) as $i=>$L): ?>
        <div class="pill">
          <div>
            <div><strong><?= htmlspecialchars($L['name'] ?? 'Lieu') ?></strong></div>
            <div class="muted">lat: <?= htmlspecialchars($L['lat']) ?>, lon: <?= htmlspecialchars($L['lon']) ?> • TZ: <?= htmlspecialchars($L['tz'] ?? 'auto') ?></div>
          </div>
          <label style="display:flex;align-items:center;gap:6px">
            <input type="checkbox" name="remove_idx[]" value="<?= $i ?>"> Supprimer
          </label>
        </div>
      <?php endforeach; ?>
      <div class="row" style="margin-top:10px">
        <div>
          <label>Rechercher un lieu (ville, pays)</label>
          <input type="text" id="mv2-q" placeholder="ex: Pau, FR">
        </div>
        <div style="align-self:flex-end">
          <button type="button" class="btn" id="mv2-search">🔎 Rechercher</button>
        </div>
      </div>
      <div id="mv2-results" class="muted" style="margin-top:6px">Astuce : tape un nom de ville puis “Rechercher”.</div>
      <div id="mv2-toadd" class="muted" style="margin-top:6px"></div>
    </div>
    <div class="sect">
      <h3>⚙️ Réglages</h3>
      <div class="row">
        <div>
          <label>Nombre de jours (1–7)</label>
          <select name="days">
            <?php for($d=1;$d<=7;$d++): ?>
              <option value="<?= $d ?>" <?= intval($cfg['days']??3)===$d?'selected':'' ?>><?= $d ?></option>
            <?php endfor; ?>
          </select>
        </div>
        <div>
          <label>Unité</label>
          <select name="unit">
            <option value="metric"  <?= ($cfg['unit']??'metric')==='metric'?'selected':'' ?>>Métrique (°C, km/h)</option>
            <option value="imperial"<?= ($cfg['unit']??'metric')==='imperial'?'selected':'' ?>>Impérial (°F, mph)</option>
          </select>
        </div>
        <div>
          <label>Mode par défaut</label>
          <select name="default_mode">
            <option value="digital"   <?= ($cfg['default_mode']??'digital')==='digital'?'selected':'' ?>>Digital (cartes)</option>
            <option value="numerique" <?= ($cfg['default_mode']??'digital')==='numerique'?'selected':'' ?>>Numérique (table)</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div>
          <label><input type="checkbox" name="show_location_switch" <?= !empty($cfg['show_location_switch'])?'checked':'' ?>> Afficher le sélecteur de lieu dans le module</label>
        </div>
        <div>
          <label><input type="checkbox" name="show_mode_switch" <?= !empty($cfg['show_mode_switch'])?'checked':'' ?>> Afficher le sélecteur de mode dans le module</label>
        </div>
      </div>
    </div>
    <div class="sect" style="display:flex;gap:8px;justify-content:flex-end">
      <button type="submit" class="btn">💾 Enregistrer</button>
      <?php if(!$isIncluded): ?>
      <a class="btn" href="meteov2.php" style="text-decoration:none">↩️ Retour module</a>
      <?php endif; ?>
    </div>
  </form>
</div>
<script>
(function(){
  const q = document.getElementById('mv2-q');
  const btn = document.getElementById('mv2-search');
  const res = document.getElementById('mv2-results');
  const toadd = document.getElementById('mv2-toadd');
  const addJson = document.getElementById('mv2-add-json');
  let buffer = [];
  function renderToAdd(){
    if (!buffer.length){ toadd.innerHTML = ''; return; }
    toadd.innerHTML = '<div><strong>À ajouter :</strong></div>' + buffer.map((L,i)=>`
      <div class="pill">
        <div>
          <div><strong>${L.name}</strong></div>
          <div class="muted">lat: ${L.lat}, lon: ${L.lon} • TZ: ${L.tz||'auto'}</div>
        </div>
        <button type="button" class="btn" data-rm="${i}">Retirer</button>
      </div>
    `).join('');
    addJson.value = JSON.stringify(buffer);
    toadd.querySelectorAll('[data-rm]').forEach(b=>{
      b.addEventListener('click', ()=>{
        const i = parseInt(b.dataset.rm);
        buffer.splice(i,1); renderToAdd();
      });
    });
  }
  async function search(){
    const s = (q.value||'').trim();
    if (!s){ res.textContent = 'Saisis une ville, ex: Pau, FR'; return; }
    res.textContent = 'Recherche…';
    try{
      const u = new URL('https://geocoding-api.open-meteo.com/v1/search');
      u.searchParams.set('name', s);
      u.searchParams.set('language','fr');
      u.searchParams.set('count','10');
      const r = await fetch(u, {cache:'no-store'});
      if (!r.ok) throw new Error('HTTP '+r.status);
      const j = await r.json();
      const list = (j.results||[]).map(x=>({
        name: `${x.name}${x.admin1?`, ${x.admin1}`:''}${x.country?`, ${x.country}`:''}`,
        lat: x.latitude, lon: x.longitude, tz: x.timezone || 'auto'
      }));
      if (!list.length){ res.textContent = 'Aucun résultat.'; return; }
      res.innerHTML = list.map((L,i)=>`
        <div class="pill">
          <div>
            <div><strong>${L.name}</strong></div>
            <div class="muted">lat: ${L.lat}, lon: ${L.lon} • TZ: ${L.tz}</div>
          </div>
          <button type="button" class="btn primary" data-add='${JSON.stringify(L).replace(/'/g,"&#39;")}'>Ajouter</button>
        </div>
      `).join('');
      res.querySelectorAll('[data-add]').forEach(b=>{
        b.addEventListener('click', ()=>{
          const L = JSON.parse(b.getAttribute('data-add').replace(/&#39;/g,"'"));
          // éviter doublons exacts (lat/lon)
          if (!buffer.some(e=> e.lat===L.lat && e.lon===L.lon)){
            buffer.push(L); renderToAdd();
          }
        });
      });
    } catch(e){
      res.textContent = '❌ Erreur de recherche.';
    }
  }
  btn.addEventListener('click', search);
  q.addEventListener('keydown', (ev)=>{ if(ev.key==='Enter'){ ev.preventDefault(); search(); } });
})();
</script>
