<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['user']['email'])) {
    echo "<div class='section'>⛔ Non connecté</div>";
    return;
}

$ipcalcCssVersion = @filemtime(__DIR__ . '/ipcalc.css') ?: time();
?>
<link rel="stylesheet" href="modules/ipcalc/ipcalc.css?v=<?= htmlspecialchars((string)$ipcalcCssVersion, ENT_QUOTES, 'UTF-8') ?>">

<section class="dmd-ipcalc" data-ipcalc-root>
    <header class="dmd-ipcalc__hero">
        <div>
            <span class="dmd-ipcalc__eyebrow">Network tools</span>
            <h2>IPCalc Pro</h2>
            <p>Calculs réseau rapides, popups et exports.</p>
        </div>
        <div class="dmd-ipcalc__status">
            <span class="dmd-ipcalc__pulse"></span>
            <strong>Prêt</strong>
            <small>Sans CFG</small>
        </div>
    </header>

    <div class="dmd-ipcalc__grid" aria-label="Catégories IPCalc">
        <button type="button" class="dmd-ipcalc__tile" data-ipcalc-open="ipv4">
            <span class="dmd-ipcalc__tile-icon">🧮</span>
            <span class="dmd-ipcalc__tile-title">IPv4 / CIDR</span>
            <span class="dmd-ipcalc__tile-desc">Réseau, masque, plage.</span>
        </button>

        <button type="button" class="dmd-ipcalc__tile" data-ipcalc-open="autocidr">
            <span class="dmd-ipcalc__tile-icon">📐</span>
            <span class="dmd-ipcalc__tile-title">Auto-CIDR</span>
            <span class="dmd-ipcalc__tile-desc">Préfixe selon besoin IP.</span>
        </button>

        <button type="button" class="dmd-ipcalc__tile" data-ipcalc-open="vlsm">
            <span class="dmd-ipcalc__tile-icon">📘</span>
            <span class="dmd-ipcalc__tile-title">Plan VLSM</span>
            <span class="dmd-ipcalc__tile-desc">Sous-réseaux auto.</span>
        </button>

        <button type="button" class="dmd-ipcalc__tile" data-ipcalc-open="ipv6">
            <span class="dmd-ipcalc__tile-icon">🧬</span>
            <span class="dmd-ipcalc__tile-title">IPv6</span>
            <span class="dmd-ipcalc__tile-desc">Validation et compression.</span>
        </button>

        <button type="button" class="dmd-ipcalc__tile" data-ipcalc-open="convert">
            <span class="dmd-ipcalc__tile-icon">🔁</span>
            <span class="dmd-ipcalc__tile-title">Conversions</span>
            <span class="dmd-ipcalc__tile-desc">Décimal, binaire, hexa.</span>
        </button>
    </div>

    <div class="dmd-ipcalc__mini-help">
        <strong>Popups :</strong> mobiles, redimensionnables, multi-fenêtres.
    </div>

    <article class="dmd-ipcalc-popup" data-ipcalc-popup="ipv4" aria-hidden="true">
        <div class="dmd-ipcalc-popup__bar" data-ipcalc-drag>
            <div><strong>🧮 IPv4 / CIDR</strong><small>Calcul réseau complet</small></div>
            <button type="button" data-ipcalc-close="ipv4">×</button>
        </div>
        <div class="dmd-ipcalc-popup__body">
            <div class="dmd-ipcalc-form dmd-ipcalc-form--two">
                <label>Adresse IPv4<input type="text" data-ipcalc-ipv4-ip value="192.168.1.10" placeholder="192.168.1.10"></label>
                <label>CIDR ou masque<input type="text" data-ipcalc-ipv4-cidr value="24" placeholder="24 ou 255.255.255.0"></label>
            </div>
            <div class="dmd-ipcalc-actions">
                <button type="button" data-ipcalc-run="ipv4">Calculer</button>
                <button type="button" data-ipcalc-export="ipv4-txt" disabled>TXT</button>
                <button type="button" data-ipcalc-export="ipv4-csv" disabled>CSV</button>
                <button type="button" data-ipcalc-export="ipv4-json" disabled>JSON</button>
                <button type="button" data-ipcalc-export="ipv4-pdf" disabled>PDF</button>
            </div>
            <div class="dmd-ipcalc-result" data-ipcalc-result="ipv4"></div>
        </div>
    </article>

    <article class="dmd-ipcalc-popup" data-ipcalc-popup="autocidr" aria-hidden="true">
        <div class="dmd-ipcalc-popup__bar" data-ipcalc-drag>
            <div><strong>📐 Auto-CIDR</strong><small>Préfixe optimal</small></div>
            <button type="button" data-ipcalc-close="autocidr">×</button>
        </div>
        <div class="dmd-ipcalc-popup__body">
            <div class="dmd-ipcalc-form dmd-ipcalc-form--two">
                <label>Adresse de base<input type="text" data-ipcalc-auto-base value="192.168.0.0" placeholder="192.168.0.0"></label>
                <label>IP utilisables nécessaires<input type="number" data-ipcalc-auto-needed value="500" min="1"></label>
            </div>
            <div class="dmd-ipcalc-actions">
                <button type="button" data-ipcalc-run="autocidr">Trouver</button>
                <button type="button" data-ipcalc-export="autocidr-txt" disabled>TXT</button>
                <button type="button" data-ipcalc-export="autocidr-csv" disabled>CSV</button>
                <button type="button" data-ipcalc-export="autocidr-json" disabled>JSON</button>
                <button type="button" data-ipcalc-export="autocidr-pdf" disabled>PDF</button>
            </div>
            <div class="dmd-ipcalc-result" data-ipcalc-result="autocidr"></div>
        </div>
    </article>

    <article class="dmd-ipcalc-popup dmd-ipcalc-popup--wide" data-ipcalc-popup="vlsm" aria-hidden="true">
        <div class="dmd-ipcalc-popup__bar" data-ipcalc-drag>
            <div><strong>📘 Générateur VLSM</strong><small>Plan d’adressage complet</small></div>
            <button type="button" data-ipcalc-close="vlsm">×</button>
        </div>
        <div class="dmd-ipcalc-popup__body">
            <div class="dmd-ipcalc-form dmd-ipcalc-form--two">
                <label>Réseau de base<input type="text" data-ipcalc-vlsm-base value="10.10.0.0/16" placeholder="10.10.0.0/16"></label>
                <label>Besoins IP<input type="text" data-ipcalc-vlsm-list value="500,200,50,20" placeholder="500, 200, 50, 20"></label>
            </div>
            <div class="dmd-ipcalc-actions">
                <button type="button" data-ipcalc-run="vlsm">Générer</button>
                <button type="button" data-ipcalc-export="vlsm-txt" disabled>TXT</button>
                <button type="button" data-ipcalc-export="vlsm-csv" disabled>CSV</button>
                <button type="button" data-ipcalc-export="vlsm-json" disabled>JSON</button>
                <button type="button" data-ipcalc-export="vlsm-pdf" disabled>PDF</button>
            </div>
            <div class="dmd-ipcalc-result" data-ipcalc-result="vlsm"></div>
        </div>
    </article>

    <article class="dmd-ipcalc-popup dmd-ipcalc-popup--wide" data-ipcalc-popup="ipv6" aria-hidden="true">
        <div class="dmd-ipcalc-popup__bar" data-ipcalc-drag>
            <div><strong>🧬 IPv6</strong><small>Analyse et outils IPv6</small></div>
            <button type="button" data-ipcalc-close="ipv6">×</button>
        </div>
        <div class="dmd-ipcalc-popup__body">
            <div class="dmd-ipcalc-tabs" role="tablist">
                <button type="button" class="is-active" data-ipcalc-tab="analyse">Analyse</button>
                <button type="button" data-ipcalc-tab="compress">Compression</button>
                <button type="button" data-ipcalc-tab="subnet">Sous-réseaux</button>
                <button type="button" data-ipcalc-tab="guide">Mémo</button>
            </div>

            <div class="dmd-ipcalc-tab is-active" data-ipcalc-tab-panel="analyse">
                <div class="dmd-ipcalc-form dmd-ipcalc-form--two">
                    <label>Adresse IPv6<input type="text" data-ipcalc-ipv6-ip value="2001:db8:abcd:12::1"></label>
                    <label>Préfixe<input type="number" data-ipcalc-ipv6-cidr value="64" min="0" max="128"></label>
                </div>
                <div class="dmd-ipcalc-actions">
                    <button type="button" data-ipcalc-run="ipv6">Analyser</button>
                    <button type="button" data-ipcalc-export="ipv6-txt" disabled>TXT</button>
                    <button type="button" data-ipcalc-export="ipv6-json" disabled>JSON</button>
                    <button type="button" data-ipcalc-export="ipv6-pdf" disabled>PDF</button>
                </div>
                <div class="dmd-ipcalc-result" data-ipcalc-result="ipv6"></div>
            </div>

            <div class="dmd-ipcalc-tab" data-ipcalc-tab-panel="compress">
                <div class="dmd-ipcalc-form dmd-ipcalc-form--two">
                    <label>IPv6 à traiter<input type="text" data-ipcalc-ipv6-convert value="2001:0db8:0000:0000:0000:ff00:0042:8329"></label>
                    <label>Validation<input type="text" data-ipcalc-ipv6-valid value="2001:db8::ff"></label>
                </div>
                <div class="dmd-ipcalc-actions"><button type="button" data-ipcalc-run="ipv6convert">Compresser / décompresser / valider</button></div>
                <div class="dmd-ipcalc-result" data-ipcalc-result="ipv6convert"></div>
            </div>

            <div class="dmd-ipcalc-tab" data-ipcalc-tab-panel="subnet">
                <div class="dmd-ipcalc-form dmd-ipcalc-form--two">
                    <label>IPv6 + préfixe<input type="text" data-ipcalc-ipv6-subnet-base value="2001:db8::/48"></label>
                    <label>Nouveau préfixe<input type="number" data-ipcalc-ipv6-subnet-new value="64" min="0" max="128"></label>
                </div>
                <div class="dmd-ipcalc-actions"><button type="button" data-ipcalc-run="ipv6subnet">Découper</button></div>
                <div class="dmd-ipcalc-result" data-ipcalc-result="ipv6subnet"></div>
            </div>

            <div class="dmd-ipcalc-tab" data-ipcalc-tab-panel="guide">
                <div class="dmd-ipcalc-guide">
                    <h3>Repères rapides</h3>
                    <p><strong>/24 IPv4</strong> = 256 adresses, 254 utilisables.</p>
                    <p><strong>Wildcard</strong> = inverse du masque, pratique pour ACL Cisco.</p>
                    <p><strong>VLSM</strong> trie les besoins du plus grand au plus petit pour éviter le gaspillage.</p>
                    <p><strong>/64 IPv6</strong> est le préfixe standard d’un LAN.</p>
                </div>
            </div>
        </div>
    </article>

    <article class="dmd-ipcalc-popup" data-ipcalc-popup="convert" aria-hidden="true">
        <div class="dmd-ipcalc-popup__bar" data-ipcalc-drag>
            <div><strong>🔁 Conversions IPv4</strong><small>Décimal, binaire, hexadécimal</small></div>
            <button type="button" data-ipcalc-close="convert">×</button>
        </div>
        <div class="dmd-ipcalc-popup__body">
            <div class="dmd-ipcalc-form">
                <label>Adresse IPv4<input type="text" data-ipcalc-convert-ip value="192.168.1.10"></label>
            </div>
            <div class="dmd-ipcalc-actions">
                <button type="button" data-ipcalc-run="convert">Convertir</button>
                <button type="button" data-ipcalc-export="convert-txt" disabled>TXT</button>
                <button type="button" data-ipcalc-export="convert-json" disabled>JSON</button>
            </div>
            <div class="dmd-ipcalc-result" data-ipcalc-result="convert"></div>
        </div>
    </article>
</section>

<script>
(() => {
    const root = document.querySelector('[data-ipcalc-root]');
    if (!root || root.dataset.ready === '1') return;
    root.dataset.ready = '1';

    const state = {};
    let topZ = 5000;

    const $ = (selector, base = root) => base.querySelector(selector);
    const $$ = (selector, base = root) => Array.from(base.querySelectorAll(selector));

    function clamp(value, min, max) {
        return Math.min(max, Math.max(min, value));
    }

    function showPopup(name) {
        const popup = $(`[data-ipcalc-popup="${name}"]`);
        if (!popup) return;
        popup.classList.add('is-open');
        popup.setAttribute('aria-hidden', 'false');
        popup.style.zIndex = String(++topZ);

        if (!popup.dataset.positioned) {
            const offset = Object.keys(state).length * 18;
            popup.style.left = `${clamp(42 + offset, 10, window.innerWidth - 280)}px`;
            popup.style.top = `${clamp(90 + offset, 10, window.innerHeight - 180)}px`;
            popup.dataset.positioned = '1';
        }
    }

    function closePopup(name) {
        const popup = $(`[data-ipcalc-popup="${name}"]`);
        if (!popup) return;
        popup.classList.remove('is-open');
        popup.setAttribute('aria-hidden', 'true');
    }

    $$('[data-ipcalc-open]').forEach(btn => btn.addEventListener('click', () => showPopup(btn.dataset.ipcalcOpen)));
    $$('[data-ipcalc-close]').forEach(btn => btn.addEventListener('click', () => closePopup(btn.dataset.ipcalcClose)));

    $$('[data-ipcalc-popup]').forEach(popup => {
        popup.addEventListener('mousedown', () => popup.style.zIndex = String(++topZ));
        const bar = $('[data-ipcalc-drag]', popup);
        if (!bar) return;
        bar.addEventListener('mousedown', event => {
            if (event.target.closest('button')) return;
            const startX = event.clientX;
            const startY = event.clientY;
            const rect = popup.getBoundingClientRect();
            const onMove = moveEvent => {
                popup.style.left = `${clamp(rect.left + moveEvent.clientX - startX, 0, window.innerWidth - 80)}px`;
                popup.style.top = `${clamp(rect.top + moveEvent.clientY - startY, 0, window.innerHeight - 60)}px`;
            };
            const onUp = () => {
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
            };
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        });
    });

    $$('[data-ipcalc-tab]').forEach(tab => tab.addEventListener('click', () => {
        const popup = tab.closest('[data-ipcalc-popup]');
        $$('[data-ipcalc-tab]', popup).forEach(t => t.classList.remove('is-active'));
        $$('[data-ipcalc-tab-panel]', popup).forEach(panel => panel.classList.remove('is-active'));
        tab.classList.add('is-active');
        $(`[data-ipcalc-tab-panel="${tab.dataset.ipcalcTab}"]`, popup)?.classList.add('is-active');
    }));

    function errorBox(message) {
        return `<div class="dmd-ipcalc-error">⚠️ ${escapeHtml(message)}</div>`;
    }

    function escapeHtml(value) {
        return String(value).replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));
    }

    function ipv4ToInt(ip) {
        const parts = String(ip).trim().split('.');
        if (parts.length !== 4) throw new Error('Adresse IPv4 invalide.');
        return parts.reduce((acc, part) => {
            if (!/^\d+$/.test(part)) throw new Error('Adresse IPv4 invalide.');
            const n = Number(part);
            if (n < 0 || n > 255) throw new Error('Chaque octet doit être entre 0 et 255.');
            return (acc * 256) + n;
        }, 0) >>> 0;
    }

    function intToIpv4(value) {
        const n = Number(value) >>> 0;
        return [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255].join('.');
    }

    function cidrToMaskInt(cidr) {
        if (cidr === 0) return 0;
        return (0xffffffff << (32 - cidr)) >>> 0;
    }

    function cidrToMask(cidr) {
        return intToIpv4(cidrToMaskInt(cidr));
    }

    function maskToCidr(mask) {
        const value = ipv4ToInt(mask);
        const bin = value.toString(2).padStart(32, '0');
        if (!/^1*0*$/.test(bin)) throw new Error('Masque non contigu invalide.');
        return bin.indexOf('0') === -1 ? 32 : bin.indexOf('0');
    }

    function parseCidr(value) {
        const raw = String(value).trim().replace(/^\//, '');
        const cidr = raw.includes('.') ? maskToCidr(raw) : Number(raw);
        if (!Number.isInteger(cidr) || cidr < 0 || cidr > 32) throw new Error('CIDR invalide.');
        return cidr;
    }

    function ipv4Class(ip) {
        const first = Number(String(ip).split('.')[0]);
        if (first === 127) return 'Loopback';
        if (first <= 126) return 'A';
        if (first <= 191) return 'B';
        if (first <= 223) return 'C';
        if (first <= 239) return 'D multicast';
        return 'E réservé';
    }

    function ipv4Type(ipInt) {
        const ip = intToIpv4(ipInt);
        const o = ip.split('.').map(Number);
        if (o[0] === 10 || (o[0] === 172 && o[1] >= 16 && o[1] <= 31) || (o[0] === 192 && o[1] === 168)) return 'Privée RFC1918';
        if (o[0] === 127) return 'Loopback';
        if (o[0] === 169 && o[1] === 254) return 'APIPA / Link-local';
        if (o[0] >= 224 && o[0] <= 239) return 'Multicast';
        if (o[0] === 0 || o[0] >= 240) return 'Réservée';
        return 'Publique';
    }

    function calcIpv4(ip, cidrInput) {
        const ipInt = ipv4ToInt(ip);
        const cidr = parseCidr(cidrInput);
        const maskInt = cidrToMaskInt(cidr);
        const wildcardInt = (~maskInt) >>> 0;
        const network = (ipInt & maskInt) >>> 0;
        const broadcast = (network + wildcardInt) >>> 0;
        const total = Math.pow(2, 32 - cidr);
        const usable = cidr === 32 ? 1 : (cidr === 31 ? 2 : total - 2);
        const first = cidr >= 31 ? network : network + 1;
        const last = cidr >= 31 ? broadcast : broadcast - 1;

        return {
            title: `IPv4 ${ip}/${cidr}`,
            rows: [
                ['Adresse IP', intToIpv4(ipInt)],
                ['Classe', ipv4Class(intToIpv4(ipInt))],
                ['Type', ipv4Type(ipInt)],
                ['CIDR', `/${cidr}`],
                ['Masque', cidrToMask(cidr)],
                ['Wildcard', intToIpv4(wildcardInt)],
                ['Réseau', intToIpv4(network)],
                ['Broadcast', intToIpv4(broadcast)],
                ['Première IP utilisable', intToIpv4(first)],
                ['Dernière IP utilisable', intToIpv4(last)],
                ['Total adresses', String(total)],
                ['Adresses utilisables', String(usable)],
                ['Masque binaire', cidrToMask(cidr).split('.').map(o => Number(o).toString(2).padStart(8, '0')).join(' ')],
                ['IP binaire', intToIpv4(ipInt).split('.').map(o => Number(o).toString(2).padStart(8, '0')).join(' ')]
            ]
        };
    }

    function renderRows(targetName, data) {
        const result = $(`[data-ipcalc-result="${targetName}"]`);
        if (!result) return;
        state[targetName] = data;
        result.innerHTML = `<h3>${escapeHtml(data.title)}</h3><div class="dmd-ipcalc-result__grid">${data.rows.map(row => `
            <div class="dmd-ipcalc-result__item">
                <span>${escapeHtml(row[0])}</span>
                <strong>${escapeHtml(row[1])}</strong>
            </div>`).join('')}</div>`;
        enableExports(targetName);
    }

    function renderTable(targetName, data) {
        const result = $(`[data-ipcalc-result="${targetName}"]`);
        if (!result) return;
        state[targetName] = data;
        const headers = data.headers || [];
        result.innerHTML = `<h3>${escapeHtml(data.title)}</h3><div class="dmd-ipcalc-table-wrap"><table class="dmd-ipcalc-table"><thead><tr>${headers.map(h => `<th>${escapeHtml(h)}</th>`).join('')}</tr></thead><tbody>${data.rows.map(row => `<tr>${headers.map(h => `<td>${escapeHtml(row[h] ?? '')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
        enableExports(targetName);
    }

    function enableExports(targetName) {
        $$(`[data-ipcalc-export^="${targetName}-"]`).forEach(btn => btn.disabled = false);
    }

    function runIpv4() {
        try {
            renderRows('ipv4', calcIpv4($('[data-ipcalc-ipv4-ip]').value, $('[data-ipcalc-ipv4-cidr]').value));
        } catch (error) {
            $('[data-ipcalc-result="ipv4"]').innerHTML = errorBox(error.message);
        }
    }

    function runAutoCidr() {
        try {
            const base = $('[data-ipcalc-auto-base]').value;
            const needed = Number($('[data-ipcalc-auto-needed]').value);
            if (!Number.isInteger(needed) || needed < 1) throw new Error('Nombre d’IP nécessaires invalide.');
            const hostBits = Math.ceil(Math.log2(needed + 2));
            const cidr = clamp(32 - hostBits, 0, 32);
            const data = calcIpv4(base, cidr);
            data.title = `Auto-CIDR pour ${needed} IP utilisables`;
            data.rows.unshift(['Besoin demandé', `${needed} IP utilisables`]);
            renderRows('autocidr', data);
        } catch (error) {
            $('[data-ipcalc-result="autocidr"]').innerHTML = errorBox(error.message);
        }
    }

    function nextAlignedNetwork(current, blockSize) {
        return Math.ceil(current / blockSize) * blockSize;
    }

    function runVlsm() {
        try {
            const baseRaw = $('[data-ipcalc-vlsm-base]').value.trim();
            const [baseIp, baseCidrRaw = '24'] = baseRaw.split('/');
            const baseCidr = parseCidr(baseCidrRaw);
            const baseData = calcIpv4(baseIp, baseCidr);
            const baseNetwork = ipv4ToInt(baseData.rows.find(r => r[0] === 'Réseau')[1]);
            const baseBroadcast = ipv4ToInt(baseData.rows.find(r => r[0] === 'Broadcast')[1]);
            const needs = $('[data-ipcalc-vlsm-list]').value.split(',').map(v => Number(v.trim())).filter(v => Number.isInteger(v) && v > 0).sort((a, b) => b - a);
            if (!needs.length) throw new Error('Liste VLSM invalide. Exemple : 500, 200, 50, 20');

            let current = baseNetwork;
            const rows = [];
            needs.forEach((need, index) => {
                const hostBits = Math.ceil(Math.log2(need + 2));
                const cidr = clamp(32 - hostBits, 0, 32);
                const blockSize = Math.pow(2, 32 - cidr);
                const network = nextAlignedNetwork(current, blockSize) >>> 0;
                const broadcast = (network + blockSize - 1) >>> 0;
                if (broadcast > baseBroadcast || network < baseNetwork) throw new Error('Le plan VLSM dépasse le réseau de base.');
                rows.push({
                    '#': String(index + 1),
                    Besoin: `${need}`,
                    Réseau: `${intToIpv4(network)}/${cidr}`,
                    Masque: cidrToMask(cidr),
                    Première: cidr >= 31 ? intToIpv4(network) : intToIpv4(network + 1),
                    Dernière: cidr >= 31 ? intToIpv4(broadcast) : intToIpv4(broadcast - 1),
                    Broadcast: intToIpv4(broadcast),
                    Capacité: String(blockSize),
                    Utilisables: String(cidr === 32 ? 1 : (cidr === 31 ? 2 : blockSize - 2))
                });
                current = broadcast + 1;
            });
            renderTable('vlsm', { title: `Plan VLSM depuis ${baseRaw}`, headers: ['#', 'Besoin', 'Réseau', 'Masque', 'Première', 'Dernière', 'Broadcast', 'Capacité', 'Utilisables'], rows });
        } catch (error) {
            $('[data-ipcalc-result="vlsm"]').innerHTML = errorBox(error.message);
        }
    }

    function expandIpv6(ip) {
        const value = String(ip).trim().toLowerCase();
        if (!value || (value.match(/::/g) || []).length > 1) throw new Error('IPv6 invalide.');
        const sides = value.split('::');
        const left = sides[0] ? sides[0].split(':') : [];
        const right = sides.length === 2 && sides[1] ? sides[1].split(':') : [];
        const all = sides.length === 2 ? [...left, ...Array(8 - left.length - right.length).fill('0'), ...right] : left;
        if (all.length !== 8 || all.some(b => !/^[0-9a-f]{1,4}$/i.test(b))) throw new Error('IPv6 invalide.');
        return all.map(b => b.padStart(4, '0')).join(':');
    }

    function compressIpv6(ip) {
        const blocks = expandIpv6(ip).split(':').map(b => b.replace(/^0+/, '') || '0');
        let bestStart = -1, bestLen = 0, start = -1, len = 0;
        blocks.forEach((block, index) => {
            if (block === '0') {
                if (start === -1) start = index;
                len++;
                if (len > bestLen) { bestStart = start; bestLen = len; }
            } else { start = -1; len = 0; }
        });
        if (bestLen < 2) return blocks.join(':');
        const before = blocks.slice(0, bestStart).join(':');
        const after = blocks.slice(bestStart + bestLen).join(':');
        return `${before}::${after}`.replace(/^:/, '::').replace(/:$/, '::');
    }

    function ipv6ToBigInt(ip) {
        return BigInt('0x' + expandIpv6(ip).replace(/:/g, ''));
    }

    function bigIntToIpv6(value) {
        return value.toString(16).padStart(32, '0').match(/.{4}/g).join(':');
    }

    function runIpv6() {
        try {
            const ip = $('[data-ipcalc-ipv6-ip]').value;
            const cidr = Number($('[data-ipcalc-ipv6-cidr]').value);
            if (!Number.isInteger(cidr) || cidr < 0 || cidr > 128) throw new Error('Préfixe IPv6 invalide.');
            const ipNum = ipv6ToBigInt(ip);
            const hostBits = BigInt(128 - cidr);
            const network = (ipNum >> hostBits) << hostBits;
            const last = network + ((1n << hostBits) - 1n);
            renderRows('ipv6', {
                title: `Analyse IPv6 /${cidr}`,
                rows: [
                    ['IPv6 saisie', ip],
                    ['IPv6 expandée', expandIpv6(ip)],
                    ['IPv6 compressée', compressIpv6(ip)],
                    ['Réseau', `${compressIpv6(bigIntToIpv6(network))}/${cidr}`],
                    ['Dernière adresse', compressIpv6(bigIntToIpv6(last))],
                    ['Nombre d’adresses', hostBits >= 64n ? `2^${128 - cidr}` : String(1n << hostBits)]
                ]
            });
        } catch (error) {
            $('[data-ipcalc-result="ipv6"]').innerHTML = errorBox(error.message);
        }
    }

    function runIpv6Convert() {
        try {
            const ip = $('[data-ipcalc-ipv6-convert]').value;
            const validIp = $('[data-ipcalc-ipv6-valid]').value;
            let validText = 'Valide';
            try { expandIpv6(validIp); } catch (_) { validText = 'Invalide'; }
            $('[data-ipcalc-result="ipv6convert"]').innerHTML = `<div class="dmd-ipcalc-result__grid">
                <div class="dmd-ipcalc-result__item"><span>IPv6 expandée</span><strong>${escapeHtml(expandIpv6(ip))}</strong></div>
                <div class="dmd-ipcalc-result__item"><span>IPv6 compressée</span><strong>${escapeHtml(compressIpv6(ip))}</strong></div>
                <div class="dmd-ipcalc-result__item"><span>Validation</span><strong>${escapeHtml(validText)}</strong></div>
            </div>`;
        } catch (error) {
            $('[data-ipcalc-result="ipv6convert"]').innerHTML = errorBox(error.message);
        }
    }

    function runIpv6Subnet() {
        try {
            const raw = $('[data-ipcalc-ipv6-subnet-base]').value.trim();
            const [ip, prefixRaw] = raw.split('/');
            const prefix = Number(prefixRaw);
            const newPrefix = Number($('[data-ipcalc-ipv6-subnet-new]').value);
            if (!Number.isInteger(prefix) || !Number.isInteger(newPrefix) || prefix < 0 || newPrefix > 128 || newPrefix < prefix) throw new Error('Préfixe IPv6 invalide.');
            const count = 1n << BigInt(newPrefix - prefix);
            const maxShown = count > 256n ? 256n : count;
            const baseNum = (ipv6ToBigInt(ip) >> BigInt(128 - prefix)) << BigInt(128 - prefix);
            const step = 1n << BigInt(128 - newPrefix);
            let html = `<h3>${count.toString()} sous-réseaux disponibles</h3>`;
            if (count > 256n) html += `<p class="dmd-ipcalc-note">Affichage limité aux 256 premiers pour éviter de faire exploser le navigateur.</p>`;
            html += '<div class="dmd-ipcalc-list">';
            for (let i = 0n; i < maxShown; i++) html += `<code>${escapeHtml(compressIpv6(bigIntToIpv6(baseNum + (i * step))))}/${newPrefix}</code>`;
            html += '</div>';
            $('[data-ipcalc-result="ipv6subnet"]').innerHTML = html;
        } catch (error) {
            $('[data-ipcalc-result="ipv6subnet"]').innerHTML = errorBox(error.message);
        }
    }

    function runConvert() {
        try {
            const ip = $('[data-ipcalc-convert-ip]').value;
            const ipInt = ipv4ToInt(ip);
            renderRows('convert', {
                title: `Conversions ${intToIpv4(ipInt)}`,
                rows: [
                    ['IPv4', intToIpv4(ipInt)],
                    ['Décimal', String(ipInt)],
                    ['Binaire', intToIpv4(ipInt).split('.').map(o => Number(o).toString(2).padStart(8, '0')).join(' ')],
                    ['Hexadécimal', '0x' + ipInt.toString(16).padStart(8, '0').toUpperCase()],
                    ['Octets', intToIpv4(ipInt).split('.').join(' / ')]
                ]
            });
        } catch (error) {
            $('[data-ipcalc-result="convert"]').innerHTML = errorBox(error.message);
        }
    }

    $$('[data-ipcalc-run]').forEach(btn => btn.addEventListener('click', () => ({
        ipv4: runIpv4,
        autocidr: runAutoCidr,
        vlsm: runVlsm,
        ipv6: runIpv6,
        ipv6convert: runIpv6Convert,
        ipv6subnet: runIpv6Subnet,
        convert: runConvert
    }[btn.dataset.ipcalcRun]?.())));

    function dataToText(data) {
        if (!data) return '';
        if (data.headers) return `${data.title}\n\n${data.headers.join('\t')}\n${data.rows.map(row => data.headers.map(h => row[h] ?? '').join('\t')).join('\n')}`;
        return `${data.title}\n\n${data.rows.map(row => `${row[0]} : ${row[1]}`).join('\n')}`;
    }

    function dataToCsv(data) {
        if (!data) return '';
        const csvEscape = value => `"${String(value).replace(/"/g, '""')}"`;
        if (data.headers) return [data.headers.map(csvEscape).join(';'), ...data.rows.map(row => data.headers.map(h => csvEscape(row[h] ?? '')).join(';'))].join('\n');
        return ['Champ;Valeur', ...data.rows.map(row => `${csvEscape(row[0])};${csvEscape(row[1])}`)].join('\n');
    }

    function downloadFile(filename, content, type) {
        const blob = new Blob([content], { type });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
    }

    function printData(data) {
        if (!data) return;
        const html = `<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>${escapeHtml(data.title)}</title><style>body{font-family:Arial,sans-serif;padding:24px;color:#111}h1{font-size:22px}.item{border-bottom:1px solid #ddd;padding:8px 0}.item span{display:block;color:#555;font-size:12px}.item strong{font-size:15px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ddd;padding:7px;text-align:left}th{background:#f2f2f2}</style></head><body><h1>${escapeHtml(data.title)}</h1>${data.headers ? `<table><thead><tr>${data.headers.map(h=>`<th>${escapeHtml(h)}</th>`).join('')}</tr></thead><tbody>${data.rows.map(row=>`<tr>${data.headers.map(h=>`<td>${escapeHtml(row[h] ?? '')}</td>`).join('')}</tr>`).join('')}</tbody></table>` : data.rows.map(row=>`<div class="item"><span>${escapeHtml(row[0])}</span><strong>${escapeHtml(row[1])}</strong></div>`).join('')}</body></html>`;
        const frame = document.createElement('iframe');
        frame.className = 'dmd-ipcalc-print-frame';
        document.body.appendChild(frame);
        frame.srcdoc = html;
        frame.onload = () => {
            frame.contentWindow.focus();
            frame.contentWindow.print();
            setTimeout(() => frame.remove(), 1200);
        };
    }

    $$('[data-ipcalc-export]').forEach(btn => btn.addEventListener('click', () => {
        const [targetName, format] = btn.dataset.ipcalcExport.split('-');
        const data = state[targetName];
        if (!data) return;
        const stamp = new Date().toISOString().slice(0, 19).replace(/[T:]/g, '-');
        if (format === 'txt') downloadFile(`ipcalc-${targetName}-${stamp}.txt`, dataToText(data), 'text/plain;charset=utf-8');
        if (format === 'csv') downloadFile(`ipcalc-${targetName}-${stamp}.csv`, dataToCsv(data), 'text/csv;charset=utf-8');
        if (format === 'json') downloadFile(`ipcalc-${targetName}-${stamp}.json`, JSON.stringify(data, null, 2), 'application/json;charset=utf-8');
        if (format === 'pdf') printData(data);
    }));
})();
</script>
