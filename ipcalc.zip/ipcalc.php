<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (empty($_SESSION['user']['email'])) {
    echo "<div class='section'>⛔ Non connecté</div>";
    return;
}
?>
<div class="calc-tile" onclick="toggleIpCalc()">
    <h3>🧮 Calculateur IP / CIDR</h3>
    <p class="tile-desc">Analyse complète : classe, masque, plage…</p>
</div>
<style>
.calc-tile {
    background:#2a2a2a;
    padding:7px;
    border-radius:5px;
    border:1px solid #444;
    cursor:pointer;
    margin-bottom:12px;
}
.calc-tile h3 { margin:0; font-size:16px; }
.tile-desc { margin:2px 0 0 0; opacity:0.7; font-size:13px; }
</style>
<div id="ipCalcBlock" style="
    display:none;
    background:#1f1f1f;
    border:1px solid #444;
    padding:15px;
    border-radius:8px;
    margin-bottom:20px;
">
    <div class="ipcalc-row">
        <label>Adresse IP</label>
        <input type="text" class="ip-ip" value="192.168.1.10">
    </div>
    <div class="ipcalc-row">
        <label>CIDR ou masque</label>
        <input type="text" class="ip-cidr" value="24">
    </div>
    <button class="ipcalc-btn">Calculer</button>
    <button class="ipcalc-export" style="display:none;">📤 Exporter TXT</button>
    <button class="ipcalc-export-pdf" style="display:none;">📄 Exporter PDF</button>
    <div class="result" style="display:none; margin-top:20px;"></div>
</div>
<div id="ipPdfPopup"
     style="display:none; position:absolute; top:100px; left:100px;
     width:720px; height:760px; background:#1f1f1f;
     border:2px solid var(--primary-color); border-radius:10px;
     padding:10px; z-index:99999;">
    <div style="display:flex; justify-content:space-between; align-items:center;">
        <h3>📄 Aperçu PDF</h3>
        <button onclick="document.getElementById('ipPdfPopup').style.display='none'"
                style="background:red;color:white;border:none;padding:6px 10px;border-radius:6px;">✖</button>
    </div>
    <iframe id="ipPdfFrame" style="width:100%;height:700px;background:white;border:none;"></iframe>
</div>
<script>
function toggleIpCalc() {
    let b = document.getElementById("ipCalcBlock");
    b.style.display = (b.style.display === "none") ? "block" : "none";
}
function ipToBinRaw(ip){ return ip.split('.').map(o=>(+o).toString(2).padStart(8,'0')).join(''); }
function binToIp(b){ return [0,1,2,3].map(i=>parseInt(b.substr(i*8,8),2)).join('.'); }
function cidrToMask(c){
    let m=[];
    for(let i=0;i<4;i++){
        let b=Math.min(8,Math.max(0,c-i*8));
        m[i]=b?256-Math.pow(2,8-b):0;
    }
    return m;
}
function maskToCidr(mask){
    return mask.split('.').map(o=>parseInt(o).toString(2).padStart(8,'0'))
               .join('').split('1').length-1;
}
function cidrFromInput(v){
    v=v.trim();
    if(v.startsWith("/")) v=v.substring(1);
    if(v.includes(".")) return maskToCidr(v);
    return parseInt(v);
}
function ipType(ip){
    let o=ip.split('.').map(Number);
    if(o[0]==10) return "Privée";
    if(o[0]==172 && o[1]>=16 && o[1]<=31) return "Privée";
    if(o[0]==192 && o[1]==168) return "Privée";
    return "Publique";
}
function ipClass(ip){
    let o=ip.split('.').map(Number);
    if(o[0]<=126) return "A";
    if(o[0]==127) return "Loopback";
    if(o[0]<=191) return "B";
    if(o[0]<=223) return "C";
    return "D/E";
}
document.querySelector('.ipcalc-btn').addEventListener('click', ()=>{
    const ip=document.querySelector('.ip-ip').value.trim();
    let cidr=cidrFromInput(document.querySelector('.ip-cidr').value);
    const mask=cidrToMask(cidr);
    const maskBin="1".repeat(cidr)+"0".repeat(32-cidr);
    const ipBin=ipToBinRaw(ip);
    const netBin=[...ipBin].map((b,i)=> (b==='1'&&maskBin[i]==='1')?'1':'0').join('');
    const bcBin =netBin.substring(0,cidr)+"1".repeat(32-cidr);
    const total=2**(32-cidr);
    const usable=cidr>=31?0:total-2;
    let first = cidr<31?binToIp((parseInt(netBin,2)+1).toString(2).padStart(32,'0')) : "-";
    let last  = cidr<31?binToIp((parseInt(bcBin,2)-1).toString(2).padStart(32,'0')) : "-";
    document.querySelector('.result').innerHTML = `
        <div class="resbox"><strong>Classe :</strong> ${ipClass(ip)}</div>
        <div class="resbox"><strong>Type :</strong> ${ipType(ip)}</div>
        <div class="resbox"><strong>Masque :</strong> ${mask.join('.')}</div>
        <div class="resbox">
            <strong>Masque binaire :</strong><br>
            <code>${maskBin.match(/.{1,8}/g).join(" ")}</code>
        </div>
        <div class="resbox"><strong>Adresse réseau :</strong> ${binToIp(netBin)}</div>
        <div class="resbox"><strong>Broadcast :</strong> ${binToIp(bcBin)}</div>
        <div class="resbox"><strong>1ère IP :</strong> ${first}</div>
        <div class="resbox"><strong>Dernière IP :</strong> ${last}</div>
        <div class="resbox"><strong>Total IP :</strong> ${total}</div>
        <div class="resbox"><strong>IP utilisables :</strong> ${usable}</div>
        <div class="resbox"><strong>Wildcard :</strong> ${mask.map(o=>255-o).join('.')}</div>
    `;
    document.querySelector('.result').style.display="block";
    document.querySelector('.ipcalc-export').style.display="block";
    document.querySelector('.ipcalc-export-pdf').style.display="block";
});
document.querySelector('.ipcalc-export').addEventListener('click',()=>{
    let txt="";
    document.querySelectorAll(".result .resbox")
        .forEach(p=>txt+=p.innerText+"\n");
    const blob=new Blob([txt],{type:"text/plain"});
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a");
    a.href=url; a.download="ipcalc_result.txt"; a.click();
});
document.querySelector('.ipcalc-export-pdf').addEventListener('click',()=>{
    let html = `
        <html><body style='font-family:Arial;padding:20px;'>
        <h2>Calcul IP / CIDR</h2>
        ${document.querySelector('.result').innerHTML}
        </body></html>
    `;
    const frame=document.getElementById("ipPdfFrame");
    frame.srcdoc = html;
    document.getElementById("ipPdfPopup").style.display="block";
    frame.onload = () => frame.contentWindow.print();
});
</script>
<style>
.ipcalc-row { margin-bottom:10px; }
.ipcalc input{
    width:100%; padding:6px 10px; height:32px;
    background:#333; border:1px solid #555; color:white; border-radius:4px;
}
.ipcalc-btn, .ipcalc-export, .ipcalc-export-pdf{
    width:100%; padding:8px; margin-top:10px;
    background:var(--primary-color,#56b6c2);
    border:none; color:white; border-radius:5px; cursor:pointer;
}
.resbox{
    padding:10px; background:#222; border:1px solid #333;
    border-radius:6px; margin-bottom:10px;
}
code{
    background:#333; padding:5px; border-radius:5px;
    font-size:13px; display:inline-block; word-break:break-all;
}
</style>
<div class="calc-tile" onclick="toggleAidCalc()">
    <h3>📐 Assistant Auto-CIDR / VLSM</h3>
    <p class="tile-desc">Trouver automatiquement le meilleur sous-réseau</p>
</div>
<style>
.calc-tile {
    background:#2a2a2a;
    padding:7px;
    border-radius:5px;
    border:1px solid #444;
    cursor:pointer;
    margin-bottom:12px;
}
.calc-tile h3 { margin:0; font-size:16px; }
.tile-desc { margin:2px 0 0 0; opacity:0.7; font-size:13px; }
</style>
<div id="aidCalcBlock" style="
    display:none;
    background:#1f1f1f;
    border:1px solid #444;
    padding:15px;
    border-radius:8px;
    margin-bottom:20px;
">
    <label>Adresse de base</label>
    <input type="text" class="aid-base"
           value="192.168.0.0"
           style="width:100%;margin-bottom:8px;background:#333;color:white;
                  border:1px solid #555;border-radius:4px;padding:6px;">
    <label>Nombre d’IP nécessaires</label>
    <input type="number" class="aid-needed"
           value="500"
           style="width:100%;margin-bottom:12px;background:#333;color:white;
                  border:1px solid #555;border-radius:4px;padding:6px;">
    <button class="aid-btn1"
            style="width:100%;padding:8px;background:var(--primary-color,#56b6c2);
                   border:none;color:white;border-radius:4px;">
        Trouver le meilleur sous-réseau
    </button>
    <button class="aid-export-pdf"
            style="width:100%;padding:8px;background:var(--primary-color,#56b6c2);
                   border:none;color:white;border-radius:4px;margin-top:15px;display:none;">
        📄 Exporter en PDF
    </button>
    <div class="aid-result1"
         style="margin-top:15px;display:none;background:#2e2e2e;
                padding:10px;border-radius:6px;"></div>
</div>
<div id="aidPdfPopup"
     style="display:none; position:absolute; top:80px; left:80px;
     width:700px; height:760px; background:#1f1f1f;
     border:2px solid var(--primary-color); border-radius:10px;
     overflow:hidden; padding:0; z-index:10000;">
    <div style="padding:8px; background:#00000055;
                display:flex;justify-content:space-between;align-items:center;">
        <h3 style="margin:0;">📄 Export PDF – Auto-CIDR</h3>
        <button onclick="document.getElementById('aidPdfPopup').style.display='none'"
                style="background:red;color:white;border:none;padding:5px 10px;border-radius:6px;">
            ✖
        </button>
    </div>
    <iframe id="aidPdfFrame"
            style="width:100%;height:690px;background:white;border:none;"></iframe>
</div>
<script>
function toggleAidCalc() {
    let b = document.getElementById("aidCalcBlock");
    b.style.display = (b.style.display === "none") ? "block" : "none";
}
function ipToBinRaw(ip){
    return ip.split('.').map(o=>Number(o).toString(2).padStart(8,'0')).join('');
}
function binToIp(bin){
    return [
        parseInt(bin.substr(0,8),2),
        parseInt(bin.substr(8,8),2),
        parseInt(bin.substr(16,8),2),
        parseInt(bin.substr(24,8),2)
    ].join('.');
}
function cidrToMask(c){
    let m=[];
    for(let i=0;i<4;i++){
        let bits=Math.min(8,Math.max(0,c - i*8));
        m[i]= bits>0 ? 256 - Math.pow(2,8-bits) : 0;
    }
    return m;
}
document.querySelector('.aid-btn1').addEventListener('click', ()=>{
    let base   = document.querySelector('.aid-base').value.trim();
    let needed = parseInt(document.querySelector('.aid-needed').value.trim());
    let out    = document.querySelector('.aid-result1');
    if(isNaN(needed) || needed < 1){
        out.innerHTML = "⚠️ Valeur incorrecte.";
        out.style.display="block";
        return;
    }
    let hostBits = Math.ceil(Math.log2(needed + 2));
    let cidr = 32 - hostBits;
    if(cidr < 0) cidr = 0;
    let mask = cidrToMask(cidr);
    let total  = Math.pow(2, 32-cidr);
    let usable = total - 2;
    let baseBin = ipToBinRaw(base);
    let maskBin = "1".repeat(cidr) + "0".repeat(32-cidr);
    let netBin = [...baseBin].map((b,i)=> (b==="1" && maskBin[i]==="1") ? "1":"0").join('');
    let bcBin  = netBin.substring(0,cidr) + "1".repeat(32-cidr);
    let first = cidr>=31 ? "-" :
                binToIp((parseInt(netBin,2)+1).toString(2).padStart(32,'0'));
    let last  = cidr>=31 ? "-" :
                binToIp((parseInt(bcBin,2)-1).toString(2).padStart(32,'0'));
    out.innerHTML = `
        <p><strong>Sous-réseau optimal :</strong> ${binToIp(netBin)}/${cidr}</p>
        <p><strong>Masque :</strong> ${mask.join('.')}</p>
        <p><strong>Total IP :</strong> ${total}</p>
        <p><strong>IP utilisables :</strong> ${usable}</p>
        <p><strong>1ère IP :</strong> ${first}</p>
        <p><strong>Dernière IP :</strong> ${last}</p>
        <p><strong>Broadcast :</strong> ${binToIp(bcBin)}</p>
    `;
    out.style.display="block";
    document.querySelector('.aid-export-pdf').style.display="block";
});
document.querySelector('.aid-export-pdf').addEventListener('click', ()=>{
    let html = `
        <html><head>
            <style>
                body { font-family: Arial; padding:20px; }
                h2 { border-bottom:2px solid #000; padding-bottom:5px; }
                p  { margin:4px 0; }
            </style>
        </head><body>
            <h2>Auto-CIDR – Résultat</h2>
            ${document.querySelector('.aid-result1').innerHTML}
        </body></html>
    `;
    let frame = document.getElementById("aidPdfFrame");
    frame.srcdoc = html;
    document.getElementById("aidPdfPopup").style.display="block";
    frame.onload = () => frame.contentWindow.print();
});
</script>
<div class="calc-tile" onclick="toggleVlsmCalc()">
    <h3>📘 Générateur VLSM Complet</h3>
    <p class="tile-desc">Calcul automatique des sous-réseaux</p>
</div>
<style>
.calc-tile {
    background:#2a2a2a;
    padding:7px;
    border-radius:5px;
    border:1px solid #444;
    cursor:pointer;
    margin-bottom:12px;
}
.calc-tile h3 { margin:0; font-size:16px; }
.tile-desc { margin:2px 0 0 0; opacity:0.7; font-size:13px; }
</style>
<div id="vlsmCalcBlock" 
     style="display:none;background:#1f1f1f;border:1px solid #444;
     padding:15px;border-radius:8px;margin-bottom:20px;">
    <label>Adresse de base</label>
    <input type="text" class="vlsm-base"
           value="10.10.0.0"
           style="width:100%;margin-bottom:10px;background:#333;color:white;
                  border:1px solid #555;border-radius:4px;padding:6px;">
    <label>Liste des tailles de sous-réseaux (séparés par virgules)</label>
    <input type="text" class="vlsm-list"
           placeholder="ex : 500,200,50,20"
           style="width:100%;margin-bottom:12px;background:#333;color:white;
                  border:1px solid #555;border-radius:4px;padding:6px;">
    <button class="vlsm-generate"
            style="width:100%;padding:8px;background:var(--primary-color,#56b6c2);
                   border:none;color:white;border-radius:4px;margin-bottom:12px;">
        Générer le plan VLSM
    </button>
    <button class="vlsm-export-pdf"
            style="width:100%;padding:8px;background:var(--primary-color,#56b6c2);
                   border:none;color:white;border-radius:4px;display:none;">
        📄 Exporter en PDF
    </button>
    <div class="vlsm-output"
         style="display:none;margin-top:10px;background:#2e2e2e;
                padding:12px;border-radius:6px;"></div>
</div>
<div id="vlsmPdfPopup"
     style="display:none;position:absolute;top:80px;left:80px;
     width:780px;height:800px;background:#1f1f1f;
     border:2px solid var(--primary-color);border-radius:10px;
     overflow:hidden;z-index:10000;">
    <div style="padding:8px;background:#00000055;
                display:flex;justify-content:space-between;align-items:center;">
        <h3 style="margin:0;">📄 Export PDF – Plan VLSM</h3>
        <button onclick="document.getElementById('vlsmPdfPopup').style.display='none'"
                style="background:red;color:white;border:none;padding:5px 10px;border-radius:6px;">
            ✖
        </button>
    </div>
    <iframe id="vlsmPdfFrame"
            style="width:100%;height:720px;background:white;border:none;"></iframe>
</div>
<script>
function toggleVlsmCalc() {
    let b = document.getElementById("vlsmCalcBlock");
    b.style.display = (b.style.display === "none") ? "block" : "none";
}
function ipToBinRaw(ip){
    return ip.split('.').map(o=>Number(o).toString(2).padStart(8,'0')).join('');
}
function binRawToIp(bin){
    bin = bin.padStart(32,'0');
    return [
        parseInt(bin.substr(0,8),2),
        parseInt(bin.substr(8,8),2),
        parseInt(bin.substr(16,8),2),
        parseInt(bin.substr(24,8),2)
    ].join('.');
}
function cidrToMask(c){
    let m=[];
    for(let i=0;i<4;i++){
        let bits=Math.min(8,Math.max(0,c - i*8));
        m[i] = bits>0 ? (256 - Math.pow(2,8-bits)) : 0;
    }
    return m;
}
document.querySelector('.vlsm-generate').addEventListener('click', ()=>{
    let base  = document.querySelector('.vlsm-base').value.trim();
    let sizes = document.querySelector('.vlsm-list').value.trim()
                .split(',')
                .map(v=>parseInt(v.trim()))
                .filter(v=>!isNaN(v) && v>0);
    let out = document.querySelector('.vlsm-output');
    if(sizes.length === 0){
        out.innerHTML = "⚠️ Format incorrect. Exemple : 500,200,50,20";
        out.style.display="block";
        return;
    }
    sizes.sort((a,b)=>b-a);
    let baseBin = ipToBinRaw(base);
    let currentBin = parseInt(baseBin,2);
    let html = `<h3>📘 Plan d’adressage VLSM</h3>`;
    sizes.forEach((needed, idx)=>{
        let hostBits = Math.ceil(Math.log2(needed+2));
        let cidr = 32 - hostBits;
        if(cidr < 0) cidr = 0;
        let mask  = cidrToMask(cidr);
        let total = Math.pow(2, 32-cidr);
        let aligned = currentBin & (~(total-1));
        let netBin  = aligned.toString(2).padStart(32,'0');
        let bcBin   = (aligned+total-1).toString(2).padStart(32,'0');
        let first = cidr>=31 ? "-" : binRawToIp((aligned+1).toString(2));
        let last  = cidr>=31 ? "-" : binRawToIp((aligned+total-2).toString(2));
        html += `
            <div class="vlsm-block" style="
                padding:10px;border:1px solid #666;border-radius:6px;margin-bottom:12px;">
                <p><strong>Bloc ${idx+1}</strong></p>
                <p>Sous-réseau : <strong>${binRawToIp(netBin)}/${cidr}</strong></p>
                <p>Masque : ${mask.join('.')}</p>
                <p>Plage : ${first} → ${last}</p>
                <p>Broadcast : ${binRawToIp(bcBin)}</p>
                <p>Besoin demandé : <strong>${needed} IP</strong></p>
                <p>Capacité fournie : <strong>${total}</strong></p>
            </div>
        `;
        currentBin = aligned + total;
    });
    out.innerHTML = html;
    out.style.display = "block";
    document.querySelector('.vlsm-export-pdf').style.display="block";
});
document.querySelector('.vlsm-export-pdf').addEventListener('click', ()=>{
    let html = `
        <html><head>
            <style>
                body { font-family:Arial; padding:20px; }
                h2 { border-bottom:2px solid #000; padding-bottom:5px; }
                p  { margin:5px 0; }
            </style>
        </head><body>
            <h2>📘 Plan VLSM</h2>
            ${document.querySelector('.vlsm-output').innerHTML}
        </body></html>
    `;
    let frame = document.getElementById("vlsmPdfFrame");
    frame.srcdoc = html;
    document.getElementById("vlsmPdfPopup").style.display="block";
    frame.onload = () => frame.contentWindow.print();
});
</script>
<div class="calc-tile" onclick="toggleIPv6()">
    <h3>🧬 Calculateur IPv6 Complet</h3>
    <p class="tile-desc">Analyse, compression, sous-réseaux et validation</p>
</div>
<div id="ipv6-block" style="display:none; margin-bottom:25px;">
    <div class="ipv6-tabs">
        <button onclick="showIPv6Tab('analyse')" class="tab ipv6-active">Analyse</button>
        <button onclick="showIPv6Tab('compress')" class="tab">Compression</button>
        <button onclick="showIPv6Tab('expand')" class="tab">Décompression</button>
        <button onclick="showIPv6Tab('subnet')" class="tab">Sous-réseaux</button>
        <button onclick="showIPv6Tab('valid')" class="tab">Validation</button>
        <button onclick="showIPv6Tab('guide')" class="tab">❓ Procédure</button>
    </div>
    <div id="ipv6-analyse" class="ipv6-tabcontent" style="display:block;">
        <label>Adresse IPv6</label>
        <input type="text" class="ipv6-ip" value="2001:db8:abcd:0012::1">
        <label>Prefix (CIDR)</label>
        <input type="number" class="ipv6-cidr" value="64">
        <button class="ipv6-btn" onclick="ipv6Analyse()">Analyser l'IPv6</button>
        <button class="ipv6-export" style="display:none;" onclick="ipv6ExportTXT()">📤 Export TXT</button>
        <button class="ipv6-export-pdf" style="display:none;" onclick="ipv6ExportPDF()">📄 Export PDF</button>
        <div class="ipv6-result" style="display:none; margin-top:15px;"></div>
    </div>
    <div id="ipv6-compress" class="ipv6-tabcontent">
        <label>IPv6 à compresser</label>
        <input type="text" class="ipv6-cin" value="2001:0db8:0000:0000:0000:ff00:0042:8329">
        <button class="ipv6-btn" onclick="ipv6Compress()">Compresser</button>
        <div class="ipv6-result-compress" style="margin-top:15px;"></div>
    </div>
    <div id="ipv6-expand" class="ipv6-tabcontent">
        <label>IPv6 à décompresser</label>
        <input type="text" class="ipv6-ein" value="2001:db8::1">
        <button class="ipv6-btn" onclick="ipv6Expand()">Décompresser</button>
        <div class="ipv6-result-expand" style="margin-top:15px;"></div>
    </div>
    <div id="ipv6-subnet" class="ipv6-tabcontent">
        <label>IPv6 + CIDR</label>
        <input type="text" class="ipv6-snip" value="2001:db8::/48">
        <label>Nouveau prefix</label>
        <input type="number" class="ipv6-newcidr" value="64">
        <button class="ipv6-btn" onclick="ipv6MakeSubnets()">Découper</button>
        <div class="ipv6-result-subnet" style="margin-top:15px;"></div>
    </div>
    <div id="ipv6-valid" class="ipv6-tabcontent">
        <label>IPv6 à vérifier</label>
        <input type="text" class="ipv6-vin" value="2001:db8::ff">
        <button class="ipv6-btn" onclick="ipv6Validate()">Vérifier</button>
        <div class="ipv6-result-valid" style="margin-top:15px;"></div>
    </div>
    <div id="ipv6-guide" class="ipv6-tabcontent">
        <h3>📘 Procédure détaillée – Calcul IPv6</h3>
        <p><strong>1️⃣ Qu’est-ce qu’une adresse IPv6 ?</strong></p>
        <p>Une adresse IPv6 contient 128 bits, découpés en 8 blocs de 16 bits (hexadécimal).</p>
        <pre>Exemple : 2001:0db8:0000:0000:0000:ff00:0042:8329</pre>
        <p><strong>2️⃣ Compression IPv6 :</strong></p>
        <ul>
        <li>Supprimer les zéros à gauche → 0db8 → db8</li>
        <li>Remplacer les groupes 0000 consécutifs par "::"</li>
        </ul>
        <pre>2001:db8::ff00:42:8329</pre>
        <p><strong>3️⃣ Décompression IPv6 :</strong></p>
        <pre>2001:db8::1 → 2001:0db8:0000:0000:0000:0000:0000:0001</pre>
        <p><strong>4️⃣ CIDR IPv6 :</strong></p>
        <p>/64 = réseau / interface, /48 = réseau d’organisation.</p>
        <p><strong>5️⃣ Découpage en sous-réseaux :</strong></p>
        <pre>2001:db8::/48 → /64 = 65 536 sous-réseaux</pre>
        <p><strong>6️⃣ Validation IPv6 :</strong></p>
        <p>Vérifie format, hex, double "::" correct, longueur, etc.</p>
    </div>
</div>
<style>
.calc-tile {
    background:#2a2a2a;
    padding:12px;
    border-radius:8px;
    border:1px solid #444;
    cursor:pointer;
    margin-bottom:18px;
}
.tile-desc { opacity:0.7; font-size:13px; }
.ipv6-tabs {
    display:flex;
    gap:6px;
    margin-bottom:12px;
}
.ipv6-tabs .tab {
    background:#333;
    color:white;
    padding:6px 10px;
    border-radius:6px;
    border:1px solid #444;
    cursor:pointer;
}
.ipv6-active {
    background:var(--primary-color);
}
.ipv6-tabcontent {
    display:none;
    background:#2a2a2a;
    padding:12px;
    border-radius:8px;
    border:1px solid #444;
}
.ipv6-btn {
    width:100%;
    padding:8px;
    background:var(--primary-color);
    border:none;
    color:white;
    border-radius:6px;
    margin-top:10px;
}
.ipv6-result,
.ipv6-result-compress,
.ipv6-result-expand,
.ipv6-result-subnet,
.ipv6-result-valid {
    background:#222;
    padding:10px;
    border-radius:6px;
    border:1px solid #333;
}
.ipv6-export,
.ipv6-export-pdf {
    width:100%;
    padding:8px;
    margin-top:10px;
    background:var(--primary-color);
    border:none;
    color:white;
    border-radius:5px;
    cursor:pointer;
}
input[type="text"], input[type="number"] {
    width:100%;
    padding:6px;
    background:#333;
    color:white;
    border:1px solid #555;
    border-radius:5px;
    margin-bottom:10px;
}
</style>
<script>
function toggleIPv6(){
    let b = document.getElementById("ipv6-block");
    b.style.display = (b.style.display==="none") ? "block" : "none";
}
function showIPv6Tab(tab){
    document.querySelectorAll('.ipv6-tabcontent').forEach(e=>e.style.display="none");
    document.querySelectorAll('.ipv6-tabs .tab').forEach(e=>e.classList.remove("ipv6-active"));
    document.getElementById("ipv6-"+tab).style.display="block";
    event.target.classList.add("ipv6-active");
}
function ipv6Analyse(){
    const ip  = document.querySelector('.ipv6-ip').value.trim();
    const cidr = parseInt(document.querySelector('.ipv6-cidr').value.trim());
    if(isNaN(cidr) || cidr<0 || cidr>128){
        alert("CIDR invalide");
        return;
    }
    const blocks = ipv6ExpandExact(ip).split(':');
    const network = ipv6Network(ip, cidr);
    const rangeStart = network;
    const rangeEnd = ipv6Last(network, cidr);
    let html = `
        <p><strong>IPv6 expandée :</strong><br>${ipv6ExpandExact(ip)}</p>
        <p><strong>Compression :</strong><br>${ipv6CompressDirect(ip)}</p>
        <p><strong>Réseau /${cidr} :</strong><br>${network}</p>
        <p><strong>Dernière IP :</strong><br>${rangeEnd}</p>
    `;
    document.querySelector('.ipv6-result').innerHTML = html;
    document.querySelector('.ipv6-result').style.display="block";
    document.querySelector('.ipv6-export').style.display="block";
    document.querySelector('.ipv6-export-pdf').style.display="block";
}
function ipv6ExpandExact(ip){
    let blocks = ip.split('::');
    if(blocks.length === 2){
        const left  = blocks[0].split(':').filter(Boolean);
        const right = blocks[1].split(':').filter(Boolean);
        const missing = 8 - (left.length + right.length);
        return [
            ...left.map(b=>b.padStart(4,'0')),
            ...Array(missing).fill('0000'),
            ...right.map(b=>b.padStart(4,'0'))
        ].join(':');
    }
    return ip.split(':').map(b=>b.padStart(4,'0')).join(':');
}
function ipv6CompressDirect(ip){
    let full = ipv6ExpandExact(ip).replace(/(^|:)0{1,3}/g,"$1");
    return full.replace(/(:0)+:/, "::");
}
function ipv6Network(ip,cidr){
    let bits = ipv6ExpandExact(ip).split(':')
        .map(h=>parseInt(h,16).toString(2).padStart(16,'0'))
        .join('');
    let net = bits.slice(0,cidr).padEnd(128,'0');
    return net.match(/.{16}/g)
              .map(b=>parseInt(b,2).toString(16).padStart(4,'0'))
              .join(':');
}
function ipv6Last(net,cidr){
    let bits = net.split(':')
        .map(h=>parseInt(h,16).toString(2).padStart(16,'0'))
        .join('');
    let end = bits.slice(0,cidr).padEnd(128,'1');
    return end.match(/.{16}/g)
              .map(b=>parseInt(b,2).toString(16).padStart(4,'0'))
              .join(':');
}
function ipv6Compress(){
    let ip = document.querySelector('.ipv6-cin').value.trim();
    document.querySelector('.ipv6-result-compress').innerHTML =
        "<p><strong>IPv6 compressée :</strong><br>"+ipv6CompressDirect(ip)+"</p>";
}
function ipv6Expand(){
    let ip = document.querySelector('.ipv6-ein').value.trim();
    document.querySelector('.ipv6-result-expand').innerHTML =
        "<p><strong>IPv6 expandée :</strong><br>"+ipv6ExpandExact(ip)+"</p>";
}
function ipv6MakeSubnets(){
    let ipcidr = document.querySelector('.ipv6-snip').value.trim();
    let newc = parseInt(document.querySelector('.ipv6-newcidr').value.trim());
    let [ip,c] = ipcidr.split('/');
    c = parseInt(c);
    if(newc < c){
        document.querySelector('.ipv6-result-subnet').innerHTML = "Impossible : prefix plus petit.";
        return;
    }
    let base = ipv6Network(ip,c);
    let diff = newc - c;
    let count = 2 ** diff;
    let html = "<h4>Nombre de sous-réseaux : "+count+"</h4>";
    for(let i=0;i<count;i++){
        let b = (BigInt("0x"+base.replace(/:/g,'')) + (BigInt(i)<<BigInt(128-newc))).toString(16).padStart(32,'0');
        let blocks = b.match(/.{4}/g).join(':');
        html += `<p>${blocks}/${newc}</p>`;
    }
    document.querySelector('.ipv6-result-subnet').innerHTML = html;
}
function ipv6Validate(){
    let ip = document.querySelector('.ipv6-vin').value.trim();
    let ok = /^(?:[0-9A-F]{0,4}:){2,7}[0-9A-F]{0,4}$/i.test(ip) || ip.includes("::");
    document.querySelector('.ipv6-result-valid').innerHTML =
        ok ? "<p>✔️ IPv6 valide</p>" : "<p>❌ IPv6 invalide</p>";
}
function ipv6ExportTXT(){
    let text = document.querySelector('.ipv6-result').innerText;
    let blob = new Blob([text],{type:"text/plain"});
    let url = URL.createObjectURL(blob);
    let a = document.createElement("a");
    a.href=url; a.download="ipv6_result.txt"; a.click();
}
function ipv6ExportPDF(){
    let html = `
        <html>
        <head>
            <style>
                body { font-family: Arial; padding:20px; }
                h2 { border-bottom:2px solid #000; padding-bottom:5px; }
                p  { margin:5px 0; }
            </style>
        </head>
        <body>
            <h2>Analyse IPv6</h2>
            ${document.querySelector('.ipv6-result').innerHTML}
        </body>
        </html>
    `;
    let frame = document.createElement("iframe");
    frame.style.position = "absolute";
    frame.style.width = "0";
    frame.style.height = "0";
    frame.style.border = "none";
    document.body.appendChild(frame);
    frame.srcdoc = html;
    frame.onload = () => {
        frame.contentWindow.print();
        setTimeout(()=> frame.remove(), 1000);
    };
}
</script>