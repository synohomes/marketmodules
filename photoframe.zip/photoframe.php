<?php
if (session_status()===PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
if (!$email) { echo "<div style='padding:10px;color:#f66'>⛔ Non connecté</div>"; return; }
$baseUser = __DIR__ . "/../../users/profiles/$email/";
$photosDir = $baseUser . "PHOTOS/";
@mkdir($photosDir, 0775, true);
$cfgFile = $baseUser . "photoframe.json";
$cfg = [
  'mode' => 'single',           // single | album
  'image' => '',                // chemin relatif depuis PHOTOS/ ou URL absolue
  'album' => '',                // nom de dossier sous PHOTOS/
  'interval_sec' => 6,
  'shuffle' => true,
  'fit' => 'cover',             // cover | contain
  'border' => 'soft',           // none | soft | rounded
  'caption' => true,            // afficher nom fichier
  'autoplay' => true
];
if (file_exists($cfgFile)) {
  $read = json_decode(file_get_contents($cfgFile), true);
  if (is_array($read)) $cfg = array_merge($cfg, $read);
}
function collectImagesFromAlbum($dir){
  $out = [];
  if (!is_dir($dir)) return $out;
  $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS));
  foreach ($rii as $f){
    if (!$f->isFile()) continue;
    $ext = strtolower(pathinfo($f->getFilename(), PATHINFO_EXTENSION));
    if (in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
      $out[] = $f->getPathname();
    }
  }
  return $out;
}
$images = [];
$caption = '';
if ($cfg['mode']==='single') {
  $img = trim($cfg['image']);
  if ($img!=='') {
    if (preg_match('~^https?://~i', $img)) {
      $images[] = $img;
      $caption = basename(parse_url($img, PHP_URL_PATH));
    } else {
      $local = realpath($photosDir . $img);
      if ($local && str_starts_with($local, realpath($photosDir))) {
        $images[] = $local;
        $caption = basename($local);
      }
    }
  }
} else {
  $album = trim($cfg['album']);
  if ($album!=='') {
    $albumPath = $photosDir . $album . '/';
    $images = collectImagesFromAlbum($albumPath);
    // Pour sécurité UI: trie par nom si pas shuffle
    if (!$cfg['shuffle']) sort($images, SORT_NATURAL|SORT_FLAG_CASE);
    $caption = $album;
  }
}
if (empty($images)) {
  echo "<div class='pf-placeholder' style='padding:12px;opacity:.8'>
    📷 <b>PhotoFrame</b> — aucune image trouvée.<br>Configurez le module dans <i>profile_edit</i> (album ou photo unique).
  </div>";
  return;
}
function toPublicUrl($absPath){
  $root = realpath(__DIR__ . '/../../'); // domydesk/
  $real = realpath($absPath);
  if ($root && $real && str_starts_with($real, $root)) {
    $rel = str_replace('\\','/', substr($real, strlen($root)+1));
    return $rel; // ex: users/profiles/...
  }
  return $absPath;
}

$publicImages = array_map(function($p){
  return preg_match('~^https?://~i',$p) ? $p : toPublicUrl($p);
}, $images);

$instanceId = 'pf_' . substr(md5($email.microtime(true).rand()),0,8);
$fit = $cfg['fit']==='contain' ? 'contain' : 'cover';
$border = $cfg['border'];
$interval = max(2, intval($cfg['interval_sec']));
$autoplay = !empty($cfg['autoplay']);
$shuffle = !empty($cfg['shuffle']);
$showCaption = !empty($cfg['caption']);
?>
<div class="photoframe" id="<?= $instanceId ?>" style="width:100%;height:100%;position:relative;overflow:hidden;">
  <div class="pf-inner" style="position:absolute;inset:8px;display:flex;align-items:center;justify-content:center;border-radius:16px;">
    <img class="pf-img" alt="Photo" draggable="false" style="max-width:100%;max-height:100%;object-fit: <?= htmlspecialchars($fit) ?>;border-radius:
      <?= $border==='none' ? '0' : ($border==='rounded' ? '24px' : '12px') ?>; box-shadow: <?= $border==='none' ? 'none' : '0 6px 30px rgba(0,0,0,.35)' ?>;">
    <?php if ($showCaption): ?>
      <div class="pf-caption" style="position:absolute;left:12px;bottom:10px;padding:4px 8px;background:rgba(0,0,0,.45);backdrop-filter:blur(2px);     border-radius:8px;font-size:.9em;color:#fff;max-width:90%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"></div>
    <?php endif; ?>
    <div class="pf-controls" style="position:absolute;right:10px;bottom:10px;display:flex;gap:6px;opacity:.85;">
      <button class="pf-btn pf-prev" title="Précédent" style="padding:6px 10px;border-radius:10px;border:0;cursor:pointer;">⟵</button>
      <button class="pf-btn pf-play" title="Lecture/Pause" style="padding:6px 10px;border-radius:10px;border:0;cursor:pointer;">⏸</button>
      <button class="pf-btn pf-next" title="Suivant" style="padding:6px 10px;border-radius:10px;border:0;cursor:pointer;">⟶</button>
    </div>
  </div>
</div>
<script>
(function(){
  const root = document.getElementById("<?= $instanceId ?>");
  const img  = root.querySelector('.pf-img');
  const cap  = root.querySelector('.pf-caption');
  const btnPrev = root.querySelector('.pf-prev');
  const btnPlay = root.querySelector('.pf-play');
  const btnNext = root.querySelector('.pf-next');
  const imgs = <?= json_encode($publicImages, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) ?>;
  const baseCaption = <?= json_encode($caption, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) ?>;
  let order = imgs.map((_,i)=>i);
  const shuffle = <?= $shuffle ? 'true' : 'false' ?>;
  if (shuffle) {
    for (let i=order.length-1;i>0;i--){
      const j = Math.floor(Math.random()*(i+1)); [order[i],order[j]] = [order[j],order[i]];
    }
  }
  let idx = 0;
  let playing = <?= $autoplay ? 'true' : 'false' ?>;
  let timer = null;
  const INTERVAL = <?= $interval ?> * 1000;
  function filename(u){
    try {
      if (/^https?:\/\//i.test(u)) return decodeURIComponent(new URL(u).pathname.split('/').pop()||u);
    } catch(e){}
    const parts = u.split('/'); return parts[parts.length-1] || u;
  }
  function show(i){
    idx = (i+order.length)%order.length;
    const u = imgs[order[idx]];
    img.style.opacity = 0;
    const pre = new Image();
    pre.onload = () => {
      img.src = u;
      img.alt = filename(u);
      img.style.transition = 'opacity .35s';
      requestAnimationFrame(()=>{ img.style.opacity = 1; });
      if (cap) cap.textContent = baseCaption ? (baseCaption + ' — ' + filename(u)) : filename(u);
    };
    pre.src = u;
  }
  function next(){ show(idx+1); }
  function prev(){ show(idx-1); }
  function play(){
    if (timer) clearInterval(timer);
    timer = setInterval(next, INTERVAL);
    playing = true;
    if (btnPlay) btnPlay.textContent = '⏸';
  }
  function pause(){
    if (timer) clearInterval(timer);
    timer = null;
    playing = false;
    if (btnPlay) btnPlay.textContent = '▶';
  }
  if (btnPrev) btnPrev.addEventListener('click', ()=>{ pause(); prev(); });
  if (btnNext) btnNext.addEventListener('click', ()=>{ pause(); next(); });
  if (btnPlay) btnPlay.addEventListener('click', ()=>{ playing ? pause() : play(); });
  root.addEventListener('dblclick', ()=>{
    const el = root.querySelector('.pf-inner');
    if (!document.fullscreenElement) { el.requestFullscreen?.(); } else { document.exitFullscreen?.(); }
  });
  let sx=0, sy=0;
  root.addEventListener('touchstart', e=>{ const t=e.touches[0]; sx=t.clientX; sy=t.clientY; }, {passive:true});
  root.addEventListener('touchend', e=>{
    const t=e.changedTouches[0]; const dx=t.clientX-sx, dy=t.clientY-sy;
    if (Math.abs(dx)>40 && Math.abs(dx)>Math.abs(dy)){ pause(); (dx<0?next:prev)(); }
  }, {passive:true});
  show(0);
  if (playing) play();
})();
</script>
