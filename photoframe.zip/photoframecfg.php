<?php
if (session_status()===PHP_SESSION_NONE) session_start();
$email = $_SESSION['user']['email'] ?? '';
$notLogged = empty($email);
$baseUser  = $email ? (__DIR__ . "/../../users/profiles/$email/") : null;
if ($email) @mkdir($baseUser, 0775, true);
$photosDir = $email ? ($baseUser . "PHOTOS/") : null;
if ($email) @mkdir($photosDir, 0775, true);
$cfgFile   = $email ? ($baseUser . "photoframe.json") : null;
function readJson($f){ return ($f && file_exists($f)) ? (json_decode(file_get_contents($f), true) ?: []) : []; }
function writeJson($f,$arr){ if($f) file_put_contents($f, json_encode($arr, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)); }
$cfg = [
  'mode'=>'single','image'=>'','album'=>'','interval_sec'=>6,'shuffle'=>true,
  'fit'=>'cover','border'=>'soft','caption'=>true,'autoplay'=>true
];
if ($cfgFile && file_exists($cfgFile)) {
  $r = json_decode(file_get_contents($cfgFile), true);
  if (is_array($r)) $cfg = array_merge($cfg, $r);
}
function listAlbums($photosDir){
  $out=[];
  if (!is_dir($photosDir)) return $out;
  foreach (scandir($photosDir) as $d){
    if ($d==='.'||$d==='..') continue;
    if (is_dir($photosDir.$d)) $out[]=$d;
  }
  sort($out, SORT_NATURAL|SORT_FLAG_CASE);
  return $out;
}
function listAllImages($photosDir){
  $res=[];
  if (!is_dir($photosDir)) return $res;
  $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($photosDir, FilesystemIterator::SKIP_DOTS));
  foreach ($rii as $f){
    if (!$f->isFile()) continue;
    $ext=strtolower(pathinfo($f->getFilename(), PATHINFO_EXTENSION));
    if (in_array($ext,['jpg','jpeg','png','gif','webp'])){
      $abs=$f->getPathname();
      $rel=substr($abs, strlen($photosDir)); // relatif depuis PHOTOS/
      $res[]=$rel;
    }
  }
  sort($res, SORT_NATURAL|SORT_FLAG_CASE);
  return $res;
}
function albumStats($photosDir, $album){
  $dir = rtrim($photosDir,'/\\').DIRECTORY_SEPARATOR.$album.DIRECTORY_SEPARATOR;
  $count=0; $first=null;
  if (is_dir($dir)){
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS));
    foreach($it as $f){
      if(!$f->isFile()) continue;
      $ext = strtolower(pathinfo($f->getFilename(), PATHINFO_EXTENSION));
      if (in_array($ext,['jpg','jpeg','png','gif','webp'])){
        $count++;
        if(!$first) $first = $f->getPathname();
      }
    }
  }
  return [$count, $first];
}
function delTreeSafe($target, $base){
  $t = realpath($target);
  $b = realpath($base);
  if(!$t || !$b) return false;
  // sécurité : le dossier à supprimer DOIT être sous $base
  if (stripos($t, $b) !== 0) return false;

  $it = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($t, FilesystemIterator::SKIP_DOTS),
    RecursiveIteratorIterator::CHILD_FIRST
  );
  foreach ($it as $file) {
    if ($file->isDir()) @rmdir($file->getPathname());
    else @unlink($file->getPathname());
  }
  return @rmdir($t);
}
function absToPublicUrl($abs, $inProfile){
  $root = realpath(__DIR__ . '/../../'); // répertoire "domydesk/"
  $real = $abs ? realpath($abs) : null;
  if ($root && $real && stripos($real, $root) === 0) {
    $rel = str_replace('\\','/', substr($real, strlen($root)+1)); // ex: users/profiles/...
    $prefix = $inProfile ? '' : '../../';
    return $prefix . $rel;
  }
  return null;
}
$inProfile = (strpos($_SERVER['SCRIPT_NAME'] ?? '', '/modules/photoframe/') === false);
$action = $inProfile ? '?module=photoframe' : '';
$msgs = [];
if ($_SERVER['REQUEST_METHOD']==='POST' && !$notLogged) {
  $act = $_POST['pf_action'] ?? '';
  if ($act==='upload') {
    $alb = trim($_POST['album'] ?? '');
    if ($alb!=='') {
      $dest = $photosDir . $alb . '/';
      @mkdir($dest, 0775, true);
      $ok = 0; $err = 0;
      if (!empty($_FILES['files']['name']) && is_array($_FILES['files']['name'])) {
        for ($i=0;$i<count($_FILES['files']['name']);$i++){
          if ($_FILES['files']['error'][$i]===UPLOAD_ERR_OK) {
            $name = basename($_FILES['files']['name'][$i]);
            $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if (in_array($ext,['jpg','jpeg','png','gif','webp'])) {
              @move_uploaded_file($_FILES['files']['tmp_name'][$i], $dest.$name) ? $ok++ : $err++;
            } else { $err++; }
          } else { $err++; }
        }
      }
      $msgs[] = ['ok', "Upload terminé : $ok ok, $err erreurs."];
    } else {
      $msgs[] = ['err', 'Album manquant.'];
    }
  }
  if ($act==='save') {
    $new = $cfg;
    $new['mode'] = ($_POST['mode']??'single')==='album'?'album':'single';
    if ($new['mode']==='single'){
      $loc = trim($_POST['image_local'] ?? '');
      $url = trim($_POST['image_url'] ?? '');
      $new['image'] = $url !== '' ? $url : $loc;
      $new['album'] = '';
    } else {
      $new['album'] = trim($_POST['album'] ?? '');
      $new['image'] = '';
    }
    $new['interval_sec'] = max(2, intval($_POST['interval_sec'] ?? 6));
    $new['shuffle']  = !empty($_POST['shuffle']);
    $new['autoplay'] = !empty($_POST['autoplay']);
    $new['caption']  = !empty($_POST['caption']);
    $new['fit']      = in_array($_POST['fit']??'cover', ['cover','contain']) ? $_POST['fit'] : 'cover';
    $new['border']   = in_array($_POST['border']??'soft', ['none','soft','rounded']) ? $_POST['border'] : 'soft';
    writeJson($cfgFile, $new);
    $cfg = $new;
    $msgs[] = ['ok', '✅ Paramètres enregistrés.'];
  }
  if ($act==='delete_album') {
    $alb = trim($_POST['album_name'] ?? '');
    if ($alb===''){
      $msgs[] = ['err','Album manquant.'];
    } else {
      $target = $photosDir . $alb;
      if (!is_dir($target)) {
        $msgs[] = ['err','Album introuvable.'];
      } else {
        if (delTreeSafe($target, $photosDir)) {
          if (($cfg['album'] ?? '') === $alb) { $cfg['album']=''; writeJson($cfgFile, $cfg); }
          $msgs[] = ['ok',"🗑️ Album « $alb » supprimé avec ses images."];
        } else {
          $msgs[] = ['err',"Impossible de supprimer l’album « $alb » (droits ?)."];
        }
      }
    }
  }
}
$albums = !$notLogged ? listAlbums($photosDir) : [];
$allImgs= !$notLogged ? listAllImages($photosDir) : [];
?>
<div class="section" style="margin: 12px auto; max-width: 980px;">
  <h2 style="margin-top:0">📷 PhotoFrame — Configuration</h2>
  <?php foreach ($msgs as [$type,$txt]): ?>
    <div style="margin:8px 0;padding:8px;border-radius:8px;<?= $type==='ok'?'background:rgba(0,128,0,.25)':'background:rgba(255,0,0,.15)' ?>">
      <?= htmlspecialchars($txt) ?>
    </div>
  <?php endforeach; ?>
  <?php if ($notLogged): ?>
    <div style="color:#f66;padding:8px;border-radius:8px;background:rgba(255,0,0,.08)">⛔ Non connecté</div>
  <?php else: ?>
  <details>
    <summary><b>Ajouter des photos</b> (création d'album automatique)</summary>
    <form method="post" action="<?= $action ?>" enctype="multipart/form-data" style="margin-top:10px">
      <input type="hidden" name="pf_action" value="upload">
      <label>Nom de l'album :
        <input type="text" name="album" required placeholder="Famille, Vacances, ..."
               value="<?= htmlspecialchars($cfg['album'] ?: '') ?>">
      </label>
      <br><br>
      <label>Fichiers (jpg, png, gif, webp) :
        <input type="file" name="files[]" multiple accept=".jpg,.jpeg,.png,.gif,.webp">
      </label>
      <br><br>
      <button type="submit">Téléverser</button>
    </form>
  </details>
  <hr style="border:none;border-top:1px solid rgba(255,255,255,.12);margin:14px 0">
  <form method="post" action="<?= $action ?>">
    <input type="hidden" name="pf_action" value="save">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;align-items:start;">
      <div>
        <h3 style="margin:.2em 0">Mode</h3>
        <label><input type="radio" name="mode" value="single" <?= $cfg['mode']==='single'?'checked':'' ?>> Photo unique</label><br>
        <label><input type="radio" name="mode" value="album"  <?= $cfg['mode']==='album'?'checked':''  ?>> Album (diaporama)</label>
        <div style="margin-top:10px;padding:10px;border-radius:12px;background:rgba(0,0,0,.15)">
          <div id="singleFields" style="<?= $cfg['mode']==='single'?'':'display:none' ?>">
            <label>Choisir une image locale :
              <select name="image_local">
                <option value="">—</option>
                <?php foreach($allImgs as $rel): ?>
                  <option value="<?= htmlspecialchars($rel) ?>" <?= ($cfg['image'] && $cfg['image']===$rel)?'selected':'' ?>>
                    <?= htmlspecialchars($rel) ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </label>
            <div style="margin:6px 0;text-align:center">ou</div>
            <label>URL directe (https://...) :
              <input type="url" name="image_url" placeholder="https://exemple.com/photo.jpg"
                     value="<?= preg_match('~^https?://~i',$cfg['image']??'') ? htmlspecialchars($cfg['image']) : '' ?>">
            </label>
          </div>

          <div id="albumFields" style="<?= $cfg['mode']==='album'?'':'display:none' ?>">
            <label>Album :
              <select name="album">
                <option value="">—</option>
                <?php foreach($albums as $alb): ?>
                  <option value="<?= htmlspecialchars($alb) ?>" <?= ($cfg['album']===$alb)?'selected':'' ?>><?= htmlspecialchars($alb) ?></option>
                <?php endforeach; ?>
              </select>
            </label>
          </div>
        </div>
      </div>
      <div>
        <h3 style="margin:.2em 0">Affichage</h3>
        <label>Transition (sec) :
          <input type="number" name="interval_sec" min="2" max="120" step="1" value="<?= intval($cfg['interval_sec']) ?>">
        </label><br>
        <label><input type="checkbox" name="shuffle" <?= !empty($cfg['shuffle'])?'checked':'' ?>> Mélanger</label><br>
        <label><input type="checkbox" name="autoplay" <?= !empty($cfg['autoplay'])?'checked':'' ?>> Lecture auto</label><br>
        <label><input type="checkbox" name="caption"  <?= !empty($cfg['caption'])?'checked':''  ?>> Afficher la légende</label><br><br>
        <label>Ajustement :
          <select name="fit">
            <option value="cover"   <?= $cfg['fit']==='cover'?'selected':'' ?>>Remplir (cover)</option>
            <option value="contain" <?= $cfg['fit']==='contain'?'selected':'' ?>>Tout voir (contain)</option>
          </select>
        </label><br>
        <label>Bordure :
          <select name="border">
            <option value="soft"    <?= $cfg['border']==='soft'?'selected':'' ?>>Douce</option>
            <option value="rounded" <?= $cfg['border']==='rounded'?'selected':'' ?>>Très arrondie</option>
            <option value="none"    <?= $cfg['border']==='none'?'selected':'' ?>>Aucune</option>
          </select>
        </label>
      </div>
    </div>
    <div style="margin-top:14px">
      <button type="submit">Enregistrer</button>
    </div>
  </form>
  <hr style="border:none;border-top:1px solid rgba(255,255,255,.12);margin:18px 0">
  <h3 style="margin:8px 0">Mes albums</h3>

  <?php if (empty($albums)): ?>
    <div style="opacity:.8">Aucun album. Utilisez la section “Ajouter des photos” pour en créer un.</div>
  <?php else: ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:12px">
      <?php foreach($albums as $alb):
        [$count,$firstAbs] = albumStats($photosDir, $alb);
        $thumb = $firstAbs ? absToPublicUrl($firstAbs, $inProfile) : null;
      ?>
      <div style="background:rgba(0,0,0,.12);border:1px solid rgba(255,255,255,.12);border-radius:12px;padding:10px;display:flex;flex-direction:column;gap:8px">
        <div style="font-weight:600;display:flex;justify-content:space-between;align-items:center">
          <span title="<?= htmlspecialchars($alb) ?>"><?= htmlspecialchars($alb) ?></span>
          <span style="opacity:.8;font-size:.9em"><?= (int)$count ?> img</span>
        </div>
        <div style="aspect-ratio:16/10;border-radius:10px;overflow:hidden;background:#111;display:grid;place-items:center;">
          <?php if ($thumb): ?>
            <img src="<?= htmlspecialchars($thumb) ?>" alt="" style="width:100%;height:100%;object-fit:cover">
          <?php else: ?>
            <div style="opacity:.6">Aperçu indisponible</div>
          <?php endif; ?>
        </div>
        <form method="post" action="<?= $action ?>" onsubmit="return confirm('Supprimer l’album « <?= htmlspecialchars($alb) ?> » et toutes ses images ?');">
          <input type="hidden" name="pf_action" value="delete_album">
          <input type="hidden" name="album_name" value="<?= htmlspecialchars($alb) ?>">
          <button type="submit" style="width:100%;padding:8px;border-radius:8px;border:0;background:rgba(255,0,0,.2);cursor:pointer">Supprimer</button>
        </form>
      </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
  <script>
  (function(){
    const radios = document.querySelectorAll('input[name="mode"]');
    const s = document.getElementById('singleFields');
    const a = document.getElementById('albumFields');
    function refresh(){
      const v = document.querySelector('input[name="mode"]:checked')?.value || 'single';
      s.style.display = (v==='single') ? 'block':'none';
      a.style.display = (v==='album')  ? 'block':'none';
    }
    radios.forEach(r=>r.addEventListener('change', refresh));
  })();
  </script>
  <?php endif; ?>
</div>
